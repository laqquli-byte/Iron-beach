import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { CareerStats, DifficultyId, GameMode } from '../game/types';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

if (typeof window !== 'undefined') {
  void testConnection();
}

export interface CloudUserProfile {
  userId: string;
  displayName: string;
  email?: string;
  photoUrl?: string;
  xp: number;
  totalKills: number;
  totalHeadshots: number;
  totalExplosiveKills: number;
  bestScore: number;
  unlockedChapter: number;
  completedChallengeIds: string[];
  unlockedMedalIds: string[];
  collectedIntelIds: string[];
}

export interface LeaderboardRecord {
  userId: string;
  displayName: string;
  score: number;
  kills: number;
  headshots: number;
  rankLevel: number;
  rankTitle: string;
  difficulty: DifficultyId;
  gameMode: GameMode;
  wave: number;
  medalsCount: number;
  intelCount: number;
}

function clampInt(val: number, min: number, max: number): number {
  const safe = Number.isFinite(val) ? Math.floor(val) : min;
  return Math.max(min, Math.min(max, safe));
}

function sanitizeCallsign(name: string | null | undefined, email: string | null | undefined): string {
  const raw = (name || email?.split('@')[0] || 'Qartal-Operator').trim();
  return (raw.length > 0 ? raw : 'Qartal-Operator').slice(0, 60);
}

function sanitizeStringList(list: readonly string[], maxLen: number): string[] {
  const out: string[] = [];
  for (const item of list) {
    if (typeof item === 'string' && item.length > 0 && item.length <= 64 && !out.includes(item)) {
      out.push(item);
      if (out.length >= maxLen) break;
    }
  }
  return out;
}

export function subscribeAuth(cb: (user: User | null) => void): Unsubscribe {
  return onAuthStateChanged(auth, cb);
}

export async function signInWithGoogle(): Promise<User> {
  const res = await signInWithPopup(auth, googleProvider);
  return res.user;
}

export async function signOutGoogle(): Promise<void> {
  await signOut(auth);
}

export async function loadOrSyncCloudProfile(
  user: User,
  localCareer: CareerStats,
  localUnlockedChapter: number,
  localMedals: readonly string[],
  localIntel: readonly string[],
): Promise<CloudUserProfile> {
  const path = `users/${user.uid}`;
  const ref = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(ref);
    const displayName = sanitizeCallsign(user.displayName, user.email);

    if (!snap.exists()) {
      const payload = {
        userId: user.uid,
        displayName,
        ...(user.email ? { email: user.email.slice(0, 120) } : {}),
        ...(user.photoURL ? { photoUrl: user.photoURL.slice(0, 400) } : {}),
        xp: clampInt(localCareer.xp, 0, 10000000),
        totalKills: clampInt(localCareer.totalKills, 0, 1000000),
        totalHeadshots: clampInt(localCareer.totalHeadshots, 0, 1000000),
        totalExplosiveKills: clampInt(localCareer.totalExplosiveKills, 0, 1000000),
        bestScore: clampInt(localCareer.bestScore, 0, 10000000),
        unlockedChapter: clampInt(localUnlockedChapter, 1, 5),
        completedChallengeIds: sanitizeStringList(localCareer.completedChallengeIds, 20),
        unlockedMedalIds: sanitizeStringList(localMedals, 20),
        collectedIntelIds: sanitizeStringList(localIntel, 10),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await setDoc(ref, payload);
      return {
        userId: payload.userId,
        displayName: payload.displayName,
        email: payload.email,
        photoUrl: payload.photoUrl,
        xp: payload.xp,
        totalKills: payload.totalKills,
        totalHeadshots: payload.totalHeadshots,
        totalExplosiveKills: payload.totalExplosiveKills,
        bestScore: payload.bestScore,
        unlockedChapter: payload.unlockedChapter,
        completedChallengeIds: payload.completedChallengeIds,
        unlockedMedalIds: payload.unlockedMedalIds,
        collectedIntelIds: payload.collectedIntelIds,
      };
    }

    const remote = snap.data() as Partial<CloudUserProfile>;
    const mergedChallenges = sanitizeStringList(
      [...(remote.completedChallengeIds || []), ...localCareer.completedChallengeIds],
      20,
    );
    const mergedMedals = sanitizeStringList(
      [...(remote.unlockedMedalIds || []), ...localMedals],
      20,
    );
    const mergedIntel = sanitizeStringList(
      [...(remote.collectedIntelIds || []), ...localIntel],
      10,
    );

    const merged: CloudUserProfile = {
      userId: user.uid,
      displayName,
      ...(user.email ? { email: user.email.slice(0, 120) } : {}),
      ...(user.photoURL ? { photoUrl: user.photoURL.slice(0, 400) } : {}),
      xp: clampInt(Math.max(Number(remote.xp || 0), localCareer.xp), 0, 10000000),
      totalKills: clampInt(Math.max(Number(remote.totalKills || 0), localCareer.totalKills), 0, 1000000),
      totalHeadshots: clampInt(
        Math.max(Number(remote.totalHeadshots || 0), localCareer.totalHeadshots),
        0,
        1000000,
      ),
      totalExplosiveKills: clampInt(
        Math.max(Number(remote.totalExplosiveKills || 0), localCareer.totalExplosiveKills),
        0,
        1000000,
      ),
      bestScore: clampInt(Math.max(Number(remote.bestScore || 0), localCareer.bestScore), 0, 10000000),
      unlockedChapter: clampInt(
        Math.max(Number(remote.unlockedChapter || 1), localUnlockedChapter),
        1,
        5,
      ),
      completedChallengeIds: mergedChallenges,
      unlockedMedalIds: mergedMedals,
      collectedIntelIds: mergedIntel,
    };

    await updateDoc(ref, {
      displayName: merged.displayName,
      ...(merged.email ? { email: merged.email } : {}),
      ...(merged.photoUrl ? { photoUrl: merged.photoUrl } : {}),
      xp: merged.xp,
      totalKills: merged.totalKills,
      totalHeadshots: merged.totalHeadshots,
      totalExplosiveKills: merged.totalExplosiveKills,
      bestScore: merged.bestScore,
      unlockedChapter: merged.unlockedChapter,
      completedChallengeIds: merged.completedChallengeIds,
      unlockedMedalIds: merged.unlockedMedalIds,
      collectedIntelIds: merged.collectedIntelIds,
      updatedAt: serverTimestamp(),
    });

    return merged;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function submitLeaderboardEntry(
  user: User,
  entry: Omit<LeaderboardRecord, 'userId' | 'displayName'>,
): Promise<void> {
  if (!user.emailVerified) return;
  const path = `leaderboard/${user.uid}`;
  const ref = doc(db, 'leaderboard', user.uid);
  const displayName = sanitizeCallsign(user.displayName, user.email);

  try {
    const existingSnap = await getDoc(ref);
    const cleanScore = clampInt(entry.score, 0, 10000000);
    const cleanKills = clampInt(entry.kills, 0, 1000000);
    const cleanHeadshots = clampInt(entry.headshots, 0, 1000000);
    const cleanRankLevel = clampInt(entry.rankLevel, 1, 7);
    const cleanRankTitle = (entry.rankTitle || 'Əsgər').slice(0, 40);
    const cleanWave = clampInt(entry.wave, 1, 999);
    const cleanMedals = clampInt(entry.medalsCount, 0, 20);
    const cleanIntel = clampInt(entry.intelCount, 0, 5);

    if (!existingSnap.exists()) {
      await setDoc(ref, {
        userId: user.uid,
        displayName,
        score: cleanScore,
        kills: cleanKills,
        headshots: cleanHeadshots,
        rankLevel: cleanRankLevel,
        rankTitle: cleanRankTitle,
        difficulty: entry.difficulty,
        gameMode: entry.gameMode,
        wave: cleanWave,
        medalsCount: cleanMedals,
        intelCount: cleanIntel,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      const prev = existingSnap.data() as Partial<LeaderboardRecord>;
      const keepScore = Math.max(Number(prev.score || 0), cleanScore);
      const isBetter = cleanScore >= Number(prev.score || 0);
      await updateDoc(ref, {
        displayName,
        score: keepScore,
        kills: isBetter ? cleanKills : Math.max(Number(prev.kills || 0), cleanKills),
        headshots: isBetter ? cleanHeadshots : Math.max(Number(prev.headshots || 0), cleanHeadshots),
        rankLevel: Math.max(Number(prev.rankLevel || 1), cleanRankLevel),
        rankTitle: cleanRankTitle,
        difficulty: isBetter ? entry.difficulty : (prev.difficulty || entry.difficulty),
        gameMode: isBetter ? entry.gameMode : (prev.gameMode || entry.gameMode),
        wave: Math.max(Number(prev.wave || 1), cleanWave),
        medalsCount: Math.max(Number(prev.medalsCount || 0), cleanMedals),
        intelCount: Math.max(Number(prev.intelCount || 0), cleanIntel),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function fetchTopLeaderboard(maxEntries = 15): Promise<LeaderboardRecord[]> {
  const path = 'leaderboard';
  try {
    const q = query(
      collection(db, path),
      where('score', '>=', 0),
      orderBy('score', 'desc'),
      limit(clampInt(maxEntries, 1, 50)),
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as LeaderboardRecord);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export function subscribeLeaderboard(
  onUpdate: (entries: LeaderboardRecord[]) => void,
  onError?: (err: Error) => void,
  maxEntries = 15,
): Unsubscribe {
  const path = 'leaderboard';
  const q = query(
    collection(db, path),
    where('score', '>=', 0),
    orderBy('score', 'desc'),
    limit(clampInt(maxEntries, 1, 50)),
  );
  return onSnapshot(
    q,
    (snap) => {
      onUpdate(snap.docs.map((d) => d.data() as LeaderboardRecord));
    },
    (err) => {
      try {
        handleFirestoreError(err, OperationType.LIST, path);
      } catch (wrapped) {
        onError?.(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    },
  );
}
