import React, { useState } from 'react';
import { BookOpen, Check, FileText, GitBranch, HeartHandshake, Lock, Trophy, X } from 'lucide-react';
import {
  getSetPieceLabel,
  getWaveBriefing,
  INTEL_SPECS,
  MAX_STORY_WAVES,
  STORY_CHOICES,
  STORY_ENDING_LIST,
  STORY_ENDINGS,
} from '../game/rules';
import type { StoryDecisionRecord, StoryEndingId } from '../game/types';

interface StoryDossierModalProps {
  squadTrust: number;
  storyDecisions: StoryDecisionRecord[];
  unlockedEndingIds: StoryEndingId[];
  collectedIntelIds: string[];
  unlockedChapter: number;
  onSelectChapter: (chapter: number) => void;
  onClose: () => void;
}

type ArchiveTab = 'story' | 'endings' | 'intel';

export const StoryDossierModal: React.FC<StoryDossierModalProps> = ({
  squadTrust,
  storyDecisions,
  unlockedEndingIds,
  collectedIntelIds,
  unlockedChapter,
  onSelectChapter,
  onClose,
}) => {
  const [tab, setTab] = useState<ArchiveTab>('story');

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="story-dossier-title"
      data-testid="story-dossier-modal"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/82 p-3 sm:p-5 pointer-events-auto"
    >
      <div className="w-full max-w-3xl max-h-[90vh] flex flex-col bg-[#12161b] border border-stone-600/90 rounded-sm shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6 sm:py-4 border-b border-stone-700/80 bg-[#0e1217]">
          <div className="min-w-0">
            <div className="text-[10px] font-mono-num tracking-widest text-amber-400 font-bold">
              QALA-04 KƏŞFİYYAT DOSYESİ · DƏMİR KÖLGƏ
            </div>
            <h2
              id="story-dossier-title"
              className="font-display font-bold text-lg sm:text-2xl text-stone-100 tracking-wide truncate"
            >
              HEKAYƏ ARXİVİ & SÜJET XƏTTİ
            </h2>
          </div>
          <button
            type="button"
            data-testid="close-dossier-btn"
            onClick={onClose}
            aria-label="Bağla"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center bg-[#181e26] hover:bg-stone-700 border border-stone-600 text-stone-200 rounded-sm cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Summary Telemetry */}
        <div className="grid grid-cols-3 gap-2 px-4 py-3 sm:px-6 bg-[#141920] border-b border-stone-700/70">
          <div className="bg-[#181e26] border border-stone-700/80 px-3 py-2 rounded-sm">
            <div className="flex items-center gap-1.5 text-[10px] font-mono-num text-stone-400">
              <HeartHandshake className="w-3.5 h-3.5 text-sky-300 shrink-0" />
              <span>DƏSTƏ GÜVƏNİ</span>
            </div>
            <div className="font-mono-num font-bold text-lg text-sky-300 mt-0.5">
              {squadTrust}%
            </div>
          </div>

          <div className="bg-[#181e26] border border-stone-700/80 px-3 py-2 rounded-sm">
            <div className="flex items-center gap-1.5 text-[10px] font-mono-num text-stone-400">
              <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>SONLUQLAR</span>
            </div>
            <div className="font-mono-num font-bold text-lg text-amber-400 mt-0.5">
              {unlockedEndingIds.length}/{STORY_ENDING_LIST.length}
            </div>
          </div>

          <div className="bg-[#181e26] border border-stone-700/80 px-3 py-2 rounded-sm">
            <div className="flex items-center gap-1.5 text-[10px] font-mono-num text-stone-400">
              <FileText className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>MƏLUMATLAR</span>
            </div>
            <div className="font-mono-num font-bold text-lg text-emerald-400 mt-0.5">
              {collectedIntelIds.length}/{INTEL_SPECS.length}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 px-4 pt-3 sm:px-6 border-b border-stone-700/80 bg-[#12161b]">
          <button
            type="button"
            data-testid="tab-story"
            onClick={() => setTab('story')}
            className={`px-3 py-2 text-xs font-display font-bold tracking-wider border-b-2 transition-colors cursor-pointer inline-flex items-center gap-1.5 ${
              tab === 'story'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>10 FƏSİL & QƏRARLAR</span>
          </button>

          <button
            type="button"
            data-testid="tab-endings"
            onClick={() => setTab('endings')}
            className={`px-3 py-2 text-xs font-display font-bold tracking-wider border-b-2 transition-colors cursor-pointer inline-flex items-center gap-1.5 ${
              tab === 'endings'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>3 SONLUQ ({unlockedEndingIds.length}/3)</span>
          </button>

          <button
            type="button"
            data-testid="tab-intel"
            onClick={() => setTab('intel')}
            className={`px-3 py-2 text-xs font-display font-bold tracking-wider border-b-2 transition-colors cursor-pointer inline-flex items-center gap-1.5 ${
              tab === 'intel'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>10 MƏLUMAT ({collectedIntelIds.length}/10)</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
          {tab === 'story' && (
            <>
              {/* Player Past Story Decisions */}
              <div className="bg-[#161b22] border border-stone-700/80 p-3.5 rounded-sm">
                <div className="flex items-center gap-1.5 text-xs font-display font-bold text-amber-300 mb-2">
                  <GitBranch className="w-4 h-4 shrink-0" />
                  <span>QƏBUL EDİLMİŞ SÜJET QƏRARLARI</span>
                </div>
                {storyDecisions.length === 0 ? (
                  <p className="text-xs text-stone-400">
                    Hələ kritik süjet qərarı verilməyib. Fəsil 04, Fəsil 06 və Fəsil 10 finallarında verdiyiniz seçimlər burada qeyd olunur.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {storyDecisions.map((dec) => {
                      const choiceSpec = STORY_CHOICES[dec.choiceId];
                      const optSpec = choiceSpec?.options[dec.optionIndex];
                      const delta = optSpec?.trustDelta ?? 0;
                      const chapterNum = choiceSpec?.chapter ?? 4;
                      return (
                        <div
                          key={dec.choiceId}
                          className="flex items-center justify-between gap-2 bg-[#11151a] border border-stone-700/70 px-3 py-1.5 rounded-sm text-xs"
                        >
                          <span className="text-stone-200">
                            <strong className="font-mono-num text-amber-400 mr-1.5">
                              F{String(chapterNum).padStart(2, '0')}
                            </strong>
                            {dec.label}
                          </span>
                          <span
                            className={`font-mono-num font-bold shrink-0 ${
                              delta >= 0 ? 'text-emerald-400' : 'text-red-400'
                            }`}
                          >
                            {delta >= 0 ? `+${delta}` : delta} GÜVƏN
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* 10 Chapters Arc */}
              <div className="space-y-2">
                {Array.from({ length: MAX_STORY_WAVES }, (_, idx) => idx + 1).map((ch) => {
                  const brief = getWaveBriefing(ch, 'marathon');
                  const completed = ch < unlockedChapter;
                  const setPieceLabel =
                    ch === 2 || ch === 8
                      ? getSetPieceLabel('stealth_infil')
                      : ch === 3
                        ? getSetPieceLabel('hostage_rescue')
                        : ch === 4
                          ? getSetPieceLabel('overwatch_sniper')
                          : ch === 5 || ch === 10
                            ? getSetPieceLabel('door_breach_slowmo')
                            : ch === 6 || ch === 7
                              ? getSetPieceLabel('escape_timer')
                              : 'Taktiki Hücum';
                  return (
                    <div
                      key={ch}
                      className="bg-[#161b22] border border-stone-700/80 p-3 rounded-sm flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono-num text-stone-400 mb-0.5">
                          <span className="text-amber-400 font-bold">
                            FƏSİL {String(ch).padStart(2, '0')}
                          </span>
                          <span>·</span>
                          <span>{brief.locationTime}</span>
                          <span>·</span>
                          <span className="text-sky-300">{setPieceLabel}</span>
                          {completed && (
                            <span className="inline-flex items-center gap-0.5 text-emerald-400 font-bold">
                              <Check className="w-3 h-3" /> TAMAMLANIB
                            </span>
                          )}
                        </div>
                        <div className="font-display font-bold text-sm text-stone-100">
                          {brief.title}
                        </div>
                        <p className="text-xs text-stone-300 mt-0.5 leading-snug">
                          {brief.context}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          onSelectChapter(ch);
                          onClose();
                        }}
                        className="px-2.5 py-1.5 bg-[#1e252e] hover:bg-amber-500 hover:text-stone-950 border border-stone-600 hover:border-amber-400 text-stone-200 font-display font-bold text-[11px] rounded-sm transition-colors shrink-0 cursor-pointer"
                      >
                        SEÇ
                      </button>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {tab === 'endings' && (
            <div className="space-y-3">
              {STORY_ENDING_LIST.map((endId) => {
                const spec = STORY_ENDINGS[endId];
                const unlocked = unlockedEndingIds.includes(endId);
                return (
                  <div
                    key={endId}
                    className={`p-4 border rounded-sm ${
                      unlocked
                        ? 'bg-[#151c22] border-amber-500/75'
                        : 'bg-[#14171c] border-stone-700/70'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-display font-bold text-base text-stone-100">
                        {spec.title}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-mono-num font-bold ${
                          unlocked ? 'text-emerald-400' : 'text-stone-400'
                        }`}
                      >
                        {unlocked ? (
                          <>
                            <Check className="w-3.5 h-3.5" /> AÇILIB
                          </>
                        ) : (
                          <>
                            <Lock className="w-3.5 h-3.5" /> KİLİDLİ
                          </>
                        )}
                      </span>
                    </div>
                    <div className="text-xs font-semibold text-amber-300 mb-1.5">
                      {spec.subtitle}
                    </div>
                    <p className="text-xs text-stone-300 leading-relaxed">
                      {unlocked
                        ? spec.epilogue
                        : 'Fəsil 04, Fəsil 06 və Fəsil 10 qərarlarınız, girovların taleyi və Dəstə Güvəni nəticəsində bu sonluq açılır.'}
                    </p>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'intel' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {INTEL_SPECS.map((spec) => {
                const found = collectedIntelIds.includes(spec.id);
                return (
                  <div
                    key={spec.id}
                    className={`p-3 border rounded-sm ${
                      found
                        ? 'bg-[#141c1a] border-emerald-500/65'
                        : 'bg-[#14171c] border-stone-700/75'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-[10px] font-mono-num mb-1">
                      <span className="text-amber-400 font-bold">
                        FƏSİL {String(spec.chapter).padStart(2, '0')}
                      </span>
                      <span className={found ? 'text-emerald-400 font-bold' : 'text-stone-400'}>
                        {found ? 'ŞİFRƏ AÇILIB' : 'TOPLANMAYIB'}
                      </span>
                    </div>
                    <div className="font-display font-bold text-xs text-stone-100 mb-1">
                      {spec.title}
                    </div>
                    <p className="text-xs text-stone-300 leading-snug">
                      {found
                        ? spec.summary
                        : `Bu gizli noutbuk Fəsil ${String(spec.chapter).padStart(2, '0')} əməliyyat meydanında gizlədilib. Yaxınlaşıb [E] ilə toplayın.`}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
