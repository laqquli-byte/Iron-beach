import React from 'react';
import { Bomb, Box, Crosshair, DollarSign, Package, Plane, Shield, X } from 'lucide-react';
import { BUY_STATION_ITEMS } from '../game/rules';
import type { BuyStationItemId } from '../game/types';

interface BuyStationModalProps {
  credits: number;
  onBuyItem: (itemId: BuyStationItemId) => void;
  onClose: () => void;
}

function renderItemIcon(id: BuyStationItemId) {
  if (id === 'ammo') return <Package className="w-5 h-5 text-amber-400 shrink-0" />;
  if (id === 'explosives') return <Bomb className="w-5 h-5 text-orange-400 shrink-0" />;
  if (id === 'juggernaut') return <Shield className="w-5 h-5 text-sky-400 shrink-0" />;
  if (id === 'sentry') return <Crosshair className="w-5 h-5 text-emerald-400 shrink-0" />;
  if (id === 'care_package') return <Box className="w-5 h-5 text-emerald-300 shrink-0" />;
  return <Plane className="w-5 h-5 text-red-400 shrink-0" />;
}

export const BuyStationModal: React.FC<BuyStationModalProps> = ({
  credits,
  onBuyItem,
  onClose,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="buy-station-title"
      data-testid="buy-station-modal"
      className="fixed inset-0 z-30 flex items-center justify-center bg-black/80 p-3 sm:p-5 pointer-events-auto"
    >
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#11151b] border border-amber-500/80 p-4 sm:p-6 rounded-sm shadow-2xl">
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-stone-700/80 mb-4">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-xs font-mono-num text-amber-400">
              <span>SAĞQALMA REJİMİ · [B] / [ESC]</span>
            </div>
            <h2
              id="buy-station-title"
              className="font-display font-bold text-xl sm:text-2xl text-stone-100 tracking-wide mt-0.5"
            >
              MAĞAZA · TAKTİKİ TƏCHİZAT
            </h2>
          </div>

          <button
            type="button"
            data-testid="close-buy-station-btn"
            onClick={onClose}
            aria-label="Bağla"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center bg-[#181d24] hover:bg-[#232a34] border border-stone-600 text-stone-200 rounded-sm transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-between bg-[#161b22] border border-emerald-500/50 px-3.5 py-2.5 rounded-sm mb-4">
          <span className="text-xs font-semibold tracking-wider text-stone-300">
            MÖVCUD BÜDCƏ
          </span>
          <span
            data-testid="buy-station-credits"
            className="flex items-center gap-1 font-mono-num font-bold text-xl text-emerald-400"
          >
            <DollarSign className="w-4 h-4" />
            {credits}
          </span>
        </div>

        <div className="space-y-2 mb-4">
          {BUY_STATION_ITEMS.map((item) => {
            const affordable = credits >= item.cost;
            return (
              <button
                key={item.id}
                type="button"
                data-buy-item={item.id}
                disabled={!affordable}
                onClick={() => onBuyItem(item.id)}
                className={`w-full flex items-center justify-between gap-3 p-3 border rounded-sm text-left min-h-[60px] transition-colors ${
                  affordable
                    ? 'bg-[#151a21] hover:bg-[#1c232d] border-stone-600 hover:border-amber-400 text-stone-100 cursor-pointer'
                    : 'bg-[#101318] border-stone-800 text-stone-500 opacity-65 cursor-not-allowed'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="mt-0.5">{renderItemIcon(item.id)}</div>
                  <div className="min-w-0">
                    <div className="font-display font-bold text-sm text-stone-100 truncate">
                      {item.title}
                    </div>
                    <div className="text-[11px] text-stone-400 leading-snug mt-0.5">
                      {item.description}
                    </div>
                  </div>
                </div>

                <div
                  className={`px-2.5 py-1.5 rounded-xs font-mono-num font-bold text-xs shrink-0 border ${
                    affordable
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                      : 'bg-stone-900 border-stone-700 text-stone-500'
                  }`}
                >
                  ${item.cost}
                </div>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full min-h-[44px] bg-stone-800 hover:bg-stone-700 text-stone-200 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
        >
          DÖYÜŞƏ QAYIT [ESC]
        </button>
      </div>
    </div>
  );
};
