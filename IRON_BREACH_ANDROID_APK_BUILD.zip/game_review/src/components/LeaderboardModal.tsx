import React, { useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import { Cloud, LogIn, LogOut, RefreshCw, Trophy, X } from 'lucide-react';
import { DIFFICULTY_SPECS } from '../game/rules';
import { subscribeLeaderboard, type LeaderboardRecord } from '../services/firebaseService';

interface LeaderboardModalProps {
  user: User | null;
  syncing: boolean;
  syncMessage: string | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onManualSync: () => void;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  user,
  syncing,
  syncMessage,
  onSignIn,
  onSignOut,
  onManualSync,
  onClose,
}) => {
  const [entries, setEntries] = useState<LeaderboardRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorText, setErrorText] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setErrorText(null);
    const unsubscribe = subscribeLeaderboard(
      (list) => {
        setEntries(list);
        setLoading(false);
        setErrorText(null);
      },
      (err) => {
        setLoading(false);
        setErrorText(
          err.message.includes('offline')
            ? 'Oflayn rejim — liderlər cədvəli əlçatan deyil.'
            : 'Liderlər cədvəlini yükləmək mümkün olmadı.',
        );
      },
      20,
    );
    return () => unsubscribe();
  }, []);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="leaderboard-title"
      data-testid="leaderboard-modal"
      className="fixed inset-0 z-30 flex items-center justify-center bg-black/82 p-3 sm:p-5 pointer-events-auto"
    >
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#11151a] border border-stone-600/90 p-4 sm:p-6 rounded-sm shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-stone-700/80 mb-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs font-mono-num text-amber-400">
              <Trophy className="w-3.5 h-3.5 shrink-0" />
              <span>QLOBAL REYTİNQ · BULUD SİNXRONİZASİYASI</span>
            </div>
            <h2
              id="leaderboard-title"
              className="font-display font-bold text-xl sm:text-2xl text-stone-100 tracking-wide mt-0.5"
            >
              LİDERLƏR CƏDVƏLİ & HESAB
            </h2>
          </div>

          <button
            type="button"
            data-testid="close-leaderboard-btn"
            onClick={onClose}
            aria-label="Bağla"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center bg-[#181d24] hover:bg-[#232a34] border border-stone-600 text-stone-200 rounded-sm transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Google Auth & Cloud Sync Panel */}
        <div className="bg-[#161b22] border border-stone-700/80 p-3.5 rounded-sm mb-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Cloud className={`w-5 h-5 shrink-0 ${user ? 'text-emerald-400' : 'text-stone-400'}`} />
              <div className="min-w-0">
                <div className="text-xs font-display font-bold text-stone-100 truncate">
                  {user ? user.displayName || user.email || 'Operator' : 'Hesaba Daxil Olunmayıb'}
                </div>
                <div className="text-[11px] text-stone-400 truncate">
                  {user
                    ? 'Karyera, medallar və nəticələr buludda saxlanır'
                    : 'Nəticəni qlobal cədvələ yazmaq üçün Google ilə daxil olun'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {user ? (
                <>
                  <button
                    type="button"
                    disabled={syncing}
                    onClick={onManualSync}
                    className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/70 text-emerald-300 font-display font-bold text-xs rounded-sm transition-colors cursor-pointer disabled:opacity-60"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
                    <span>SİNXRONİZASİYA</span>
                  </button>
                  <button
                    type="button"
                    onClick={onSignOut}
                    className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[40px] bg-[#1e242d] hover:bg-[#2a323e] border border-stone-600 text-stone-200 font-display font-bold text-xs rounded-sm transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>ÇIXIŞ</span>
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  data-testid="google-signin-btn"
                  onClick={onSignIn}
                  className="inline-flex items-center gap-2 px-3.5 py-2 min-h-[42px] bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-xs tracking-wider rounded-sm transition-colors cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  <span>GOOGLE İLƏ DAXİL OL</span>
                </button>
              )}
            </div>
          </div>

          {syncMessage && (
            <div className="mt-2 pt-2 border-t border-stone-700/60 text-[11px] font-mono-num text-amber-300">
              {syncMessage}
            </div>
          )}
        </div>

        {/* Error banner (non-blocking) */}
        {errorText && (
          <div className="bg-red-950/50 border border-red-500/60 px-3 py-2 rounded-sm text-xs text-red-200 mb-3">
            {errorText}
          </div>
        )}

        {/* Global Top-20 Leaderboard Table */}
        <div className="border border-stone-700/80 rounded-sm overflow-hidden bg-[#14181f]">
          <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-[#1a2029] border-b border-stone-700/80 text-[10px] font-mono-num font-bold text-stone-400">
            <div className="col-span-1">#</div>
            <div className="col-span-5">OPERATOR</div>
            <div className="col-span-2 text-center">REJİM</div>
            <div className="col-span-2 text-right">MƏHV</div>
            <div className="col-span-2 text-right">XAL</div>
          </div>

          {loading ? (
            <div className="p-6 text-center text-xs text-stone-400 font-mono-num">
              Məlumatlar yüklənir...
            </div>
          ) : entries.length === 0 ? (
            <div className="p-6 text-center text-xs text-stone-400">
              Hələ qlobal rekord qeydə alınmayıb. İlk lider siz olun!
            </div>
          ) : (
            <div className="divide-y divide-stone-800/80 max-h-[46vh] overflow-y-auto">
              {entries.map((row, idx) => {
                const isSelf = user?.uid === row.userId;
                const diffName = DIFFICULTY_SPECS[row.difficulty]?.name ?? row.difficulty;
                return (
                  <div
                    key={row.userId}
                    className={`grid grid-cols-12 gap-2 px-3 py-2.5 items-center text-xs ${
                      isSelf ? 'bg-amber-500/12 text-amber-200' : 'text-stone-200'
                    }`}
                  >
                    <div className="col-span-1 font-mono-num font-bold text-amber-400">
                      {idx + 1}
                    </div>
                    <div className="col-span-5 min-w-0">
                      <div className="font-display font-bold truncate">
                        {row.displayName}
                      </div>
                      <div className="text-[10px] text-stone-400 truncate">
                        {row.rankTitle} · {diffName} · {row.medalsCount || 0} Medal
                      </div>
                    </div>
                    <div className="col-span-2 text-center font-mono-num text-[10px]">
                      <span
                        className={`px-1.5 py-0.5 rounded-xs border ${
                          row.gameMode === 'survival'
                            ? 'border-emerald-500/50 text-emerald-300 bg-emerald-950/40'
                            : 'border-sky-500/50 text-sky-300 bg-sky-950/40'
                        }`}
                      >
                        {row.gameMode === 'survival' ? `Z-${row.wave}` : `F0${row.wave}`}
                      </span>
                    </div>
                    <div className="col-span-2 text-right font-mono-num text-stone-300">
                      {row.kills}
                    </div>
                    <div className="col-span-2 text-right font-mono-num font-bold text-amber-300">
                      {row.score}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full min-h-[44px] bg-stone-800 hover:bg-stone-700 text-stone-100 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
        >
          BAĞLA
        </button>
      </div>
    </div>
  );
};
