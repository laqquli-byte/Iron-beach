import React, { useState } from 'react';
import { Award, Check, FileText, Lock, Medal, Shield, Sliders, X, Zap } from 'lucide-react';
import {
  ATTACHMENT_LIST,
  ATTACHMENT_SPECS,
  CHALLENGE_SPECS,
  getCamoProgress,
  getChallengeProgress,
  getEffectiveWeaponSpec,
  getWeaponShortName,
  INTEL_SPECS,
  MEDAL_LIST,
  MEDAL_SPECS,
  PERK_LIST,
  PERK_SPECS,
  WEAPON_CAMO_LIST,
  WEAPON_CAMOS,
  WEAPON_LIST,
  WEAPON_SPECS,
} from '../game/rules';
import type {
  AttachmentId,
  CareerStats,
  MedalId,
  PerkId,
  RankInfo,
  WeaponCamoId,
  WeaponId,
} from '../game/types';

interface ArsenalModalProps {
  selectedWeapon: WeaponId;
  onSelectWeapon: (weapon: WeaponId) => void;
  equippedCamos: Record<WeaponId, WeaponCamoId>;
  onSelectCamo: (weapon: WeaponId, camo: WeaponCamoId) => void;
  equippedAttachments: Record<WeaponId, AttachmentId[]>;
  onToggleAttachment: (weapon: WeaponId, attachment: AttachmentId) => void;
  selectedPerk: PerkId;
  onSelectPerk: (perk: PerkId) => void;
  careerStats: CareerStats;
  rankInfo: RankInfo;
  unlockedMedalIds: MedalId[];
  collectedIntelIds: string[];
  onClose: () => void;
}

export const ArsenalModal: React.FC<ArsenalModalProps> = ({
  selectedWeapon,
  onSelectWeapon,
  equippedCamos,
  onSelectCamo,
  equippedAttachments,
  onToggleAttachment,
  selectedPerk,
  onSelectPerk,
  careerStats,
  rankInfo,
  unlockedMedalIds,
  collectedIntelIds,
  onClose,
}) => {
  const [lockedNoticeId, setLockedNoticeId] = useState<WeaponCamoId | null>(null);

  const activeAttachments = equippedAttachments[selectedWeapon] ?? [];
  const activeCamoId = equippedCamos[selectedWeapon] ?? 'standard';
  const effectiveSpec = getEffectiveWeaponSpec(
    selectedWeapon,
    activeAttachments,
    selectedPerk,
  );
  const lockedNoticeSpec = lockedNoticeId ? WEAPON_CAMOS[lockedNoticeId] : null;
  const lockedNoticeProgress = lockedNoticeId
    ? getCamoProgress(lockedNoticeId, careerStats)
    : null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="arsenal-title"
      data-testid="arsenal-modal"
      className="fixed inset-0 z-30 flex items-center justify-center bg-black/82 p-3 sm:p-5"
    >
      <div className="w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-[#11151a] border border-stone-600/90 p-4 sm:p-6 rounded-sm shadow-2xl pointer-events-auto">
        {/* Header + Close */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-stone-700/80 mb-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs font-mono-num text-amber-400">
              <Sliders className="w-3.5 h-3.5 shrink-0" />
              <span>GUNSMITH · MEDALLAR · KƏŞFİYYAT</span>
            </div>
            <h2
              id="arsenal-title"
              className="font-display font-bold text-xl sm:text-2xl text-stone-100 tracking-wide mt-0.5"
            >
              CƏBBƏXANA VƏ TƏCHİZAT
            </h2>
          </div>

          <button
            type="button"
            data-testid="close-arsenal-btn"
            onClick={onClose}
            aria-label="Bağla"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center bg-[#181d24] hover:bg-[#232a34] border border-stone-600 text-stone-200 rounded-sm transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Rank & XP Bar */}
        <div className="bg-[#161b22] border border-stone-700/80 p-3 rounded-sm mb-4">
          <div className="flex items-center justify-between gap-2 text-xs mb-1.5">
            <div className="flex items-center gap-2 font-display font-bold text-stone-100">
              <Award className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                RÜTBƏ {rankInfo.level} · {rankInfo.title.toUpperCase()}
              </span>
            </div>
            <span className="font-mono-num text-amber-300 font-semibold">
              {rankInfo.xp} / {rankInfo.nextLevelXp} XP
            </span>
          </div>
          <div className="h-1.5 bg-stone-800 overflow-hidden rounded-xs">
            <div
              className="h-full bg-amber-400 transition-all duration-200"
              style={{ width: `${rankInfo.progressPct}%` }}
            />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 mt-2 text-[11px] font-mono-num text-stone-400">
            <span>Məhv: {careerStats.totalKills}</span>
            <span>Başdan Zərbə: {careerStats.totalHeadshots}</span>
            <span>Partlayış: {careerStats.totalExplosiveKills}</span>
            <span>Rekord: {careerStats.bestScore}</span>
          </div>
        </div>

        {/* 9 Weapon Tabs */}
        <div className="mb-3">
          <div className="text-[11px] font-semibold tracking-wider text-stone-400 mb-1.5">
            SİLAH MODİFİKASİYASI SEÇİN (9 SİLAH)
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
            {WEAPON_LIST.map((wId) => {
              const spec = WEAPON_SPECS[wId];
              const active = selectedWeapon === wId;
              const attCount = (equippedAttachments[wId] ?? []).length;
              return (
                <button
                  key={wId}
                  type="button"
                  data-arsenal-weapon={wId}
                  aria-pressed={active}
                  onClick={() => {
                    setLockedNoticeId(null);
                    onSelectWeapon(wId);
                  }}
                  className={`px-2 py-2 border rounded-sm text-left min-h-[44px] transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#1c222b] border-amber-500 text-stone-100'
                      : 'bg-[#14181e] border-stone-700/80 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-xs truncate">
                      {getWeaponShortName(wId)}
                    </span>
                    {attCount > 0 && (
                      <span className="text-[10px] font-mono-num text-amber-400 font-bold">
                        +{attCount}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-stone-400 truncate mt-0.5">
                    {spec.role.split(' · ')[0]}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Effective Stats Strip */}
        <div className="grid grid-cols-4 gap-2 bg-[#161b22] border border-stone-700/75 p-2.5 rounded-sm mb-4 text-center">
          <div>
            <div className="text-[10px] text-stone-400 font-semibold">ZƏRƏR</div>
            <div className="font-mono-num font-bold text-sm text-amber-300">
              {effectiveSpec.pellets && effectiveSpec.pellets > 1
                ? `${effectiveSpec.damage}×${effectiveSpec.pellets}`
                : effectiveSpec.damage}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-stone-400 font-semibold">DARAQ</div>
            <div className="font-mono-num font-bold text-sm text-stone-100">
              {effectiveSpec.isMelee ? '∞' : `${effectiveSpec.magSize}/${effectiveSpec.maxReserve}`}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-stone-400 font-semibold">DOLDURMA</div>
            <div className="font-mono-num font-bold text-sm text-sky-300">
              {effectiveSpec.reloadDuration}s
            </div>
          </div>
          <div>
            <div className="text-[10px] text-stone-400 font-semibold">MƏSAFƏ</div>
            <div className="font-mono-num font-bold text-sm text-emerald-300">
              {effectiveSpec.range}m
            </div>
          </div>
        </div>

        {/* Gunsmith Attachments */}
        <div className="mb-4">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[11px] font-semibold tracking-wider text-stone-400">
              GUNSMITH ƏLAVƏLƏRİ · {WEAPON_SPECS[selectedWeapon].name.toUpperCase()}
            </span>
            <span className="text-[11px] font-mono-num text-amber-400">
              {activeAttachments.length}/4 AKTİV
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {ATTACHMENT_LIST.map((attId) => {
              const spec = ATTACHMENT_SPECS[attId];
              const equipped = activeAttachments.includes(attId);
              return (
                <button
                  key={attId}
                  type="button"
                  data-attachment={attId}
                  aria-pressed={equipped}
                  onClick={() => onToggleAttachment(selectedWeapon, attId)}
                  className={`flex items-start justify-between gap-2 p-2.5 border rounded-sm text-left min-h-[54px] transition-colors cursor-pointer ${
                    equipped
                      ? 'bg-[#1c232d] border-amber-500 text-stone-100'
                      : 'bg-[#151920] border-stone-700/80 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="font-display font-bold text-xs sm:text-sm text-stone-100">
                      {spec.name}
                    </div>
                    <div className="text-[11px] text-stone-400 leading-snug mt-0.5">
                      {spec.description}
                    </div>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-xs border flex items-center justify-center shrink-0 mt-0.5 ${
                      equipped
                        ? 'bg-amber-500 border-amber-400 text-stone-950'
                        : 'border-stone-600 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Weapon Camos */}
        <div className="mb-4">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[11px] font-semibold tracking-wider text-stone-400">
              BOYA VƏ KAMUFLYAJ
            </span>
            <span className="text-[11px] text-stone-300 truncate">
              {lockedNoticeSpec && lockedNoticeProgress ? (
                <span className="text-amber-300">
                  Kilidli · {lockedNoticeSpec.unlockLabel} ({lockedNoticeProgress.current}/
                  {lockedNoticeProgress.target})
                </span>
              ) : (
                <span>Aktiv: {WEAPON_CAMOS[activeCamoId].name}</span>
              )}
            </span>
          </div>
          <div className="grid grid-cols-5 gap-1.5">
            {WEAPON_CAMO_LIST.map((camoId) => {
              const camo = WEAPON_CAMOS[camoId];
              const progress = getCamoProgress(camoId, careerStats);
              const unlocked = progress.unlocked;
              const equipped = activeCamoId === camoId;
              return (
                <button
                  key={camoId}
                  type="button"
                  data-camo={camoId}
                  data-unlocked={unlocked ? 'true' : 'false'}
                  data-equipped={equipped ? 'true' : 'false'}
                  aria-pressed={equipped}
                  onClick={() => {
                    if (unlocked) {
                      setLockedNoticeId(null);
                      onSelectCamo(selectedWeapon, camoId);
                    } else {
                      setLockedNoticeId(camoId);
                    }
                  }}
                  className={`flex flex-col items-stretch justify-between p-1.5 border rounded-sm min-h-[54px] transition-colors cursor-pointer ${
                    equipped
                      ? 'bg-[#1c222b] border-amber-500 text-stone-100'
                      : unlocked
                        ? 'bg-[#151920] border-stone-700/80 text-stone-200 hover:border-stone-400'
                        : 'bg-[#101318] border-stone-800 text-stone-400 hover:border-stone-600'
                  }`}
                >
                  <div
                    className={`w-full h-3 rounded-xs border border-black/40 ${
                      !unlocked ? 'opacity-55' : ''
                    }`}
                    style={{
                      background: `linear-gradient(135deg, ${camo.swatchHex} 0%, ${camo.swatchHex} 52%, ${camo.accentHex} 52%, ${camo.accentHex} 100%)`,
                    }}
                  />
                  <div className="text-[10px] font-semibold leading-tight truncate mt-1 text-center">
                    {camo.shortName}
                  </div>
                  <div className="flex items-center justify-center gap-0.5 text-[9px] font-mono-num mt-0.5">
                    {equipped ? (
                      <>
                        <Check className="w-2.5 h-2.5 text-amber-400 shrink-0" />
                        <span className="text-amber-400">Aktiv</span>
                      </>
                    ) : unlocked ? (
                      <span className="text-stone-400">Açıq</span>
                    ) : (
                      <>
                        <Lock className="w-2.5 h-2.5 text-stone-500 shrink-0" />
                        <span>
                          {progress.current}/{progress.target}
                        </span>
                      </>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tactical Perks */}
        <div className="mb-4">
          <div className="text-[11px] font-semibold tracking-wider text-stone-400 mb-1.5">
            TAKTİKİ PERK (1 AKTİV)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {PERK_LIST.map((perkId) => {
              const spec = PERK_SPECS[perkId];
              const active = selectedPerk === perkId;
              return (
                <button
                  key={perkId}
                  type="button"
                  data-perk={perkId}
                  aria-pressed={active}
                  onClick={() => onSelectPerk(perkId)}
                  className={`p-2.5 border rounded-sm text-left min-h-[60px] transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#1c232d] border-sky-400 text-stone-100'
                      : 'bg-[#151920] border-stone-700/80 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="font-display font-bold text-xs sm:text-sm">
                      {spec.name}
                    </span>
                    {perkId === 'heavy_armor' ? (
                      <Shield
                        className={`w-3.5 h-3.5 shrink-0 ${active ? 'text-sky-400' : 'text-stone-500'}`}
                      />
                    ) : (
                      <Zap
                        className={`w-3.5 h-3.5 shrink-0 ${active ? 'text-sky-400' : 'text-stone-500'}`}
                      />
                    )}
                  </div>
                  <div className="text-[11px] text-stone-400 leading-snug mt-1">
                    {spec.description}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Career Challenges */}
        <div className="mb-4">
          <div className="text-[11px] font-semibold tracking-wider text-stone-400 mb-1.5">
            KARYERA TAPŞIRIQLARI (BONUS XP)
          </div>
          <div className="space-y-1.5">
            {CHALLENGE_SPECS.map((ch) => {
              const prog = getChallengeProgress(ch, careerStats);
              const pct = Math.min(100, Math.round((prog.current / prog.target) * 100));
              return (
                <div
                  key={ch.id}
                  className="bg-[#151920] border border-stone-700/80 px-3 py-2 rounded-sm"
                >
                  <div className="flex items-center justify-between gap-2 text-xs mb-1">
                    <span className="font-medium text-stone-200 truncate">{ch.title}</span>
                    <span
                      className={`font-mono-num text-[11px] shrink-0 font-semibold ${
                        prog.completed ? 'text-emerald-400' : 'text-amber-300'
                      }`}
                    >
                      {prog.completed
                        ? `TAMAMLANDI (+${ch.xpReward} XP)`
                        : `${prog.current}/${prog.target} · +${ch.xpReward} XP`}
                    </span>
                  </div>
                  <div className="h-1 bg-stone-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-200 ${
                        prog.completed ? 'bg-emerald-400' : 'bg-amber-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 7 Unlockable Medals */}
        <div className="mb-4">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[11px] font-semibold tracking-wider text-stone-400">
              DÖYÜŞ MEDALLARI
            </span>
            <span className="text-[11px] font-mono-num text-amber-400 font-bold">
              {unlockedMedalIds.length}/{MEDAL_LIST.length} AÇILIB
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {MEDAL_LIST.map((mId) => {
              const m = MEDAL_SPECS[mId];
              const unlocked = unlockedMedalIds.includes(mId);
              return (
                <div
                  key={mId}
                  className={`flex items-start gap-2.5 p-2 border rounded-sm ${
                    unlocked
                      ? 'bg-[#1a221d] border-emerald-500/60 text-stone-100'
                      : 'bg-[#12151a] border-stone-800 text-stone-400 opacity-75'
                  }`}
                >
                  <Medal
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      unlocked ? 'text-amber-400' : 'text-stone-600'
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1 text-xs font-display font-bold">
                      <span className="truncate">{m.title}</span>
                      <span className="text-[10px] font-mono-num text-amber-300 shrink-0">
                        +{m.xpReward} XP
                      </span>
                    </div>
                    <div className="text-[10px] text-stone-400 leading-snug mt-0.5">
                      {m.description}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 5 Collectible Intel Dossiers */}
        <div className="mb-4">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[11px] font-semibold tracking-wider text-stone-400">
              MƏLUMATLAR / INTEL DOSYELƏRİ
            </span>
            <span className="text-[11px] font-mono-num text-sky-300 font-bold">
              {collectedIntelIds.length}/{INTEL_SPECS.length} TOPLANIB
            </span>
          </div>
          <div className="space-y-1.5">
            {INTEL_SPECS.map((intel) => {
              const found = collectedIntelIds.includes(intel.id);
              return (
                <div
                  key={intel.id}
                  className={`flex items-start gap-2.5 p-2 border rounded-sm ${
                    found
                      ? 'bg-[#151d26] border-sky-500/60 text-stone-100'
                      : 'bg-[#12151a] border-stone-800 text-stone-500'
                  }`}
                >
                  <FileText
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      found ? 'text-sky-400' : 'text-stone-600'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-display font-bold truncate">
                      {intel.title} · Fəsil 0{intel.chapter}
                    </div>
                    <div className="text-[11px] text-stone-400 leading-snug mt-0.5">
                      {found
                        ? intel.summary
                        : 'Kəşf edilməyib — bazada parlayan noutbuku [E] ilə götürün.'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full min-h-[46px] bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
        >
          TƏSDİQLƏ VƏ QAYIT
        </button>
      </div>
    </div>
  );
};
