import React from 'react';
import { FastForward, Radio } from 'lucide-react';
import type { HudSnapshot } from '../game/types';

interface CutsceneOverlayProps {
  cutscene: NonNullable<HudSnapshot['cutscene']>;
  onSkip: () => void;
}

export const CutsceneOverlay: React.FC<CutsceneOverlayProps> = ({ cutscene, onSkip }) => {
  const progressPct = Math.round(((cutscene.beatIndex + 1) / Math.max(1, cutscene.totalBeats)) * 100);

  return (
    <div
      data-testid="cutscene-overlay"
      className="fixed inset-0 z-30 flex flex-col justify-between pointer-events-auto select-none"
    >
      {/* Top Cinema Letterbox Bar */}
      <div className="bg-black border-b border-stone-800/90 px-4 py-2.5 sm:px-8 sm:py-4 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-[10px] sm:text-xs font-mono-num text-amber-400 tracking-widest truncate">
            <span>{cutscene.locationTime}</span>
            <span className="text-stone-600" aria-hidden="true">·</span>
            <span className="text-stone-400">
              SƏHNƏ {cutscene.beatIndex + 1}/{cutscene.totalBeats}
            </span>
          </div>
          <h2 className="font-display font-bold text-sm sm:text-xl text-stone-100 tracking-wider truncate mt-0.5">
            {cutscene.title}
          </h2>
        </div>

        <button
          type="button"
          data-testid="skip-cutscene-btn"
          onClick={(e) => {
            e.currentTarget.blur();
            onSkip();
          }}
          className="min-h-[40px] sm:min-h-[44px] px-3 sm:px-4 bg-[#161b22] hover:bg-amber-500 hover:text-stone-950 border border-stone-600 hover:border-amber-400 text-stone-100 font-display font-bold text-xs sm:text-sm tracking-wider rounded-sm transition-colors inline-flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <span>SƏHNƏNİ KEÇ</span>
          <span className="hidden sm:inline font-mono-num text-[11px] opacity-80">[SPACE]</span>
          <FastForward className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>
      </div>

      {/* Clear 3D Center Cinema Viewport */}
      <div className="flex-1 pointer-events-none" />

      {/* Bottom Cinema Letterbox Bar with Squad Transmission Subtitle */}
      <div className="bg-black border-t border-stone-800/90 px-4 py-3 sm:px-10 sm:py-5">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between gap-2 text-[11px] sm:text-xs font-mono-num font-bold tracking-wider mb-1">
            <div className="flex items-center gap-2 min-w-0">
              <Radio className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="px-1.5 py-0.5 bg-amber-500/15 border border-amber-500/40 text-amber-300 rounded-xs shrink-0">
                {cutscene.callsign}
              </span>
              <span className="text-stone-100 uppercase truncate">{cutscene.speaker}</span>
            </div>
            <span className="text-stone-400 shrink-0">{progressPct}%</span>
          </div>

          <p
            data-testid="cutscene-subtitle"
            className="text-sm sm:text-lg text-stone-100 font-medium leading-snug sm:leading-relaxed"
          >
            “{cutscene.subtitle}”
          </p>

          <div className="mt-2.5 flex items-center gap-2">
            <div className="flex-1 h-1 bg-stone-800 overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <div className="flex items-center gap-1 shrink-0">
              {Array.from({ length: cutscene.totalBeats }).map((_, idx) => (
                <span
                  key={idx}
                  className={`w-2 h-1 rounded-xs transition-colors ${
                    idx <= cutscene.beatIndex ? 'bg-amber-400' : 'bg-stone-700'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
