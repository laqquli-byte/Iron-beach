import React from 'react';
import { Award, Gamepad2, Home, Monitor, Play, RotateCcw, Sliders, Trophy } from 'lucide-react';
import {
  computeAccuracyPct,
  DIFFICULTY_SPECS,
  INTEL_SPECS,
  MAX_STORY_WAVES,
  MEDAL_LIST,
  type GraphicsQuality,
} from '../game/rules';
import type { HudSnapshot } from '../game/types';

interface GameModalsProps {
  hud: HudSnapshot;
  showTouchControls: boolean;
  graphicsQuality: GraphicsQuality;
  onToggleTouchControls: () => void;
  onToggleGraphicsQuality: () => void;
  onOpenSettings: () => void;
  onResume: () => void;
  onRestart: () => void;
  onRestartCheckpoint: () => void;
  onSwitchChapter: (chapter: number) => void;
  onTitle: () => void;
  onContinueEndless: () => void;
  onOpenLeaderboard: () => void;
}

export const GameModals: React.FC<GameModalsProps> = ({
  hud,
  showTouchControls,
  graphicsQuality,
  onToggleTouchControls,
  onToggleGraphicsQuality,
  onOpenSettings,
  onResume,
  onRestart,
  onRestartCheckpoint,
  onSwitchChapter,
  onTitle,
  onContinueEndless,
  onOpenLeaderboard,
}) => {
  if (hud.phase === 'paused') {
    return (
      <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/70 p-4">
        <div className="w-full max-w-sm bg-[#12161b] border border-stone-600/90 p-6 rounded-sm shadow-2xl">
          <h2 className="font-display font-bold text-2xl text-stone-100 tracking-wide mb-1">
            OYUN DAYANDIRILDI
          </h2>
          <p className="text-xs text-stone-400 mb-5">
            {hud.gameMode === 'survival'
              ? `Sağqalma · Dalğa ${hud.wave}`
              : hud.gameMode === 'firing_range'
                ? 'Təlim Poliqonu'
                : hud.gameMode === 'spec_ops'
                  ? 'Spec Ops Bomba'
                  : `Fəsil ${String(hud.wave).padStart(2, '0')}`}{' '}
            · {DIFFICULTY_SPECS[hud.selectedDifficulty].name} · Xal {hud.score}
          </p>

          <div className="flex flex-col gap-2.5">
            <button
              type="button"
              onClick={onResume}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-base tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>DAVAM ET</span>
            </button>

            <button
              type="button"
              onClick={onToggleGraphicsQuality}
              className="w-full min-h-[44px] flex items-center justify-center gap-2 bg-[#171c23] hover:bg-[#1f2630] border border-stone-600 text-stone-200 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Monitor className="w-4 h-4 text-amber-400" />
              <span>QRAFİKA: {graphicsQuality === '720p' ? '720P PERFORMANS' : 'ULTRA'}</span>
            </button>

            <button
              type="button"
              data-testid="pause-settings-btn"
              onClick={onOpenSettings}
              className="w-full min-h-[44px] flex items-center justify-center gap-2 bg-[#171c23] hover:bg-[#1f2630] border border-stone-600 text-stone-200 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>OYUN TƏNZİMLƏMƏLƏRİ</span>
            </button>

            <button
              type="button"
              onClick={onToggleTouchControls}
              className="w-full min-h-[44px] flex items-center justify-center gap-2 bg-[#171c23] hover:bg-[#1f2630] border border-stone-600 text-stone-200 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Gamepad2 className="w-4 h-4 text-amber-400" />
              <span>EKRAN DÜYMƏLƏRİ: {showTouchControls ? 'AÇIQ' : 'BAĞLI'}</span>
            </button>

            <button
              type="button"
              onClick={onRestart}
              className="w-full min-h-[44px] flex items-center justify-center gap-2 bg-[#1b2129] hover:bg-[#242b35] border border-stone-600 text-stone-100 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>YENİDƏN BAŞLA</span>
            </button>

            {hud.gameMode === 'campaign' && (
              <div className="bg-[#161b22] border border-stone-700/80 p-2.5 rounded-sm">
                <div className="flex items-center justify-between text-[10px] font-semibold tracking-wider text-stone-400 mb-1.5">
                  <span>BÖLÜM KEÇİDİ</span>
                  {hud.wave < MAX_STORY_WAVES && (
                    <button
                      type="button"
                      data-testid="next-chapter-btn"
                      onClick={() => onSwitchChapter(hud.wave + 1)}
                      className="text-amber-400 hover:text-amber-300 font-mono-num cursor-pointer"
                    >
                      NÖVBƏTİ: F{String(hud.wave + 1).padStart(2, '0')} →
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-5 gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((ch) => (
                    <button
                      key={ch}
                      type="button"
                      data-pause-chapter={ch}
                      onClick={() => onSwitchChapter(ch)}
                      className={`min-h-[30px] border rounded-sm font-mono-num font-bold text-xs cursor-pointer transition-colors ${
                        hud.wave === ch
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-[#12161b] border-stone-700 text-stone-300 hover:border-stone-500'
                      }`}
                    >
                      F{String(ch).padStart(2, '0')}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={onTitle}
              className="w-full min-h-[46px] flex items-center justify-center gap-2 bg-transparent hover:bg-stone-800/70 border border-stone-700 text-stone-300 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>ANA MENYU</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (hud.phase === 'gameover') {
    const isVictory = hud.outcome === 'victory';
    const isSurvival = hud.gameMode === 'survival';
    const isSpecOps = hud.gameMode === 'spec_ops';
    const isFiringRange = hud.gameMode === 'firing_range';
    const accuracy = computeAccuracyPct(hud.shotsFired, hud.shotsHit);

    return (
      <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
        <div className="w-full max-w-md max-h-[92vh] overflow-y-auto bg-[#12161b] border border-stone-600/90 p-5 sm:p-6 rounded-sm shadow-2xl">
          <div className="flex items-center justify-between gap-2 text-xs font-bold tracking-widest mb-1">
            <span className={isVictory ? 'text-amber-400' : 'text-red-400'}>
              {isSurvival
                ? 'ZOMBİ / SAĞQALMA REJİMİ BİTDİ'
                : isSpecOps
                  ? isVictory
                    ? 'SPEC OPS ƏMƏLİYYATI TAMAMLANDI'
                    : 'SPEC OPS UĞURSUZ OLDU'
                  : isFiringRange
                    ? 'TƏLİM POLİQONU SESİYASI'
                    : isVictory
                      ? 'ƏMƏLİYYAT DƏMİR KÖLGƏ TAMAMLANDI'
                      : 'ƏMƏLİYYAT DAYANDI'}
            </span>
            <span className="text-sky-300 font-mono-num">
              {DIFFICULTY_SPECS[hud.selectedDifficulty].name.toUpperCase()}
            </span>
          </div>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-stone-100 tracking-wide mb-2">
            {isSpecOps
              ? isVictory
                ? 'A & B BOMBALARI ZƏRƏRSİZLƏŞDİRİLDİ'
                : 'BOMBA PARTLADI'
              : isVictory
                ? hud.wave >= 10
                  ? 'SİNDİKAT LİDERİ ZƏRƏRSİZLƏŞDİRİLDİ'
                  : 'KOMANDİR XƏNCƏR ZƏRƏRSİZLƏŞDİRİLDİ'
                : 'MƏĞLUBİYYƏT'}
          </h2>
          {isVictory && (
            hud.gameMode === 'campaign' && hud.activeEnding ? (
              <div
                data-testid="ending-dossier-card"
                className="bg-[#161c24] border border-amber-500/75 p-3.5 rounded-sm mb-4 space-y-1.5"
              >
                <div className="flex items-center justify-between gap-2 text-[10px] font-mono-num font-bold">
                  <span className="text-amber-400">SONLUQ · {hud.unlockedEndingIds.length}/3 AÇILDI</span>
                  <span className="text-sky-300">DƏSTƏ GÜVƏNİ: {hud.squadTrust}%</span>
                </div>
                <div className="font-display font-bold text-base text-stone-100">
                  {hud.activeEnding.title}
                </div>
                <div className="text-xs font-semibold text-amber-300">
                  {hud.activeEnding.subtitle}
                </div>
                <p className="text-xs text-stone-300 leading-relaxed">
                  {hud.activeEnding.epilogue}
                </p>
              </div>
            ) : (
              <p className="text-xs sm:text-sm text-stone-300 mb-4 leading-relaxed">
                {isSpecOps
                  ? 'Hər iki strateji bomba vaxtında zərərsizləşdirildi və komanda bölgədən təxliyə olundu.'
                  : 'Bütün düşmən müqaviməti qırıldı və sektor azad edildi. İstəsəniz Sonsuz Müdafiə rejimində rekordu artırın.'}
              </p>
            )
          )}

          <div className="grid grid-cols-3 gap-2.5 mb-3">
            <div className="bg-[#181d24] border border-stone-700/80 p-3 rounded-sm">
              <div className="text-[11px] text-stone-400 font-semibold">
                {isSurvival ? 'DALĞA' : isSpecOps ? 'REJİM' : 'FƏSİL'}
              </div>
              <div className="font-mono-num font-bold text-xl text-amber-400 mt-0.5">
                {isSurvival ? hud.wave : isSpecOps ? 'A/B' : `${hud.wave}/${hud.maxWaves}`}
              </div>
            </div>
            <div className="bg-[#181d24] border border-stone-700/80 p-3 rounded-sm">
              <div className="text-[11px] text-stone-400 font-semibold">MƏHV EDİLƏN</div>
              <div className="font-mono-num font-bold text-xl text-stone-100 mt-0.5">
                {hud.kills}
              </div>
            </div>
            <div className="bg-[#181d24] border border-stone-700/80 p-3 rounded-sm">
              <div className="text-[11px] text-stone-400 font-semibold">DƏQİQLİK</div>
              <div className="font-mono-num font-bold text-xl text-sky-300 mt-0.5">
                {accuracy}%
              </div>
            </div>
          </div>

          {/* Medals & Intel Summary Strip */}
          <div className="grid grid-cols-2 gap-2.5 mb-3 text-xs font-mono-num">
            <div className="bg-[#161b22] border border-stone-700/80 px-3 py-2 rounded-sm flex items-center justify-between">
              <span className="text-stone-400">MEDALLAR</span>
              <span className="text-amber-300 font-bold">
                {hud.unlockedMedalIds.length}/{MEDAL_LIST.length}
              </span>
            </div>
            <div className="bg-[#161b22] border border-stone-700/80 px-3 py-2 rounded-sm flex items-center justify-between">
              <span className="text-stone-400">
                {isSurvival ? 'QALAN KREDİT' : 'INTEL'}
              </span>
              <span className="text-emerald-300 font-bold">
                {isSurvival ? `$${hud.credits}` : `${hud.collectedIntelIds.length}/${INTEL_SPECS.length}`}
              </span>
            </div>
          </div>

          {/* Rank & XP Progression Summary */}
          <div className="bg-[#181d24] border border-stone-700/80 p-3 rounded-sm mb-4">
            <div className="flex items-center justify-between gap-2 text-xs font-mono-num mb-1.5">
              <span className="flex items-center gap-1.5 text-stone-100 font-semibold">
                <Award className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  RÜTBƏ {hud.rankInfo.level} · {hud.rankInfo.title.toUpperCase()}
                </span>
              </span>
              <span className="text-amber-300 font-semibold">
                {hud.rankInfo.xp} / {hud.rankInfo.nextLevelXp} XP
              </span>
            </div>
            <div className="h-1.5 bg-stone-800 overflow-hidden">
              <div
                className="h-full bg-amber-400 transition-all duration-200"
                style={{ width: `${hud.rankInfo.progressPct}%` }}
              />
            </div>
          </div>

          <div className="flex items-baseline justify-between border-t border-b border-stone-700/80 py-3 mb-5">
            <div>
              <div className="text-xs text-stone-400">ÜMUMİ XAL</div>
              <div className="font-mono-num font-bold text-2xl text-stone-100">{hud.score}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-stone-400">REKORD</div>
              <div className="font-mono-num font-bold text-xl text-amber-400">{hud.bestScore}</div>
            </div>
          </div>

          <div className="flex flex-col gap-2.5">
            {!isVictory && !isSurvival && hud.campaignPace === 'marathon' && hud.chapterTotalStages > 1 && (
              <button
                type="button"
                data-testid="checkpoint-restart-btn"
                onClick={onRestartCheckpoint}
                className="w-full min-h-[48px] flex items-center justify-center gap-2 bg-sky-500 hover:bg-sky-400 text-stone-950 font-display font-bold text-sm sm:text-base tracking-wider rounded-sm transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>
                  YOXLAMA NÖQTƏSİNDƏN DAVAM ({hud.checkpointStage}/{hud.chapterTotalStages})
                </span>
              </button>
            )}

            {isVictory && (
              <button
                type="button"
                onClick={onContinueEndless}
                className="w-full min-h-[48px] flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-display font-bold text-base tracking-wider rounded-sm transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>SONSUZ DALĞAYA DAVAM</span>
              </button>
            )}

            <button
              type="button"
              data-start="true"
              onClick={onRestart}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-base tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>YENİDƏN OYNA</span>
            </button>

            <button
              type="button"
              onClick={onOpenLeaderboard}
              className="w-full min-h-[46px] flex items-center justify-center gap-2 bg-[#181e26] hover:bg-[#212934] border border-stone-600 text-amber-300 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Trophy className="w-4 h-4" />
              <span>LİDERLƏR CƏDVƏLİ</span>
            </button>

            <button
              type="button"
              onClick={onTitle}
              className="w-full min-h-[46px] flex items-center justify-center gap-2 bg-transparent hover:bg-stone-800/70 border border-stone-700 text-stone-300 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>ANA MENYU</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
