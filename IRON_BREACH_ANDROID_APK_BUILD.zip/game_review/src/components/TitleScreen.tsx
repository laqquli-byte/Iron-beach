import React from 'react';
import type { User } from 'firebase/auth';
import {
  Award,
  BookOpen,
  Check,
  Cloud,
  Crosshair,
  Play,
  ShieldCheck,
  Skull,
  Sliders,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  DIFFICULTY_LIST,
  DIFFICULTY_SPECS,
  FIELD_UPGRADE_LIST,
  FIELD_UPGRADE_SPECS,
  getChapterCanonLoadout,
  getWeaponShortName,
  MAX_STORY_WAVES,
  PERK_SPECS,
  resolveModeStartLabel,
  WEAPON_CAMOS,
  WEAPON_LIST,
  WEAPON_SPECS,
} from '../game/rules';
import type {
  AttachmentId,
  CampaignPace,
  DifficultyId,
  FieldUpgradeId,
  GameMode,
  PerkId,
  RankInfo,
  WeaponCamoId,
  WeaponId,
} from '../game/types';

interface TitleScreenProps {
  gameMode: GameMode;
  onSelectGameMode: (mode: GameMode) => void;
  selectedWeapon: WeaponId;
  onSelectWeapon: (weapon: WeaponId) => void;
  selectedChapter: number;
  unlockedChapter: number;
  onSelectChapter: (chapter: number) => void;
  campaignPace: CampaignPace;
  onSelectCampaignPace: (pace: CampaignPace) => void;
  selectedDifficulty: DifficultyId;
  onSelectDifficulty: (difficulty: DifficultyId) => void;
  selectedFieldUpgrade: FieldUpgradeId;
  onSelectFieldUpgrade: (id: FieldUpgradeId) => void;
  selectedPerk: PerkId;
  equippedAttachments: Record<WeaponId, AttachmentId[]>;
  equippedCamos: Record<WeaponId, WeaponCamoId>;
  rankInfo: RankInfo;
  cloudUser: User | null;
  onOpenArsenal: () => void;
  onOpenLeaderboard: () => void;
  onStart: () => void;
  bestScore: number;
  muted: boolean;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  canonLoadoutEnabled: boolean;
  onToggleCanonLoadout: () => void;
  unlockedEndingsCount: number;
  collectedIntelCount: number;
  totalIntelCount: number;
  onOpenStoryArchive: () => void;
}

const CHAPTER_SHORT_NAMES = [
  'Qulaq Kəsmə',
  'Səssiz Sızma',
  'Zirehli Təzyiq',
  'Son Xəbərdarlıq',
  'Gecə Hücumu',
  'Yeraltı Bunker',
  'Neft Platforması',
  'Qədim Məbəd',
  'Hava Limanı',
  'Sindikat Qərargahı',
];

export const TitleScreen: React.FC<TitleScreenProps> = ({
  gameMode,
  onSelectGameMode,
  selectedWeapon,
  onSelectWeapon,
  selectedChapter,
  unlockedChapter,
  onSelectChapter,
  campaignPace,
  onSelectCampaignPace,
  selectedDifficulty,
  onSelectDifficulty,
  selectedFieldUpgrade,
  onSelectFieldUpgrade,
  selectedPerk,
  equippedAttachments,
  equippedCamos,
  rankInfo,
  cloudUser,
  onOpenArsenal,
  onOpenLeaderboard,
  onStart,
  bestScore,
  muted,
  onToggleMute,
  onOpenSettings,
  canonLoadoutEnabled,
  onToggleCanonLoadout,
  unlockedEndingsCount,
  collectedIntelCount,
  totalIntelCount,
  onOpenStoryArchive,
}) => {
  const activeCamo = WEAPON_CAMOS[equippedCamos[selectedWeapon] ?? 'standard'];
  const activeAttCount = (equippedAttachments[selectedWeapon] ?? []).length;
  const [canonPrimary, canonSecondary] = getChapterCanonLoadout(selectedChapter);

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between pointer-events-none">
      {/* Contrast scrims over 3D flyover leaving center-right world vista clear */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(11,13,16,0.92) 0%, rgba(11,13,16,0.62) 50%, rgba(11,13,16,0.12) 100%), linear-gradient(180deg, rgba(11,13,16,0.48) 0%, rgba(11,13,16,0) 26%, rgba(11,13,16,0.88) 100%)',
        }}
      />

      {/* Top minimal utility strip */}
      <div className="relative z-10 flex items-center justify-between px-4 pt-2.5 sm:px-8 sm:pt-4 shrink-0">
        <div className="flex items-center gap-2 text-[11px] sm:text-xs tracking-wider text-stone-300 font-mono-num hud-stroke truncate">
          <span>QALA-04 · DƏMİR KÖLGƏ</span>
          {bestScore > 0 && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-amber-400">REKORD {bestScore}</span>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenSettings();
            }}
            aria-label="Ayarlar"
            className="pointer-events-auto min-w-[40px] min-h-[40px] sm:min-w-[44px] sm:min-h-[44px] flex items-center justify-center bg-[#14171c]/90 border border-stone-700/80 text-stone-200 hover:border-amber-500 hover:text-amber-400 transition-colors rounded-sm cursor-pointer shrink-0"
          >
            <Sliders className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            aria-label={muted ? 'Səsi aç' : 'Səsi bağla'}
            className="pointer-events-auto min-w-[40px] min-h-[40px] sm:min-w-[44px] sm:min-h-[44px] flex items-center justify-center bg-[#14171c]/90 border border-stone-700/80 text-stone-200 hover:border-amber-500 hover:text-amber-400 transition-colors rounded-sm cursor-pointer shrink-0"
          >
            {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Main scrollable-safe tactical panel */}
      <div className="relative z-10 px-4 sm:px-10 max-w-2xl my-auto overflow-y-auto max-h-[calc(100vh-88px)] py-1">
        {/* Bespoke inline SVG tactical emblem & lockup */}
        <div className="mb-1 sm:mb-2">
          <svg
            viewBox="0 0 360 88"
            className="w-36 sm:w-56 h-auto overflow-visible"
            aria-label="IRON BREACH"
          >
            <g fill="none" stroke="#f59e0b" strokeWidth="2.2">
              <path d="M10 18 L28 6 L46 18 L46 52 L28 68 L10 52 Z" fill="rgba(20,23,28,0.85)" />
              <circle cx="28" cy="35" r="9" stroke="#f4f1ea" strokeWidth="2" />
              <line x1="28" y1="20" x2="28" y2="29" stroke="#f59e0b" />
              <line x1="28" y1="41" x2="28" y2="50" stroke="#f59e0b" />
              <line x1="13" y1="35" x2="22" y2="35" stroke="#f59e0b" />
              <line x1="34" y1="35" x2="43" y2="35" stroke="#f59e0b" />
            </g>
            <text
              x="62"
              y="41"
              fill="#f4f1ea"
              fontFamily="'Chakra Petch', sans-serif"
              fontWeight="700"
              fontSize="37"
              letterSpacing="2"
            >
              IRON BREACH
            </text>
            <line x1="62" y1="50" x2="316" y2="50" stroke="#f59e0b" strokeWidth="2" />
            <text
              x="62"
              y="69"
              fill="#d6d3d1"
              fontFamily="'Plus Jakarta Sans', sans-serif"
              fontWeight="600"
              fontSize="12"
              letterSpacing="2.8"
            >
              ƏMƏLİYYAT: DƏMİR KÖLGƏ
            </text>
          </svg>
        </div>

        {/* Rank & XP slim progress strip */}
        <div
          data-testid="title-rank-bar"
          className="mb-1.5 sm:mb-2 max-w-md bg-[#12161b]/88 border border-stone-700/80 px-2.5 py-1 rounded-sm"
        >
          <div className="flex items-center justify-between gap-2 text-[11px] font-mono-num">
            <span className="flex items-center gap-1.5 text-stone-100 font-semibold">
              <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                RÜTBƏ {rankInfo.level} · {rankInfo.title.toUpperCase()}
              </span>
            </span>
            <span className="text-amber-300 font-semibold">{rankInfo.xp} XP</span>
          </div>
          <div className="h-1 bg-stone-800 mt-1 overflow-hidden">
            <div
              className="h-full bg-amber-400 transition-all duration-200"
              style={{ width: `${rankInfo.progressPct}%` }}
            />
          </div>
        </div>

        {/* Mode Switcher: Featured Story Campaign + 3 Secondary Modes */}
        <div className="mb-1.5 sm:mb-2 pointer-events-auto max-w-md space-y-1.5">
          <button
            type="button"
            data-testid="mode-campaign-btn"
            aria-pressed={gameMode === 'campaign'}
            onClick={() => onSelectGameMode('campaign')}
            className={`w-full px-3 py-2 border rounded-sm text-left transition-colors cursor-pointer flex items-center justify-between gap-3 ${
              gameMode === 'campaign'
                ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
            }`}
          >
            <div className="min-w-0">
              <div className="font-display font-bold text-xs sm:text-sm text-amber-400 tracking-wide truncate">
                HEKAYƏ KAMPANİYASI · ƏSAS REJİM
              </div>
              <div className="text-[10px] text-stone-300 truncate">
                10 Fəsil · Süjet Seçimləri · 3 Sonluq · 10 Gizli Məlumat
              </div>
            </div>
            <span className="font-mono-num text-[10px] font-bold text-amber-300 border border-amber-500/50 bg-amber-500/10 px-2 py-0.5 rounded-xs shrink-0">
              SP SÜJET
            </span>
          </button>

          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              data-testid="mode-survival-btn"
              aria-pressed={gameMode === 'survival'}
              onClick={() => onSelectGameMode('survival')}
              className={`px-2 py-1.5 border rounded-sm text-left min-h-[36px] transition-colors cursor-pointer ${
                gameMode === 'survival'
                  ? 'bg-[#17221d]/95 border-emerald-400 text-stone-100'
                  : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
              }`}
            >
              <div className="flex items-center gap-1 font-display font-bold text-[10px] sm:text-xs text-emerald-400 truncate">
                <Skull className="w-3 h-3 shrink-0" />
                <span>SAĞQALMA</span>
              </div>
              <div className="text-[8px] sm:text-[9px] text-stone-400 truncate">
                Dalğa · Mağaza [B]
              </div>
            </button>

            <button
              type="button"
              data-testid="mode-firing-range-btn"
              aria-pressed={gameMode === 'firing_range'}
              onClick={() => onSelectGameMode('firing_range')}
              className={`px-2 py-1.5 border rounded-sm text-left min-h-[36px] transition-colors cursor-pointer ${
                gameMode === 'firing_range'
                  ? 'bg-[#1f1a14]/95 border-orange-400 text-stone-100'
                  : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
              }`}
            >
              <div className="flex items-center gap-1 font-display font-bold text-[10px] sm:text-xs text-orange-400 truncate">
                <Crosshair className="w-3 h-3 shrink-0" />
                <span>POLİQON</span>
              </div>
              <div className="text-[8px] sm:text-[9px] text-stone-400 truncate">
                9 Silah Sınağı
              </div>
            </button>

            <button
              type="button"
              data-testid="mode-spec-ops-btn"
              aria-pressed={gameMode === 'spec_ops'}
              onClick={() => onSelectGameMode('spec_ops')}
              className={`px-2 py-1.5 border rounded-sm text-left min-h-[36px] transition-colors cursor-pointer ${
                gameMode === 'spec_ops'
                  ? 'bg-[#1a1524]/95 border-purple-400 text-stone-100'
                  : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
              }`}
            >
              <div className="font-display font-bold text-[10px] sm:text-xs text-purple-400 truncate">
                SPEC OPS
              </div>
              <div className="text-[8px] sm:text-[9px] text-stone-400 truncate">
                A / B Bomba
              </div>
            </button>
          </div>
        </div>

        {/* Campaign Chapter & Pace Selectors OR Survival Brief */}
        {gameMode === 'campaign' ? (
          <>
            <div className="mb-1.5 sm:mb-2 pointer-events-auto">
              <div className="flex items-center justify-between gap-2 mb-0.5">
                <span className="text-[10px] sm:text-[11px] font-semibold tracking-wider text-stone-400 hud-stroke">
                  FƏSİL SEÇİMİ
                </span>
                <span className="text-[10px] sm:text-[11px] font-mono-num text-emerald-400/90 hud-stroke">
                  {MAX_STORY_WAVES}/{MAX_STORY_WAVES} BÖLÜM AÇIQ
                </span>
              </div>
              <div className="grid grid-cols-5 gap-1">
                {CHAPTER_SHORT_NAMES.map((name, idx) => {
                  const ch = idx + 1;
                  const cleared = ch < unlockedChapter;
                  const active = selectedChapter === ch;
                  return (
                    <button
                      key={ch}
                      type="button"
                      data-chapter={ch}
                      aria-pressed={active}
                      onClick={() => onSelectChapter(ch)}
                      className={`px-1 py-1 border rounded-sm text-center min-h-[34px] transition-colors cursor-pointer ${
                        active
                          ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                          : cleared
                            ? 'bg-[#131a17]/90 border-emerald-600/60 text-stone-200 hover:border-amber-400'
                            : 'bg-[#121519]/88 border-stone-700/80 text-stone-300 hover:border-stone-500'
                      }`}
                    >
                      <div className="flex items-center justify-center gap-0.5 text-[10px] font-mono-num font-bold">
                        {cleared && <Check className="w-2.5 h-2.5 text-emerald-400 shrink-0" />}
                        <span className={active ? 'text-amber-400' : ''}>
                          F{String(ch).padStart(2, '0')}
                        </span>
                      </div>
                      <div className="text-[8px] sm:text-[9px] leading-tight truncate text-stone-400">
                        {name}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mb-1.5 sm:mb-2 pointer-events-auto">
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  data-pace="marathon"
                  aria-pressed={campaignPace === 'marathon'}
                  onClick={() => onSelectCampaignPace('marathon')}
                  className={`px-2 py-1 border rounded-sm text-left min-h-[34px] transition-colors cursor-pointer ${
                    campaignPace === 'marathon'
                      ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                      : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-[11px] sm:text-xs text-amber-400 whitespace-nowrap">
                      CoD Epik
                    </span>
                    <span className="text-[9px] font-mono-num text-emerald-300 whitespace-nowrap">
                      4 Mərhələ
                    </span>
                  </div>
                  <div className="text-[9px] text-stone-400 truncate">
                    Səhnələr · Yoxlama nöqtəli
                  </div>
                </button>

                <button
                  type="button"
                  data-pace="standard"
                  aria-pressed={campaignPace === 'standard'}
                  onClick={() => onSelectCampaignPace('standard')}
                  className={`px-2 py-1 border rounded-sm text-left min-h-[34px] transition-colors cursor-pointer ${
                    campaignPace === 'standard'
                      ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                      : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-[11px] sm:text-xs whitespace-nowrap">
                      Sürətli
                    </span>
                    <span className="text-[9px] font-mono-num text-stone-400 whitespace-nowrap">
                      1 Mərhələ
                    </span>
                  </div>
                  <div className="text-[9px] text-stone-400 truncate">
                    Birbaşa əsas hədəf
                  </div>
                </button>
              </div>
            </div>

            {/* Canon Chapter Loadout Toggle + Story Dossier Archive Button */}
            <div className="mb-1.5 sm:mb-2 pointer-events-auto grid grid-cols-2 gap-1.5 max-w-md">
              <button
                type="button"
                data-testid="canon-loadout-toggle"
                aria-pressed={canonLoadoutEnabled}
                onClick={onToggleCanonLoadout}
                className={`px-2 py-1.5 border rounded-sm text-left transition-colors cursor-pointer ${
                  canonLoadoutEnabled
                    ? 'bg-[#161f24]/95 border-sky-400 text-stone-100'
                    : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="inline-flex items-center gap-1 font-display font-bold text-[10px] sm:text-[11px] text-sky-300 truncate">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>Süjet Silahı (Canon)</span>
                  </span>
                  <span
                    className={`font-mono-num text-[9px] font-bold shrink-0 ${
                      canonLoadoutEnabled ? 'text-emerald-300' : 'text-stone-400'
                    }`}
                  >
                    {canonLoadoutEnabled ? 'AÇIQ' : 'BAĞLI'}
                  </span>
                </div>
                <div className="text-[8px] sm:text-[9px] font-mono-num text-stone-400 truncate">
                  {canonLoadoutEnabled
                    ? `F${String(selectedChapter).padStart(2, '0')}: ${getWeaponShortName(canonPrimary)} + ${getWeaponShortName(canonSecondary)}`
                    : 'Sərbəst silah seçimi aktivdir'}
                </div>
              </button>

              <button
                type="button"
                data-testid="open-story-archive-btn"
                onClick={(e) => {
                  e.currentTarget.blur();
                  onOpenStoryArchive();
                }}
                className="px-2 py-1.5 border border-amber-500/60 hover:border-amber-400 bg-[#171b22]/95 hover:bg-[#1e242e] rounded-sm text-left transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-1 font-display font-bold text-[10px] sm:text-[11px] text-amber-300 truncate">
                  <BookOpen className="w-3.5 h-3.5 shrink-0" />
                  <span>HEKAYƏ ARXİVİ</span>
                </div>
                <div className="text-[8px] sm:text-[9px] font-mono-num text-stone-300 truncate">
                  {unlockedEndingsCount}/3 Sonluq · {collectedIntelCount}/{totalIntelCount} Məlumat
                </div>
              </button>
            </div>
          </>
        ) : gameMode === 'firing_range' ? (
          <div className="mb-2 max-w-md bg-[#1a1510]/90 border border-orange-500/45 px-3 py-2 rounded-sm">
            <div className="text-xs font-display font-bold text-orange-300">
              TƏLİM POLİQONU · DƏQİQLİK SINAĞI
            </div>
            <p className="text-[10px] sm:text-[11px] text-stone-300 leading-snug mt-0.5">
              15m, 30m hərəkətli və 45m zirehli hədəflərdə bütün 9 silahı limitsiz sursatla test edin və rekordu yeniləyin.
            </p>
          </div>
        ) : gameMode === 'spec_ops' ? (
          <div className="mb-2 max-w-md bg-[#161220]/90 border border-purple-500/45 px-3 py-2 rounded-sm">
            <div className="text-xs font-display font-bold text-purple-300">
              SPEC OPS · BOMBA ZƏRƏRSİZLƏŞDİRMƏ
            </div>
            <p className="text-[10px] sm:text-[11px] text-stone-300 leading-snug mt-0.5">
              120 saniyə ərzində A və B bombalarına yaxınlaşıb [E] basılı tutun. Düşmən dəstələri saytları qoruyur!
            </p>
          </div>
        ) : (
          <div className="mb-2 max-w-md bg-[#111916]/90 border border-emerald-500/45 px-3 py-2 rounded-sm">
            <div className="text-xs font-display font-bold text-emerald-300">
              SAĞQALMA REJİMİ · DALĞA ARTIŞI
            </div>
            <p className="text-[10px] sm:text-[11px] text-stone-300 leading-snug mt-0.5">
              Hər məhv $ Kredit qazandırır. [B] düyməsi ilə Mağazadan Avto-Turet, Juggernaut Zireh, C4 və AC-130 Gunship alın!
            </p>
          </div>
        )}

        {/* Field Upgrade Selector [O] */}
        <div className="mb-1.5 sm:mb-2 pointer-events-auto">
          <div className="text-[10px] sm:text-[11px] font-semibold tracking-wider text-stone-400 mb-1 hud-stroke">
            TAKTİKİ VASİTƏ [O]
          </div>
          <div className="grid grid-cols-3 gap-1.5 max-w-md">
            {FIELD_UPGRADE_LIST.map((fuId) => {
              const spec = FIELD_UPGRADE_SPECS[fuId];
              const active = selectedFieldUpgrade === fuId;
              return (
                <button
                  key={fuId}
                  type="button"
                  data-field-upgrade={fuId}
                  aria-pressed={active}
                  onClick={() => onSelectFieldUpgrade(fuId)}
                  className={`px-2 py-1 border rounded-sm text-left min-h-[34px] transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#17202a]/95 border-cyan-400 text-stone-100'
                      : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-[11px] truncate text-cyan-300">
                      {spec.shortName}
                    </span>
                    <span className="text-[9px] font-mono-num text-stone-400 shrink-0">
                      {spec.cooldownSec}s
                    </span>
                  </div>
                  <div className="text-[8px] sm:text-[9px] text-stone-400 truncate">
                    {spec.description}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Difficulty Selector */}
        <div className="mb-1.5 sm:mb-2 pointer-events-auto">
          <div className="grid grid-cols-3 gap-1.5">
            {DIFFICULTY_LIST.map((diffId) => {
              const spec = DIFFICULTY_SPECS[diffId];
              const active = selectedDifficulty === diffId;
              return (
                <button
                  key={diffId}
                  type="button"
                  data-difficulty={diffId}
                  aria-pressed={active}
                  onClick={() => onSelectDifficulty(diffId)}
                  className={`px-2 py-1 border rounded-sm text-left min-h-[34px] transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                      : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-[11px] sm:text-xs">
                      {spec.name}
                    </span>
                    <span className="text-[9px] font-mono-num text-amber-400 font-semibold">
                      {spec.xpMult}x XP
                    </span>
                  </div>
                  <div className="text-[8px] sm:text-[9px] text-stone-400 truncate">
                    {spec.minimalHud ? 'Minimal HUD' : `Zərər ${Math.round(spec.enemyDamageScale * 100)}%`}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 9-Weapon Compact Loadout Selector */}
        <div className="mb-2 pointer-events-auto">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-[10px] sm:text-[11px] font-semibold tracking-wider text-stone-400 hud-stroke">
              {gameMode === 'campaign' && canonLoadoutEnabled
                ? `SÜJET SİLAHI AKTİVDİR (F${String(selectedChapter).padStart(2, '0')}: ${getWeaponShortName(canonPrimary)} + ${getWeaponShortName(canonSecondary)})`
                : 'ƏSAS SİLAH SEÇİMİ (9 SİLAH)'}
            </span>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1">
            {WEAPON_LIST.map((id) => {
              const spec = WEAPON_SPECS[id];
              const active = selectedWeapon === id;
              const camoId = equippedCamos[id] ?? 'standard';
              const camo = WEAPON_CAMOS[camoId];
              const attCount = (equippedAttachments[id] ?? []).length;
              return (
                <button
                  key={id}
                  type="button"
                  data-weapon={id}
                  aria-pressed={active}
                  onClick={() => onSelectWeapon(id)}
                  className={`text-left px-1.5 py-1 border transition-colors rounded-sm min-h-[36px] cursor-pointer ${
                    active
                      ? 'bg-[#1a1f26]/95 border-amber-500 text-stone-100'
                      : 'bg-[#121519]/85 border-stone-700/75 text-stone-300 hover:border-stone-500'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display font-bold text-[11px] whitespace-nowrap truncate">
                      {getWeaponShortName(id)}
                    </span>
                    <div className="flex items-center gap-0.5 shrink-0">
                      <span
                        className="w-2 h-2 rounded-xs border border-stone-400/60 shrink-0"
                        style={{
                          background: `linear-gradient(135deg, ${camo.swatchHex} 50%, ${camo.accentHex} 50%)`,
                        }}
                        title={camo.name}
                      />
                      <Crosshair
                        className={`w-2.5 h-2.5 shrink-0 ${active ? 'text-amber-400' : 'text-stone-500'}`}
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-1 text-[8px] sm:text-[9px] text-stone-400">
                    <span className="truncate">{spec.role.split(' · ')[0]}</span>
                    {attCount > 0 && (
                      <span className="font-mono-num text-amber-400 font-bold shrink-0">
                        +{attCount}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-1 text-[10px] sm:text-[11px] text-stone-300 hud-stroke truncate">
            <span>
              Perk: <strong className="text-sky-300">{PERK_SPECS[selectedPerk].shortName}</strong>
            </span>
            <span className="mx-1.5 text-stone-500">·</span>
            <span>
              Boya: <strong className="text-amber-300">{activeCamo.shortName}</strong>
            </span>
            <span className="mx-1.5 text-stone-500">·</span>
            <span>
              Əlavələr: <strong className="text-stone-100">{activeAttCount}/4</strong>
            </span>
          </div>
        </div>

        {/* Primary Action Row */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 pointer-events-auto">
          <button
            type="button"
            data-start="true"
            onClick={(e) => {
              e.currentTarget.blur();
              onStart();
            }}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 font-display font-bold text-xs sm:text-sm tracking-wider rounded-sm transition-colors shadow-lg cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{resolveModeStartLabel(gameMode, selectedChapter)}</span>
          </button>

          <button
            type="button"
            data-testid="open-arsenal-btn"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenArsenal();
            }}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 min-h-[44px] bg-[#161b22]/95 hover:bg-[#1f2630] border border-stone-600 hover:border-amber-400 text-stone-100 font-display font-bold text-xs tracking-wider rounded-sm transition-colors shadow-lg cursor-pointer"
          >
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>CƏBBƏXANA</span>
          </button>

          <button
            type="button"
            data-testid="open-leaderboard-btn"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenLeaderboard();
            }}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 min-h-[44px] bg-[#161b22]/95 hover:bg-[#1f2630] border border-stone-600 hover:border-emerald-400 text-stone-100 font-display font-bold text-xs tracking-wider rounded-sm transition-colors shadow-lg cursor-pointer"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>LİDERLƏR</span>
            {cloudUser && <Cloud className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
          </button>
        </div>
      </div>

      {/* Bottom single-line flat control hint */}
      <div className="relative z-10 px-4 pb-2.5 sm:px-8 sm:pb-4 shrink-0">
        <p className="text-[10px] sm:text-xs text-stone-300/90 hud-stroke truncate">
          {gameMode === 'campaign'
            ? 'PC: WASD · Q Əyil · O Taktik · C Çök/Sürüş · H Stim · F Bıçaq/QTE · Z C4 · E Xilas/Təsir · [1/2] Qərar'
            : 'PC: WASD · Q Əyil · O Taktik · C Çök/Sürüş · H Stim/Qalx · J Paket · F Bıçaq · Z C4 · Y AC-130 · E Təsir'}
        </p>
      </div>
    </div>
  );
};
