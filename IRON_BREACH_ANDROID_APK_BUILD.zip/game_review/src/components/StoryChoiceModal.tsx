import React from 'react';
import { GitBranch, HeartHandshake, Radio } from 'lucide-react';
import type { StoryChoiceSpec } from '../game/types';

interface StoryChoiceModalProps {
  choice: StoryChoiceSpec;
  squadTrust: number;
  onSelectOption: (optionIndex: 0 | 1) => void;
}

export const StoryChoiceModal: React.FC<StoryChoiceModalProps> = ({
  choice,
  squadTrust,
  onSelectOption,
}) => {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="story-choice-title"
      data-testid="story-choice-modal"
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/82 p-4 pointer-events-auto"
    >
      <div className="w-full max-w-xl bg-[#12161b] border border-amber-500/75 p-5 sm:p-6 rounded-sm shadow-2xl">
        <div className="flex items-center justify-between gap-2 text-[11px] font-mono-num tracking-wider text-stone-400 mb-2">
          <span className="inline-flex items-center gap-1.5 text-amber-400 font-bold">
            <GitBranch className="w-3.5 h-3.5 shrink-0" />
            <span>FƏSİL {String(choice.chapter).padStart(2, '0')} · SÜJET QƏRARI</span>
          </span>
          <span className="inline-flex items-center gap-1.5 text-sky-300 font-bold">
            <HeartHandshake className="w-3.5 h-3.5 shrink-0" />
            <span>DƏSTƏ GÜVƏNİ: {squadTrust}%</span>
          </span>
        </div>

        <h2
          id="story-choice-title"
          className="font-display font-bold text-xl sm:text-2xl text-stone-100 tracking-wide mb-2"
        >
          {choice.title}
        </h2>

        <div className="bg-[#171c23] border border-stone-700/80 px-3.5 py-2.5 rounded-sm mb-4">
          <div className="flex items-center gap-1.5 text-[10px] font-mono-num font-bold text-amber-300 mb-1">
            <Radio className="w-3.5 h-3.5 shrink-0" />
            <span>{choice.speaker.toUpperCase()}</span>
            <span className="text-stone-400">· {choice.callsign}</span>
          </div>
          <p className="text-xs sm:text-sm text-stone-200 leading-relaxed">{choice.prompt}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {choice.options.map((opt, idx) => {
            const optionIndex = idx as 0 | 1;
            const trustPositive = opt.trustDelta >= 0;
            return (
              <button
                key={opt.index}
                type="button"
                data-testid={`story-choice-option-${idx + 1}`}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onSelectOption(optionIndex);
                }}
                className="text-left p-3.5 bg-[#161c24] hover:bg-[#1e2631] border border-stone-600 hover:border-amber-400 rounded-sm transition-colors flex flex-col justify-between gap-2.5 cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-mono-num text-[11px] font-bold text-amber-400">
                      [{idx + 1}] SEÇİM
                    </span>
                    <span
                      className={`font-mono-num text-[10px] font-bold ${
                        trustPositive ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {trustPositive ? `+${opt.trustDelta}` : opt.trustDelta} GÜVƏN
                    </span>
                  </div>
                  <div className="font-display font-bold text-sm sm:text-base text-stone-100 mb-1">
                    {opt.label}
                  </div>
                </div>

                <div className="pt-2 border-t border-stone-700/70 text-[10px] font-mono-num text-stone-300">
                  {opt.consequenceHint}
                </div>
              </button>
            );
          })}
        </div>

        <p className="mt-3 text-[11px] text-stone-400 font-mono-num text-center">
          Seçim etmək üçün klikləyin və ya klaviaturada [1] / [2] düyməsini basın
        </p>
      </div>
    </div>
  );
};
