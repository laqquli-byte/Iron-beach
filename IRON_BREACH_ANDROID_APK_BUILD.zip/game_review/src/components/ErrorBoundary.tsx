import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

function formatReadableError(raw: string): string {
  try {
    const parsed = JSON.parse(raw) as { error?: string; operationType?: string; path?: string };
    if (parsed && typeof parsed.error === 'string') {
      if (parsed.error.toLowerCase().includes('permission')) {
        return `Məlumat bazasına giriş icazəsi rədd edildi (${parsed.path || 'sistem'}).`;
      }
      return parsed.error;
    }
  } catch {
    // not JSON
  }
  return raw || 'Gözlənilməz tətbiq xətası baş verdi.';
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  public state: ErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: formatReadableError(error.message),
    };
  }

  public componentDidCatch(error: Error, info: React.ErrorInfo): void {
    console.error('UI ErrorBoundary caught:', error, info.componentStack);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div
          role="alert"
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d1115] p-6 text-stone-100"
        >
          <div className="w-full max-w-md bg-[#14191f] border border-red-500/70 p-6 rounded-sm shadow-2xl">
            <div className="flex items-center gap-2 text-red-400 font-display font-bold text-lg mb-2">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <span>TEXNİKİ XƏTA BAŞ VERDİ</span>
            </div>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed mb-5">
              {this.state.errorMessage}
            </p>
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, errorMessage: '' })}
              className="w-full min-h-[46px] flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>YENİDƏN CƏHD ET</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
