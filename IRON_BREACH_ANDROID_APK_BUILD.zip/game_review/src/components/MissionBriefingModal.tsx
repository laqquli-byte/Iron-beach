import React from 'react';
import { Crosshair, Home, Play, Radio, ShieldAlert, Target } from 'lucide-react';
import {
  ATTACHMENT_SPECS,
  DIFFICULTY_SPECS,
  ENEMY_SPECS,
  getChapterCanonLoadout,
  getChapterStageSpecs,
  getSetPieceLabel,
  getWaveBriefing,
  getWeaponShortName,
  MAX_STORY_WAVES,
  PERK_SPECS,
  WEAPON_SPECS,
} from '../game/rules';
import type { HudSnapshot } from '../game/types';

interface MissionBriefingModalProps {
  hud: HudSnapshot;
  onDeploy: () => void;
  onSwitchChapter: (chapter: number) => void;
  onTitle: () => void;
}

const THREAT_TEXT_CLASSES: Record<string, string> = {
  Aşağı: 'text-emerald-400',
  Orta: 'text-amber-400',
  Yüksək: 'text-orange-400',
  Kritik: 'text-red-400',
};

export const MissionBriefingModal: React.FC<MissionBriefingModalProps> = ({
  hud,
  onDeploy,
  onSwitchChapter,
  onTitle,
}) => {
  const briefing = getWaveBriefing(hud.wave, hud.campaignPace);
  const isCampaignCanon = hud.gameMode === 'campaign' && hud.canonLoadoutEnabled;
  const [canonPrimary, canonSecondary] = getChapterCanonLoadout(hud.wave);
  const firstStage = getChapterStageSpecs(hud.wave, hud.campaignPace)[0];
  const stageKindLabel = getSetPieceLabel(firstStage?.setPieceKind);
  const weaponName = isCampaignCanon
    ? `${getWeaponShortName(canonPrimary)} + ${getWeaponShortName(canonSecondary)}`
    : WEAPON_SPECS[hud.activeWeapon].name;
  const activeAttachments = hud.equippedAttachments[hud.activeWeapon] ?? [];
  const diffSpec = DIFFICULTY_SPECS[hud.selectedDifficulty];
  const perkSpec = PERK_SPECS[hud.selectedPerk];
  const threatColor = THREAT_TEXT_CLASSES[briefing.threatLevel] ?? 'text-amber-400';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="briefing-title"
      data-testid="mission-briefing-modal"
      className="fixed inset-0 z-30 flex items-center justify-center bg-black/78 p-4"
    >
      <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto bg-[#12161b] border border-stone-600/90 p-5 sm:p-6 rounded-sm shadow-2xl">
        {/* Top unboxed telemetry metadata row */}
        <div className="flex items-center justify-between gap-3 text-xs font-semibold tracking-wider text-stone-400 mb-1">
          <span className="truncate font-mono-num">
            {briefing.wave <= hud.maxWaves
              ? `FƏSİL ${String(briefing.wave).padStart(2, '0')} / ${String(hud.maxWaves).padStart(2, '0')}`
              : `DALĞA ${briefing.wave} · SONSUZ`}{' '}
            · {briefing.codeName}
          </span>
          <span className={`inline-flex items-center gap-1.5 shrink-0 ${threatColor}`}>
            <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{briefing.threatLevel}</span>
          </span>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-num text-amber-400/90 tracking-wider mb-1">
          <span>{briefing.locationTime}</span>
          <span className="text-sky-300">
            {hud.gameMode === 'campaign' ? `${stageKindLabel.toUpperCase()} · ` : ''}
            {diffSpec.name.toUpperCase()} · {perkSpec.shortName.toUpperCase()}
          </span>
        </div>

        <h2
          id="briefing-title"
          className="font-display font-bold text-2xl sm:text-3xl text-stone-100 tracking-wide mb-2.5"
        >
          {briefing.title}
        </h2>

        <p className="text-sm text-stone-300 leading-relaxed mb-3">
          {briefing.context}
        </p>

        {/* Story Squad Radio Dialogue */}
        <div
          data-testid="briefing-dialogue"
          className="border-l-2 border-amber-500 bg-[#171c23] px-3 py-2 rounded-r-sm mb-3.5 flex items-start gap-2"
        >
          <Radio className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-stone-200 leading-snug italic">
            {briefing.storyDialogue}
          </p>
        </div>

        {/* Wave telemetry summary */}
        <div className="grid grid-cols-3 gap-2 mb-3.5">
          <div className="bg-[#171c23] border border-stone-700/80 p-2.5 sm:p-3 rounded-sm">
            <div className="text-[11px] text-stone-400 font-semibold">DÜŞMƏN</div>
            <div className="font-mono-num font-bold text-lg sm:text-xl text-amber-400 mt-0.5">
              {briefing.enemyCount}
            </div>
          </div>
          <div className="bg-[#171c23] border border-stone-700/80 p-2.5 sm:p-3 rounded-sm">
            <div className="text-[11px] text-stone-400 font-semibold">MÜDAFİƏ</div>
            <div className="font-mono-num font-bold text-lg sm:text-xl text-stone-100 mt-0.5">
              {hud.hp}/{hud.armor}
            </div>
          </div>
          <div className="bg-[#171c23] border border-stone-700/80 p-2.5 sm:p-3 rounded-sm min-w-0">
            <div className="text-[11px] text-stone-400 font-semibold">
              {isCampaignCanon ? 'SÜJET SİLAHI' : 'SİLAH'}
            </div>
            <div className="font-display font-bold text-xs sm:text-base text-sky-300 mt-1 sm:mt-1 leading-tight truncate">
              {weaponName}
            </div>
            {isCampaignCanon ? (
              <div className="text-[10px] text-emerald-400/90 truncate mt-0.5">
                Canon Fəsil Təchizatı
              </div>
            ) : (
              activeAttachments.length > 0 && (
                <div className="text-[10px] text-stone-400 truncate mt-0.5">
                  {activeAttachments.map((id) => ATTACHMENT_SPECS[id].shortName).join(' · ')}
                </div>
              )
            )}
          </div>
        </div>

        {/* Objectives & Threat Roster */}
        <div className="bg-[#171c23] border border-stone-700/80 p-3.5 rounded-sm space-y-2.5 mb-4">
          <div className="flex items-start gap-2.5">
            <Target className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-semibold tracking-wider text-stone-400">
                  ƏSAS TAPŞIRIQ
                </span>
                <span className="text-[10px] font-mono-num text-amber-400">
                  {briefing.objectiveLabel}
                </span>
              </div>
              <div className="text-sm font-medium text-stone-100">
                {briefing.primaryObjective}
              </div>
            </div>
          </div>

          <div className="border-t border-stone-700/60 pt-2.5 flex items-start gap-2.5">
            <Crosshair className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <div className="min-w-0">
              <div className="text-[11px] font-semibold tracking-wider text-stone-400">
                TAKTİKİ MƏSLƏHƏT
              </div>
              <div className="text-sm text-stone-300">
                {briefing.tacticalObjective}
              </div>
            </div>
          </div>

          <div className="border-t border-stone-700/60 pt-2.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-xs">
            <span className="text-stone-400 font-semibold shrink-0">GÖZLƏNİLƏN QÜVVƏLƏR</span>
            <span className="text-stone-200 font-medium text-right">
              {briefing.expectedEnemyTypes.map((arch) => ENEMY_SPECS[arch].label).join(' · ')}
            </span>
          </div>
        </div>

        {/* Direct Chapter Switcher in Campaign Mode */}
        {hud.gameMode === 'campaign' && hud.wave <= MAX_STORY_WAVES && (
          <div className="mb-3">
            <div className="text-[10px] font-semibold tracking-wider text-stone-400 mb-1">
              DİGƏR BÖLÜMƏ KEÇ
            </div>
            <div className="grid grid-cols-5 gap-1">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((ch) => {
                const active = hud.wave === ch;
                return (
                  <button
                    key={ch}
                    type="button"
                    data-briefing-chapter={ch}
                    onClick={() => onSwitchChapter(ch)}
                    className={`min-h-[34px] py-1 border rounded-sm font-mono-num font-bold text-xs transition-colors cursor-pointer ${
                      active
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                        : 'bg-[#171c23] border-stone-700 text-stone-300 hover:border-stone-500'
                    }`}
                  >
                    F{String(ch).padStart(2, '0')}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            data-deploy="true"
            onClick={(e) => {
              e.currentTarget.blur();
              onDeploy();
            }}
            className="w-full min-h-[48px] flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-stone-950 font-display font-bold text-base tracking-wider rounded-sm transition-colors cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>ƏMƏLİYYATA BAŞLA</span>
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.currentTarget.blur();
              onTitle();
            }}
            className="w-full min-h-[44px] flex items-center justify-center gap-2 bg-transparent hover:bg-stone-800/70 border border-stone-700 text-stone-300 font-display font-bold text-sm tracking-wider rounded-sm transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>ANA MENYU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
