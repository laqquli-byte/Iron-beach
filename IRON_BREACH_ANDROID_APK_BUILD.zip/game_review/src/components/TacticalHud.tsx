import React, { useEffect, useRef, useState } from 'react';
import {
  Bomb,
  ChevronUp,
  Crosshair,
  Eye,
  Flame,
  Gamepad2,
  Medal,
  Pause,
  Plane,
  Radar,
  Radio,
  RotateCw,
  Shield,
  ShoppingCart,
  Sparkles,
  Swords,
  Target,
  Thermometer,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import {
  DIFFICULTY_SPECS,
  FIELD_UPGRADE_SPECS,
  getWeaponShortName,
  WEAPON_LIST,
  WEAPON_SPECS,
} from '../game/rules';
import type { HudSnapshot, WeaponId } from '../game/types';

interface TacticalHudProps {
  hud: HudSnapshot;
  muted: boolean;
  showTouchControls: boolean;
  onToggleTouchControls: () => void;
  onToggleMute: () => void;
  onPause: () => void;
  onToggleAutoFire: () => void;
  onToggleNvg: () => void;
  onToggleThermal: () => void;
  onMoveInput: (x: number, y: number) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onFireHeld: (held: boolean) => void;
  onToggleAds: () => void;
  onReload: () => void;
  onGrenade: () => void;
  onThrowFlashbang: () => void;
  onMelee: () => void;
  onTriggerC4: () => void;
  onPlaceClaymore: () => void;
  onInteract: () => void;
  onGunship: () => void;
  onCallCarePackage: () => void;
  onUseStim: () => void;
  onToggleCrouch: () => void;
  onInspectWeapon: () => void;
  onOpenBuyStation: () => void;
  onJump: () => void;
  onSlide: () => void;
  onUseArmorPlate: () => void;
  onTriggerUav: () => void;
  onKillstreak: () => void;
  onSwitchWeapon: (id: WeaponId) => void;
  onCycleLean: () => void;
  onActivateFieldUpgrade: () => void;
  onSelfRevive: () => void;
  onDefuseHeld: (held: boolean) => void;
  onResetFiringRange: () => void;
  onBossQteStrike: () => void;
}

const COMPASS_LABELS: Record<number, string> = {
  0: 'N',
  45: 'NE',
  90: 'E',
  135: 'SE',
  180: 'S',
  225: 'SW',
  270: 'W',
  315: 'NW',
};

const COMPASS_TICKS = Array.from({ length: 24 }, (_, i) => i * 15);

function getCardinalLabel(deg: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const idx = Math.round(((deg % 360) + 360) % 360 / 45) % 8;
  return dirs[idx];
}

export const TacticalHud: React.FC<TacticalHudProps> = ({
  hud,
  muted,
  showTouchControls,
  onToggleTouchControls,
  onToggleMute,
  onPause,
  onToggleAutoFire,
  onToggleNvg,
  onToggleThermal,
  onMoveInput,
  onLookDelta,
  onFireHeld,
  onToggleAds,
  onReload,
  onGrenade,
  onThrowFlashbang,
  onMelee,
  onTriggerC4,
  onPlaceClaymore,
  onInteract,
  onGunship,
  onCallCarePackage,
  onUseStim,
  onToggleCrouch,
  onInspectWeapon,
  onOpenBuyStation,
  onJump,
  onSlide,
  onUseArmorPlate,
  onTriggerUav,
  onKillstreak,
  onSwitchWeapon,
  onCycleLean,
  onActivateFieldUpgrade,
  onSelfRevive,
  onDefuseHeld,
  onResetFiringRange,
  onBossQteStrike,
}) => {
  const [ghostHp, setGhostHp] = useState(hud.hp);
  const [weaponDrawerOpen, setWeaponDrawerOpen] = useState(false);

  useEffect(() => {
    if (hud.hp >= ghostHp) {
      setGhostHp(hud.hp);
      return;
    }
    const timer = window.setTimeout(() => {
      setGhostHp(hud.hp);
    }, 380);
    return () => window.clearTimeout(timer);
  }, [hud.hp, ghostHp]);

  // Virtual Joystick state
  const joyRef = useRef<HTMLDivElement | null>(null);
  const joyPointerId = useRef<number | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });

  // Touch Look Pad state
  const lookPointerId = useRef<number | null>(null);
  const lookLastPos = useRef({ x: 0, y: 0 });

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = joyRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.38;

    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    setKnobOffset({ x: dx, y: dy });
    onMoveInput(dx / maxR, -dy / maxR);
  };

  const resetJoystick = () => {
    joyPointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    onMoveInput(0, 0);
  };

  const hpPct = Math.max(0, Math.min(100, (hud.hp / hud.maxHp) * 100));
  const ghostPct = Math.max(hpPct, Math.min(100, (ghostHp / hud.maxHp) * 100));
  const armorPct = Math.max(0, Math.min(100, (hud.armor / hud.maxArmor) * 100));
  const plateReady = hud.armorPlates > 0 && hud.armor < hud.maxArmor;
  const minimalHud = DIFFICULTY_SPECS[hud.selectedDifficulty].minimalHud;
  const isSniperScoped = hud.activeWeapon === 'msr' && hud.isAds && !hud.gunshipActive;
  const uavActive = hud.uavActiveTimer > 0;
  const isCampaign = hud.gameMode === 'campaign';
  const isSurvival = hud.gameMode === 'survival';
  const isFiringRange = hud.gameMode === 'firing_range';
  const isSpecOps = hud.gameMode === 'spec_ops';
  const activeFieldUpgradeSpec = FIELD_UPGRADE_SPECS[hud.fieldUpgrade];

  // Radar blip transform helper (world to player-local space)
  const cosYaw = Math.cos(-hud.playerYaw);
  const sinYaw = Math.sin(-hud.playerYaw);

  const wpColor =
    hud.objectiveWaypoint?.kind === 'uplink'
      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300'
      : hud.objectiveWaypoint?.kind === 'hold'
        ? 'border-amber-400 bg-amber-500/20 text-amber-300'
        : 'border-red-400 bg-red-500/20 text-red-300';

  const objectiveBarColor =
    hud.objectiveStage === 'boss' || hud.objectiveWaypoint?.kind === 'jammer'
      ? 'bg-red-500'
      : hud.objectiveStage === 'done'
        ? 'bg-emerald-400'
        : 'bg-amber-400';

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none overflow-hidden">
      {/* Night Vision Goggles (NVG) Phosphor Tint & Vignette */}
      {hud.isNvgActive && !hud.thermalActive && (
        <div
          data-testid="nvg-overlay"
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at center, rgba(16,185,129,0.14) 36%, rgba(2,28,16,0.72) 100%)',
            boxShadow: 'inset 0 0 90px rgba(4,40,22,0.75)',
          }}
        />
      )}

      {/* Thermal Optic Overlay [T] */}
      {hud.thermalActive && (
        <div
          data-testid="thermal-overlay"
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at center, rgba(14,116,144,0.18) 38%, rgba(15,23,42,0.78) 100%)',
            boxShadow: 'inset 0 0 110px rgba(56,189,248,0.35)',
          }}
        />
      )}

      {/* Door Breach Slow-Mo Tint */}
      {hud.breachSlowMoTimer > 0 && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: 'inset 0 0 120px rgba(245,158,11,0.45)',
          }}
        />
      )}

      {/* Adrenaline Stim Boost Edge Tint */}
      {hud.stimBoostTimer > 0 && (
        <div
          data-testid="stim-vignette"
          className="absolute inset-0 pointer-events-none"
          style={{
            boxShadow: 'inset 0 0 95px rgba(16,185,129,0.42)',
          }}
        />
      )}

      {/* AC-130 Gunship Aerial Targeting HUD [Y] */}
      {hud.gunshipActive && (
        <div
          data-testid="gunship-hud"
          className="absolute inset-0 pointer-events-none flex items-center justify-center"
          style={{
            background:
              'radial-gradient(circle at center, rgba(15,23,42,0.08) 42%, rgba(2,6,23,0.75) 100%)',
          }}
        >
          <div className="relative w-[68vmin] h-[68vmin] border border-stone-300/40 flex items-center justify-center">
            <div className="w-14 h-14 border-2 border-amber-400/90" />
            <div className="absolute inset-x-0 top-1/2 h-px bg-stone-300/40" />
            <div className="absolute inset-y-0 left-1/2 w-px bg-stone-300/40" />
            <div className="absolute top-2 left-3 text-[11px] font-mono-num text-amber-300 font-bold hud-stroke">
              AC-130 SPECTRE · 105MM TOP
            </div>
            <div className="absolute top-2 right-3 text-[11px] font-mono-num text-stone-100 font-bold hud-stroke">
              MƏRMİ {hud.gunshipShells} · {hud.gunshipTimer.toFixed(1)}s
            </div>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] font-mono-num text-stone-200 hud-stroke whitespace-nowrap">
              SOL DÜYMƏ: BOMBALA · [Y]: ÇIXIŞ
            </div>
          </div>
        </div>
      )}

      {/* MSR Sniper Optic Scope Overlay */}
      {isSniperScoped && (
        <div
          data-testid="sniper-scope"
          className="absolute inset-0 pointer-events-none flex items-center justify-center"
          style={{
            background:
              'radial-gradient(circle at center, rgba(0,0,0,0) 31%, rgba(6,9,12,0.96) 33%)',
          }}
        >
          <svg viewBox="0 0 200 200" className="w-[72vmin] h-[72vmin] opacity-90">
            <circle cx="100" cy="100" r="96" fill="none" stroke="#181c20" strokeWidth="4" />
            <line x1="6" y1="100" x2="88" y2="100" stroke="#0c0f12" strokeWidth="1.2" />
            <line x1="112" y1="100" x2="194" y2="100" stroke="#0c0f12" strokeWidth="1.2" />
            <line x1="100" y1="6" x2="100" y2="88" stroke="#0c0f12" strokeWidth="1.2" />
            <line x1="100" y1="112" x2="100" y2="194" stroke="#0c0f12" strokeWidth="1.6" />
            {[40, 58, 76, 124, 142, 160].map((pos) => (
              <React.Fragment key={pos}>
                <circle cx={pos} cy="100" r="1.2" fill="#e5e7eb" />
                <circle cx="100" cy={pos} r="1.2" fill="#e5e7eb" />
              </React.Fragment>
            ))}
            <circle cx="100" cy="100" r="1.8" fill="#ef4444" />
          </svg>
        </div>
      )}

      {/* World-projected floating HP bars above injured active enemies */}
      {hud.projectedEnemies.map((marker) => {
        const isBoss = marker.archetype === 'boss';
        if (minimalHud && !isBoss) return null;
        return (
          <div
            key={marker.id}
            className="absolute -translate-x-1/2 -translate-y-full pointer-events-none"
            style={{
              left: `${marker.xPct.toFixed(2)}%`,
              top: `${marker.yPct.toFixed(2)}%`,
            }}
          >
            {marker.stunned && (
              <div className="text-[9px] font-mono-num font-bold tracking-wider text-sky-300 text-center mb-0.5 hud-stroke whitespace-nowrap">
                STUN
              </div>
            )}
            {isBoss && (
              <div className="text-[10px] font-display font-bold tracking-wider text-amber-300 text-center mb-0.5 hud-stroke whitespace-nowrap">
                {hud.wave >= 10 ? 'SİNDİKAT LİDERİ' : 'KOMANDİR XƏNCƏR'}
                {hud.bossPhase && hud.bossPhase > 1 ? ` · FAZA ${hud.bossPhase === 2 ? 'II' : 'III'}` : ''}
              </div>
            )}
            <div
              className={`${
                isBoss ? 'w-28 h-2 border-amber-400/90' : 'w-11 h-1.5 border-stone-600/80'
              } bg-[#0b0e12]/85 border overflow-hidden mx-auto`}
            >
              <div
                className={`h-full transition-all duration-100 ${
                  isBoss
                    ? 'bg-gradient-to-r from-red-600 to-amber-400'
                    : hud.thermalActive
                      ? 'bg-amber-300'
                      : marker.archetype === 'heavy' || marker.archetype === 'shield'
                        ? 'bg-amber-400'
                        : marker.archetype === 'sniper'
                          ? 'bg-fuchsia-400'
                          : marker.archetype === 'zombie'
                            ? 'bg-emerald-400'
                            : 'bg-red-500'
                }`}
                style={{ width: `${marker.hpPct}%` }}
              />
            </div>
          </div>
        );
      })}

      {/* 3D Projected Story Objective Waypoint Diamond */}
      {hud.objectiveWaypoint &&
        !(
          hud.objectiveWaypoint.kind === 'boss' &&
          hud.projectedEnemies.some((m) => m.archetype === 'boss')
        ) && (
          <div
            data-testid="objective-waypoint"
            className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center"
            style={{
              left: `${hud.objectiveWaypoint.xPct.toFixed(2)}%`,
              top: `${hud.objectiveWaypoint.yPct.toFixed(2)}%`,
            }}
          >
            <div className={`w-4 h-4 rotate-45 border-2 ${wpColor} shadow-md`} />
            <div className="mt-1 px-1.5 py-0.5 bg-[#0e1217]/85 border border-stone-700/80 rounded-xs text-[10px] font-mono-num text-stone-100 whitespace-nowrap hud-stroke">
              <span className="text-amber-300 font-bold">{hud.objectiveWaypoint.label}</span>{' '}
              <span>{hud.objectiveWaypoint.distanceMeters}m</span>
            </div>
          </div>
        )}

      {/* Peripheral low-HP & incoming hit vignette */}
      {(hud.damageFlash > 0.02 || hud.hp <= 30) && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-150"
          style={{
            background:
              'radial-gradient(circle at center, rgba(220,38,38,0) 48%, rgba(185,28,28,0.58) 100%)',
            opacity: Math.max(hud.damageFlash * 0.9, hud.hp <= 30 ? 0.45 : 0),
          }}
        />
      )}

      {/* Directional damage arc indicator */}
      {hud.damageFlash > 0.08 && hud.damageDirectionAngle !== null && (
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 pointer-events-none"
          style={{
            transform: `translate(-50%, -50%) rotate(${hud.damageDirectionAngle}rad)`,
            opacity: hud.damageFlash,
          }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <path
              d="M 32 10 Q 50 2 68 10"
              fill="none"
              stroke="#ef4444"
              strokeWidth="4.5"
              strokeLinecap="round"
            />
          </svg>
        </div>
      )}

      {/* Incoming Enemy Frag Grenade Threat Indicator */}
      {hud.grenadeWarning && (
        <div
          data-testid="grenade-threat-warning"
          className="absolute left-1/2 top-[38%] -translate-x-1/2 -translate-y-1/2 pointer-events-none flex items-center gap-2 px-3 py-1 bg-red-950/95 border-2 border-red-400 text-red-200 font-mono-num font-bold text-xs rounded-sm shadow-xl whitespace-nowrap"
        >
          <Bomb className="w-4 h-4 text-red-400 shrink-0" />
          <span>QUMBARA! {hud.grenadeWarning.distanceMeters}m</span>
          <span
            className="inline-block text-amber-300 text-sm leading-none"
            style={{ transform: `rotate(${hud.grenadeWarning.angleRad}rad)` }}
          >
            ▲
          </span>
        </div>
      )}

      {/* Right-side Touch Look Zone */}
      {showTouchControls && (
        <div
          data-testid="touch-look-pad"
          className="absolute right-0 top-16 bottom-0 w-[56%] pointer-events-auto touch-none"
          onPointerDown={(e) => {
            if (lookPointerId.current !== null) return;
            lookPointerId.current = e.pointerId;
            lookLastPos.current = { x: e.clientX, y: e.clientY };
            e.currentTarget.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (lookPointerId.current !== e.pointerId) return;
            const dx = e.clientX - lookLastPos.current.x;
            const dy = e.clientY - lookLastPos.current.y;
            lookLastPos.current = { x: e.clientX, y: e.clientY };
            onLookDelta(dx * 1.45, dy * 1.45);
          }}
          onPointerUp={(e) => {
            if (lookPointerId.current === e.pointerId) {
              lookPointerId.current = null;
            }
          }}
          onPointerCancel={(e) => {
            if (lookPointerId.current === e.pointerId) {
              lookPointerId.current = null;
            }
          }}
        />
      )}

      {/* TOP-LEFT CLUSTER: Radar + Vitality + Squad/Sentry */}
      <div className="absolute top-3 left-3 sm:top-4 sm:left-4 flex flex-col gap-1.5">
        <div className="flex items-start gap-1.5 sm:gap-2.5">
          {/* Live Radar Minimap */}
          <div
            className={`relative w-14 h-14 sm:w-24 sm:h-24 rounded-sm bg-[#101418]/85 border shadow-md overflow-hidden shrink-0 ${
              uavActive ? 'border-emerald-400' : 'border-stone-600/80'
            }`}
          >
            <svg viewBox="-40 -40 80 80" className="w-full h-full">
              <circle cx="0" cy="0" r="36" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
              <circle cx="0" cy="0" r="18" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
              <path d="M 0 0 L -18 -34 L 18 -34 Z" fill="rgba(245,158,11,0.16)" />
              {hud.radarEnemies.map((en, idx) => {
                const rx = en.x - hud.playerX;
                const rz = en.z - hud.playerZ;
                const lx = rx * cosYaw - rz * sinYaw;
                const lz = rx * sinYaw + rz * cosYaw;
                const clampedX = Math.max(-35, Math.min(35, lx));
                const clampedZ = Math.max(-35, Math.min(35, lz));
                const fill =
                  en.archetype === 'ally'
                    ? '#34d399'
                    : en.archetype === 'sentry'
                      ? '#38bdf8'
                      : en.archetype === 'boss'
                        ? '#facc15'
                        : en.archetype === 'heavy' || en.archetype === 'shield'
                          ? '#f59e0b'
                          : en.archetype === 'sniper'
                            ? '#e879f9'
                            : en.archetype === 'drone'
                              ? '#60a5fa'
                              : '#ef4444';
                return (
                  <circle
                    key={idx}
                    cx={clampedX}
                    cy={clampedZ}
                    r={en.archetype === 'boss' ? 4.4 : en.archetype === 'heavy' ? 3.5 : 2.6}
                    fill={fill}
                  />
                );
              })}
              <polygon points="0,-4.5 3.5,3.5 -3.5,3.5" fill="#f4f1ea" />
            </svg>
            {uavActive && (
              <span className="absolute bottom-0.5 right-1 text-[8px] font-mono-num font-bold text-emerald-300 hud-stroke">
                UAV {Math.ceil(hud.uavActiveTimer)}s
              </span>
            )}
          </div>

          {/* Health & Armor Bars + Plate pips */}
          <div className="bg-[#101418]/85 border border-stone-700/80 px-2 py-1.5 sm:px-2.5 sm:py-2 rounded-sm w-[104px] sm:min-w-[158px]">
            <div className="flex items-baseline justify-between gap-2 mb-0.5 sm:mb-1">
              <span className="text-[10px] sm:text-[11px] font-semibold tracking-wider text-stone-400">
                CAN
              </span>
              <span
                data-testid="hud-hp"
                className={`font-mono-num font-bold text-sm sm:text-lg leading-none ${
                  hud.hp <= 30 ? 'text-red-400' : 'text-stone-100'
                }`}
              >
                {hud.hp}
              </span>
            </div>
            <div className="relative h-1.5 sm:h-2 bg-stone-800 overflow-hidden mb-1 sm:mb-1.5">
              <div
                className="absolute inset-y-0 left-0 bg-red-500/70 transition-all duration-300"
                style={{ width: `${ghostPct}%` }}
              />
              <div
                className={`relative h-full transition-all duration-100 ${
                  hud.hp <= 30 ? 'bg-red-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${hpPct}%` }}
              />
            </div>

            <div className="flex items-center justify-between gap-1 mb-0.5">
              <span className="text-[9px] sm:text-[10px] font-semibold tracking-wider text-stone-400">
                {isCampaign ? 'MÜDAFİƏ' : 'ZİREH'}
              </span>
              <div className="flex items-center gap-0.5 sm:gap-1">
                {!isCampaign &&
                  Array.from({ length: hud.maxArmorPlates }).map((_, idx) => (
                    <span
                      key={idx}
                      className={`w-1.5 sm:w-2 h-1.5 rounded-xs ${
                        idx < hud.armorPlates ? 'bg-sky-400' : 'bg-stone-700'
                      }`}
                    />
                  ))}
                <span className="font-mono-num text-[11px] sm:text-xs text-sky-300 leading-none ml-0.5">
                  {hud.armor}
                </span>
              </div>
            </div>
            <div className="h-1 sm:h-1.5 bg-stone-800 overflow-hidden">
              <div
                className="h-full bg-sky-400 transition-all duration-150"
                style={{ width: `${armorPct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Allied Squad & Sentry + Survival Credits Strip (Desktop) */}
        {(hud.allySquad.length > 0 || hud.sentryActiveCount > 0 || isSurvival) && (
          <div className="hidden sm:flex flex-col gap-1 max-w-[260px]">
            {hud.allySquad.length > 0 && (
              <div className="flex items-center gap-1.5 bg-[#101418]/80 border border-stone-700/70 px-2 py-1 rounded-sm">
                {hud.allySquad.map((ally) => (
                  <div key={ally.name} className="flex-1 min-w-0">
                    <div
                      className={`text-[9px] font-mono-num truncate ${
                        ally.downed ? 'text-red-400 font-bold' : 'text-emerald-300'
                      }`}
                    >
                      {ally.downed ? 'YARALI!' : ally.name.split(' ').pop()}
                    </div>
                    <div className="h-1 bg-stone-800 mt-0.5 overflow-hidden">
                      <div
                        className={`h-full ${ally.downed ? 'bg-red-500' : 'bg-emerald-400'}`}
                        style={{ width: `${Math.max(ally.downed ? 12 : 0, Math.min(100, ally.hpPct))}%` }}
                      />
                    </div>
                  </div>
                ))}
                {hud.sentryActiveCount > 0 && (
                  <span className="text-[9px] font-mono-num font-bold text-sky-300 shrink-0 pl-1 border-l border-stone-700">
                    TURET×{hud.sentryActiveCount}
                  </span>
                )}
              </div>
            )}

            {isSurvival && (
              <div className="flex items-center gap-1.5 pointer-events-auto">
                <div className="px-2.5 py-1 bg-[#101815]/90 border border-emerald-500/60 rounded-sm text-xs font-mono-num font-bold text-emerald-300">
                  ${hud.credits}
                </div>
                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="open-buy-station-btn"
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onOpenBuyStation();
                  }}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/90 hover:bg-amber-400 text-stone-950 font-display font-bold text-[11px] rounded-sm transition-colors cursor-pointer"
                >
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>MAĞAZA [B]</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* DESKTOP SQUAD RADIO COMMS BANNER (stacked cleanly below top-left cluster) */}
        {hud.radioMessage && (
          <div
            data-testid="radio-comms"
            className={`hidden sm:block max-w-[320px] bg-[#0f1318]/92 border-l-4 ${
              hud.radioMessage.tone === 'enemy'
                ? 'border-red-500'
                : hud.radioMessage.tone === 'command'
                  ? 'border-amber-400'
                  : 'border-emerald-400'
            } border-t border-r border-b border-stone-700/80 px-3 py-2 rounded-r-sm shadow-lg`}
          >
            <div className="flex items-center gap-2 text-[10px] font-mono-num font-bold tracking-wider mb-0.5">
              <Radio
                className={`w-3.5 h-3.5 shrink-0 ${
                  hud.radioMessage.tone === 'enemy'
                    ? 'text-red-400'
                    : hud.radioMessage.tone === 'command'
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                }`}
              />
              <span className="text-stone-100">{hud.radioMessage.speaker.toUpperCase()}</span>
              <span className="text-stone-400">· {hud.radioMessage.callsign}</span>
            </div>
            <p className="text-xs text-stone-200 leading-snug">{hud.radioMessage.text}</p>
          </div>
        )}
      </div>

      {/* TOP-CENTER DESKTOP: MW2 Tactical Compass + Chapter/Wave & Active Objective */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 hidden sm:flex flex-col items-center gap-1.5">
        <div
          data-testid="tactical-compass"
          className="relative w-72 h-6 bg-[#101418]/85 border border-stone-700/80 rounded-sm overflow-hidden flex items-center"
        >
          <div className="absolute left-1/2 top-0 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[5px] border-l-transparent border-r-transparent border-t-amber-400 z-10" />
          {COMPASS_TICKS.map((deg) => {
            const delta = ((deg - hud.compassHeadingDeg + 540) % 360) - 180;
            if (Math.abs(delta) > 72) return null;
            const leftPct = 50 + (delta / 72) * 46;
            const label = COMPASS_LABELS[deg];
            return (
              <div
                key={deg}
                className="absolute -translate-x-1/2 flex flex-col items-center"
                style={{ left: `${leftPct.toFixed(1)}%` }}
              >
                <span
                  className={`font-mono-num leading-none ${
                    label
                      ? 'text-[10px] font-bold text-stone-100'
                      : 'text-[9px] text-stone-500'
                  }`}
                >
                  {label ?? deg}
                </span>
              </div>
            );
          })}
          <span className="ml-auto mr-1.5 px-1 bg-[#161b22] text-[10px] font-mono-num font-bold text-amber-400 z-10">
            {String(hud.compassHeadingDeg).padStart(3, '0')}°
          </span>
        </div>

        <div className="flex items-center gap-3 px-4 py-1 bg-[#101418]/85 border border-stone-700/80 rounded-sm">
          <div className="text-xs text-stone-300 font-display font-bold tracking-wider">
            {isSurvival
              ? 'DALĞA'
              : isFiringRange
                ? 'POLİQON'
                : isSpecOps
                  ? 'SPEC OPS'
                  : 'FƏSİL'}{' '}
            {!isFiringRange && !isSpecOps && (
              <span className="font-mono-num text-amber-400">{hud.wave}</span>
            )}
            {!isSurvival && !isFiringRange && !isSpecOps && hud.chapterTotalStages > 1 && (
              <span className="font-mono-num text-sky-300 ml-1">
                · M{hud.chapterStage}/{hud.chapterTotalStages}
              </span>
            )}
          </div>
          <span className="text-stone-600" aria-hidden="true">·</span>
          <div className="text-xs text-stone-300 font-display font-bold tracking-wider">
            DÜŞMƏN{' '}
            <span className="font-mono-num text-red-400">
              {isSpecOps ? '∞' : hud.enemiesRemaining}
            </span>
          </div>
          <span className="text-stone-600" aria-hidden="true">·</span>
          <div className="text-xs text-stone-300 font-display font-bold tracking-wider">
            XAL <span className="font-mono-num text-stone-100">{hud.score}</span>
          </div>
        </div>

        {hud.activeObjectiveText && (
          <div
            data-testid="objective-tracker"
            className="w-80 bg-[#101418]/85 border border-stone-700/80 px-3 py-1 rounded-sm"
          >
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-100 truncate">
              <Target className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="truncate">{hud.activeObjectiveText}</span>
            </div>
            <div className="h-1 bg-stone-800 mt-1 overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${objectiveBarColor}`}
                style={{ width: `${Math.max(4, hud.objectiveProgressPct)}%` }}
              />
            </div>
          </div>
        )}

        {/* Campaign Set-Piece Status Widgets (Stealth / Hostages / Escape Timer / Wounded Ally) */}
        {isCampaign && hud.setPieceKind === 'stealth_infil' && (
          <div
            data-testid="stealth-hud"
            className={`w-80 px-3 py-1 rounded-sm border ${
              hud.stealthDetected
                ? 'bg-red-950/92 border-red-400/90'
                : 'bg-[#101418]/88 border-emerald-500/70'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-mono-num font-bold">
              <span className={hud.stealthDetected ? 'text-red-300' : 'text-emerald-300'}>
                {hud.stealthDetected ? 'HƏYƏCAN SİQNALI · AÇILDI!' : 'GİZLİ REJİM · SİZMA'}
              </span>
              <span className="text-stone-200">{hud.stealthSuspicionPct}%</span>
            </div>
            <div className="h-1 bg-stone-800 mt-1 overflow-hidden">
              <div
                className={`h-full transition-all duration-100 ${
                  hud.stealthDetected ? 'bg-red-500' : hud.stealthSuspicionPct >= 50 ? 'bg-amber-400' : 'bg-emerald-400'
                }`}
                style={{ width: `${Math.max(4, hud.stealthSuspicionPct)}%` }}
              />
            </div>
          </div>
        )}

        {isCampaign && hud.hostagesTotal > 0 && (
          <div
            data-testid="hostage-hud"
            className="w-80 bg-[#101418]/88 border border-sky-400/75 px-3 py-1 rounded-sm flex items-center justify-between text-[11px] font-mono-num font-bold"
          >
            <span className="text-sky-300">GİROVLAR XİLAS EDİLDİ</span>
            <span className="text-amber-300">
              {hud.hostagesRescued}/{hud.hostagesTotal} (SAĞ: {hud.hostagesAlive})
            </span>
          </div>
        )}

        {isCampaign && hud.escapeTimerSec !== null && (
          <div
            data-testid="escape-timer-hud"
            className="w-80 bg-red-950/92 border border-red-400 px-3 py-1 rounded-sm flex items-center justify-between text-[11px] font-mono-num font-bold"
          >
            <span className="text-red-200">TƏXLİYƏ TAYMERİ</span>
            <span className="text-amber-300 text-sm">{hud.escapeTimerSec}s</span>
          </div>
        )}

        {isCampaign && hud.woundedAlly !== null && (
          <div
            data-testid="wounded-ally-hud"
            className="w-80 bg-[#231214]/95 border border-red-400 px-3 py-1 rounded-sm flex items-center justify-between text-[10px] font-mono-num font-bold"
          >
            <span className="text-red-300 truncate">
              YOLDAŞ YARALI: {hud.woundedAlly.name.toUpperCase()} ({hud.woundedAlly.bleedoutSec}s)
            </span>
            <span className="text-amber-300 shrink-0 ml-2">[E] XİLAS ET</span>
          </div>
        )}

        {/* Spec Ops Bomb A/B Timer & Defusal Progress */}
        {hud.bombObjective && (
          <div
            data-testid="spec-ops-bomb-hud"
            className="w-80 bg-[#161222]/92 border border-purple-400/75 px-3 py-1.5 rounded-sm pointer-events-auto"
          >
            <div className="flex items-center justify-between text-[11px] font-mono-num font-bold">
              <span className="text-purple-300">
                BOMBA {hud.bombObjective.site} · {hud.bombObjective.timer}s
              </span>
              <span className="text-amber-300">{hud.bombObjective.progress}%</span>
            </div>
            <div className="h-1.5 bg-stone-800 mt-1 overflow-hidden">
              <div
                className="h-full bg-purple-400 transition-all duration-100"
                style={{ width: `${Math.max(2, hud.bombObjective.progress)}%` }}
              />
            </div>
            <div className="mt-1.5 flex items-center justify-between gap-2">
              <span className="text-[10px] text-stone-300 truncate">
                Yaxınlaş və [E] basılı tut
              </span>
              <button
                type="button"
                tabIndex={-1}
                data-testid="defuse-hold-btn"
                onPointerDown={() => onDefuseHeld(true)}
                onPointerUp={() => onDefuseHeld(false)}
                onPointerLeave={() => onDefuseHeld(false)}
                onPointerCancel={() => onDefuseHeld(false)}
                className="px-2 py-0.5 bg-purple-500 hover:bg-purple-400 text-stone-950 font-display font-bold text-[10px] rounded-xs cursor-pointer shrink-0"
              >
                ZƏRƏRSİZLƏŞDİR [E]
              </button>
            </div>
          </div>
        )}

        {/* Firing Range Live Stats & Reset */}
        {hud.firingRangeStats && (
          <div
            data-testid="firing-range-hud"
            className="w-80 bg-[#1a1510]/92 border border-orange-400/75 px-3 py-1.5 rounded-sm flex items-center justify-between gap-2 pointer-events-auto"
          >
            <div className="flex items-center gap-2.5 text-[11px] font-mono-num">
              <span className="text-stone-200">
                VURUŞ <strong className="text-orange-300">{hud.firingRangeStats.hits}</strong>
              </span>
              <span className="text-stone-200">
                BAŞ <strong className="text-amber-300">{hud.firingRangeStats.headshots}</strong>
              </span>
              <span className="text-stone-200">
                DƏQ <strong className="text-emerald-300">{hud.firingRangeStats.accuracyPct}%</strong>
              </span>
            </div>
            <button
              type="button"
              tabIndex={-1}
              data-testid="reset-range-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onResetFiringRange();
              }}
              className="px-2 py-0.5 bg-orange-500 hover:bg-orange-400 text-stone-950 font-display font-bold text-[10px] rounded-xs cursor-pointer shrink-0"
            >
              SIFIRLA
            </button>
          </div>
        )}

        {(hud.waveBanner || hud.checkpointBanner || hud.comboBanner) && (
          <div className="flex flex-col items-center gap-1.5 pointer-events-none">
            {hud.waveBanner && (
              <div className="px-5 py-1.5 bg-[#101418]/90 border border-amber-500/80 text-amber-400 font-display font-bold text-base lg:text-lg tracking-widest rounded-sm whitespace-nowrap text-center">
                {hud.waveBanner}
              </div>
            )}
            {hud.checkpointBanner && (
              <div
                data-testid="checkpoint-banner"
                className="px-4 py-1 bg-emerald-950/95 border border-emerald-400/90 text-emerald-300 font-mono-num font-bold text-sm tracking-widest rounded-sm whitespace-nowrap"
              >
                {hud.checkpointBanner}
              </div>
            )}
            {hud.comboBanner && (
              <div className="px-4 py-1 bg-[#14181e]/90 border-b-2 border-amber-400 text-amber-300 font-display font-bold text-sm tracking-widest whitespace-nowrap hud-stroke">
                {hud.comboBanner}
              </div>
            )}
          </div>
        )}
      </div>

      {/* MOBILE COMPACT STATUS + OBJECTIVE STRIP */}
      <div className="sm:hidden absolute top-[80px] left-3 right-3 flex flex-col gap-1 pointer-events-none">
        <div className="flex items-center justify-between gap-2 text-[11px] font-mono-num text-stone-200 hud-stroke">
          <div className="flex items-center gap-1.5">
            <span className="text-amber-400 font-bold">
              {isSurvival
                ? `DALĞA ${hud.wave}`
                : isFiringRange
                  ? 'POLİQON'
                  : isSpecOps
                    ? 'SPEC OPS'
                    : `FƏSİL ${hud.wave}`}
              {!isSurvival && !isFiringRange && !isSpecOps && hud.chapterTotalStages > 1
                ? ` · M${hud.chapterStage}/${hud.chapterTotalStages}`
                : ''}
            </span>
            <span>·</span>
            <span className="text-red-300 font-bold">
              DÜŞMƏN {isSpecOps ? '∞' : hud.enemiesRemaining}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            {isSurvival && (
              <button
                type="button"
                data-testid="open-buy-station-btn-mobile"
                onClick={onOpenBuyStation}
                className="pointer-events-auto px-1.5 py-0.5 bg-amber-500 text-stone-950 font-bold rounded-xs text-[10px]"
              >
                ${hud.credits} MAĞAZA
              </button>
            )}
            <span className="text-amber-300 font-bold">
              {String(hud.compassHeadingDeg).padStart(3, '0')}° {getCardinalLabel(hud.compassHeadingDeg)}
            </span>
          </div>
        </div>
        {hud.activeObjectiveText && (
          <div
            data-testid="objective-tracker-mobile"
            className="bg-[#101418]/80 border border-stone-700/75 px-2 py-1 rounded-sm"
          >
            <div className="flex items-center gap-1.5 text-[10px] font-semibold text-stone-100 truncate">
              <Target className="w-3 h-3 text-amber-400 shrink-0" />
              <span className="truncate">{hud.activeObjectiveText}</span>
            </div>
            <div className="h-1 bg-stone-800 mt-0.5 overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${objectiveBarColor}`}
                style={{ width: `${Math.max(4, hud.objectiveProgressPct)}%` }}
              />
            </div>
          </div>
        )}
        {isCampaign && hud.setPieceKind === 'stealth_infil' && (
          <div
            data-testid="stealth-hud-mobile"
            className={`px-2 py-1 rounded-sm border text-[10px] font-mono-num font-bold flex items-center justify-between ${
              hud.stealthDetected
                ? 'bg-red-950/92 border-red-400 text-red-200'
                : 'bg-[#101418]/85 border-emerald-500/70 text-emerald-300'
            }`}
          >
            <span>{hud.stealthDetected ? 'HƏYƏCAN!' : 'GİZLİLİK'}</span>
            <span>{hud.stealthSuspicionPct}%</span>
          </div>
        )}
        {isCampaign && hud.hostagesTotal > 0 && (
          <div
            data-testid="hostage-hud-mobile"
            className="bg-[#101418]/85 border border-sky-400/75 px-2 py-0.5 rounded-sm flex items-center justify-between text-[10px] font-mono-num font-bold text-sky-300"
          >
            <span>GİROVLAR</span>
            <span className="text-amber-300">{hud.hostagesRescued}/{hud.hostagesTotal}</span>
          </div>
        )}
        {isCampaign && hud.escapeTimerSec !== null && (
          <div
            data-testid="escape-timer-hud-mobile"
            className="bg-red-950/92 border border-red-400 px-2 py-0.5 rounded-sm flex items-center justify-between text-[10px] font-mono-num font-bold text-red-200"
          >
            <span>TƏXLİYƏ TAYMERİ</span>
            <span className="text-amber-300">{hud.escapeTimerSec}s</span>
          </div>
        )}
        {isCampaign && hud.woundedAlly !== null && (
          <div
            data-testid="wounded-ally-hud-mobile"
            className="bg-[#231214]/95 border border-red-400 px-2 py-0.5 rounded-sm flex items-center justify-between text-[10px] font-mono-num font-bold text-red-300"
          >
            <span className="truncate">YARALI: {hud.woundedAlly.name} ({hud.woundedAlly.bleedoutSec}s)</span>
            <span className="text-amber-300 shrink-0">[E]</span>
          </div>
        )}
        {hud.bombObjective && (
          <div
            data-testid="spec-ops-bomb-hud-mobile"
            className="bg-[#161222]/90 border border-purple-400/75 px-2 py-1 rounded-sm pointer-events-auto flex items-center justify-between gap-2"
          >
            <span className="text-[10px] font-mono-num font-bold text-purple-200">
              BOMBA {hud.bombObjective.site} · {hud.bombObjective.timer}s ({hud.bombObjective.progress}%)
            </span>
            <button
              type="button"
              tabIndex={-1}
              onPointerDown={() => onDefuseHeld(true)}
              onPointerUp={() => onDefuseHeld(false)}
              onPointerLeave={() => onDefuseHeld(false)}
              onPointerCancel={() => onDefuseHeld(false)}
              className="px-2 py-0.5 bg-purple-500 text-stone-950 font-display font-bold text-[10px] rounded-xs"
            >
              ZƏRƏRSİZLƏŞDİR
            </button>
          </div>
        )}
        {hud.firingRangeStats && (
          <div
            data-testid="firing-range-hud-mobile"
            className="bg-[#1a1510]/90 border border-orange-400/75 px-2 py-1 rounded-sm pointer-events-auto flex items-center justify-between gap-2"
          >
            <span className="text-[10px] font-mono-num text-stone-100">
              VURUŞ {hud.firingRangeStats.hits} · BAŞ {hud.firingRangeStats.headshots} ·{' '}
              {hud.firingRangeStats.accuracyPct}%
            </span>
            <button
              type="button"
              tabIndex={-1}
              onClick={onResetFiringRange}
              className="px-2 py-0.5 bg-orange-500 text-stone-950 font-display font-bold text-[10px] rounded-xs"
            >
              SIFIRLA
            </button>
          </div>
        )}
        {hud.radioMessage && (
          <div
            className={`mt-0.5 max-w-[330px] bg-[#0f1318]/92 border-l-4 ${
              hud.radioMessage.tone === 'enemy'
                ? 'border-red-500'
                : hud.radioMessage.tone === 'command'
                  ? 'border-amber-400'
                  : 'border-emerald-400'
            } border-t border-r border-b border-stone-700/80 px-3 py-1.5 rounded-r-sm shadow-lg`}
          >
            <div className="flex items-center gap-2 text-[10px] font-mono-num font-bold tracking-wider mb-0.5">
              <Radio
                className={`w-3.5 h-3.5 shrink-0 ${
                  hud.radioMessage.tone === 'enemy'
                    ? 'text-red-400'
                    : hud.radioMessage.tone === 'command'
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                }`}
              />
              <span className="text-stone-100">{hud.radioMessage.speaker.toUpperCase()}</span>
              <span className="text-stone-400">· {hud.radioMessage.callsign}</span>
            </div>
            <p className="text-xs text-stone-200 leading-snug">{hud.radioMessage.text}</p>
          </div>
        )}
        {(hud.waveBanner || hud.checkpointBanner || hud.comboBanner) && (
          <div className="mt-1 flex flex-col items-center gap-1 pointer-events-none">
            {hud.waveBanner && (
              <div className="px-3 py-1 bg-[#101418]/90 border border-amber-500/80 text-amber-400 font-display font-bold text-xs tracking-widest rounded-sm text-center max-w-full truncate">
                {hud.waveBanner}
              </div>
            )}
            {hud.checkpointBanner && (
              <div
                data-testid="checkpoint-banner"
                className="px-3 py-0.5 bg-emerald-950/95 border border-emerald-400/90 text-emerald-300 font-mono-num font-bold text-[11px] tracking-widest rounded-sm whitespace-nowrap"
              >
                {hud.checkpointBanner}
              </div>
            )}
            {hud.comboBanner && (
              <div className="px-3 py-0.5 bg-[#14181e]/90 border-b-2 border-amber-400 text-amber-300 font-display font-bold text-xs tracking-widest whitespace-nowrap hud-stroke">
                {hud.comboBanner}
              </div>
            )}
          </div>
        )}
      </div>

      {/* TOP-RIGHT UTILITY BUTTONS (Thermal + NVG + AutoFire + Gamepad + Mute + Pause) */}
      <div className="absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-1 sm:gap-1.5 pointer-events-auto">
        <button
          type="button"
          tabIndex={-1}
          data-testid="thermal-toggle-btn"
          onClick={(e) => {
            e.currentTarget.blur();
            onToggleThermal();
          }}
          aria-label="Termal Kamera"
          title="Termal Kamera [T]"
          className={`w-8 h-8 sm:w-auto sm:min-w-[44px] sm:min-h-[44px] sm:px-2.5 flex items-center justify-center gap-1 border rounded-sm text-xs font-semibold transition-colors cursor-pointer ${
            hud.thermalActive
              ? 'bg-sky-400/95 border-sky-200 text-stone-950'
              : 'bg-[#101418]/85 border-stone-700/80 text-stone-300 hover:border-sky-400'
          }`}
        >
          <Thermometer className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="hidden lg:inline">TERMAL [T]</span>
        </button>

        <button
          type="button"
          tabIndex={-1}
          data-testid="nvg-toggle-btn"
          onClick={(e) => {
            e.currentTarget.blur();
            onToggleNvg();
          }}
          aria-label="Gecə Görüş Eynəyi"
          title="Gecə Görüş Eynəyi [N]"
          className={`w-8 h-8 sm:w-auto sm:min-w-[44px] sm:min-h-[44px] sm:px-2.5 flex items-center justify-center gap-1 border rounded-sm text-xs font-semibold transition-colors cursor-pointer ${
            hud.isNvgActive
              ? 'bg-emerald-500/90 border-emerald-300 text-stone-950'
              : 'bg-[#101418]/85 border-stone-700/80 text-stone-300 hover:border-emerald-400'
          }`}
        >
          <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="hidden lg:inline">NVG [N]</span>
        </button>

        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onToggleAutoFire();
          }}
          aria-label="Avto-Atəş"
          title="Avto-Atəş (Hədəfdə avtomatik atəş)"
          className={`w-8 h-8 sm:w-auto sm:min-w-[44px] sm:min-h-[44px] sm:px-2.5 flex items-center justify-center gap-1.5 border rounded-sm text-xs font-semibold transition-colors cursor-pointer ${
            hud.autoFire
              ? 'bg-amber-500/90 border-amber-400 text-stone-950'
              : 'bg-[#101418]/85 border-stone-700/80 text-stone-300 hover:border-stone-500'
          }`}
        >
          <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="hidden md:inline">AVTO</span>
        </button>

        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onToggleTouchControls();
          }}
          aria-label="Ekran düymələri"
          title="Mobil düymələri göstər/gizlət"
          className={`hidden sm:flex min-w-[44px] min-h-[44px] items-center justify-center border rounded-sm transition-colors cursor-pointer ${
            showTouchControls
              ? 'bg-[#1a222b]/90 border-amber-500/80 text-amber-400'
              : 'bg-[#101418]/85 border-stone-700/80 text-stone-300 hover:border-stone-500'
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
        </button>

        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onToggleMute();
          }}
          aria-label={muted ? 'Səsi aç' : 'Səsi bağla'}
          className="w-8 h-8 sm:min-w-[44px] sm:min-h-[44px] flex items-center justify-center bg-[#101418]/85 border border-stone-700/80 text-stone-200 hover:border-amber-500 rounded-sm transition-colors cursor-pointer"
        >
          {muted ? <VolumeX className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Volume2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
        </button>

        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onPause();
          }}
          aria-label="Fasilə"
          className="w-8 h-8 sm:min-w-[44px] sm:min-h-[44px] flex items-center justify-center bg-[#101418]/85 border border-stone-700/80 text-stone-200 hover:border-amber-500 rounded-sm transition-colors cursor-pointer"
        >
          <Pause className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>
      </div>

      {/* Optics status indicator */}
      {(hud.isNvgActive || hud.thermalActive || hud.blackoutActive) && (
        <div
          data-testid="nvg-indicator"
          className="hidden sm:block absolute top-16 right-4 text-[10px] font-mono-num font-bold tracking-widest text-emerald-300 hud-stroke"
        >
          {hud.thermalActive
            ? 'TERMAL AKTİV · [T]'
            : hud.isNvgActive
              ? 'NVG AKTİV · [N]'
              : 'EMP BLACKOUT · [N]/[T]'}
        </div>
      )}

      {/* Last Stand / Self-Revive Banner */}
      {hud.isLastStand && (
        <div
          data-testid="last-stand-banner"
          className="pointer-events-auto absolute bottom-32 sm:bottom-24 left-1/2 -translate-x-1/2 bg-red-950/95 border-2 border-red-400 px-4 py-2 rounded-sm shadow-2xl flex items-center gap-3 whitespace-nowrap"
        >
          <span className="font-display font-bold text-xs sm:text-sm text-red-200 tracking-wider">
            SON DAYAQ · AYAĞA QALXMAQ ÜÇÜN DÜŞMƏNİ VUR!
          </span>
          {hud.selfReviveKit && (
            <button
              type="button"
              tabIndex={-1}
              data-testid="self-revive-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onSelfRevive();
              }}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-display font-bold text-xs rounded-xs cursor-pointer"
            >
              ÖZÜNÜ QALDIR [H]
            </button>
          )}
        </div>
      )}

      {/* Boss Close-Quarters Combat (CQC) Quick-Time Event Panel */}
      {hud.bossQte && (
        <button
          type="button"
          tabIndex={-1}
          data-testid="boss-qte-panel"
          onClick={(e) => {
            e.currentTarget.blur();
            onBossQteStrike();
          }}
          className="pointer-events-auto absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-10 w-[280px] sm:w-[320px] bg-[#1a1012]/95 border-2 border-amber-400 hover:border-white px-4 py-3 rounded-sm shadow-2xl text-left cursor-pointer"
        >
          <div className="flex items-center justify-between gap-2 text-[10px] font-mono-num font-bold mb-1">
            <span className="text-red-400 truncate">{hud.bossQte.bossName.toUpperCase()} · DUEL</span>
            <span className="text-amber-300 shrink-0">{hud.bossQte.timeLeftSec.toFixed(1)}s</span>
          </div>
          <div className="font-display font-bold text-sm sm:text-base text-stone-100 mb-2">
            YAXIN DÖYÜŞ ZƏRBƏSİ: [F] BAS!
          </div>
          <div className="flex items-center justify-between text-[10px] font-mono-num text-stone-300 mb-1">
            <span>ZƏRBƏ PROQRESİ</span>
            <span className="text-amber-300 font-bold">
              {hud.bossQte.hitsDone}/{hud.bossQte.hitsRequired}
            </span>
          </div>
          <div className="h-2 bg-stone-800 overflow-hidden mb-1.5">
            <div
              className="h-full bg-amber-400 transition-all duration-100"
              style={{
                width: `${Math.min(100, Math.round((hud.bossQte.hitsDone / Math.max(1, hud.bossQte.hitsRequired)) * 100))}%`,
              }}
            />
          </div>
          <div className="h-1 bg-stone-800 overflow-hidden">
            <div
              className="h-full bg-red-500 transition-all duration-100"
              style={{
                width: `${Math.min(100, Math.round((hud.bossQte.timeLeftSec / Math.max(0.1, hud.bossQte.maxTimeSec)) * 100))}%`,
              }}
            />
          </div>
        </button>
      )}

      {/* Contextual [E] Interact Prompt (Intel / Door Breach / Humvee Turret) */}
      {hud.interactPrompt && (
        <button
          type="button"
          tabIndex={-1}
          data-testid="interact-prompt"
          onClick={(e) => {
            e.currentTarget.blur();
            onInteract();
          }}
          className="pointer-events-auto absolute bottom-36 sm:bottom-28 left-1/2 -translate-x-1/2 px-4 py-2 bg-[#12171e]/95 border-2 border-amber-400 text-stone-100 font-display font-bold text-xs sm:text-sm tracking-wider rounded-sm shadow-xl cursor-pointer hover:bg-amber-500 hover:text-stone-950 transition-colors whitespace-nowrap"
        >
          {hud.interactPrompt.label}
        </button>
      )}

      {/* Medal Unlocked Banner */}
      {hud.medalBanner && (
        <div
          data-testid="medal-banner"
          className="absolute top-[168px] sm:top-[130px] right-3 sm:right-4 bg-[#141b22]/95 border-l-4 border-amber-400 border-t border-r border-b border-stone-600 px-3 py-2 rounded-sm shadow-xl max-w-[260px]"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-mono-num font-bold text-amber-400">
            <Medal className="w-3.5 h-3.5 shrink-0" />
            <span>MEDAL AÇILDI</span>
          </div>
          <div className="font-display font-bold text-xs text-stone-100 mt-0.5">
            {hud.medalBanner.title}
          </div>
          <div className="text-[10px] text-stone-400 leading-tight">
            {hud.medalBanner.description}
          </div>
        </div>
      )}

      {/* Killfeed (hidden in story campaign for cleaner tactical cinema look) */}
      {!isCampaign && hud.killFeed.length > 0 && (
        <div className="hidden sm:flex flex-col items-end gap-1 absolute top-22 right-4 text-xs font-semibold hud-stroke">
          {hud.killFeed.map((item) => (
            <div
              key={item.id}
              className={`px-2 py-0.5 bg-[#101418]/75 border-r-2 ${
                item.isHeadshot
                  ? 'border-amber-400 text-amber-300'
                  : 'border-stone-400 text-stone-200'
              }`}
            >
              {item.text}
            </div>
          ))}
        </div>
      )}

      {/* CENTER CROSSHAIR & HITMARKER */}
      {!hud.gunshipActive && (
        <div
          className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
          aria-hidden="true"
        >
          {!isSniperScoped &&
            (hud.isAds ? (
              <div className="relative w-8 h-8 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.9)]" />
              </div>
            ) : (
              <div className="relative w-2 h-2 flex items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-stone-100/90" />
                <div
                  className="absolute w-2.5 h-0.5 bg-stone-100/90 shadow-sm"
                  style={{ transform: `translateX(${-hud.crosshairSpread}px)` }}
                />
                <div
                  className="absolute w-2.5 h-0.5 bg-stone-100/90 shadow-sm"
                  style={{ transform: `translateX(${hud.crosshairSpread}px)` }}
                />
                <div
                  className="absolute w-0.5 h-2.5 bg-stone-100/90 shadow-sm"
                  style={{ transform: `translateY(${-hud.crosshairSpread}px)` }}
                />
                <div
                  className="absolute w-0.5 h-2.5 bg-stone-100/90 shadow-sm"
                  style={{ transform: `translateY(${hud.crosshairSpread}px)` }}
                />
              </div>
            ))}

          {/* Hitmarker X flash */}
          {hud.hitmarkerKind !== 'none' && (
            <svg
              viewBox="0 0 36 36"
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9"
            >
              <g
                stroke={hud.hitmarkerKind === 'kill' ? '#ef4444' : '#ffffff'}
                strokeWidth="2.4"
                strokeLinecap="round"
              >
                <line x1="7" y1="7" x2="13" y2="13" />
                <line x1="29" y1="7" x2="23" y2="13" />
                <line x1="7" y1="29" x2="13" y2="23" />
                <line x1="29" y1="29" x2="23" y2="23" />
              </g>
            </svg>
          )}

          {/* Reloading bar directly under center gaze */}
          {hud.reloading && (
            <div className="absolute left-1/2 top-8 -translate-x-1/2 w-24">
              <div className="text-[10px] font-display font-bold tracking-wider text-amber-300 text-center mb-1 hud-stroke">
                DOLDURULUR...
              </div>
              <div className="h-1 bg-stone-900/90 border border-stone-600/60 overflow-hidden">
                <div
                  className="h-full bg-amber-400"
                  style={{ width: `${Math.round(hud.reloadProgress * 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* 9-Weapon Quick Drawer Popup */}
      {weaponDrawerOpen && (
        <div
          data-testid="weapon-drawer"
          className={`absolute pointer-events-auto bg-[#11161c]/95 border border-stone-600 p-2 rounded-sm shadow-2xl grid grid-cols-3 gap-1 ${
            showTouchControls
              ? 'bottom-16 left-1/2 -translate-x-1/2 w-[300px]'
              : 'bottom-18 right-4 w-[340px]'
          }`}
        >
          {WEAPON_LIST.map((wId, idx) => {
            const spec = WEAPON_SPECS[wId];
            const st = hud.weapons[wId];
            const isActive = hud.activeWeapon === wId;
            return (
              <button
                key={wId}
                type="button"
                tabIndex={-1}
                onClick={() => {
                  onSwitchWeapon(wId);
                  setWeaponDrawerOpen(false);
                }}
                className={`px-2 py-1.5 border rounded-sm text-left cursor-pointer ${
                  isActive
                    ? 'bg-amber-500/20 border-amber-400 text-stone-100'
                    : 'bg-[#161c24] border-stone-700 text-stone-300 hover:border-stone-500'
                }`}
              >
                <div className="text-[10px] font-mono-num text-amber-400">
                  [{idx + 1}] {getWeaponShortName(wId)}
                </div>
                <div className="text-[9px] font-mono-num text-stone-400">
                  {spec.isMelee ? '∞' : `${st.mag}/${st.reserve}`}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* BOTTOM WEAPON SWITCHER & PC TACTICAL BAR */}
      <div
        className={`absolute flex items-center gap-1 sm:gap-1.5 pointer-events-auto ${
          showTouchControls
            ? 'bottom-2.5 left-1/2 -translate-x-1/2'
            : 'bottom-4 right-4'
        }`}
      >
        {hud.loadoutWeapons.map((id, idx) => {
          const isActive = hud.activeWeapon === id;
          const st = hud.weapons[id];
          const spec = WEAPON_SPECS[id];
          return (
            <button
              key={id}
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onSwitchWeapon(id);
              }}
              className={`min-h-[42px] px-2 sm:px-2.5 py-1 border rounded-sm text-left transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#151a20]/95 border-amber-500 text-stone-100'
                  : 'bg-[#101418]/80 border-stone-700/75 text-stone-400 hover:border-stone-500'
              }`}
            >
              <div className="flex items-center gap-1">
                <span className="text-[10px] font-mono-num text-amber-400">[{idx + 1}]</span>
                <span className="font-display font-bold text-xs whitespace-nowrap">
                  {getWeaponShortName(id)}
                </span>
              </div>
              <div className="font-mono-num text-[11px] text-stone-300">
                {spec.isMelee ? (
                  '∞'
                ) : (
                  <>
                    <span className={isActive && st.mag <= 3 ? 'text-red-400 font-bold' : ''}>
                      {st.mag}
                    </span>{' '}
                    <span className="text-stone-500">/ {st.reserve}</span>
                  </>
                )}
              </div>
            </button>
          );
        })}

        {/* Active extra weapon chip if using 3..9 */}
        {!hud.loadoutWeapons.includes(hud.activeWeapon) && (
          <div className="min-h-[42px] px-2 py-1 border border-amber-500 bg-[#151a20]/95 text-stone-100 rounded-sm">
            <div className="text-[10px] font-display font-bold text-amber-300 whitespace-nowrap">
              {getWeaponShortName(hud.activeWeapon)}
            </div>
            <div className="font-mono-num text-[11px]">
              {WEAPON_SPECS[hud.activeWeapon].isMelee
                ? '∞'
                : `${hud.weapons[hud.activeWeapon].mag} / ${hud.weapons[hud.activeWeapon].reserve}`}
            </div>
          </div>
        )}

        {/* All 9 Weapons drawer toggle */}
        <button
          type="button"
          tabIndex={-1}
          data-testid="toggle-weapon-drawer-btn"
          onClick={(e) => {
            e.currentTarget.blur();
            setWeaponDrawerOpen((v) => !v);
          }}
          title="Bütün 9 silah [1-9]"
          className="min-h-[42px] px-2 py-1 bg-[#101418]/85 border border-stone-600 hover:border-amber-400 text-stone-200 rounded-sm flex items-center gap-1 text-[10px] font-mono-num cursor-pointer"
        >
          <ChevronUp className={`w-3.5 h-3.5 transition-transform ${weaponDrawerOpen ? 'rotate-180' : ''}`} />
          <span>9</span>
        </button>

        {!showTouchControls && (
          <>
            {!isCampaign && (
              <button
                type="button"
                tabIndex={-1}
                data-testid="armor-plate-btn"
                disabled={!plateReady}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onUseArmorPlate();
                }}
                className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                  plateReady
                    ? 'bg-sky-500/90 border-sky-300 text-stone-950 cursor-pointer'
                    : 'bg-[#101418]/85 border-stone-700/80 text-stone-400'
                }`}
              >
                <div className="text-[9px] font-semibold">LÖVHƏ [V]</div>
                <div className="font-mono-num font-bold text-xs leading-tight">
                  {hud.armorPlates}/{hud.maxArmorPlates}
                </div>
              </button>
            )}

            <button
              type="button"
              tabIndex={-1}
              data-testid="stim-btn"
              disabled={hud.stims <= 0 || (hud.hp >= hud.maxHp && hud.stimBoostTimer > 0)}
              onClick={(e) => {
                e.currentTarget.blur();
                onUseStim();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                hud.stimBoostTimer > 0
                  ? 'bg-emerald-500 border-emerald-200 text-stone-950 cursor-pointer'
                  : hud.stims > 0
                    ? 'bg-[#101418]/85 border-emerald-500/70 hover:border-emerald-300 text-emerald-300 cursor-pointer'
                    : 'bg-[#101418]/85 border-stone-700/80 text-stone-500'
              }`}
            >
              <div className="text-[9px] font-semibold">STİM [H]</div>
              <div className="font-mono-num font-bold text-xs leading-tight">
                {hud.stimBoostTimer > 0 ? `${Math.ceil(hud.stimBoostTimer)}s` : `${hud.stims}/${hud.maxStims}`}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="lean-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onCycleLean();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors cursor-pointer ${
                hud.lean !== 'none'
                  ? 'bg-amber-500/90 border-amber-300 text-stone-950'
                  : 'bg-[#101418]/85 border-stone-700/80 hover:border-amber-400 text-stone-200'
              }`}
            >
              <div className="text-[9px] font-semibold">ƏYİL [Q]</div>
              <div className="font-mono-num font-bold text-[10px] leading-tight">
                {hud.lean === 'left' ? 'SOL' : hud.lean === 'right' ? 'SAĞ' : 'DÜZ'}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="field-upgrade-btn"
              disabled={hud.fieldUpgradeCooldownPct < 1 && hud.fieldUpgradeActiveTimer <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onActivateFieldUpgrade();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                hud.fieldUpgradeActiveTimer > 0
                  ? 'bg-emerald-500 border-emerald-200 text-stone-950 cursor-pointer'
                  : hud.fieldUpgradeCooldownPct >= 1
                    ? 'bg-cyan-500/90 border-cyan-200 text-stone-950 cursor-pointer'
                    : 'bg-[#101418]/85 border-stone-700/80 text-stone-400'
              }`}
            >
              <div className="text-[9px] font-semibold truncate max-w-[66px]">
                {activeFieldUpgradeSpec.shortName.toUpperCase()} [O]
              </div>
              <div className="font-mono-num font-bold text-[10px] leading-tight">
                {hud.fieldUpgradeActiveTimer > 0
                  ? `${Math.ceil(hud.fieldUpgradeActiveTimer)}s`
                  : hud.fieldUpgradeCooldownPct >= 1
                    ? 'HAZIR'
                    : `${Math.round(hud.fieldUpgradeCooldownPct * 100)}%`}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="crouch-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onToggleCrouch();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors cursor-pointer ${
                hud.isCrouching
                  ? 'bg-amber-500/90 border-amber-300 text-stone-950'
                  : 'bg-[#101418]/85 border-stone-700/80 hover:border-amber-400 text-stone-200'
              }`}
            >
              <div className="text-[9px] font-semibold">ÇÖK [C]</div>
              <div className="font-mono-num font-bold text-[10px] leading-tight">
                {hud.isCrouching ? 'AŞAĞI' : 'DİK'}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="inspect-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onInspectWeapon();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors cursor-pointer ${
                hud.isInspecting
                  ? 'bg-sky-500/90 border-sky-200 text-stone-950'
                  : 'bg-[#101418]/85 border-stone-700/80 hover:border-sky-400 text-stone-300'
              }`}
            >
              <div className="text-[9px] font-semibold">BAXIŞ [I]</div>
              <Eye className="w-3.5 h-3.5 mx-auto mt-0.5" />
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="melee-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onMelee();
              }}
              className="min-h-[42px] px-2 py-1 bg-[#101418]/85 border border-stone-700/80 hover:border-amber-400 text-stone-200 rounded-sm text-center cursor-pointer"
            >
              <div className="text-[9px] font-semibold text-stone-400">BIÇAQ [F]</div>
              <Swords className="w-3.5 h-3.5 mx-auto text-amber-400 mt-0.5" />
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="c4-btn"
              disabled={hud.c4Count <= 0 && hud.c4PlantedCount <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onTriggerC4();
              }}
              className={`min-h-[42px] px-2 py-1 border rounded-sm text-center disabled:opacity-45 cursor-pointer ${
                hud.c4PlantedCount > 0
                  ? 'bg-red-600/90 border-red-300 text-white'
                  : 'bg-[#101418]/85 border-stone-700/80 hover:border-orange-400 text-stone-200'
              }`}
            >
              <div className="text-[9px] font-semibold">
                {hud.c4PlantedCount > 0 ? 'PARTLAT [Z]' : 'C4 [Z]'}
              </div>
              <div className="font-mono-num font-bold text-xs leading-tight">
                {hud.c4PlantedCount > 0 ? `×${hud.c4PlantedCount}` : hud.c4Count}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="claymore-btn"
              disabled={hud.claymoreCount <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onPlaceClaymore();
              }}
              className="min-h-[42px] px-2 py-1 bg-[#101418]/85 border border-stone-700/80 hover:border-emerald-400 disabled:opacity-45 rounded-sm text-center cursor-pointer"
            >
              <div className="text-[9px] font-semibold text-stone-400">CLAY [K]</div>
              <div className="font-mono-num font-bold text-xs text-emerald-300 leading-tight">
                {hud.claymoreCount}
              </div>
            </button>

            {!isCampaign && (
              <>
                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="uav-btn"
                  disabled={!hud.uavReady}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onTriggerUav();
                  }}
                  className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                    uavActive || hud.uavReady
                      ? 'bg-emerald-500/90 border-emerald-300 text-stone-950 cursor-pointer'
                      : 'bg-[#101418]/85 border-stone-700/80 text-stone-400'
                  }`}
                >
                  <div className="text-[9px] font-semibold">UAV [U]</div>
                  <div className="font-mono-num font-bold text-xs leading-tight">
                    {uavActive
                      ? `${Math.ceil(hud.uavActiveTimer)}s`
                      : hud.uavReady
                        ? 'HAZIR'
                        : `${Math.min(hud.uavThreshold, hud.killstreakProgress)}/${hud.uavThreshold}`}
                  </div>
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="care-package-btn"
                  disabled={!hud.carePackageReady}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onCallCarePackage();
                  }}
                  className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                    hud.carePackageReady
                      ? 'bg-emerald-500/95 border-emerald-200 text-stone-950 cursor-pointer'
                      : hud.carePackageActive
                        ? 'bg-emerald-950/90 border-emerald-400 text-emerald-300'
                        : 'bg-[#101418]/85 border-stone-700/80 text-stone-400'
                  }`}
                >
                  <div className="text-[9px] font-semibold">PAKET [J]</div>
                  <div className="font-mono-num font-bold text-xs leading-tight">
                    {hud.carePackageReady
                      ? 'ÇAĞIR'
                      : hud.carePackageActive
                        ? 'YOLDA'
                        : `${Math.min(4, hud.killstreakProgress)}/4`}
                  </div>
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="gunship-btn"
                  disabled={!hud.gunshipReady && !hud.gunshipActive && !hud.killstreakReady}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    if (hud.gunshipReady || hud.gunshipActive) {
                      onGunship();
                    } else {
                      onKillstreak();
                    }
                  }}
                  className={`min-h-[42px] px-2 py-1 border rounded-sm text-center transition-colors ${
                    hud.gunshipActive
                      ? 'bg-red-500 border-red-200 text-white cursor-pointer'
                      : hud.gunshipReady || hud.killstreakReady
                        ? 'bg-amber-500/95 border-amber-300 text-stone-950 cursor-pointer'
                        : 'bg-[#101418]/85 border-stone-700/80 text-stone-400'
                  }`}
                >
                  <div className="text-[9px] font-semibold">AC-130 [Y]</div>
                  <div className="font-mono-num font-bold text-xs leading-tight">
                    {hud.gunshipActive
                      ? `${Math.ceil(hud.gunshipTimer)}s`
                      : hud.gunshipReady || hud.killstreakReady
                        ? 'HAZIR'
                        : `${hud.killstreakProgress}/${hud.killstreakThreshold}`}
                  </div>
                </button>
              </>
            )}

            <button
              type="button"
              tabIndex={-1}
              data-testid="flashbang-btn"
              disabled={hud.flashbangs <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onThrowFlashbang();
              }}
              className="min-h-[42px] px-2 py-1 bg-[#101418]/85 border border-stone-700/80 hover:border-sky-400 disabled:opacity-50 rounded-sm text-center cursor-pointer"
            >
              <div className="text-[9px] font-semibold text-stone-400">FLASH [X]</div>
              <div className="font-mono-num font-bold text-xs text-sky-300 leading-tight">
                {hud.flashbangs}
              </div>
            </button>

            <button
              type="button"
              tabIndex={-1}
              disabled={hud.grenades <= 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onGrenade();
              }}
              className="min-h-[42px] px-2 py-1 bg-[#101418]/85 border border-stone-700/80 hover:border-amber-400 disabled:opacity-50 rounded-sm text-center cursor-pointer"
            >
              <div className="text-[9px] font-semibold text-stone-400">QUM [G]</div>
              <div className="font-mono-num font-bold text-xs text-amber-400 leading-tight">
                {hud.grenades}
              </div>
            </button>
          </>
        )}
      </div>

      {/* MOBILE / TOUCH DUAL-THUMB CONTROLS */}
      {showTouchControls && (
        <>
          {/* Left-side Armor Plate + Stim + Crouch + Care Package + UAV + AC-130 triggers above Joystick */}
          <div className="absolute bottom-[202px] left-4 sm:bottom-[180px] sm:left-8 flex flex-wrap gap-1 max-w-[172px] pointer-events-auto">
            {!isCampaign && (
              <button
                type="button"
                tabIndex={-1}
                data-testid="armor-plate-btn-mobile"
                disabled={!plateReady}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onUseArmorPlate();
                }}
                aria-label="Zireh lövhəsi tax"
                className={`min-h-[34px] px-2 py-1 border rounded-sm flex items-center gap-1 transition-colors ${
                  plateReady
                    ? 'bg-sky-500 border-stone-100 text-stone-950 shadow-md'
                    : 'bg-[#101418]/80 border-stone-700/80 text-stone-400 opacity-75'
                }`}
              >
                <Shield className="w-3 h-3" />
                <span className="font-display font-bold text-[10px] tracking-wider">
                  {hud.armorPlates}/{hud.maxArmorPlates}
                </span>
              </button>
            )}

            <button
              type="button"
              tabIndex={-1}
              data-testid="stim-btn-mobile"
              disabled={hud.stims <= 0 || (hud.hp >= hud.maxHp && hud.stimBoostTimer > 0)}
              onPointerDown={(e) => {
                e.stopPropagation();
                onUseStim();
              }}
              aria-label="Adrenalin Stim"
              className={`min-h-[34px] px-2 py-1 border rounded-sm font-display font-bold text-[10px] tracking-wider transition-colors ${
                hud.stimBoostTimer > 0
                  ? 'bg-emerald-500 border-white text-stone-950'
                  : hud.stims > 0
                    ? 'bg-[#101815]/90 border-emerald-400 text-emerald-300'
                    : 'bg-[#101418]/80 border-stone-700 text-stone-500 opacity-70'
              }`}
            >
              STİM {hud.stims}
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="lean-btn-mobile"
              onPointerDown={(e) => {
                e.stopPropagation();
                onCycleLean();
              }}
              aria-label="Əyil"
              className={`min-h-[34px] px-2 py-1 border rounded-sm font-display font-bold text-[10px] tracking-wider transition-colors ${
                hud.lean !== 'none'
                  ? 'bg-amber-500 border-white text-stone-950'
                  : 'bg-[#101418]/80 border-stone-600 text-stone-200'
              }`}
            >
              ƏYİL
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="field-upgrade-btn-mobile"
              disabled={hud.fieldUpgradeCooldownPct < 1 && hud.fieldUpgradeActiveTimer <= 0}
              onPointerDown={(e) => {
                e.stopPropagation();
                onActivateFieldUpgrade();
              }}
              aria-label="Taktiki Vasitə"
              className={`min-h-[34px] px-2 py-1 border rounded-sm font-display font-bold text-[10px] tracking-wider transition-colors ${
                hud.fieldUpgradeActiveTimer > 0
                  ? 'bg-emerald-500 border-white text-stone-950'
                  : hud.fieldUpgradeCooldownPct >= 1
                    ? 'bg-cyan-500 border-white text-stone-950'
                    : 'bg-[#101418]/80 border-stone-700 text-stone-400 opacity-75'
              }`}
            >
              {hud.fieldUpgradeActiveTimer > 0
                ? `${Math.ceil(hud.fieldUpgradeActiveTimer)}s`
                : activeFieldUpgradeSpec.shortName.slice(0, 6).toUpperCase()}
            </button>

            <button
              type="button"
              tabIndex={-1}
              data-testid="crouch-btn-mobile"
              onPointerDown={(e) => {
                e.stopPropagation();
                onToggleCrouch();
              }}
              aria-label="Çök"
              className={`min-h-[34px] px-2 py-1 border rounded-sm font-display font-bold text-[10px] tracking-wider transition-colors ${
                hud.isCrouching
                  ? 'bg-amber-500 border-white text-stone-950'
                  : 'bg-[#101418]/80 border-stone-600 text-stone-200'
              }`}
            >
              ÇÖK
            </button>

            {!isCampaign && (
              <>
                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="care-package-btn-mobile"
                  disabled={!hud.carePackageReady}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onCallCarePackage();
                  }}
                  aria-label="Yardım Paketi"
                  className={`min-h-[34px] px-2 py-1 border rounded-sm font-display font-bold text-[10px] tracking-wider transition-colors ${
                    hud.carePackageReady
                      ? 'bg-emerald-500 border-white text-stone-950 shadow-md'
                      : 'bg-[#101418]/80 border-stone-700/80 text-stone-400 opacity-75'
                  }`}
                >
                  {hud.carePackageReady ? 'PAKET!' : `PAK ${Math.min(4, hud.killstreakProgress)}/4`}
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  data-testid="uav-btn-mobile"
                  disabled={!hud.uavReady}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    onTriggerUav();
                  }}
                  aria-label="UAV Kəşfiyyat"
                  className={`min-h-[34px] px-2 py-1 border rounded-sm flex items-center gap-1 transition-colors ${
                    uavActive || hud.uavReady
                      ? 'bg-emerald-500 border-stone-100 text-stone-950 shadow-md'
                      : 'bg-[#101418]/80 border-stone-700/80 text-stone-300 opacity-80'
                  }`}
                >
                  <Radar className="w-3 h-3" />
                  <span className="font-display font-bold text-[10px] tracking-wider">
                    {uavActive
                      ? `${Math.ceil(hud.uavActiveTimer)}s`
                      : hud.uavReady
                        ? 'UAV'
                        : `${Math.min(hud.uavThreshold, hud.killstreakProgress)}/${hud.uavThreshold}`}
                  </span>
                </button>

                <button
                  type="button"
                  tabIndex={-1}
                  disabled={!hud.killstreakReady && !hud.gunshipReady && !hud.gunshipActive}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    if (hud.gunshipReady || hud.gunshipActive) {
                      onGunship();
                    } else {
                      onKillstreak();
                    }
                  }}
                  aria-label="AC-130 Gunship"
                  className={`min-h-[34px] px-2 py-1 border rounded-sm flex items-center gap-1 transition-colors ${
                    hud.gunshipActive
                      ? 'bg-red-500 border-white text-white shadow-lg'
                      : hud.killstreakReady || hud.gunshipReady
                        ? 'bg-amber-500 border-stone-100 text-stone-950 shadow-lg'
                        : 'bg-[#101418]/80 border-stone-700/80 text-stone-300 opacity-80'
                  }`}
                >
                  <Plane className="w-3 h-3" />
                  <span className="font-display font-bold text-[10px] tracking-wider">
                    {hud.gunshipActive
                      ? `${Math.ceil(hud.gunshipTimer)}s`
                      : hud.killstreakReady || hud.gunshipReady
                        ? 'AC130'
                        : `${hud.killstreakProgress}/${hud.killstreakThreshold}`}
                  </span>
                </button>
              </>
            )}
          </div>

          {/* Left Thumb Virtual Analog Joystick */}
          <div
            ref={joyRef}
            data-testid="virtual-joystick"
            className={`absolute bottom-20 left-4 sm:bottom-10 sm:left-8 w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-[#101418]/65 border-2 pointer-events-auto touch-none flex items-center justify-center transition-colors ${
              hud.isSprinting ? 'border-amber-400' : 'border-stone-500/60'
            }`}
            onPointerDown={(e) => {
              if (joyPointerId.current !== null) return;
              joyPointerId.current = e.pointerId;
              e.currentTarget.setPointerCapture(e.pointerId);
              updateJoystick(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => {
              if (joyPointerId.current !== e.pointerId) return;
              updateJoystick(e.clientX, e.clientY);
            }}
            onPointerUp={(e) => {
              if (joyPointerId.current === e.pointerId) resetJoystick();
            }}
            onPointerCancel={(e) => {
              if (joyPointerId.current === e.pointerId) resetJoystick();
            }}
          >
            {hud.isSprinting && (
              <span className="absolute top-1.5 text-[9px] font-display font-bold tracking-wider text-amber-300 pointer-events-none">
                QAÇIŞ
              </span>
            )}
            <div
              className="w-12 h-12 rounded-full bg-amber-500/85 border-2 border-stone-100/80 shadow-md pointer-events-none"
              style={{
                transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
              }}
            />
          </div>

          {/* Right Thumb Ergonomic Combat Trigger Cluster */}
          <div className="absolute bottom-20 right-4 sm:bottom-10 sm:right-8 flex flex-col items-end gap-2 pointer-events-none">
            {/* Upper quick actions: Knife, C4, Slide, Jump, Reload, Flashbang, Grenade */}
            <div className="flex items-center gap-1 pointer-events-auto">
              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onMelee();
                }}
                aria-label="Bıçaq"
                className="w-9 h-9 rounded-full bg-[#101418]/85 border border-stone-500/80 text-amber-300 active:scale-95 transition-transform flex items-center justify-center"
              >
                <Swords className="w-4 h-4" />
              </button>

              <button
                type="button"
                tabIndex={-1}
                disabled={hud.c4Count <= 0 && hud.c4PlantedCount <= 0}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onTriggerC4();
                }}
                aria-label="C4"
                className={`relative w-9 h-9 rounded-full border active:scale-95 transition-transform flex items-center justify-center ${
                  hud.c4PlantedCount > 0
                    ? 'bg-red-600/90 border-red-300 text-white'
                    : 'bg-[#101418]/85 border-stone-500/80 text-orange-300 disabled:opacity-40'
                }`}
              >
                <Bomb className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-orange-500 text-stone-950 font-mono-num font-bold text-[9px] flex items-center justify-center">
                  {hud.c4PlantedCount > 0 ? hud.c4PlantedCount : hud.c4Count}
                </span>
              </button>

              <button
                type="button"
                tabIndex={-1}
                disabled={hud.slideCooldownPct < 1}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onSlide();
                }}
                aria-label="Sürüş"
                className="w-9 h-9 rounded-full bg-[#101418]/85 border border-stone-500/80 text-stone-100 disabled:opacity-45 font-display font-bold text-[8px] active:scale-95 transition-transform flex items-center justify-center"
              >
                SÜRÜŞ
              </button>

              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onJump();
                }}
                aria-label="Tullan"
                className="w-9 h-9 rounded-full bg-[#101418]/85 border border-stone-500/80 text-stone-100 font-display font-bold text-[8px] active:scale-95 transition-transform flex items-center justify-center"
              >
                ATIL
              </button>

              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onReload();
                }}
                aria-label="Doldur"
                className="w-9 h-9 rounded-full bg-[#101418]/85 border border-stone-500/80 text-stone-100 active:scale-95 transition-transform flex items-center justify-center"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              <button
                type="button"
                tabIndex={-1}
                disabled={hud.flashbangs <= 0}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onThrowFlashbang();
                }}
                aria-label="Flashbang"
                className="relative w-9 h-9 rounded-full bg-[#101418]/85 border border-sky-400/70 text-sky-300 disabled:opacity-40 active:scale-95 transition-transform flex items-center justify-center"
              >
                <Sparkles className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-sky-400 text-stone-950 font-mono-num font-bold text-[9px] flex items-center justify-center">
                  {hud.flashbangs}
                </span>
              </button>

              <button
                type="button"
                tabIndex={-1}
                disabled={hud.grenades <= 0}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onGrenade();
                }}
                aria-label="Qumbara"
                className="relative w-9 h-9 rounded-full bg-[#101418]/85 border border-stone-500/80 text-amber-400 disabled:opacity-40 active:scale-95 transition-transform flex items-center justify-center"
              >
                <Flame className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-stone-950 font-mono-num font-bold text-[9px] flex items-center justify-center">
                  {hud.grenades}
                </span>
              </button>
            </div>

            {/* Primary Thumb Triggers: ADS + FIRE */}
            <div className="flex items-center gap-3 pointer-events-auto">
              <button
                type="button"
                tabIndex={-1}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  onToggleAds();
                }}
                aria-label="Nişangah"
                className={`w-14 h-14 rounded-full border-2 font-display font-bold text-xs active:scale-95 transition-transform flex flex-col items-center justify-center ${
                  hud.isAds
                    ? 'bg-amber-500 border-stone-100 text-stone-950'
                    : 'bg-[#101418]/85 border-stone-400/80 text-stone-100'
                }`}
              >
                <Crosshair className="w-5 h-5" />
                <span className="text-[9px] mt-0.5">NİŞAN</span>
              </button>

              <button
                type="button"
                tabIndex={-1}
                data-testid="touch-fire-btn"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.currentTarget.setPointerCapture(e.pointerId);
                  onFireHeld(true);
                }}
                onPointerUp={(e) => {
                  e.stopPropagation();
                  onFireHeld(false);
                }}
                onPointerCancel={() => onFireHeld(false)}
                aria-label="Atəş et"
                className="w-[72px] h-[72px] rounded-full bg-red-600/90 active:bg-red-500 border-2 border-amber-300 text-white font-display font-bold text-xs shadow-lg active:scale-95 transition-transform flex flex-col items-center justify-center touch-none"
              >
                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                  <path d="M12 2L14.8 8.2L14.8 18L9.2 18L9.2 8.2Z M9.2 19.5L14.8 19.5L14.8 22L9.2 22Z" />
                </svg>
                <span className="text-[10px] tracking-wider mt-0.5">ATƏŞ</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
