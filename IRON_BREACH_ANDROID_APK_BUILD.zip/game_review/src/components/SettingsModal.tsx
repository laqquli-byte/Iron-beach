import React from 'react';
import { Sliders, Volume2, Eye, Monitor, X } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sensitivity: number;
  setSensitivity: (val: number) => void;
  fov: number;
  setFov: (val: number) => void;
  volume: number;
  setVolume: (val: number) => void;
  touchControlsEnabled: boolean;
  setTouchControlsEnabled: (val: boolean) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  sensitivity,
  setSensitivity,
  fov,
  setFov,
  volume,
  setVolume,
  touchControlsEnabled,
  setTouchControlsEnabled,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Oyun Tənzimləmələri"
      data-testid="settings-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 animate-fadeIn"
    >
      <div className="w-full max-w-lg bg-[#0e1217] border border-amber-500/40 rounded-lg shadow-2xl overflow-hidden font-sans text-stone-200">
        <div className="flex items-center justify-between px-6 py-4 bg-[#141a22] border-b border-stone-800">
          <div className="flex items-center gap-3">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h2 className="font-display font-bold text-lg tracking-wider text-amber-400">
              OYUN TƏNZİMLƏMƏLƏRİ
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Bağla"
            className="p-1.5 text-stone-400 hover:text-white rounded-md hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Sensitivity */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-semibold text-stone-300 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" /> Baxış Həssaslığı (Sensitivity)
              </span>
              <span className="font-mono-num font-bold text-amber-400">{sensitivity.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              aria-label="Baxış Həssaslığı"
              min="0.3"
              max="2.5"
              step="0.05"
              value={sensitivity}
              onChange={(e) => setSensitivity(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* FOV */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-semibold text-stone-300 flex items-center gap-2">
                <Eye className="w-4 h-4 text-amber-400" /> Görüş Bucağı (FOV)
              </span>
              <span className="font-mono-num font-bold text-amber-400">{fov}°</span>
            </div>
            <input
              type="range"
              aria-label="Görüş Bucağı"
              min="60"
              max="110"
              step="1"
              value={fov}
              onChange={(e) => setFov(parseInt(e.target.value, 10))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Volume */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-semibold text-stone-300 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-amber-400" /> Səs Səviyyəsi (Master Volume)
              </span>
              <span className="font-mono-num font-bold text-amber-400">{Math.round(volume * 100)}%</span>
            </div>
            <input
              type="range"
              aria-label="Səs Səviyyəsi"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Touch Controls Toggle */}
          <div className="flex items-center justify-between pt-2 border-t border-stone-800">
            <div className="flex items-center gap-2">
              <Monitor className="w-4 h-4 text-amber-400" />
              <div>
                <div className="text-sm font-semibold text-stone-200">Mobil / Touch İdarəetmə Düymələri</div>
                <div className="text-xs text-stone-400">Ekranda virtual joystik və hərəkət düymələrini göstər</div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setTouchControlsEnabled(!touchControlsEnabled)}
              className={`px-4 py-1.5 rounded-sm font-display font-bold text-xs tracking-wider transition-colors ${
                touchControlsEnabled
                  ? 'bg-amber-500 text-stone-950 font-bold'
                  : 'bg-stone-800 text-stone-400 hover:bg-stone-700'
              }`}
            >
              {touchControlsEnabled ? 'AÇIQ' : 'BAĞLI'}
            </button>
          </div>
        </div>

        <div className="px-6 py-4 bg-[#141a22] border-t border-stone-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-display font-bold text-xs tracking-wider rounded-sm transition-colors cursor-pointer"
          >
            TƏSDİQ ET & QAYIT
          </button>
        </div>
      </div>
    </div>
  );
};
