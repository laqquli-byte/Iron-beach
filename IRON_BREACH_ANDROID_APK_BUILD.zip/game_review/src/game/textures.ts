import * as THREE from 'three';
import type { WeaponCamoId } from './types';

function createCanvas(size = 256): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function finalizeTexture(
  canvas: HTMLCanvasElement,
  repeatX: number,
  repeatY: number,
  maxAniso: number,
  isColor = true,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = maxAniso;
  if (isColor) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.needsUpdate = true;
  return tex;
}

export interface MaterialTextures {
  groundMap: THREE.CanvasTexture;
  groundBump: THREE.CanvasTexture;
  concreteMap: THREE.CanvasTexture;
  concreteBump: THREE.CanvasTexture;
  containerRibBump: THREE.CanvasTexture;
  camoMap: THREE.CanvasTexture;
  crateMap: THREE.CanvasTexture;
  shadowDiscMap: THREE.CanvasTexture;
  weaponCamos: Record<WeaponCamoId, THREE.CanvasTexture | null>;
  dispose: () => void;
}

export function createProceduralTextures(maxAniso: number): MaterialTextures {
  // 1. Modern tactical base concrete-tarmac slab texture (512x512)
  const [gCanvas, gCtx] = createCanvas(512);
  gCtx.fillStyle = '#585247';
  gCtx.fillRect(0, 0, 512, 512);
  // Subtle aggregate & desert dust mottling
  for (let i = 0; i < 8500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = 68 + Math.floor(Math.random() * 40);
    gCtx.fillStyle = `rgb(${v + 9}, ${v + 3}, ${v - 7})`;
    gCtx.fillRect(x, y, 1.5 + Math.random() * 2.5, 1.5 + Math.random() * 2.5);
  }
  // Subtle tire/wear streaks
  gCtx.fillStyle = 'rgba(42, 38, 32, 0.14)';
  for (let i = 0; i < 16; i++) {
    gCtx.fillRect(0, Math.random() * 512, 512, 4 + Math.random() * 12);
  }
  // Concrete slab expansion joints + bevel highlight
  for (let p = 0; p <= 512; p += 128) {
    gCtx.strokeStyle = 'rgba(28, 25, 21, 0.48)';
    gCtx.lineWidth = 3;
    gCtx.beginPath();
    gCtx.moveTo(p, 0);
    gCtx.lineTo(p, 512);
    gCtx.stroke();
    gCtx.beginPath();
    gCtx.moveTo(0, p);
    gCtx.lineTo(512, p);
    gCtx.stroke();

    gCtx.strokeStyle = 'rgba(175, 160, 138, 0.18)';
    gCtx.lineWidth = 1;
    gCtx.beginPath();
    gCtx.moveTo(p + 2, 0);
    gCtx.lineTo(p + 2, 512);
    gCtx.stroke();
    gCtx.beginPath();
    gCtx.moveTo(0, p + 2);
    gCtx.lineTo(512, p + 2);
    gCtx.stroke();
  }
  // Corner tie-down bolts on concrete tiles
  gCtx.fillStyle = 'rgba(25, 24, 22, 0.5)';
  for (let x = 10; x < 512; x += 128) {
    for (let y = 10; y < 512; y += 128) {
      gCtx.fillRect(x, y, 4, 4);
      gCtx.fillRect(x + 104, y + 104, 4, 4);
    }
  }
  const groundMap = finalizeTexture(gCanvas, 16, 16, maxAniso, true);

  // Ground bump map matching joints + micro-gravel
  const [gbCanvas, gbCtx] = createCanvas(256);
  gbCtx.fillStyle = '#848484';
  gbCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 4200; i++) {
    const v = 96 + Math.floor(Math.random() * 76);
    gbCtx.fillStyle = `rgb(${v},${v},${v})`;
    gbCtx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  gbCtx.strokeStyle = '#363636';
  gbCtx.lineWidth = 2;
  for (let p = 0; p <= 256; p += 64) {
    gbCtx.beginPath();
    gbCtx.moveTo(p, 0);
    gbCtx.lineTo(p, 256);
    gbCtx.stroke();
    gbCtx.beginPath();
    gbCtx.moveTo(0, p);
    gbCtx.lineTo(256, p);
    gbCtx.stroke();
  }
  const groundBump = finalizeTexture(gbCanvas, 16, 16, maxAniso, false);

  // 2. Concrete barrier texture with hazard stripes + weathering
  const [cCanvas, cCtx] = createCanvas(256);
  cCtx.fillStyle = '#8e8a81';
  cCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3200; i++) {
    const v = 112 + Math.floor(Math.random() * 44);
    cCtx.fillStyle = `rgb(${v},${v - 2},${v - 5})`;
    cCtx.fillRect(Math.random() * 256, Math.random() * 256, 2, 2);
  }
  // Vertical panel seam & top bevel wear
  cCtx.fillStyle = 'rgba(255,255,255,0.12)';
  cCtx.fillRect(0, 0, 256, 8);
  cCtx.fillStyle = 'rgba(40,36,30,0.22)';
  cCtx.fillRect(0, 234, 256, 22);
  // Hazard stripe band near base
  cCtx.fillStyle = '#e08212';
  cCtx.fillRect(0, 208, 256, 24);
  cCtx.fillStyle = '#181615';
  for (let x = -32; x < 288; x += 32) {
    cCtx.beginPath();
    cCtx.moveTo(x, 232);
    cCtx.lineTo(x + 16, 232);
    cCtx.lineTo(x + 28, 208);
    cCtx.lineTo(x + 12, 208);
    cCtx.closePath();
    cCtx.fill();
  }
  const concreteMap = finalizeTexture(cCanvas, 1, 1, maxAniso, true);

  const [cbCanvas, cbCtx] = createCanvas(128);
  cbCtx.fillStyle = '#808080';
  cbCtx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 1600; i++) {
    const v = 90 + Math.floor(Math.random() * 75);
    cbCtx.fillStyle = `rgb(${v},${v},${v})`;
    cbCtx.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  }
  const concreteBump = finalizeTexture(cbCanvas, 1, 1, maxAniso, false);

  // 3. Corrugated shipping container rib bump
  const [ribCanvas, ribCtx] = createCanvas(256);
  for (let x = 0; x < 256; x += 16) {
    const grad = ribCtx.createLinearGradient(x, 0, x + 16, 0);
    grad.addColorStop(0, '#3a3a3a');
    grad.addColorStop(0.5, '#f2f2f2');
    grad.addColorStop(1, '#3a3a3a');
    ribCtx.fillStyle = grad;
    ribCtx.fillRect(x, 0, 16, 256);
  }
  const containerRibBump = finalizeTexture(ribCanvas, 4, 1, maxAniso, false);

  // 4. Modern digital/multicam tactical uniform pattern
  const [camoCanvas, camoCtx] = createCanvas(256);
  camoCtx.fillStyle = '#484f3d';
  camoCtx.fillRect(0, 0, 256, 256);
  const camoColors = ['#2e3427', '#666c52', '#22261e', '#7e7056', '#3d4435'];
  for (let i = 0; i < 64; i++) {
    camoCtx.fillStyle = camoColors[i % camoColors.length];
    camoCtx.beginPath();
    camoCtx.ellipse(
      Math.random() * 256,
      Math.random() * 256,
      10 + Math.random() * 24,
      6 + Math.random() * 14,
      Math.random() * Math.PI,
      0,
      Math.PI * 2,
    );
    camoCtx.fill();
  }
  // Micro ripstop grid weave
  camoCtx.strokeStyle = 'rgba(0,0,0,0.12)';
  camoCtx.lineWidth = 1;
  for (let p = 0; p < 256; p += 8) {
    camoCtx.beginPath();
    camoCtx.moveTo(p, 0);
    camoCtx.lineTo(p, 256);
    camoCtx.stroke();
    camoCtx.beginPath();
    camoCtx.moveTo(0, p);
    camoCtx.lineTo(256, p);
    camoCtx.stroke();
  }
  const camoMap = finalizeTexture(camoCanvas, 1, 1, maxAniso, true);

  // 5. Reinforced wooden military supply crate
  const [wCanvas, wCtx] = createCanvas(256);
  wCtx.fillStyle = '#745939';
  wCtx.fillRect(0, 0, 256, 256);
  for (let y = 28; y < 228; y += 28) {
    wCtx.strokeStyle = 'rgba(38,26,14,0.48)';
    wCtx.lineWidth = 2;
    wCtx.beginPath();
    wCtx.moveTo(12, y);
    wCtx.lineTo(244, y);
    wCtx.stroke();
  }
  wCtx.strokeStyle = '#3f2e1b';
  wCtx.lineWidth = 12;
  wCtx.strokeRect(8, 8, 240, 240);
  wCtx.lineWidth = 7;
  wCtx.beginPath();
  wCtx.moveTo(14, 14);
  wCtx.lineTo(242, 242);
  wCtx.stroke();
  // Dark steel corner brackets
  wCtx.fillStyle = '#25282c';
  for (const [bx, by] of [
    [0, 0],
    [226, 0],
    [0, 226],
    [226, 226],
  ]) {
    wCtx.fillRect(bx, by, 30, 10);
    wCtx.fillRect(bx, by, 10, 30);
  }
  const crateMap = finalizeTexture(wCanvas, 1, 1, maxAniso, true);

  // 6. Soft radial contact shadow
  const [sCanvas, sCtx] = createCanvas(128);
  const rad = sCtx.createRadialGradient(64, 64, 6, 64, 64, 62);
  rad.addColorStop(0, 'rgba(0,0,0,0.68)');
  rad.addColorStop(0.55, 'rgba(0,0,0,0.28)');
  rad.addColorStop(1, 'rgba(0,0,0,0)');
  sCtx.fillStyle = rad;
  sCtx.fillRect(0, 0, 128, 128);
  const shadowDiscMap = finalizeTexture(sCanvas, 1, 1, 1, true);
  shadowDiscMap.wrapS = THREE.ClampToEdgeWrapping;
  shadowDiscMap.wrapT = THREE.ClampToEdgeWrapping;

  // 7. Procedural Weapon Skins / Camos (128x128 crisp patterns)
  const makeCamoTex = (
    bg: string,
    stripe1: string,
    stripe2: string,
    mode: 'digital' | 'tiger' | 'hex',
  ) => {
    const [cv, cx] = createCanvas(128);
    cx.fillStyle = bg;
    cx.fillRect(0, 0, 128, 128);
    if (mode === 'digital') {
      const cols = [stripe1, stripe2];
      for (let i = 0; i < 48; i++) {
        cx.fillStyle = cols[i % 2];
        cx.fillRect(
          Math.floor(Math.random() * 16) * 8,
          Math.floor(Math.random() * 16) * 8,
          8 + Math.floor(Math.random() * 3) * 8,
          8 + Math.floor(Math.random() * 2) * 8,
        );
      }
    } else if (mode === 'tiger') {
      cx.strokeStyle = stripe1;
      cx.lineWidth = 9;
      for (let y = -16; y < 144; y += 22) {
        cx.beginPath();
        cx.moveTo(0, y);
        cx.bezierCurveTo(42, y + 14, 86, y - 14, 128, y + 6);
        cx.stroke();
      }
      cx.strokeStyle = stripe2;
      cx.lineWidth = 4;
      for (let y = -6; y < 144; y += 22) {
        cx.beginPath();
        cx.moveTo(0, y + 4);
        cx.bezierCurveTo(40, y - 10, 90, y + 12, 128, y - 4);
        cx.stroke();
      }
    } else {
      // Carbon / Gold geometric weave
      cx.fillStyle = stripe1;
      for (let y = 0; y < 128; y += 16) {
        for (let x = (y % 32 === 0 ? 0 : 8); x < 128; x += 16) {
          cx.fillRect(x, y, 7, 7);
        }
      }
      cx.strokeStyle = stripe2;
      cx.lineWidth = 2;
      for (let i = -128; i < 256; i += 24) {
        cx.beginPath();
        cx.moveTo(i, 0);
        cx.lineTo(i + 128, 128);
        cx.stroke();
      }
    }
    return finalizeTexture(cv, 1, 1, maxAniso, true);
  };

  const desertCamo = makeCamoTex('#c7a876', '#a08152', '#e1cca1', 'digital');
  const cobaltCamo = makeCamoTex('#1e3a8a', '#3b82f6', '#0f172a', 'digital');
  const crimsonCamo = makeCamoTex('#7f1d1d', '#ef4444', '#180909', 'tiger');
  const goldCamo = makeCamoTex('#eab308', '#ca8a04', '#fef08a', 'hex');

  const weaponCamos: Record<WeaponCamoId, THREE.CanvasTexture | null> = {
    standard: null,
    desert: desertCamo,
    cobalt: cobaltCamo,
    crimson: crimsonCamo,
    gold: goldCamo,
  };

  return {
    groundMap,
    groundBump,
    concreteMap,
    concreteBump,
    containerRibBump,
    camoMap,
    crateMap,
    shadowDiscMap,
    weaponCamos,
    dispose: () => {
      groundMap.dispose();
      groundBump.dispose();
      concreteMap.dispose();
      concreteBump.dispose();
      containerRibBump.dispose();
      camoMap.dispose();
      crateMap.dispose();
      shadowDiscMap.dispose();
      desertCamo.dispose();
      cobaltCamo.dispose();
      crimsonCamo.dispose();
      goldCamo.dispose();
    },
  };
}
