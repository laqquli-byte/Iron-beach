import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildTacticalArena, type ArenaWorld } from './arena';
import { soundEngine } from './audio';
import {
  applyWeaponAttachmentsToRig,
  applyWeaponCamoToRig,
  createAlliedSoldier,
  createBombDevice,
  createC4Pack,
  createCarePackageCrate,
  createClaymoreMine,
  createEnemySoldier,
  createFiringRangeTarget,
  createHostageModel,
  createIntelLaptop,
  createLandmine,
  createMissionObjectiveProp,
  createMortarRing,
  createPickupMesh,
  createRpgRocket,
  createSentryTurret,
  createViewmodelWeapon,
  type AlliedRig,
  type BombDeviceRig,
  type EnemyRig,
  type FiringRangeTargetRig,
  type HostageRig,
  type MissionObjectiveProp,
  type SentryTurretRig,
  type ViewmodelRig,
} from './models';
import {
  addAmmoPickup,
  applyArmorPlate,
  applyFieldUpgrade,
  applyPlayerDamage,
  applyReload,
  applyStimShot,
  CARE_PACKAGE_THRESHOLD,
  CHALLENGE_SPECS,
  computeAccuracyPct,
  computeBombDefusalProgress,
  computeBossPhase,
  computeCompassHeadingDeg,
  computeExplosionDamage,
  computeFiringRangeScore,
  computeGrenadeThreat,
  computeRankFromXp,
  computeShotDamage,
  computeStanceModifiers,
  computeStealthTakedownDamage,
  computeTargetPixelRatio,
  createDefaultCareerStats,
  createDefaultEquippedAttachments,
  createDefaultEquippedCamos,
  createInitialWeaponStates,
  DIFFICULTY_SPECS,
  ENEMY_RADIUS,
  ENEMY_SPECS,
  FIELD_UPGRADE_SPECS,
  getChapterCanonLoadout,
  getComboLabel,
  getChapterCutscene,
  getChapterStageSpecs,
  getEffectiveWeaponSpec,
  getFiringRangeTargets,
  getLoadoutPair,
  getNewlyUnlockedCamos,
  getSpecOpsBombSites,
  getWaveBriefing,
  getWaveConfig,
  type GraphicsQuality,
  INTEL_SPECS,
  isCamoUnlocked,
  KILLSTREAK_THRESHOLD,
  MAX_STORY_WAVES,
  MEDAL_SPECS,
  PERK_SPECS,
  pickArchetypeForWave,
  pickCarePackageReward,
  PLAYER_RADIUS,
  purchaseBuyStationItem,
  resolveAllCollisions,
  resolveNextLean,
  resolvePlayableChapter,
  resolveStoryEnding,
  sanitizeEquippedAttachments,
  sanitizeEquippedCamos,
  STORY_CHOICES,
  STORY_ENDING_LIST,
  UAV_THRESHOLD,
  WEAPON_CAMOS,
  WEAPON_LIST,
  WEAPON_SPECS,
} from './rules';
import { createProceduralTextures, type MaterialTextures } from './textures';
import type {
  AttachmentId,
  BossQteHud,
  BuyStationItemId,
  CampaignPace,
  CareerStats,
  ChapterStageSpec,
  CutsceneSpec,
  DifficultyId,
  EnemyArchetype,
  FieldUpgradeId,
  GameMode,
  GamePhase,
  HudSnapshot,
  KillFeedItem,
  MedalId,
  MissionObjectiveKind,
  PerkId,
  ProjectedEnemyMarker,
  SetPieceKind,
  StoryChoiceId,
  StoryChoiceSpec,
  StoryDecisionRecord,
  StoryEndingId,
  StoryEndingSpec,
  StoryProgressSave,
  WeaponCamoId,
  WeaponId,
  WeaponState,
  WoundedAllyHud,
} from './types';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  state: 'moving' | 'telegraph' | 'dying';
  telegraphTimer: number;
  fireCooldown: number;
  hitFlashTimer: number;
  stunTimer: number;
  dyingTimer: number;
  strafeDir: number;
  strafeTimer: number;
  gaitPhase: number;
  grenadeThrowCooldown: number;
  alerted?: boolean;
}

interface ActiveCarePackage {
  root: THREE.Group;
  chuteGroup: THREE.Group;
  beaconMesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  landed: boolean;
  age: number;
}

interface ActiveAlly {
  name: string;
  rig: AlliedRig;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  fireCooldown: number;
  gaitPhase: number;
  downed: boolean;
  bleedoutTimer: number;
  downedCooldown: number;
}

interface ActiveHostage {
  id: number;
  name: string;
  rig: HostageRig;
  x: number;
  z: number;
  rescued: boolean;
  alive: boolean;
}

interface ActiveSentry {
  rig: SentryTurretRig;
  x: number;
  z: number;
  timer: number;
  fireCooldown: number;
  flashTimer: number;
}

interface ActiveC4 {
  root: THREE.Group;
  ledMesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
}

interface ActiveClaymore {
  root: THREE.Group;
  x: number;
  z: number;
  yaw: number;
}

interface ActiveLandmine {
  root: THREE.Group;
  ledMesh: THREE.Mesh;
  x: number;
  z: number;
  exploded: boolean;
}

interface ActiveMortarStrike {
  root: THREE.Group;
  ringMesh: THREE.Mesh;
  coreMesh: THREE.Mesh;
  x: number;
  z: number;
  timer: number;
}

interface ActiveRocket {
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  age: number;
}

interface ActiveIntelPickup {
  id: string;
  chapter: number;
  title: string;
  summary: string;
  root: THREE.Group;
  x: number;
  z: number;
  collected: boolean;
}

interface ActivePickup {
  id: number;
  kind: 'medkit' | 'ammo';
  mesh: THREE.Group;
  x: number;
  z: number;
  age: number;
}

interface ActiveGrenade {
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuse: number;
  kind: 'frag' | 'flash' | 'enemy_frag';
}

interface ParticleSlot {
  active: boolean;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  age: number;
  maxAge: number;
  size: number;
  color: THREE.Color;
  gravity: number;
}

interface TracerSlot {
  mesh: THREE.Mesh;
  timer: number;
}

// Module-level pre-allocated scratch math objects (zero GC inside render loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _vForward = new THREE.Vector3();
const _vRight = new THREE.Vector3();
const _vDir = new THREE.Vector3();
const _mat4 = new THREE.Matrix4();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _euler = new THREE.Euler(0, 0, 0, 'YXZ');
const _ndcCenter = new THREE.Vector2(0, 0);

const PARTICLE_POOL_SIZE = 96;
const TRACER_POOL_SIZE = 10;
const BEST_SCORE_KEY = 'iron_breach_best_score_v1';
const CAREER_STATS_KEY = 'iron_breach_career_v1';
const EQUIPPED_CAMOS_KEY = 'iron_breach_camos_v1';
const EQUIPPED_ATTACHMENTS_KEY = 'iron_breach_attachments_v1';
const SELECTED_PERK_KEY = 'iron_breach_perk_v1';
const SELECTED_DIFFICULTY_KEY = 'iron_breach_diff_v1';
const CAMPAIGN_PACE_KEY = 'iron_breach_pace_v1';
const UNLOCKED_CHAPTER_KEY = 'iron_breach_chapter_v1';
const MEDALS_KEY = 'iron_breach_medals_v1';
const INTEL_KEY = 'iron_breach_intel_v1';
const SETTINGS_KEY = 'iron_breach_settings_v1';
const STORY_PROGRESS_KEY = 'iron_breach_story_v1';

interface ActiveBombSite {
  site: 'A' | 'B';
  label: string;
  x: number;
  z: number;
  rig: BombDeviceRig;
  defused: boolean;
  progress: number;
}

interface ActiveRangeTarget {
  id: number;
  baseX: number;
  x: number;
  z: number;
  isArmored: boolean;
  isMoving: boolean;
  moveAmplitudeX: number;
  moveSpeed: number;
  knockedTimer: number;
  flipBlend: number;
  rig: FiringRangeTargetRig;
}

export class FpsEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private textures: MaterialTextures;
  private arena: ArenaWorld;
  private envMap: THREE.Texture;

  private raycaster = new THREE.Raycaster();
  private viewmodels: Record<WeaponId, ViewmodelRig>;
  private weaponMount = new THREE.Group();
  private muzzlePointLight: THREE.PointLight;
  private graphicsQuality: GraphicsQuality = '720p';

  // Pooled particles & tracers
  private particleMesh: THREE.InstancedMesh;
  private particles: ParticleSlot[] = [];
  private particleCursor = 0;
  private tracers: TracerSlot[] = [];
  private tracerCursor = 0;

  // Game loop timing
  private frameId = 0;
  private lastTime = 0;
  private disposed = false;
  private hudEmitAccum = 0;

  // Game state
  private phase: GamePhase = 'title';
  private gameMode: GameMode = 'campaign';
  private outcome: 'victory' | 'defeat' | null = null;
  private endlessMode = false;
  private hitstopTimer = 0;
  private trauma = 0;
  private elapsedTime = 0;

  // Player state
  private playerX = 0;
  private playerY = 1.7;
  private playerZ = 22;
  private playerVelY = 0;
  private isGrounded = true;
  private yaw = 0;
  private pitch = 0;
  private recoilPitch = 0;
  private recoilYaw = 0;
  private walkDistance = 0;
  private footstepAccum = 0;

  private hp = 100;
  private maxHp = 100;
  private armor = 50;
  private maxArmor = 50;
  private grenades = 3;
  private flashbangs = 2;
  private c4Count = 2;
  private claymoreCount = 2;
  private credits = 0;
  private activeWeapon: WeaponId = 'm4a1';
  private loadoutWeapons: [WeaponId, WeaponId] = ['m4a1', 'mp5'];
  private weaponStates: Record<WeaponId, WeaponState> = createInitialWeaponStates();
  private fireTimer = 0;
  private muzzleFlashTimer = 0;
  private reloadTimer = 0;
  private reloading = false;
  private adsBlend = 0; // 0..1
  private adsDesired = false;
  private autoFire = true;

  // Modern Tactical Movement, Optics, Gunship, Breach, Turret & Blackout state
  private isSprinting = false;
  private sprintBlend = 0;
  private isNvgActive = false;
  private thermalActive = false;
  private blackoutActive = false;
  private breachSlowMoTimer = 0;
  private mountedTurret = false;
  private turretFireTimer = 0;
  private slideTimer = 0;
  private slideCooldown = 0;
  private slideDirX = 0;
  private slideDirZ = -1;
  private isCrouching = false;
  private crouchOffset = 0;
  private stims = 2;
  private maxStims = 3;
  private stimBoostTimer = 0;
  private inspectTimer = 0;
  private finalKillSlowMoTimer = 0;
  private stageClearAwarded = false;
  private killstreakProgress = 0;
  private uavReady = false;
  private uavActiveTimer = 0;
  private carePackageReady = false;
  private gunshipReady = false;
  private gunshipActive = false;
  private gunshipTimer = 0;
  private gunshipShells = 12;
  private gunshipAimX = 0;
  private gunshipAimZ = 0;
  private gunshipCooldown = 0;
  private buyStationOpen = false;
  private pendingStrikes: { x: number; z: number; timer: number }[] = [];

  // Medals, Intel & Boss Phases
  private unlockedMedalIds: MedalId[] = [];
  private medalBanner: { title: string; description: string } | null = null;
  private medalBannerTimer = 0;
  private collectedIntelIds: string[] = [];
  private knifeKillsThisRun = 0;
  private stageDamaged = false;
  private lastBossPhase: 1 | 2 | 3 = 1;

  // Feedback state
  private hitmarkerKind: 'none' | 'hit' | 'kill' = 'none';
  private hitmarkerTimer = 0;
  private damageFlash = 0;
  private damageDirectionAngle: number | null = null;
  private killFeed: KillFeedItem[] = [];
  private killFeedSeq = 1;
  private comboCount = 0;
  private comboWindowTimer = 0;
  private comboBanner: string | null = null;
  private comboBannerTimer = 0;

  // Progression, Campaign Story & Stats
  private wave = 1;
  private unlockedChapter = 1;
  private waveToSpawn = 0;
  private waveSpawnTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private betweenWaveTimer = 0;
  private armorPlates = 2;
  private maxArmorPlates = 2;
  private objectiveProp: MissionObjectiveProp | null = null;
  private objectiveKind: MissionObjectiveKind | null = null;
  private objectiveLabel = '';
  private objectiveX = 0;
  private objectiveZ = 0;
  private objectiveHp = 0;
  private objectiveMaxHp = 160;
  private objectiveHoldProgress = 0;
  private objectiveCompleted = false;
  private bossSpawnedInWave = false;
  private midWaveRadioSent = false;
  private radioMessage: HudSnapshot['radioMessage'] = null;
  private radioTimer = 0;
  private score = 0;
  private bestScore = 0;
  private kills = 0;
  private headshots = 0;
  private shotsFired = 0;
  private shotsHit = 0;
  private careerStats: CareerStats = createDefaultCareerStats(0);
  private equippedCamos: Record<WeaponId, WeaponCamoId> = createDefaultEquippedCamos();
  private equippedAttachments: Record<WeaponId, AttachmentId[]> =
    createDefaultEquippedAttachments();
  private selectedPerk: PerkId = 'fast_reload';
  private selectedDifficulty: DifficultyId = 'regular';
  private campaignPace: CampaignPace = 'marathon';
  private chapterStages: ChapterStageSpec[] = [];
  private chapterStageIdx = 0;
  private checkpointStage = 1;
  private checkpointScore = 0;
  private checkpointKills = 0;
  private checkpointHeadshots = 0;
  private checkpointBanner: string | null = null;
  private checkpointBannerTimer = 0;
  private activeCutscene: CutsceneSpec | null = null;
  private cutsceneBeatIdx = 0;
  private cutsceneBeatTimer = 0;
  private cutsceneOnComplete: (() => void) | null = null;

  // Dynamic entities
  private enemies: ActiveEnemy[] = [];
  private allies: ActiveAlly[] = [];
  private sentries: ActiveSentry[] = [];
  private carePackages: ActiveCarePackage[] = [];
  private c4Charges: ActiveC4[] = [];
  private claymores: ActiveClaymore[] = [];
  private landmines: ActiveLandmine[] = [];
  private mortarStrikes: ActiveMortarStrike[] = [];
  private rpgRockets: ActiveRocket[] = [];
  private intelPickups: ActiveIntelPickup[] = [];
  private titlePatrollers: ActiveEnemy[] = [];
  private enemyIdSeq = 1;
  private pickups: ActivePickup[] = [];
  private pickupIdSeq = 1;
  private activeGrenades: ActiveGrenade[] = [];
  private grenadeGeo = new THREE.SphereGeometry(0.11, 10, 10);
  private grenadeMat = new THREE.MeshStandardMaterial({
    color: 0x365314,
    roughness: 0.4,
    metalness: 0.5,
  });
  private enemyGrenadeMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0x991b1b,
    emissiveIntensity: 0.75,
    roughness: 0.35,
    metalness: 0.45,
  });

  // Unified input state
  private keys = new Set<string>();
  private touchMoveX = 0;
  private touchMoveY = 0;
  private mouseFireHeld = false;
  private touchFireHeld = false;
  private keyFireHeld = false;
  private pointerLocked = false;
  private isMouseDragging = false;
  private lastPointerX = 0;
  private lastPointerY = 0;
  private jumpBufferTimer = 0;
  private coyoteTimer = 0;

  // AAA Settings, Lean, Field Upgrades, Last Stand, Spec Ops & Firing Range
  private sensitivity = 1.0;
  private fov = 75;
  private volume = 0.7;
  private touchControlsEnabled = true;
  private lean: 'left' | 'right' | 'none' = 'none';
  private leanBlend = 0;
  private swayX = 0;
  private swayY = 0;
  private fieldUpgrade: FieldUpgradeId = 'shield';
  private fieldUpgradeCooldown = 0;
  private fieldUpgradeActiveTimer = 0;
  private isLastStand = false;
  private selfReviveKit = true;
  private lastStandTimer = 0;
  private lastStandPulseAccum = 0;
  private touchDefuseHeld = false;
  private bombTimer = 120;
  private bombTickAccum = 0;
  private bombSites: ActiveBombSite[] = [];
  private rangeTargets: ActiveRangeTarget[] = [];
  private rangeHits = 0;
  private rangeHeadshots = 0;

  // Story Campaign Narrative, Set-Pieces, Hostages, Stealth, Wounded Allies & Boss QTE
  private canonLoadoutEnabled = true;
  private squadTrust = 65;
  private storyDecisions: StoryDecisionRecord[] = [];
  private unlockedEndingIds: StoryEndingId[] = [];
  private activeStoryChoice: StoryChoiceSpec | null = null;
  private triggeredChoiceIdsThisRun = new Set<StoryChoiceId>();
  private activeEnding: StoryEndingSpec | null = null;
  private pendingEndingResolution = false;
  private outOfCombatTimer = 0;
  private currentSetPieceKind: SetPieceKind | null = null;
  private currentBossName = 'Komandir Xəncər';
  private hostages: ActiveHostage[] = [];
  private hostagesLostThisRun = 0;
  private stealthActive = false;
  private stealthSuspicionPct = 0;
  private stealthDetected = false;
  private escapeTimerSec: number | null = null;
  private escapeTickAccum = 0;
  private bossQte: {
    bossId: number;
    bossName: string;
    timeLeftSec: number;
    maxTimeSec: number;
    hitsDone: number;
    hitsRequired: number;
  } | null = null;
  private bossQteTriggeredThisStage = false;
  private cutsceneBlendTimer = 0;
  private cutsceneExitPos = new THREE.Vector3();
  private cutsceneExitQuat = new THREE.Quaternion();

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;

    let loadedBest = 0;
    try {
      const saved = localStorage.getItem(BEST_SCORE_KEY);
      if (saved) loadedBest = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      loadedBest = 0;
    }
    this.bestScore = loadedBest;

    try {
      const rawCareer = localStorage.getItem(CAREER_STATS_KEY);
      if (rawCareer) {
        const parsed = JSON.parse(rawCareer) as Partial<CareerStats>;
        this.careerStats = {
          totalKills: Math.max(0, Math.floor(Number(parsed.totalKills) || 0)),
          totalHeadshots: Math.max(0, Math.floor(Number(parsed.totalHeadshots) || 0)),
          bestScore: Math.max(this.bestScore, Math.floor(Number(parsed.bestScore) || 0)),
          totalExplosiveKills: Math.max(0, Math.floor(Number(parsed.totalExplosiveKills) || 0)),
          xp: Math.max(0, Math.floor(Number(parsed.xp) || 0)),
          completedChallengeIds: Array.isArray(parsed.completedChallengeIds)
            ? parsed.completedChallengeIds.filter((id): id is string => typeof id === 'string')
            : [],
        };
      } else {
        this.careerStats = createDefaultCareerStats(this.bestScore);
      }
    } catch {
      this.careerStats = createDefaultCareerStats(this.bestScore);
    }
    this.bestScore = Math.max(this.bestScore, this.careerStats.bestScore);

    try {
      const rawCamos = localStorage.getItem(EQUIPPED_CAMOS_KEY);
      if (rawCamos) {
        const parsed = JSON.parse(rawCamos) as Partial<Record<WeaponId, WeaponCamoId>>;
        this.equippedCamos = sanitizeEquippedCamos(parsed, this.careerStats);
      } else {
        this.equippedCamos = createDefaultEquippedCamos();
      }
    } catch {
      this.equippedCamos = createDefaultEquippedCamos();
    }

    try {
      const rawAtt = localStorage.getItem(EQUIPPED_ATTACHMENTS_KEY);
      if (rawAtt) {
        const parsed = JSON.parse(rawAtt) as Partial<Record<WeaponId, AttachmentId[]>>;
        this.equippedAttachments = sanitizeEquippedAttachments(parsed);
      }
    } catch {
      this.equippedAttachments = createDefaultEquippedAttachments();
    }

    try {
      const savedPerk = localStorage.getItem(SELECTED_PERK_KEY) as PerkId | null;
      if (savedPerk && savedPerk in PERK_SPECS) {
        this.selectedPerk = savedPerk;
      }
      const savedDiff = localStorage.getItem(SELECTED_DIFFICULTY_KEY) as DifficultyId | null;
      if (savedDiff && savedDiff in DIFFICULTY_SPECS) {
        this.selectedDifficulty = savedDiff;
      }
      const savedPace = localStorage.getItem(CAMPAIGN_PACE_KEY) as CampaignPace | null;
      if (savedPace === 'marathon' || savedPace === 'standard') {
        this.campaignPace = savedPace;
      }
    } catch {
      // ignore storage failures
    }

    try {
      const savedCh = localStorage.getItem(UNLOCKED_CHAPTER_KEY);
      const parsedCh = savedCh ? parseInt(savedCh, 10) : 1;
      if (Number.isFinite(parsedCh)) {
        this.unlockedChapter = Math.max(1, Math.min(MAX_STORY_WAVES, parsedCh));
      }
    } catch {
      this.unlockedChapter = 1;
    }

    try {
      const savedMedals = localStorage.getItem(MEDALS_KEY);
      if (savedMedals) {
        const parsed = JSON.parse(savedMedals);
        if (Array.isArray(parsed)) {
          this.unlockedMedalIds = parsed.filter((m): m is MedalId => typeof m === 'string' && m in MEDAL_SPECS);
        }
      }
      const savedIntel = localStorage.getItem(INTEL_KEY);
      if (savedIntel) {
        const parsed = JSON.parse(savedIntel);
        if (Array.isArray(parsed)) {
          this.collectedIntelIds = parsed.filter((id): id is string => typeof id === 'string');
        }
      }
    } catch {
      // ignore storage failures
    }

    try {
      const rawSettings = localStorage.getItem(SETTINGS_KEY);
      if (rawSettings) {
        const parsed = JSON.parse(rawSettings) as Partial<{
          sensitivity: number;
          fov: number;
          volume: number;
          touchControlsEnabled: boolean;
          fieldUpgrade: FieldUpgradeId;
          graphicsQuality: GraphicsQuality;
        }>;
        if (typeof parsed.sensitivity === 'number' && Number.isFinite(parsed.sensitivity)) {
          this.sensitivity = Math.max(0.2, Math.min(2.5, parsed.sensitivity));
        }
        if (typeof parsed.fov === 'number' && Number.isFinite(parsed.fov)) {
          this.fov = Math.max(60, Math.min(110, parsed.fov));
        }
        if (typeof parsed.volume === 'number' && Number.isFinite(parsed.volume)) {
          this.volume = Math.max(0, Math.min(1, parsed.volume));
        }
        if (typeof parsed.touchControlsEnabled === 'boolean') {
          this.touchControlsEnabled = parsed.touchControlsEnabled;
        }
        if (parsed.fieldUpgrade && parsed.fieldUpgrade in FIELD_UPGRADE_SPECS) {
          this.fieldUpgrade = parsed.fieldUpgrade;
        }
        if (parsed.graphicsQuality === '720p' || parsed.graphicsQuality === 'ultra') {
          this.graphicsQuality = parsed.graphicsQuality;
        }
      }
    } catch {
      // ignore storage failures
    }
    soundEngine.setMasterVolume(this.volume);

    try {
      const rawStory = localStorage.getItem(STORY_PROGRESS_KEY);
      if (rawStory) {
        const parsed = JSON.parse(rawStory) as Partial<StoryProgressSave>;
        if (typeof parsed.squadTrust === 'number' && Number.isFinite(parsed.squadTrust)) {
          this.squadTrust = Math.max(0, Math.min(100, Math.round(parsed.squadTrust)));
        }
        if (Array.isArray(parsed.storyDecisions)) {
          this.storyDecisions = parsed.storyDecisions.filter(
            (d): d is StoryDecisionRecord =>
              Boolean(d && d.choiceId in STORY_CHOICES && (d.optionIndex === 0 || d.optionIndex === 1)),
          );
        }
        if (Array.isArray(parsed.unlockedEndingIds)) {
          this.unlockedEndingIds = parsed.unlockedEndingIds.filter(
            (id): id is StoryEndingId => STORY_ENDING_LIST.includes(id as StoryEndingId),
          );
        }
        if (typeof parsed.canonLoadoutEnabled === 'boolean') {
          this.canonLoadoutEnabled = parsed.canonLoadoutEnabled;
        }
      }
    } catch {
      // ignore storage failures
    }

    this.isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.16;
    const width = Math.max(1, container.clientWidth || window.innerWidth);
    const height = Math.max(1, container.clientHeight || window.innerHeight);
    this.renderer.setPixelRatio(
      computeTargetPixelRatio(
        width,
        height,
        window.devicePixelRatio || 1,
        this.isSoftwareGl,
        this.graphicsQuality,
      ),
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.setAttribute('data-testid', 'fps-canvas');
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(74, width / height, 0.08, 220);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    // Procedural Studio PMREM Environment
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.envMap = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = this.envMap;
    pmrem.dispose();

    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.textures = createProceduralTextures(maxAniso);
    this.arena = buildTacticalArena(
      this.scene,
      this.textures,
      this.isSoftwareGl,
      this.graphicsQuality === 'ultra' && Math.min(width, height) >= 768 ? 2048 : 1024,
    );

    // First-person weapon mount attached to camera + dynamic muzzle flash light
    this.camera.add(this.weaponMount);
    this.muzzlePointLight = new THREE.PointLight(0xffb24a, 0, 11, 2);
    this.muzzlePointLight.position.set(0, 0.04, -0.78);
    this.weaponMount.add(this.muzzlePointLight);

    this.viewmodels = {
      m4a1: createViewmodelWeapon('m4a1'),
      mp5: createViewmodelWeapon('mp5'),
      scarh: createViewmodelWeapon('scarh'),
      spas12: createViewmodelWeapon('spas12'),
      msr: createViewmodelWeapon('msr'),
      m249: createViewmodelWeapon('m249'),
      deagle: createViewmodelWeapon('deagle'),
      rpg7: createViewmodelWeapon('rpg7'),
      knife: createViewmodelWeapon('knife'),
    };
    WEAPON_LIST.forEach((w) => {
      applyWeaponCamoToRig(this.viewmodels[w], w, this.equippedCamos[w], this.textures);
      applyWeaponAttachmentsToRig(this.viewmodels[w], this.equippedAttachments[w]);
      this.weaponMount.add(this.viewmodels[w].root);
      this.viewmodels[w].root.visible = w === this.activeWeapon;
    });
    this.weaponMount.visible = false; // Hidden during title screen flyover

    // Pooled InstancedMesh particles
    const pGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
    const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.particleMesh = new THREE.InstancedMesh(pGeo, pMat, PARTICLE_POOL_SIZE);
    this.particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.particleMesh.frustumCulled = false;
    this.scene.add(this.particleMesh);
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      this.particles.push({
        active: false,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        age: 0,
        maxAge: 0.4,
        size: 1,
        color: new THREE.Color(0xffffff),
        gravity: 9.8,
      });
      _mat4.makeScale(0, 0, 0);
      this.particleMesh.setMatrixAt(i, _mat4);
      this.particleMesh.setColorAt(i, this.particles[i].color);
    }

    // Pooled bullet tracers
    const tracerGeo = new THREE.CylinderGeometry(0.015, 0.015, 1, 6);
    tracerGeo.rotateX(Math.PI / 2);
    for (let i = 0; i < TRACER_POOL_SIZE; i++) {
      const tMat = new THREE.MeshBasicMaterial({
        color: 0xffd166,
        transparent: true,
        opacity: 0.85,
        depthWrite: false,
      });
      const tMesh = new THREE.Mesh(tracerGeo, tMat);
      tMesh.visible = false;
      this.scene.add(tMesh);
      this.tracers.push({ mesh: tMesh, timer: 0 });
    }

    // Spawn ambient patrolling soldiers for the Title Screen live-world vista
    this.spawnTitlePatrollers();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.lastTime = performance.now();
    this.emitHud();
    this.scheduleNextFrame();
  }

  private spawnTitlePatrollers(): void {
    const spots: { x: number; z: number; arch: EnemyArchetype }[] = [
      { x: -6, z: 2, arch: 'rifleman' },
      { x: 7, z: -4, arch: 'heavy' },
      { x: -9, z: -12, arch: 'rusher' },
      { x: 4, z: 9, arch: 'rifleman' },
    ];
    spots.forEach((s, idx) => {
      const rig = createEnemySoldier(s.arch, this.textures, this.isSoftwareGl);
      rig.root.position.set(s.x, 0, s.z);
      this.scene.add(rig.root);
      this.titlePatrollers.push({
        id: -1 - idx,
        archetype: s.arch,
        rig,
        x: s.x,
        z: s.z,
        yaw: idx * 1.4,
        hp: 100,
        maxHp: 100,
        speed: 2.2,
        damage: 0,
        state: 'moving',
        telegraphTimer: 0,
        fireCooldown: 1,
        hitFlashTimer: 0,
        stunTimer: 0,
        dyingTimer: 0,
        strafeDir: 1,
        strafeTimer: 2,
        gaitPhase: idx,
        grenadeThrowCooldown: 999,
      });
    });
  }

  private clearTitlePatrollers(): void {
    for (const p of this.titlePatrollers) {
      this.scene.remove(p.rig.root);
    }
    this.titlePatrollers = [];
  }

  private getActiveWeaponSpec(weaponId: WeaponId) {
    return getEffectiveWeaponSpec(
      weaponId,
      this.equippedAttachments[weaponId],
      this.selectedPerk,
    );
  }

  public setGameMode(mode: GameMode): void {
    this.gameMode = mode;
    this.emitHud();
  }

  public startGame(initialWeapon?: WeaponId, skipBriefing = false, startChapter = 1): void {
    soundEngine.unlock();
    this.clearTitlePatrollers();
    this.clearDynamicEntities();

    const chapter =
      this.gameMode === 'survival' || this.gameMode === 'firing_range'
        ? 1
        : this.gameMode === 'spec_ops'
          ? 5
          : resolvePlayableChapter(startChapter);

    const primary = initialWeapon ?? this.activeWeapon;
    if (this.gameMode === 'campaign' && this.canonLoadoutEnabled && !skipBriefing) {
      this.loadoutWeapons = getChapterCanonLoadout(chapter);
      this.activeWeapon = this.loadoutWeapons[0];
    } else if (this.gameMode === 'campaign' && this.canonLoadoutEnabled && skipBriefing && !initialWeapon) {
      this.loadoutWeapons = getChapterCanonLoadout(chapter);
      this.activeWeapon = this.loadoutWeapons[0];
    } else {
      this.loadoutWeapons = getLoadoutPair(primary);
      this.activeWeapon = this.loadoutWeapons[0];
    }
    WEAPON_LIST.forEach((w) => {
      applyWeaponCamoToRig(this.viewmodels[w], w, this.equippedCamos[w], this.textures);
      applyWeaponAttachmentsToRig(this.viewmodels[w], this.equippedAttachments[w]);
      this.viewmodels[w].root.visible = w === this.activeWeapon;
    });

    this.outcome = null;
    this.endlessMode = this.gameMode === 'survival';
    this.hitstopTimer = 0;
    this.trauma = 0;
    this.elapsedTime = 0;

    // Reset player on open courtyard lane facing north (-Z) toward Humvee & Watchtower
    this.playerX = 0;
    this.playerY = 1.7;
    this.playerZ = this.gameMode === 'firing_range' ? -3.4 : 22;
    this.playerVelY = 0;
    this.isGrounded = true;
    this.yaw = 0;
    this.pitch = 0;
    this.recoilPitch = 0;
    this.recoilYaw = 0;
    this.swayX = 0;
    this.swayY = 0;
    this.lean = 'none';
    this.leanBlend = 0;
    this.walkDistance = 0;

    const heavyPerk = this.selectedPerk === 'heavy_armor';
    this.hp = 100;
    this.maxArmor = heavyPerk ? 75 : 50;
    this.armor = this.maxArmor;
    this.maxArmorPlates = heavyPerk ? 3 : 2;
    this.armorPlates = this.gameMode === 'campaign' ? 0 : this.maxArmorPlates;
    this.grenades = 3;
    this.flashbangs = 2;
    this.c4Count = 2;
    this.claymoreCount = 2;
    this.credits = this.gameMode === 'survival' ? 200 : 0;
    this.weaponStates = createInitialWeaponStates(this.equippedAttachments, this.selectedPerk);
    this.fireTimer = 0;
    this.reloadTimer = 0;
    this.reloading = false;
    this.adsDesired = false;
    this.adsBlend = 0;
    this.isSprinting = false;
    this.sprintBlend = 0;
    this.isNvgActive = false;
    this.thermalActive = false;
    this.blackoutActive = false;
    this.breachSlowMoTimer = 0;
    this.mountedTurret = false;
    this.turretFireTimer = 0;
    this.gunshipReady = false;
    this.gunshipActive = false;
    this.gunshipTimer = 0;
    this.gunshipShells = 12;
    this.buyStationOpen = false;
    this.knifeKillsThisRun = 0;
    this.stageDamaged = false;
    this.lastBossPhase = 1;
    this.renderer.toneMappingExposure = 1.16;
    this.slideTimer = 0;
    this.slideCooldown = 0;
    this.isCrouching = false;
    this.crouchOffset = 0;
    this.stims = 2;
    this.stimBoostTimer = 0;
    this.inspectTimer = 0;
    this.finalKillSlowMoTimer = 0;
    this.stageClearAwarded = false;
    this.killstreakProgress = 0;
    this.uavReady = false;
    this.uavActiveTimer = 0;
    this.carePackageReady = false;
    this.pendingStrikes = [];
    this.fieldUpgradeCooldown = 0;
    this.fieldUpgradeActiveTimer = 0;
    this.isLastStand = false;
    this.selfReviveKit = this.gameMode !== 'firing_range';
    this.lastStandTimer = 0;
    this.touchDefuseHeld = false;
    this.bombTimer = 120;
    this.bombTickAccum = 0;
    this.rangeHits = 0;
    this.rangeHeadshots = 0;

    // Reset run story/set-piece state
    this.activeStoryChoice = null;
    this.triggeredChoiceIdsThisRun.clear();
    this.activeEnding = null;
    this.pendingEndingResolution = false;
    this.outOfCombatTimer = 0;
    this.hostagesLostThisRun = 0;
    this.stealthActive = false;
    this.stealthSuspicionPct = 0;
    this.stealthDetected = false;
    this.escapeTimerSec = null;
    this.escapeTickAccum = 0;
    this.bossQte = null;
    this.bossQteTriggeredThisStage = false;
    this.cutsceneBlendTimer = 0;

    this.hitmarkerKind = 'none';
    this.hitmarkerTimer = 0;
    this.damageFlash = 0;
    this.damageDirectionAngle = null;
    this.killFeed = [];
    this.comboCount = 0;
    this.comboWindowTimer = 0;
    this.comboBanner = null;
    this.comboBannerTimer = 0;
    this.medalBanner = null;
    this.medalBannerTimer = 0;
    this.radioMessage = null;
    this.radioTimer = 0;

    this.score = 0;
    this.kills = 0;
    this.headshots = 0;
    this.shotsFired = 0;
    this.shotsHit = 0;

    // Restore exploded barrels, destructible supply crates, and breach doors
    for (const b of this.arena.barrels) {
      b.exploded = false;
      b.hp = 45;
      b.mesh.visible = true;
    }
    for (const c of this.arena.destructibleCrates) {
      c.destroyed = false;
      c.hp = 45;
      c.mesh.visible = true;
      if (!this.arena.colliders.includes(c.box)) {
        this.arena.colliders.push(c.box);
      }
    }
    for (const d of this.arena.breachDoors) {
      d.breached = false;
      d.openProgress = 0;
      d.doorPanel.rotation.y = 0;
      if (!this.arena.colliders.includes(d.box)) {
        this.arena.colliders.push(d.box);
      }
    }
    this.arena.helicopter.root.visible = false;

    this.checkpointStage = 1;
    this.checkpointScore = 0;
    this.checkpointKills = 0;
    this.checkpointHeadshots = 0;
    this.checkpointBanner = null;
    this.checkpointBannerTimer = 0;
    this.activeCutscene = null;
    this.cutsceneOnComplete = null;
    this.clearHeldInputs();

    if (this.gameMode !== 'campaign' || skipBriefing) {
      this.arena.setChapterAtmosphere(chapter, false, this.gameMode);
      this.phase = 'playing';
      this.weaponMount.visible = true;
      this.camera.position.set(this.playerX, this.playerY, this.playerZ);
      this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
      this.camera.fov = this.fov;
      this.camera.updateProjectionMatrix();
      this.camera.updateMatrixWorld(true);
      this.beginWave(chapter, 0);
      if (this.gameMode !== 'firing_range') {
        this.spawnAlliedSquad();
      }
      document.body.dataset.state = 'playing';
      this.emitHud();
    } else {
      this.prepareWaveBriefing(chapter);
    }
  }

  private unlockStoryChapter(waveNum: number): void {
    const capped = Math.max(1, Math.min(MAX_STORY_WAVES, waveNum));
    if (capped > this.unlockedChapter) {
      this.unlockedChapter = capped;
      try {
        localStorage.setItem(UNLOCKED_CHAPTER_KEY, String(this.unlockedChapter));
      } catch {
        // ignore storage failures
      }
    }
  }

  private prepareWaveBriefing(waveNum: number): void {
    this.wave = waveNum;
    if (waveNum <= MAX_STORY_WAVES) {
      this.unlockStoryChapter(waveNum);
    }
    this.arena.setChapterAtmosphere(waveNum, false, this.gameMode);
    this.clearObjectiveProp();
    this.chapterStages = getChapterStageSpecs(waveNum, this.campaignPace);
    this.chapterStageIdx = 0;
    this.checkpointStage = 1;
    this.checkpointScore = this.score;
    this.checkpointKills = this.kills;
    this.checkpointHeadshots = this.headshots;
    const firstStage = this.chapterStages[0];
    this.waveToSpawn = firstStage.enemyCount;
    this.waveSpawnTimer = 0.6;
    this.betweenWaveTimer = 0;
    this.waveBanner = null;
    this.waveBannerTimer = 0;
    this.checkpointBanner = null;
    this.checkpointBannerTimer = 0;
    this.radioMessage = null;
    this.radioTimer = 0;
    this.activeCutscene = null;
    this.cutsceneOnComplete = null;
    this.phase = 'briefing';
    this.weaponMount.visible = false;
    this.clearHeldInputs();
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    this.camera.position.set(this.playerX, this.playerY, this.playerZ);
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    document.body.dataset.state = 'briefing';
    this.emitHud();
  }

  private startCutscene(spec: CutsceneSpec, onComplete: () => void): void {
    this.activeCutscene = spec;
    this.cutsceneBeatIdx = 0;
    this.cutsceneBeatTimer = 0;
    this.cutsceneOnComplete = onComplete;
    this.phase = 'cutscene';
    this.weaponMount.visible = false;
    this.adsDesired = false;
    this.adsBlend = 0;
    this.clearHeldInputs();
    const firstBeatHeli = Boolean(spec.beats[0]?.showHeli);
    this.arena.helicopter.root.visible = firstBeatHeli;
    if (firstBeatHeli) {
      soundEngine.playHelicopterPass();
    }
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    soundEngine.playRadioComms();
    document.body.dataset.state = 'cutscene';
    this.emitHud();
  }

  public skipCutscene(): void {
    if (this.phase !== 'cutscene') return;
    this.cutsceneExitPos.copy(this.camera.position);
    this.cutsceneExitQuat.copy(this.camera.quaternion);
    this.cutsceneBlendTimer = 0.48;
    this.arena.helicopter.root.visible = false;
    const cb = this.cutsceneOnComplete;
    this.activeCutscene = null;
    this.cutsceneOnComplete = null;
    this.cutsceneBeatIdx = 0;
    this.cutsceneBeatTimer = 0;
    cb?.();
  }

  public deployWave(): void {
    if (this.phase !== 'briefing') return;
    soundEngine.unlock();
    this.clearHeldInputs();
    if (this.wave <= MAX_STORY_WAVES && this.gameMode === 'campaign') {
      const introScene = getChapterCutscene(this.wave, 'intro');
      this.startCutscene(introScene, () => {
        this.phase = 'playing';
        this.weaponMount.visible = true;
        this.camera.position.set(this.playerX, this.playerY, this.playerZ);
        this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
        this.camera.fov = this.fov;
        this.camera.updateProjectionMatrix();
        this.beginWave(this.wave, 0);
        this.spawnAlliedSquad();
        document.body.dataset.state = 'playing';
        this.emitHud();
      });
    } else {
      this.phase = 'playing';
      this.weaponMount.visible = true;
      this.beginWave(this.wave, 0);
      this.spawnAlliedSquad();
      document.body.dataset.state = 'playing';
      this.emitHud();
    }
  }

  public restartFromCheckpoint(): void {
    if (this.phase !== 'gameover' || this.outcome !== 'defeat') return;
    soundEngine.unlock();
    this.clearDynamicEntities();
    this.outcome = null;
    this.score = this.checkpointScore;
    this.kills = this.checkpointKills;
    this.headshots = this.checkpointHeadshots;

    const heavyPerk = this.selectedPerk === 'heavy_armor';
    this.hp = this.maxHp;
    this.maxArmor = heavyPerk ? 75 : 50;
    this.armor = this.maxArmor;
    this.maxArmorPlates = heavyPerk ? 3 : 2;
    this.armorPlates = this.maxArmorPlates;
    this.grenades = Math.max(2, this.grenades);
    this.flashbangs = Math.max(2, this.flashbangs);
    this.weaponStates = createInitialWeaponStates(this.equippedAttachments, this.selectedPerk);
    this.reloading = false;
    this.reloadTimer = 0;
    this.adsDesired = false;
    this.adsBlend = 0;
    this.playerX = 0;
    this.playerY = 1.7;
    this.playerZ = 22;
    this.playerVelY = 0;
    this.isGrounded = true;
    this.yaw = 0;
    this.pitch = 0;

    this.phase = 'playing';
    this.weaponMount.visible = true;
    this.clearHeldInputs();
    this.beginWave(this.wave, Math.max(0, this.checkpointStage - 1));
    this.checkpointBanner = `YOXLAMA NÖQTƏSİ YÜKLƏNDİ (${this.checkpointStage}/${this.chapterStages.length})`;
    this.checkpointBannerTimer = 2.4;
    document.body.dataset.state = 'playing';
    this.emitHud();
  }

  public setCampaignPace(pace: CampaignPace): void {
    this.campaignPace = pace;
    try {
      localStorage.setItem(CAMPAIGN_PACE_KEY, pace);
    } catch {
      // ignore storage failures
    }
    this.emitHud();
  }

  public continueEndless(): void {
    if (this.phase !== 'gameover' || this.outcome !== 'victory') return;
    this.endlessMode = true;
    this.outcome = null;
    this.hp = Math.min(this.maxHp, this.hp + 40);
    this.armor = Math.min(this.maxArmor, this.armor + 25);
    this.armorPlates = this.maxArmorPlates;
    this.grenades = Math.min(4, this.grenades + 1);
    this.prepareWaveBriefing(this.wave + 1);
  }

  public jumpToChapter(chapter: number): void {
    const targetChapter = resolvePlayableChapter(chapter);
    this.gameMode = 'campaign';
    this.startGame(this.activeWeapon, false, targetChapter);
  }

  public pauseGame(): void {
    if (this.phase !== 'playing') return;
    this.phase = 'paused';
    this.clearHeldInputs();
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    document.body.dataset.state = 'paused';
    this.emitHud();
  }

  public resumeGame(): void {
    if (this.phase !== 'paused') return;
    soundEngine.unlock();
    this.phase = 'playing';
    this.clearHeldInputs();
    document.body.dataset.state = 'playing';
    this.emitHud();
  }

  public returnToTitle(): void {
    this.clearDynamicEntities();
    this.isNvgActive = false;
    this.activeCutscene = null;
    this.cutsceneOnComplete = null;
    this.renderer.toneMappingExposure = 1.16;
    this.arena.setChapterAtmosphere(1, false, 'campaign');
    if (this.titlePatrollers.length === 0) {
      this.spawnTitlePatrollers();
    }
    this.phase = 'title';
    this.outcome = null;
    this.radioMessage = null;
    this.radioTimer = 0;
    this.weaponMount.visible = false;
    this.clearHeldInputs();
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    document.body.dataset.state = 'title';
    this.emitHud();
  }

  public switchWeapon(weaponId?: WeaponId): void {
    const next: WeaponId =
      weaponId ??
      (this.activeWeapon === this.loadoutWeapons[0]
        ? this.loadoutWeapons[1]
        : this.loadoutWeapons[0]);
    if (next === this.activeWeapon) return;
    this.activeWeapon = next;
    this.reloading = false;
    this.reloadTimer = 0;
    this.fireTimer = 0.18;
    WEAPON_LIST.forEach((w) => {
      this.viewmodels[w].root.visible = w === next;
      this.viewmodels[w].muzzleFlash.visible = false;
    });
    this.emitHud();
  }

  public setWeaponCamo(weapon: WeaponId, camo: WeaponCamoId): void {
    if (!isCamoUnlocked(camo, this.careerStats)) return;
    this.equippedCamos[weapon] = camo;
    try {
      localStorage.setItem(EQUIPPED_CAMOS_KEY, JSON.stringify(this.equippedCamos));
    } catch {
      // ignore storage failures
    }
    applyWeaponCamoToRig(this.viewmodels[weapon], weapon, camo, this.textures);
    this.emitHud();
  }

  public toggleAttachment(weapon: WeaponId, attachment: AttachmentId): void {
    const current = this.equippedAttachments[weapon] ?? [];
    const next = current.includes(attachment)
      ? current.filter((id) => id !== attachment)
      : [...current, attachment];
    this.equippedAttachments[weapon] = next;
    try {
      localStorage.setItem(EQUIPPED_ATTACHMENTS_KEY, JSON.stringify(this.equippedAttachments));
    } catch {
      // ignore storage failures
    }
    applyWeaponAttachmentsToRig(this.viewmodels[weapon], next);
    this.emitHud();
  }

  public setPerk(perk: PerkId): void {
    if (!(perk in PERK_SPECS)) return;
    this.selectedPerk = perk;
    try {
      localStorage.setItem(SELECTED_PERK_KEY, perk);
    } catch {
      // ignore storage failures
    }
    this.emitHud();
  }

  public setDifficulty(diff: DifficultyId): void {
    if (!(diff in DIFFICULTY_SPECS)) return;
    this.selectedDifficulty = diff;
    try {
      localStorage.setItem(SELECTED_DIFFICULTY_KEY, diff);
    } catch {
      // ignore storage failures
    }
    this.emitHud();
  }

  public toggleNvg(): void {
    if (this.phase !== 'playing') return;
    this.isNvgActive = !this.isNvgActive;
    this.renderer.toneMappingExposure = this.isNvgActive ? 1.68 : 1.16;
    soundEngine.playNvgToggle();
    this.emitHud();
  }

  public setMoveInput(x: number, y: number): void {
    this.touchMoveX = Math.max(-1, Math.min(1, x));
    this.touchMoveY = Math.max(-1, Math.min(1, y));
  }

  private saveStoryProgress(): void {
    try {
      const payload: StoryProgressSave = {
        squadTrust: this.squadTrust,
        storyDecisions: this.storyDecisions,
        unlockedEndingIds: this.unlockedEndingIds,
        canonLoadoutEnabled: this.canonLoadoutEnabled,
      };
      localStorage.setItem(STORY_PROGRESS_KEY, JSON.stringify(payload));
    } catch {
      // ignore storage failures
    }
  }

  public setCanonLoadoutEnabled(enabled: boolean): void {
    this.canonLoadoutEnabled = Boolean(enabled);
    this.saveStoryProgress();
    this.emitHud();
  }

  public submitStoryChoice(optionIndex: 0 | 1): void {
    const choice = this.activeStoryChoice;
    if (!choice) return;
    const opt = choice.options[optionIndex];
    if (!opt) return;

    this.squadTrust = Math.max(0, Math.min(100, this.squadTrust + opt.trustDelta));
    this.storyDecisions = [
      ...this.storyDecisions.filter((d) => d.choiceId !== choice.id),
      {
        choiceId: choice.id,
        optionIndex,
        label: opt.label,
        tag: opt.tag,
      },
    ];
    this.triggeredChoiceIdsThisRun.add(choice.id);
    this.activeStoryChoice = null;
    soundEngine.playStoryChoice();
    this.comboBanner = opt.label;
    this.comboBannerTimer = 2.8;
    this.triggerRadioComms(
      choice.speaker,
      choice.callsign,
      opt.consequenceHint,
      opt.trustDelta >= 0 ? 'ally' : 'command',
      5.0,
    );

    if (this.pendingEndingResolution) {
      this.pendingEndingResolution = false;
      const ending = resolveStoryEnding(
        this.storyDecisions,
        this.squadTrust,
        this.hostagesLostThisRun,
      );
      this.activeEnding = ending;
      if (!this.unlockedEndingIds.includes(ending.id)) {
        this.unlockedEndingIds.push(ending.id);
      }
      this.saveStoryProgress();
      this.unlockMedal('veteran_hero');
      this.awardXp(300);
      this.finishGame('victory');
      return;
    }

    this.saveStoryProgress();
    this.betweenWaveTimer = 1.6;
    this.emitHud();
  }

  public triggerBossQteStrike(): void {
    if (this.phase !== 'playing' || !this.bossQte) return;
    this.bossQte.hitsDone += 1;
    soundEngine.playQteClash();
    this.trauma = Math.min(1, this.trauma + 0.32);

    if (this.bossQte.hitsDone >= this.bossQte.hitsRequired) {
      const bossId = this.bossQte.bossId;
      this.bossQte = null;
      const boss = this.enemies.find((e) => e.id === bossId && e.state !== 'dying');
      if (boss) {
        this.finalKillSlowMoTimer = 1.0;
        _v1.set(boss.x, 1.4, boss.z);
        this.damageEnemy(boss, boss.hp + 80, true, _v1, false);
        this.score += 500;
        this.awardXp(150);
        this.comboBanner = 'YAXIN DÖYÜŞ FINISHER · QƏLƏBƏ!';
        this.comboBannerTimer = 2.5;
      }
    }
    this.emitHud();
  }

  private saveSettings(): void {
    try {
      localStorage.setItem(
        SETTINGS_KEY,
        JSON.stringify({
          sensitivity: this.sensitivity,
          fov: this.fov,
          volume: this.volume,
          touchControlsEnabled: this.touchControlsEnabled,
          fieldUpgrade: this.fieldUpgrade,
          graphicsQuality: this.graphicsQuality,
        }),
      );
    } catch {
      // ignore storage failures
    }
  }

  public setSensitivity(val: number): void {
    this.sensitivity = Math.max(0.2, Math.min(2.5, Number.isFinite(val) ? val : 1.0));
    this.saveSettings();
    this.emitHud();
  }

  public setFov(val: number): void {
    this.fov = Math.max(60, Math.min(110, Number.isFinite(val) ? Math.round(val) : 75));
    this.saveSettings();
    this.emitHud();
  }

  public setVolume(val: number): void {
    this.volume = Math.max(0, Math.min(1, Number.isFinite(val) ? val : 0.7));
    soundEngine.setMasterVolume(this.volume);
    this.saveSettings();
    this.emitHud();
  }

  public setTouchControlsEnabled(enabled: boolean): void {
    this.touchControlsEnabled = Boolean(enabled);
    this.saveSettings();
    this.emitHud();
  }

  public setFieldUpgrade(id: FieldUpgradeId): void {
    if (!(id in FIELD_UPGRADE_SPECS)) return;
    this.fieldUpgrade = id;
    this.saveSettings();
    this.emitHud();
  }

  public cycleLean(): void {
    if (this.phase !== 'playing' || this.gunshipActive || this.mountedTurret) return;
    this.lean = resolveNextLean(this.lean);
    soundEngine.playLean();
    this.emitHud();
  }

  public activateFieldUpgrade(): void {
    if (this.phase !== 'playing' || this.fieldUpgradeCooldown > 0 || this.isLastStand) return;
    const spec = FIELD_UPGRADE_SPECS[this.fieldUpgrade];
    const res = applyFieldUpgrade(this.fieldUpgrade, this.stims, this.maxStims);
    this.stims = res.stims;
    this.fieldUpgradeCooldown = spec.cooldownSec;
    this.fieldUpgradeActiveTimer = spec.durationSec;

    if (this.fieldUpgrade === 'ammo_box') {
      for (const w of WEAPON_LIST) {
        const ws = this.getActiveWeaponSpec(w);
        this.weaponStates[w] = { id: w, mag: ws.magSize, reserve: ws.maxReserve };
      }
      this.grenades = Math.min(4, this.grenades + 1);
    } else if (this.fieldUpgrade === 'shield') {
      this.armor = Math.min(this.maxArmor, this.armor + 35);
    }

    soundEngine.playFieldUpgrade();
    this.comboBanner = res.message;
    this.comboBannerTimer = 2.2;
    this.emitHud();
  }

  public selfRevive(): void {
    if (this.phase !== 'playing' || !this.isLastStand || !this.selfReviveKit) return;
    this.isLastStand = false;
    this.selfReviveKit = false;
    this.lastStandTimer = 0;
    this.hp = 55;
    this.isCrouching = false;
    soundEngine.playStimShot();
    this.comboBanner = 'SON DAYAQDAN QALXDINIZ! (+55 CAN)';
    this.comboBannerTimer = 2.2;
    this.emitHud();
  }

  public setDefuseHeld(held: boolean): void {
    this.touchDefuseHeld = held;
  }

  public resetFiringRange(): void {
    if (this.gameMode !== 'firing_range' || this.phase !== 'playing') return;
    this.rangeHits = 0;
    this.rangeHeadshots = 0;
    this.shotsFired = 0;
    this.shotsHit = 0;
    this.score = 0;
    for (const rt of this.rangeTargets) {
      rt.knockedTimer = 0;
      rt.flipBlend = 0;
      rt.rig.pivotGroup.rotation.x = 0;
    }
    soundEngine.playPickup();
    this.comboBanner = 'TƏLİM POLİQONU SIFIRLANDI';
    this.comboBannerTimer = 1.6;
    this.emitHud();
  }

  public addLookDelta(dx: number, dy: number): void {
    if (this.phase !== 'playing') return;
    const baseSens = this.adsDesired ? 0.0022 : 0.0038;
    const sens = baseSens * this.sensitivity;
    this.yaw -= dx * sens;
    this.pitch = THREE.MathUtils.clamp(
      this.pitch - dy * sens,
      -Math.PI * 0.42,
      Math.PI * 0.42,
    );
    this.swayX = THREE.MathUtils.clamp(this.swayX - dx * 0.00038 * this.sensitivity, -0.036, 0.036);
    this.swayY = THREE.MathUtils.clamp(this.swayY - dy * 0.00038 * this.sensitivity, -0.03, 0.03);
  }

  public setFireHeld(held: boolean): void {
    soundEngine.unlock();
    this.touchFireHeld = held;
  }

  public setAds(desired: boolean): void {
    this.adsDesired = desired;
    if (this.activeWeapon === 'msr' && this.phase === 'playing') {
      this.weaponMount.visible = !desired;
    }
  }

  public toggleAds(): void {
    this.adsDesired = !this.adsDesired;
    if (this.activeWeapon === 'msr' && this.phase === 'playing') {
      this.weaponMount.visible = !this.adsDesired;
    }
    this.emitHud();
  }

  public toggleAutoFire(): void {
    this.autoFire = !this.autoFire;
    this.emitHud();
  }

  public triggerReload(): void {
    if (this.phase !== 'playing' || this.reloading) return;
    const spec = this.getActiveWeaponSpec(this.activeWeapon);
    const st = this.weaponStates[this.activeWeapon];
    if (st.mag >= spec.magSize || st.reserve <= 0) return;
    this.reloading = true;
    this.reloadTimer = spec.reloadDuration;
    this.adsDesired = false;
    soundEngine.playReload();
    this.emitHud();
  }

  public triggerJump(): void {
    if (this.phase !== 'playing') return;
    this.jumpBufferTimer = 0.12;
  }

  public triggerSlide(): void {
    if (
      this.phase !== 'playing' ||
      this.slideTimer > 0 ||
      this.slideCooldown > 0 ||
      !this.isGrounded
    ) {
      return;
    }
    let moveRight = this.touchMoveX;
    let moveFwd = this.touchMoveY;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) moveRight += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) moveRight -= 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) moveFwd += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) moveFwd -= 1;

    _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    _vRight.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    if (Math.hypot(moveRight, moveFwd) > 0.15) {
      this.slideDirX = _vRight.x * moveRight + _vForward.x * moveFwd;
      this.slideDirZ = _vRight.z * moveRight + _vForward.z * moveFwd;
      const len = Math.max(0.01, Math.hypot(this.slideDirX, this.slideDirZ));
      this.slideDirX /= len;
      this.slideDirZ /= len;
    } else {
      this.slideDirX = _vForward.x;
      this.slideDirZ = _vForward.z;
    }

    this.slideTimer = 0.45;
    this.slideCooldown = this.selectedPerk === 'lightweight' ? 0.9 : 1.25;
    this.adsDesired = false;
    soundEngine.playSlide();
    _v1.set(this.playerX, 0.25, this.playerZ);
    this.spawnParticleBurst(_v1, 7, 0xd4b995, 3.6);
    this.emitHud();
  }

  public useArmorPlate(): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign') return;
    const res = applyArmorPlate(this.armor, this.maxArmor, this.armorPlates, 35);
    if (!res.applied) return;
    this.armor = res.armor;
    this.armorPlates = res.plates;
    soundEngine.playArmorPlate();
    this.comboBanner = 'ZİREH LÖVHƏSİ TAXILDI +35';
    this.comboBannerTimer = 1.4;
    this.emitHud();
  }

  public triggerUavSweep(): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign' || !this.uavReady) return;
    this.uavReady = false;
    this.uavActiveTimer = 15;
    soundEngine.playUavScan();
    this.comboBanner = 'UAV KƏŞFİYYATI AKTİV · 15s';
    this.comboBannerTimer = 2.0;
    this.emitHud();
  }

  public useStimShot(): void {
    if (this.phase !== 'playing') return;
    const res = applyStimShot(this.hp, this.maxHp, this.stims, 45);
    if (!res.applied) return;
    this.hp = res.hp;
    this.stims = res.stims;
    this.stimBoostTimer = 4.0;
    soundEngine.playStimShot();
    this.comboBanner = 'ADRENALİN STİM +45 CAN · SÜRƏT ARTIMI!';
    this.comboBannerTimer = 1.8;
    this.emitHud();
  }

  public toggleCrouch(): void {
    if (this.phase !== 'playing' || this.gunshipActive || this.mountedTurret) return;
    this.isCrouching = !this.isCrouching;
    if (this.isCrouching) {
      this.isSprinting = false;
    }
    this.emitHud();
  }

  public triggerWeaponInspect(): void {
    if (this.phase !== 'playing' || this.gunshipActive || this.reloading || this.adsDesired) return;
    this.inspectTimer = 2.2;
    soundEngine.playPickup();
    this.emitHud();
  }

  public callCarePackage(freeFromBuyStation = false): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign') return;
    if (!freeFromBuyStation && !this.carePackageReady) return;
    if (!freeFromBuyStation) {
      this.carePackageReady = false;
    }

    _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const dropX = Math.max(-31, Math.min(31, this.playerX + _vForward.x * 4.5));
    const dropZ = Math.max(-31, Math.min(31, this.playerZ + _vForward.z * 4.5));
    const resolved = resolveAllCollisions(dropX, dropZ, 1.0, this.arena.colliders);

    const { root, chuteGroup, beaconMesh } = createCarePackageCrate();
    root.position.set(resolved.x, 22, resolved.z);
    this.scene.add(root);
    this.carePackages.push({
      root,
      chuteGroup,
      beaconMesh,
      x: resolved.x,
      y: 22,
      z: resolved.z,
      landed: false,
      age: 0,
    });

    soundEngine.playCarePackageDrop();
    this.comboBanner = 'YARDIM PAKETİ ENDİRİLİR! (YAŞIL TÜSTÜ)';
    this.comboBannerTimer = 2.2;
    this.triggerRadioComms(
      'Overwatch',
      'PEYK DƏSTƏYİ',
      'Yardım paketi paraşütlə sektorunuza göndərildi! Yaşıl mayakın yanından [E] ilə açın.',
      'ally',
    );
    this.emitHud();
  }

  public triggerKillstreak(): void {
    if (
      this.phase !== 'playing' ||
      this.gameMode === 'campaign' ||
      this.killstreakProgress < KILLSTREAK_THRESHOLD
    ) {
      return;
    }
    this.killstreakProgress = 0;
    soundEngine.playDroneStrike();

    const living = this.enemies.filter((e) => e.state !== 'dying');
    const targets: { x: number; z: number }[] = [];
    for (let i = 0; i < Math.min(4, living.length); i++) {
      targets.push({ x: living[i].x, z: living[i].z });
    }
    if (targets.length === 0) {
      _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      targets.push(
        {
          x: Math.max(-32, Math.min(32, this.playerX + _vForward.x * 16)),
          z: Math.max(-32, Math.min(32, this.playerZ + _vForward.z * 16)),
        },
        {
          x: Math.max(-32, Math.min(32, this.playerX + _vForward.x * 23)),
          z: Math.max(-32, Math.min(32, this.playerZ + _vForward.z * 23)),
        },
      );
    }

    targets.forEach((tgt, idx) => {
      _v1.copy(this.arena.uavDrone.position);
      _v2.set(tgt.x, 0.3, tgt.z);
      this.spawnTracer(_v1, _v2);
      this.pendingStrikes.push({
        x: tgt.x,
        z: tgt.z,
        timer: 0.28 + idx * 0.14,
      });
    });

    this.comboBanner = 'AC-130 DRON ZƏRBƏSİ ENDİRİLDİ!';
    this.comboBannerTimer = 2.0;
    this.emitHud();
  }

  public throwGrenade(): void {
    if (this.phase !== 'playing' || this.grenades <= 0) return;
    this.grenades -= 1;
    soundEngine.playPickup();

    const mesh = new THREE.Mesh(this.grenadeGeo, this.grenadeMat);
    this.camera.getWorldDirection(_vDir);
    const startPos = new THREE.Vector3(this.playerX, this.playerY - 0.1, this.playerZ).addScaledVector(
      _vDir,
      0.7,
    );
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    const vel = _vDir.clone().multiplyScalar(17.5);
    vel.y += 4.5;

    this.activeGrenades.push({
      mesh,
      pos: startPos,
      vel,
      fuse: 1.15,
      kind: 'frag',
    });
    this.emitHud();
  }

  public throwFlashbang(): void {
    if (this.phase !== 'playing' || this.flashbangs <= 0) return;
    this.flashbangs -= 1;
    soundEngine.playPickup();

    const mesh = new THREE.Mesh(this.grenadeGeo, this.grenadeMat);
    this.camera.getWorldDirection(_vDir);
    const startPos = new THREE.Vector3(this.playerX, this.playerY - 0.1, this.playerZ).addScaledVector(
      _vDir,
      0.7,
    );
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    const vel = _vDir.clone().multiplyScalar(19.0);
    vel.y += 3.8;

    this.activeGrenades.push({
      mesh,
      pos: startPos,
      vel,
      fuse: 0.65,
      kind: 'flash',
    });
    this.emitHud();
  }

  public requestPointerLock(): void {
    if (this.phase !== 'playing') return;
    try {
      this.renderer.domElement.requestPointerLock?.();
    } catch {
      // Fallback drag-look already works seamlessly
    }
  }

  public triggerC4(): void {
    if (this.phase !== 'playing') return;
    if (this.c4Charges.length > 0) {
      // Detonate all planted C4 charges remotely!
      const charges = [...this.c4Charges];
      this.c4Charges = [];
      for (const c of charges) {
        this.scene.remove(c.root);
        _v1.set(c.x, c.y + 0.3, c.z);
        this.triggerExplosion(_v1, 7.6, 210);
      }
      this.comboBanner = 'C4 UZAQDAN PARTLADILDI!';
      this.comboBannerTimer = 1.6;
      this.emitHud();
      return;
    }

    if (this.c4Count <= 0) return;
    this.c4Count -= 1;
    soundEngine.playC4Beep();
    _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const tx = Math.max(-35, Math.min(35, this.playerX + _vForward.x * 2.1));
    const tz = Math.max(-35, Math.min(35, this.playerZ + _vForward.z * 2.1));
    const { root, ledMesh } = createC4Pack();
    root.position.set(tx, 0, tz);
    this.scene.add(root);
    this.c4Charges.push({ root, ledMesh, x: tx, y: 0.1, z: tz });
    this.comboBanner = 'C4 YERLƏŞDİRİLDİ · [Z] İLƏ PARTLAT';
    this.comboBannerTimer = 1.8;
    this.emitHud();
  }

  public placeClaymore(): void {
    if (this.phase !== 'playing' || this.claymoreCount <= 0) return;
    this.claymoreCount -= 1;
    soundEngine.playC4Beep();
    _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const cx = Math.max(-35, Math.min(35, this.playerX + _vForward.x * 1.4));
    const cz = Math.max(-35, Math.min(35, this.playerZ + _vForward.z * 1.4));
    const { root } = createClaymoreMine();
    root.position.set(cx, 0, cz);
    root.rotation.y = this.yaw;
    this.scene.add(root);
    this.claymores.push({ root, x: cx, z: cz, yaw: this.yaw });
    this.comboBanner = 'CLAYMORE MİNASI QURULDU!';
    this.comboBannerTimer = 1.6;
    this.emitHud();
  }

  public toggleThermal(): void {
    if (this.phase !== 'playing') return;
    this.thermalActive = !this.thermalActive;
    soundEngine.playNvgToggle();
    this.emitHud();
  }

  public setBuyStationOpen(open: boolean): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign') return;
    this.buyStationOpen = open;
    if (open) {
      this.clearHeldInputs();
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock?.();
      }
    }
    this.emitHud();
  }

  public buyStationPurchase(itemId: BuyStationItemId): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign') return;
    const res = purchaseBuyStationItem(this.credits, itemId);
    if (!res.ok) return;
    this.credits = res.remainingCredits;
    soundEngine.playBuyStation();

    if (itemId === 'ammo') {
      for (const w of WEAPON_LIST) {
        const spec = this.getActiveWeaponSpec(w);
        this.weaponStates[w] = {
          id: w,
          mag: spec.magSize,
          reserve: spec.maxReserve,
        };
      }
      this.grenades = Math.min(4, this.grenades + 2);
      this.flashbangs = Math.min(3, this.flashbangs + 1);
      this.comboBanner = 'TAM SURSAT & QUMBARA ALINDI!';
    } else if (itemId === 'explosives') {
      this.c4Count += 2;
      this.claymoreCount += 2;
      this.comboBanner = '+2 C4 & +2 CLAYMORE ALINDI!';
    } else if (itemId === 'juggernaut') {
      this.hp = this.maxHp;
      this.maxArmor = Math.max(this.maxArmor, 100);
      this.armor = this.maxArmor;
      this.armorPlates = this.maxArmorPlates;
      this.comboBanner = 'JUGGERNAUT ZİREHİ AKTİVDİR!';
    } else if (itemId === 'sentry') {
      _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      const sx = Math.max(-34, Math.min(34, this.playerX + _vForward.x * 2.2));
      const sz = Math.max(-34, Math.min(34, this.playerZ + _vForward.z * 2.2));
      const rig = createSentryTurret();
      rig.root.position.set(sx, 0, sz);
      this.scene.add(rig.root);
      this.sentries.push({ rig, x: sx, z: sz, timer: 35, fireCooldown: 0.25, flashTimer: 0 });
      this.comboBanner = 'AVTO-TURET QURULDU (35s)!';
    } else if (itemId === 'care_package') {
      this.buyStationOpen = false;
      this.callCarePackage(true);
      return;
    } else if (itemId === 'ac130') {
      this.gunshipReady = true;
      this.buyStationOpen = false;
      this.triggerGunship();
      return;
    }

    this.comboBannerTimer = 1.9;
    this.buyStationOpen = false;
    this.emitHud();
  }

  public triggerGunship(): void {
    if (this.phase !== 'playing' || this.gameMode === 'campaign') return;
    if (this.gunshipActive) {
      this.gunshipActive = false;
      this.weaponMount.visible = true;
      this.emitHud();
      return;
    }
    if (!this.gunshipReady && this.killstreakProgress < KILLSTREAK_THRESHOLD) return;
    this.gunshipReady = false;
    this.killstreakProgress = 0;
    this.gunshipActive = true;
    this.gunshipTimer = 10;
    this.gunshipShells = 12;
    this.gunshipAimX = this.playerX;
    this.gunshipAimZ = Math.max(-28, this.playerZ - 12);
    this.adsDesired = false;
    this.weaponMount.visible = false;
    soundEngine.playHelicopterPass();
    this.comboBanner = 'AC-130 GUNSHIP MODU AKTİVDİR! ATƏŞ EDİN';
    this.comboBannerTimer = 2.4;
    this.emitHud();
  }

  public triggerMeleeStrike(): void {
    if (this.phase !== 'playing' || this.gunshipActive) return;
    if (this.bossQte) {
      this.triggerBossQteStrike();
      return;
    }
    soundEngine.playKnifeSlash();
    this.fireTimer = 0.35;

    let bestEnemy: ActiveEnemy | null = null;
    let bestDist = 3.6;
    _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));

    for (const e of this.enemies) {
      if (e.state === 'dying') continue;
      const dx = e.x - this.playerX;
      const dz = e.z - this.playerZ;
      const d = Math.hypot(dx, dz);
      if (d <= bestDist) {
        const dotLook = (dx * _vForward.x + dz * _vForward.z) / Math.max(0.01, d);
        if (dotLook > 0.35 || d < 1.6) {
          bestDist = d;
          bestEnemy = e;
        }
      }
    }

    if (bestEnemy) {
      const eFwdX = Math.sin(bestEnemy.yaw);
      const eFwdZ = Math.cos(bestEnemy.yaw);
      const toEnemyX = bestEnemy.x - this.playerX;
      const toEnemyZ = bestEnemy.z - this.playerZ;
      const behindDot = (eFwdX * toEnemyX + eFwdZ * toEnemyZ) / Math.max(0.01, bestDist);
      const isBehind = behindDot > 0.3 || !bestEnemy.alerted;
      const res = computeStealthTakedownDamage(140, bestDist, 3.6, isBehind);
      if (res.hit) {
        _v1.set(bestEnemy.x, 1.35, bestEnemy.z);
        const prevKills = this.kills;
        this.damageEnemy(bestEnemy, res.damage, res.isStealthKill, _v1, false);
        if (this.kills > prevKills) {
          this.knifeKillsThisRun += 1;
          if (this.knifeKillsThisRun >= 2) {
            this.unlockMedal('blade_master');
          }
          if (res.isStealthKill) {
            this.comboBanner = 'GİZLİ BIÇAQ ZƏRBƏSİ +150';
            this.comboBannerTimer = 1.8;
            this.score += 150;
          }
        }
      }
    }
    this.emitHud();
  }

  private getNearestInteraction(): {
    kind: 'intel' | 'breach' | 'turret' | 'care_package' | 'hostage' | 'revive_ally';
    label: string;
    refId?: string | number;
  } | null {
    if (this.mountedTurret) {
      return { kind: 'turret', label: 'Pulemyotdan en [E]' };
    }
    for (const ally of this.allies) {
      if (ally.downed && Math.hypot(ally.x - this.playerX, ally.z - this.playerZ) <= 3.1) {
        return { kind: 'revive_ally', label: `${ally.name} Yoldaşı Xilas Et [E]`, refId: ally.name };
      }
    }
    for (const h of this.hostages) {
      if (h.alive && !h.rescued && Math.hypot(h.x - this.playerX, h.z - this.playerZ) <= 2.9) {
        return { kind: 'hostage', label: `Girovu Xilas Et [E] · ${h.name}`, refId: h.id };
      }
    }
    for (let i = 0; i < this.carePackages.length; i++) {
      const cp = this.carePackages[i];
      if (cp.landed && Math.hypot(cp.x - this.playerX, cp.z - this.playerZ) <= 3.0) {
        return { kind: 'care_package', label: 'Yardım Paketini aç [E]', refId: i };
      }
    }
    for (const intel of this.intelPickups) {
      if (!intel.collected && Math.hypot(intel.x - this.playerX, intel.z - this.playerZ) <= 2.8) {
        return { kind: 'intel', label: `Məlumatı götür [E] · ${intel.title}`, refId: intel.id };
      }
    }
    for (const door of this.arena.breachDoors) {
      if (!door.breached && Math.hypot(door.x - this.playerX, door.z - this.playerZ) <= 3.3) {
        return { kind: 'breach', label: 'Qapını Partlat [E] (Slow-Mo)', refId: door.id };
      }
    }
    if (
      this.gameMode !== 'firing_range' &&
      Math.hypot(this.arena.jeepPos.x - this.playerX, this.arena.jeepPos.z - this.playerZ) <= 4.3
    ) {
      return { kind: 'turret', label: 'Humvee Pulemyotuna keç [E]' };
    }
    return null;
  }

  public triggerInteract(): void {
    if (this.phase !== 'playing') return;
    if (
      this.gameMode === 'spec_ops' &&
      this.bombSites.some(
        (b) => !b.defused && Math.hypot(b.x - this.playerX, b.z - this.playerZ) <= 3.2,
      )
    ) {
      return;
    }
    const prompt = this.getNearestInteraction();
    if (!prompt) {
      if (this.gameMode !== 'campaign' && this.killstreakProgress >= KILLSTREAK_THRESHOLD) {
        this.triggerKillstreak();
      }
      return;
    }

    if (prompt.kind === 'revive_ally') {
      const ally = this.allies.find((a) => a.name === prompt.refId && a.downed);
      if (ally) {
        ally.downed = false;
        ally.hp = 85;
        ally.bleedoutTimer = 0;
        ally.downedCooldown = 28;
        ally.rig.bodyGroup.position.y = 0;
        ally.rig.bodyGroup.rotation.x = 0;
        soundEngine.playAllyRevived();
        this.squadTrust = Math.min(100, this.squadTrust + 8);
        this.saveStoryProgress();
        this.awardXp(120);
        this.comboBanner = `${ally.name.toUpperCase()} XİLAS EDİLDİ! (+8 GÜVƏN)`;
        this.comboBannerTimer = 2.3;
        this.triggerRadioComms(
          ally.name,
          'QARTAL-SQUAD',
          'Sağ ol, komandir! Yenidən atəş xəttindəyəm!',
          'ally',
        );
        this.emitHud();
      }
      return;
    }

    if (prompt.kind === 'hostage') {
      const h = this.hostages.find((item) => item.id === prompt.refId && item.alive && !item.rescued);
      if (h) {
        h.rescued = true;
        h.rig.ringMesh.visible = false;
        h.rig.root.visible = false;
        soundEngine.playHostageRescued();
        this.squadTrust = Math.min(100, this.squadTrust + 6);
        this.saveStoryProgress();
        this.score += 350;
        this.awardXp(110);
        _v1.set(h.x, 1.0, h.z);
        this.spawnParticleBurst(_v1, 14, 0x38bdf8, 4.2);
        this.comboBanner = `${h.name.toUpperCase()} AZAD EDİLDİ! +350`;
        this.comboBannerTimer = 2.3;
        this.emitHud();
      }
      return;
    }

    if (prompt.kind === 'care_package') {
      const idx = typeof prompt.refId === 'number' ? prompt.refId : 0;
      this.collectCarePackage(idx);
      return;
    }

    if (prompt.kind === 'intel') {
      const item = this.intelPickups.find((i) => i.id === prompt.refId);
      if (item && !item.collected) {
        item.collected = true;
        item.root.visible = false;
        soundEngine.playIntelPickup();
        if (!this.collectedIntelIds.includes(item.id)) {
          this.collectedIntelIds.push(item.id);
          try {
            localStorage.setItem(INTEL_KEY, JSON.stringify(this.collectedIntelIds));
          } catch {
            // ignore
          }
        }
        this.awardXp(120);
        this.score += 300;
        this.comboBanner = `${item.title.toUpperCase()} TOPLANDI! (${this.collectedIntelIds.length}/${INTEL_SPECS.length})`;
        this.comboBannerTimer = 2.6;
        if (this.collectedIntelIds.length >= INTEL_SPECS.length) {
          this.unlockMedal('intel_hunter');
        }
        this.emitHud();
      }
      return;
    }

    if (prompt.kind === 'breach') {
      const door = this.arena.breachDoors.find((d) => d.id === prompt.refId);
      if (door && !door.breached) {
        door.breached = true;
        const idx = this.arena.colliders.indexOf(door.box);
        if (idx >= 0) this.arena.colliders.splice(idx, 1);
        soundEngine.playBreachSlowMo();
        this.breachSlowMoTimer = 1.9;
        this.trauma = Math.min(1, this.trauma + 0.45);
        _v1.set(door.x, 1.3, door.z);
        this.spawnParticleBurst(_v1, 20, 0xfbbf24, 6.5);
        this.comboBanner = 'QAPI PARTLADILDI · SLOW-MO AKTİV!';
        this.comboBannerTimer = 1.8;
        for (const e of this.enemies) {
          if (e.state !== 'dying' && Math.hypot(e.x - door.x, e.z - door.z) <= 10) {
            e.stunTimer = Math.max(e.stunTimer, 2.2);
          }
        }
        this.emitHud();
      }
      return;
    }

    if (prompt.kind === 'turret') {
      this.mountedTurret = !this.mountedTurret;
      soundEngine.playPickup();
      if (this.mountedTurret) {
        this.playerX = this.arena.jeepPos.x;
        this.playerZ = this.arena.jeepPos.z;
        this.playerY = 2.95;
        this.comboBanner = 'HUMVEE AĞIR PULEMYOTU AKTİV!';
      } else {
        this.playerX = this.arena.jeepPos.x + 2.5;
        this.playerZ = this.arena.jeepPos.z + 1.8;
        this.playerY = 1.7;
        this.comboBanner = 'PULEMYOTDAN ENDİNİZ';
      }
      this.comboBannerTimer = 1.6;
      this.emitHud();
    }
  }

  private unlockMedal(medalId: MedalId): void {
    if (this.unlockedMedalIds.includes(medalId)) return;
    this.unlockedMedalIds.push(medalId);
    const spec = MEDAL_SPECS[medalId];
    this.medalBanner = { title: spec.title, description: spec.description };
    this.medalBannerTimer = 3.2;
    this.awardXp(spec.xpReward);
    soundEngine.playMedalUnlock();
    try {
      localStorage.setItem(MEDALS_KEY, JSON.stringify(this.unlockedMedalIds));
    } catch {
      // ignore
    }
  }

  public getCloudSyncPayload() {
    return {
      careerStats: this.careerStats,
      unlockedChapter: this.unlockedChapter,
      unlockedMedalIds: [...this.unlockedMedalIds],
      collectedIntelIds: [...this.collectedIntelIds],
      equippedCamos: { ...this.equippedCamos },
      equippedAttachments: { ...this.equippedAttachments },
      selectedPerk: this.selectedPerk,
      selectedDifficulty: this.selectedDifficulty,
    };
  }

  public applyCloudSave(data: {
    careerStats?: CareerStats;
    unlockedChapter?: number;
    unlockedMedalIds?: MedalId[];
    collectedIntelIds?: string[];
  }): void {
    if (data.careerStats) {
      this.careerStats = {
        totalKills: Math.max(this.careerStats.totalKills, data.careerStats.totalKills || 0),
        totalHeadshots: Math.max(this.careerStats.totalHeadshots, data.careerStats.totalHeadshots || 0),
        bestScore: Math.max(this.careerStats.bestScore, data.careerStats.bestScore || 0),
        totalExplosiveKills: Math.max(
          this.careerStats.totalExplosiveKills,
          data.careerStats.totalExplosiveKills || 0,
        ),
        xp: Math.max(this.careerStats.xp, data.careerStats.xp || 0),
        completedChallengeIds: Array.from(
          new Set([
            ...this.careerStats.completedChallengeIds,
            ...(data.careerStats.completedChallengeIds || []),
          ]),
        ),
      };
      this.bestScore = Math.max(this.bestScore, this.careerStats.bestScore);
      this.saveCareerStats();
    }
    if (data.unlockedChapter && data.unlockedChapter > this.unlockedChapter) {
      this.unlockStoryChapter(data.unlockedChapter);
    }
    if (Array.isArray(data.unlockedMedalIds)) {
      this.unlockedMedalIds = Array.from(
        new Set([...this.unlockedMedalIds, ...data.unlockedMedalIds]),
      );
      try {
        localStorage.setItem(MEDALS_KEY, JSON.stringify(this.unlockedMedalIds));
      } catch {
        // ignore
      }
    }
    if (Array.isArray(data.collectedIntelIds)) {
      this.collectedIntelIds = Array.from(
        new Set([...this.collectedIntelIds, ...data.collectedIntelIds]),
      );
      try {
        localStorage.setItem(INTEL_KEY, JSON.stringify(this.collectedIntelIds));
      } catch {
        // ignore
      }
    }
    this.emitHud();
  }

  private clearHeldInputs(): void {
    this.keys.clear();
    this.mouseFireHeld = false;
    this.touchFireHeld = false;
    this.keyFireHeld = false;
    this.touchMoveX = 0;
    this.touchMoveY = 0;
    this.isMouseDragging = false;
  }

  private clearObjectiveProp(): void {
    if (this.objectiveProp) {
      this.scene.remove(this.objectiveProp.root);
      this.objectiveProp = null;
    }
    this.objectiveKind = null;
    this.objectiveLabel = '';
    this.objectiveHp = 0;
    this.objectiveHoldProgress = 0;
    this.objectiveCompleted = false;
  }

  private clearDynamicEntities(): void {
    this.clearObjectiveProp();
    for (const e of this.enemies) {
      this.scene.remove(e.rig.root);
    }
    this.enemies = [];
    for (const a of this.allies) {
      this.scene.remove(a.rig.root);
    }
    this.allies = [];
    for (const s of this.sentries) {
      this.scene.remove(s.rig.root);
    }
    this.sentries = [];
    for (const cp of this.carePackages) {
      this.scene.remove(cp.root);
    }
    this.carePackages = [];
    for (const c of this.c4Charges) {
      this.scene.remove(c.root);
    }
    this.c4Charges = [];
    for (const cl of this.claymores) {
      this.scene.remove(cl.root);
    }
    this.claymores = [];
    for (const lm of this.landmines) {
      this.scene.remove(lm.root);
    }
    this.landmines = [];
    for (const ms of this.mortarStrikes) {
      this.scene.remove(ms.root);
    }
    this.mortarStrikes = [];
    for (const r of this.rpgRockets) {
      this.scene.remove(r.mesh);
    }
    this.rpgRockets = [];
    for (const intel of this.intelPickups) {
      this.scene.remove(intel.root);
    }
    this.intelPickups = [];
    for (const p of this.pickups) {
      this.scene.remove(p.mesh);
    }
    this.pickups = [];
    for (const g of this.activeGrenades) {
      this.scene.remove(g.mesh);
    }
    this.activeGrenades = [];
    for (const b of this.bombSites) {
      this.scene.remove(b.rig.root);
    }
    this.bombSites = [];
    for (const rt of this.rangeTargets) {
      this.scene.remove(rt.rig.root);
    }
    this.rangeTargets = [];
    for (const h of this.hostages) {
      this.scene.remove(h.rig.root);
    }
    this.hostages = [];
  }

  private spawnAlliedSquad(): void {
    if (this.allies.length > 0) return;
    const specs = [
      { name: 'Çavuş Rəşad', x: -3.2, z: 20.5 },
      { name: 'Leytenant Tural', x: 3.2, z: 20.5 },
    ];
    for (const sp of specs) {
      const rig = createAlliedSoldier(this.textures, this.isSoftwareGl);
      rig.root.position.set(sp.x, 0, sp.z);
      this.scene.add(rig.root);
      this.allies.push({
        name: sp.name,
        rig,
        x: sp.x,
        z: sp.z,
        yaw: 0,
        hp: 100,
        maxHp: 100,
        fireCooldown: 0.6,
        gaitPhase: 0,
        downed: false,
        bleedoutTimer: 0,
        downedCooldown: 14,
      });
    }
  }

  private spawnStageHostages(count: number): void {
    for (const h of this.hostages) {
      this.scene.remove(h.rig.root);
    }
    this.hostages = [];
    const positions: [number, number, string][] = [
      [-11.5, -7.5, 'Müəllim Elçin'],
      [11.5, -7.5, 'Həkim Aynur'],
      [0, -14.5, 'Kəşfiyyatçı Orxan'],
      [-14.5, 4.5, 'Mühəndis Rauf'],
    ];
    for (let i = 0; i < Math.min(count, positions.length); i++) {
      const [hx, hz, name] = positions[i];
      const resolved = resolveAllCollisions(hx, hz, 0.7, this.arena.colliders);
      const rig = createHostageModel(this.textures, this.isSoftwareGl);
      rig.root.position.set(resolved.x, 0, resolved.z);
      rig.root.rotation.y = Math.atan2(-resolved.x, 12 - resolved.z);
      this.scene.add(rig.root);
      this.hostages.push({
        id: i + 1,
        name,
        rig,
        x: resolved.x,
        z: resolved.z,
        rescued: false,
        alive: true,
      });
    }
  }

  private triggerStealthAlarm(): void {
    if (!this.stealthActive || this.stealthDetected) return;
    this.stealthDetected = true;
    this.stealthSuspicionPct = 100;
    soundEngine.playStealthAlarm();
    for (const e of this.enemies) {
      e.alerted = true;
    }
    this.waveToSpawn += 2;
    this.comboBanner = 'HƏYƏCAN SİQNALI! DÜŞMƏNLƏR SİZİ GÖRDÜ';
    this.comboBannerTimer = 2.6;
    this.triggerRadioComms(
      'Kapitan Şahin',
      'QARTAL-COMMS',
      'Örtük açıldı! Həyəcan siqnalı çalınır — dəstək düşmən qüvvələri sektoru mühasirəyə alır!',
      'enemy',
    );
    this.emitHud();
  }

  private spawnLandminesAndIntel(waveNum: number): void {
    for (const lm of this.landmines) this.scene.remove(lm.root);
    this.landmines = [];
    for (const ip of this.intelPickups) this.scene.remove(ip.root);
    this.intelPickups = [];

    // 4 Enemy Proximity Landmines along main lanes
    const mineCoords: [number, number][] = [
      [-6.5, 4.5],
      [6.5, -2.5],
      [-10.5, -10.5],
      [9.5, 11.5],
    ];
    for (const [mx, mz] of mineCoords) {
      const { root, ledMesh } = createLandmine();
      root.position.set(mx, 0, mz);
      this.scene.add(root);
      this.landmines.push({ root, ledMesh, x: mx, z: mz, exploded: false });
    }

    // Spawn uncollected Intel Laptop for this chapter
    if (this.gameMode === 'campaign') {
      const specs = INTEL_SPECS.filter(
        (i) => i.chapter === waveNum && !this.collectedIntelIds.includes(i.id),
      );
      for (const spec of specs) {
        const { root } = createIntelLaptop();
        root.position.set(spec.x, 0, spec.z);
        this.scene.add(root);
        this.intelPickups.push({
          id: spec.id,
          chapter: spec.chapter,
          title: spec.title,
          summary: spec.summary,
          root,
          x: spec.x,
          z: spec.z,
          collected: false,
        });
      }
    }
  }

  private triggerRadioComms(
    speaker: string,
    callsign: string,
    text: string,
    tone: 'ally' | 'command' | 'enemy',
    duration = 4.4,
  ): void {
    const betrayedRemoved = this.gameMode === 'campaign' && this.wave >= 7 && speaker === 'Overwatch';
    this.radioMessage = {
      speaker: betrayedRemoved ? 'Kapitan Şahin' : speaker,
      callsign: betrayedRemoved ? 'QARTAL-COMMS' : callsign,
      text,
      tone,
    };
    this.radioTimer = duration;
    soundEngine.playRadioComms();
  }

  private setupStageObjective(waveNum: number, stage: ChapterStageSpec): void {
    this.clearObjectiveProp();
    this.blackoutActive = Boolean(stage.blackout);
    this.arena.setChapterAtmosphere(waveNum, this.blackoutActive, this.gameMode);
    this.stageDamaged = false;
    this.currentSetPieceKind = this.gameMode === 'campaign' ? (stage.setPieceKind ?? null) : null;
    this.currentBossName = stage.bossName ?? 'Komandir Xəncər';
    this.bossQte = null;
    this.bossQteTriggeredThisStage = false;
    this.stealthActive = this.gameMode === 'campaign' && stage.setPieceKind === 'stealth_infil';
    this.stealthSuspicionPct = 0;
    this.stealthDetected = false;
    this.escapeTimerSec =
      this.gameMode === 'campaign' && stage.setPieceKind === 'escape_timer'
        ? (stage.escapeTimeSec ?? 60)
        : null;
    this.escapeTickAccum = 0;

    for (const h of this.hostages) {
      this.scene.remove(h.rig.root);
    }
    this.hostages = [];

    this.spawnLandminesAndIntel(waveNum);
    this.objectiveKind = this.gameMode === 'survival' ? 'hold' : stage.objectiveKind;
    this.objectiveLabel = this.gameMode === 'survival' ? 'SAĞQALMA MÖVQEYİ' : stage.objectiveLabel;
    this.objectiveX = stage.objectiveX;
    this.objectiveZ = stage.objectiveZ;
    this.bossSpawnedInWave = false;
    this.midWaveRadioSent = false;
    this.objectiveCompleted = this.gameMode === 'survival' || waveNum > MAX_STORY_WAVES;
    this.objectiveHoldProgress = 0;

    if (this.gameMode === 'campaign') {
      if (stage.setPieceKind === 'hostage_rescue') {
        this.spawnStageHostages(stage.hostageCount ?? 3);
      }
      if (stage.objectiveKind === 'uplink') {
        this.objectiveProp = createMissionObjectiveProp('uplink');
        this.objectiveProp.root.position.set(this.objectiveX, 0, this.objectiveZ);
        this.scene.add(this.objectiveProp.root);
      } else if (stage.objectiveKind === 'jammer') {
        this.objectiveHp = 160 + waveNum * 15;
        this.objectiveMaxHp = this.objectiveHp;
        this.objectiveProp = createMissionObjectiveProp('jammer');
        this.objectiveProp.root.position.set(this.objectiveX, 0, this.objectiveZ);
        this.scene.add(this.objectiveProp.root);
      } else if (stage.objectiveKind === 'hold') {
        this.objectiveProp = createMissionObjectiveProp('hold');
        this.objectiveProp.root.position.set(this.objectiveX, 0, this.objectiveZ);
        this.scene.add(this.objectiveProp.root);
      }
    }

    if (this.blackoutActive) {
      this.triggerRadioComms(
        'Kapitan Şahin',
        'QARTAL-COMMS',
        'DİQQƏT! EMP partlayışı elektrik şəbəkəsini söndürdü — [N] NVG və ya [T] Termalı açın!',
        'enemy',
      );
    } else {
      this.triggerRadioComms(
        stage.radioSpeaker,
        stage.radioCallsign,
        stage.radioText,
        stage.radioTone,
      );
    }
  }

  private beginWave(waveNum: number, startStageIdx = 0): void {
    this.wave = waveNum;
    if (this.gameMode === 'firing_range') {
      this.chapterStages = [
        {
          stage: 1,
          totalStages: 1,
          title: 'Təlim Poliqonu',
          objectiveKind: 'hold',
          objectiveLabel: 'HƏDƏF MEYDANI',
          objectiveX: 0,
          objectiveZ: -12,
          enemyCount: 0,
          maxConcurrent: 0,
          spawnInterval: 1,
          radioSpeaker: 'Kapitan Şahin',
          radioCallsign: 'QARTAL-COMMS',
          radioText: 'Təlim Poliqonuna xoş gəldiniz! [1-9] ilə 9 silahı sınayın və hədəfləri vurun!',
          radioTone: 'command',
        },
      ];
    } else if (this.gameMode === 'spec_ops') {
      this.chapterStages = [
        {
          stage: 1,
          totalStages: 1,
          title: 'Spec Ops · A & B Bombaları',
          objectiveKind: 'hold',
          objectiveLabel: 'BOMBA A / B',
          objectiveX: -17,
          objectiveZ: -13,
          enemyCount: 999,
          maxConcurrent: 6,
          spawnInterval: 2.6,
          radioSpeaker: 'Kapitan Şahin',
          radioCallsign: 'QARTAL-COMMS',
          radioText: 'A və B bombaları qurulub! Yaxınlaşıb [E] basılı tutaraq zərərsizləşdirin!',
          radioTone: 'command',
        },
      ];
    } else if (this.gameMode === 'survival') {
      const cfg = getWaveConfig(waveNum, 'survival');
      this.chapterStages = [
        {
          stage: 1,
          totalStages: 1,
          title: `Zombi Dalğası ${waveNum}`,
          objectiveKind: 'hold',
          objectiveLabel: 'SAĞQALMA',
          objectiveX: 0,
          objectiveZ: 0,
          enemyCount: cfg.totalEnemies,
          maxConcurrent: cfg.maxConcurrent,
          spawnInterval: cfg.spawnInterval,
          radioSpeaker: 'Kapitan Şahin',
          radioCallsign: 'QARTAL-COMMS',
          radioText: `Dalğa ${waveNum} gəlir! [B] ilə Mağazadan Avto-Turet və AC-130 alın!`,
          radioTone: 'command',
        },
      ];
    } else {
      this.chapterStages = getChapterStageSpecs(waveNum, this.campaignPace);
    }
    this.beginStage(startStageIdx);
  }

  private beginStage(stageIdx: number): void {
    const safeIdx = Math.max(0, Math.min(this.chapterStages.length - 1, stageIdx));
    this.chapterStageIdx = safeIdx;
    const stage = this.chapterStages[safeIdx];
    this.waveToSpawn = stage.enemyCount;
    this.waveSpawnTimer = 0.6;
    this.betweenWaveTimer = 0;
    this.stageClearAwarded = false;

    if (this.gameMode === 'firing_range') {
      this.clearObjectiveProp();
      this.blackoutActive = false;
      this.arena.setChapterAtmosphere(1, false, 'firing_range');
      this.waveToSpawn = 0;
      for (const rt of this.rangeTargets) {
        this.scene.remove(rt.rig.root);
      }
      this.rangeTargets = [];
      for (const spec of getFiringRangeTargets()) {
        const rig = createFiringRangeTarget(spec.isArmored);
        rig.root.position.set(spec.x, 0, spec.z);
        rig.headCollider.userData = { part: 'head', rangeTargetId: spec.id };
        rig.bodyCollider.userData = { part: 'body', rangeTargetId: spec.id };
        this.scene.add(rig.root);
        this.rangeTargets.push({
          id: spec.id,
          baseX: spec.x,
          x: spec.x,
          z: spec.z,
          isArmored: spec.isArmored,
          isMoving: spec.isMoving,
          moveAmplitudeX: spec.moveAmplitudeX,
          moveSpeed: spec.moveSpeed,
          knockedTimer: 0,
          flipBlend: 0,
          rig,
        });
      }
      this.waveBanner = 'TƏLİM POLİQONU · 9 SİLAH SINAĞI';
      this.waveBannerTimer = 2.6;
      this.triggerRadioComms(stage.radioSpeaker, stage.radioCallsign, stage.radioText, stage.radioTone);
      return;
    }

    if (this.gameMode === 'spec_ops') {
      this.clearObjectiveProp();
      this.blackoutActive = false;
      this.arena.setChapterAtmosphere(5, false, 'spec_ops');
      this.stageDamaged = false;
      this.spawnLandminesAndIntel(5);
      this.objectiveCompleted = false;
      for (const b of this.bombSites) {
        this.scene.remove(b.rig.root);
      }
      this.bombSites = [];
      for (const s of getSpecOpsBombSites()) {
        const rig = createBombDevice();
        rig.root.position.set(s.x, 0, s.z);
        this.scene.add(rig.root);
        this.bombSites.push({
          site: s.site,
          label: s.label,
          x: s.x,
          z: s.z,
          rig,
          defused: false,
          progress: 0,
        });
      }
      this.bombTimer = 120;
      this.bombTickAccum = 0;
      this.waveBanner = 'SPEC OPS · A & B BOMBALARINI ZƏRƏRSİZLƏŞDİR!';
      this.waveBannerTimer = 3.0;
      this.triggerRadioComms(stage.radioSpeaker, stage.radioCallsign, stage.radioText, stage.radioTone);
      for (let i = 0; i < 2; i++) {
        this.spawnWaveEnemy();
      }
      return;
    }

    const briefing = getWaveBriefing(this.wave, this.campaignPace);
    this.waveBanner =
      this.gameMode === 'survival'
        ? `SAĞQALMA · DALĞA ${this.wave}`
        : this.wave <= MAX_STORY_WAVES
          ? stage.totalStages > 1
            ? `FƏSİL ${String(this.wave).padStart(2, '0')} · ${stage.title.toUpperCase()}`
            : briefing.title.toUpperCase()
          : `DALĞA ${this.wave}`;
    this.waveBannerTimer = 2.6;

    this.setupStageObjective(this.wave, stage);

    const immediate = Math.min(2, this.waveToSpawn);
    for (let i = 0; i < immediate; i++) {
      this.spawnWaveEnemy();
    }
  }

  private spawnBossEnemy(): void {
    if (this.bossSpawnedInWave) return;
    this.bossSpawnedInWave = true;
    const arch: EnemyArchetype = 'boss';
    const spec = ENEMY_SPECS[arch];
    const diff = DIFFICULTY_SPECS[this.selectedDifficulty];
    const resolved = resolveAllCollisions(0, -26, ENEMY_RADIUS, this.arena.colliders);
    const rig = createEnemySoldier(arch, this.textures, this.isSoftwareGl);
    rig.root.position.set(resolved.x, 0, resolved.z);
    this.scene.add(rig.root);

    const scaledHp = Math.round(spec.hp * diff.enemyHpScale);
    this.enemies.push({
      id: this.enemyIdSeq++,
      archetype: arch,
      rig,
      x: resolved.x,
      z: resolved.z,
      yaw: Math.atan2(this.playerX - resolved.x, this.playerZ - resolved.z),
      hp: scaledHp,
      maxHp: scaledHp,
      speed: spec.speed,
      damage: Math.round(spec.damage * diff.enemyDamageScale),
      state: 'moving',
      telegraphTimer: 0,
      fireCooldown: 0.9,
      hitFlashTimer: 0,
      stunTimer: 0,
      dyingTimer: 0,
      strafeDir: 1,
      strafeTimer: 1.8,
      gaitPhase: 0,
      grenadeThrowCooldown: 6.5,
      alerted: true,
    });

    const bossUpper = this.currentBossName.toUpperCase();
    this.comboBanner = `HƏDƏF GÖRÜNDÜ: ${bossUpper}`;
    this.comboBannerTimer = 2.6;
    this.triggerRadioComms(
      'Kapitan Şahin',
      'QARTAL-COMMS',
      `${this.currentBossName} şimaldan meydana girdi! Bütün atəşi üzərinə cəmlə!`,
      'command',
    );
  }

  private spawnWaveEnemy(): void {
    if (this.waveToSpawn <= 0) return;
    const cfg = getWaveConfig(this.wave, this.gameMode);
    const diff = DIFFICULTY_SPECS[this.selectedDifficulty];
    const arch = pickArchetypeForWave(this.wave, Math.random(), this.gameMode);
    const spec = ENEMY_SPECS[arch];

    let chosen = this.arena.spawnPoints[0];
    let bestDist = -1;
    const startIdx = Math.floor(Math.random() * this.arena.spawnPoints.length);
    for (let k = 0; k < this.arena.spawnPoints.length; k++) {
      const pt =
        this.arena.spawnPoints[(startIdx + k) % this.arena.spawnPoints.length];
      const d = Math.hypot(pt.x - this.playerX, pt.z - this.playerZ);
      if (d > 16) {
        chosen = pt;
        break;
      }
      if (d > bestDist) {
        bestDist = d;
        chosen = pt;
      }
    }

    const jitterX = (Math.random() - 0.5) * 2.4;
    const jitterZ = (Math.random() - 0.5) * 2.4;
    const resolved = resolveAllCollisions(
      chosen.x + jitterX,
      chosen.z + jitterZ,
      ENEMY_RADIUS,
      this.arena.colliders,
    );

    const rig = createEnemySoldier(arch, this.textures, this.isSoftwareGl);
    rig.root.position.set(resolved.x, 0, resolved.z);
    this.scene.add(rig.root);

    const scaledHp = Math.round(spec.hp * diff.enemyHpScale);
    this.enemies.push({
      id: this.enemyIdSeq++,
      archetype: arch,
      rig,
      x: resolved.x,
      z: resolved.z,
      yaw: Math.atan2(this.playerX - resolved.x, this.playerZ - resolved.z),
      hp: scaledHp,
      maxHp: scaledHp,
      speed: spec.speed * cfg.speedScale,
      damage: Math.round(spec.damage * cfg.damageScale * diff.enemyDamageScale),
      state: 'moving',
      telegraphTimer: 0,
      fireCooldown: 0.7 + Math.random() * 0.6,
      hitFlashTimer: 0,
      stunTimer: 0,
      dyingTimer: 0,
      strafeDir: Math.random() < 0.5 ? -1 : 1,
      strafeTimer: 1.5 + Math.random() * 1.5,
      gaitPhase: Math.random() * Math.PI * 2,
      grenadeThrowCooldown: 7 + Math.random() * 6,
      alerted: !this.stealthActive || this.stealthDetected,
    });
    this.waveToSpawn -= 1;
  }

  private bindEvents(): void {
    const canvas = this.renderer.domElement;

    const onResize = () => {
      if (this.disposed) return;
      const w = Math.max(1, this.container.clientWidth || window.innerWidth);
      const h = Math.max(1, this.container.clientHeight || window.innerHeight);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setPixelRatio(
        computeTargetPixelRatio(
          w,
          h,
          window.devicePixelRatio || 1,
          this.isSoftwareGl,
          this.graphicsQuality,
        ),
      );
      this.renderer.setSize(w, h);
    };

    const onKeyDown = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (this.phase !== 'playing') return;

      if (this.activeStoryChoice) {
        if (e.code === 'Digit1') {
          this.submitStoryChoice(0);
        } else if (e.code === 'Digit2') {
          this.submitStoryChoice(1);
        }
        return;
      }

      if (e.code === 'KeyB' && this.gameMode === 'survival') {
        this.setBuyStationOpen(!this.buyStationOpen);
        return;
      }
      if (this.buyStationOpen) {
        if (e.code === 'Escape') {
          this.setBuyStationOpen(false);
        }
        return;
      }

      if (e.code === 'Space') {
        this.jumpBufferTimer = 0.12;
      } else if (e.code === 'KeyR') {
        this.triggerReload();
      } else if (e.code === 'KeyG') {
        this.throwGrenade();
      } else if (e.code === 'KeyX') {
        this.throwFlashbang();
      } else if (e.code === 'KeyZ') {
        this.triggerC4();
      } else if (e.code === 'KeyK') {
        this.placeClaymore();
      } else if (e.code === 'KeyC') {
        if (this.isSprinting) {
          this.triggerSlide();
        } else {
          this.toggleCrouch();
        }
      } else if (e.code === 'ControlLeft') {
        e.preventDefault();
        this.toggleCrouch();
      } else if (e.code === 'KeyH') {
        if (this.isLastStand) {
          this.selfRevive();
        } else {
          this.useStimShot();
        }
      } else if (e.code === 'KeyO') {
        this.activateFieldUpgrade();
      } else if (e.code === 'KeyJ' && this.gameMode !== 'campaign') {
        this.callCarePackage(false);
      } else if (e.code === 'KeyI') {
        this.triggerWeaponInspect();
      } else if (e.code === 'KeyV' && this.gameMode !== 'campaign') {
        this.useArmorPlate();
      } else if (e.code === 'KeyU' && this.gameMode !== 'campaign') {
        this.triggerUavSweep();
      } else if (e.code === 'KeyY' && this.gameMode !== 'campaign') {
        this.triggerGunship();
      } else if (e.code === 'KeyE') {
        this.triggerInteract();
      } else if (e.code === 'KeyN') {
        this.toggleNvg();
      } else if (e.code === 'KeyT') {
        this.toggleThermal();
      } else if (e.code === 'KeyQ') {
        this.cycleLean();
      } else if (e.code === 'Digit1') {
        this.switchWeapon(this.loadoutWeapons[0]);
      } else if (e.code === 'Digit2') {
        this.switchWeapon(this.loadoutWeapons[1]);
      } else if (e.code === 'Digit3') {
        this.switchWeapon('scarh');
      } else if (e.code === 'Digit4') {
        this.switchWeapon('spas12');
      } else if (e.code === 'Digit5') {
        this.switchWeapon('msr');
      } else if (e.code === 'Digit6') {
        this.switchWeapon('m249');
      } else if (e.code === 'Digit7') {
        this.switchWeapon('deagle');
      } else if (e.code === 'Digit8') {
        this.switchWeapon('rpg7');
      } else if (e.code === 'Digit9') {
        this.switchWeapon('knife');
      } else if (e.code === 'KeyF') {
        this.triggerMeleeStrike();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };

    const onBlur = () => {
      this.clearHeldInputs();
    };

    const onVisibility = () => {
      if (document.hidden) {
        this.clearHeldInputs();
      }
    };

    const onPointerLockChange = () => {
      this.pointerLocked = document.pointerLockElement === canvas;
      this.emitHud();
    };

    const onMouseDown = (e: MouseEvent) => {
      if (this.phase !== 'playing') return;
      soundEngine.unlock();
      if (e.button === 0) {
        if (!this.pointerLocked) {
          this.isMouseDragging = true;
          this.lastPointerX = e.clientX;
          this.lastPointerY = e.clientY;
        }
        this.mouseFireHeld = true;
      } else if (e.button === 2) {
        this.adsDesired = true;
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        this.mouseFireHeld = false;
        this.isMouseDragging = false;
      } else if (e.button === 2) {
        this.adsDesired = false;
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (this.phase !== 'playing') return;
      if (this.pointerLocked) {
        this.addLookDelta(e.movementX, e.movementY);
      } else if (this.isMouseDragging) {
        const dx = e.clientX - this.lastPointerX;
        const dy = e.clientY - this.lastPointerY;
        this.lastPointerX = e.clientX;
        this.lastPointerY = e.clientY;
        this.addLookDelta(dx, dy);
      }
    };

    const onContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const onDblClick = () => {
      if (this.phase === 'playing' && !this.pointerLocked) {
        this.requestPointerLock();
      }
    };

    const onContextLost = (e: Event) => {
      e.preventDefault();
    };

    window.addEventListener('resize', onResize);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    document.addEventListener('visibilitychange', onVisibility);
    document.addEventListener('pointerlockchange', onPointerLockChange);
    canvas.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('contextmenu', onContextMenu);
    canvas.addEventListener('dblclick', onDblClick);
    canvas.addEventListener('webglcontextlost', onContextLost);

    this.unbindEvents = () => {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('visibilitychange', onVisibility);
      document.removeEventListener('pointerlockchange', onPointerLockChange);
      canvas.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('contextmenu', onContextMenu);
      canvas.removeEventListener('dblclick', onDblClick);
      canvas.removeEventListener('webglcontextlost', onContextLost);
    };
  }

  private unbindEvents: () => void = () => {};

  private scheduleNextFrame(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = requestAnimationFrame(() => this.tick());
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || !gl.fenceSync) {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick(): void {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.phase === 'title') {
      this.updateTitleFlyover(dt);
    } else if (this.phase === 'briefing') {
      this.updateBriefingView(dt);
    } else if (this.phase === 'cutscene') {
      this.updateCutscene(dt);
    } else if (this.phase === 'playing') {
      this.updatePlaying(dt);
    }

    this.updateParticles(dt);
    this.updateTracers(dt);

    this.renderer.render(this.scene, this.camera);

    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.08) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    this.scheduleNextFrame();
  }

  private updateTitleFlyover(dt: number): void {
    this.elapsedTime += dt;
    const t = this.elapsedTime * 0.16;
    const radius = 25;
    this.camera.position.set(
      Math.sin(t) * radius,
      9.2 + Math.sin(t * 2) * 1.1,
      Math.cos(t) * radius,
    );
    this.camera.lookAt(0, 1.8, -2);
    if (Math.abs(this.camera.fov - 64) > 0.1) {
      this.camera.fov = 64;
      this.camera.updateProjectionMatrix();
    }

    // Animate world radar dish, circling Recon UAV drone + propeller, and desert dust motes
    this.arena.radarDish.rotation.y += dt * 1.1;
    const uavT = this.elapsedTime * 0.28;
    this.arena.uavDrone.position.set(
      Math.cos(uavT) * 26,
      24 + Math.sin(uavT * 2) * 0.8,
      Math.sin(uavT) * 26,
    );
    this.arena.uavDrone.rotation.y = -uavT;
    this.arena.uavDrone.rotation.z = 0.18;
    const prop = this.arena.uavDrone.userData.propeller as THREE.Object3D | undefined;
    if (prop) prop.rotation.z += dt * 28;
    this.arena.dustPoints.rotation.y += dt * 0.018;

    // Animate patrolling soldiers on the live compound floor
    for (const p of this.titlePatrollers) {
      p.gaitPhase += dt * 4.5;
      const orbitA = this.elapsedTime * 0.35 + p.id * -1.3;
      const nx = p.x + Math.cos(orbitA) * 0.02;
      const nz = p.z + Math.sin(orbitA) * 0.02;
      p.rig.root.position.set(nx, 0, nz);
      p.rig.root.rotation.y = -orbitA;
      p.rig.leftLeg.rotation.x = Math.sin(p.gaitPhase) * 0.45;
      p.rig.rightLeg.rotation.x = -Math.sin(p.gaitPhase) * 0.45;
      p.rig.leftArm.rotation.x = -Math.sin(p.gaitPhase) * 0.25;
    }
  }

  private updateBriefingView(dt: number): void {
    this.elapsedTime += dt;
    this.camera.position.set(this.playerX, this.playerY, this.playerZ);
    this.camera.rotation.set(
      this.pitch + Math.sin(this.elapsedTime * 0.55) * 0.012,
      this.yaw + Math.cos(this.elapsedTime * 0.4) * 0.025,
      0,
      'YXZ',
    );
    if (Math.abs(this.camera.fov - 74) > 0.1) {
      this.camera.fov = 74;
      this.camera.updateProjectionMatrix();
    }
    this.arena.radarDish.rotation.y += dt * 1.1;
    const uavT = this.elapsedTime * 0.28;
    this.arena.uavDrone.position.set(
      Math.cos(uavT) * 26,
      24 + Math.sin(uavT * 2) * 0.8,
      Math.sin(uavT) * 26,
    );
    this.arena.uavDrone.rotation.y = -uavT;
    this.arena.uavDrone.rotation.z = 0.18;
    const prop = this.arena.uavDrone.userData.propeller as THREE.Object3D | undefined;
    if (prop) prop.rotation.z += dt * 28;
    this.arena.dustPoints.rotation.y += dt * 0.018;
  }

  private updateCutscene(dt: number): void {
    const spec = this.activeCutscene;
    if (!spec || spec.beats.length === 0) {
      this.skipCutscene();
      return;
    }

    const beat = spec.beats[this.cutsceneBeatIdx];
    this.cutsceneBeatTimer += dt;
    const t = Math.max(0, Math.min(1, this.cutsceneBeatTimer / Math.max(0.2, beat.duration)));
    const smoothT = t * t * (3 - 2 * t);

    this.camera.position.set(
      THREE.MathUtils.lerp(beat.camFrom[0], beat.camTo[0], smoothT),
      THREE.MathUtils.lerp(beat.camFrom[1], beat.camTo[1], smoothT),
      THREE.MathUtils.lerp(beat.camFrom[2], beat.camTo[2], smoothT),
    );
    this.camera.lookAt(beat.lookAt[0], beat.lookAt[1], beat.lookAt[2]);
    if (Math.abs(this.camera.fov - 56) > 0.1) {
      this.camera.fov = 56;
      this.camera.updateProjectionMatrix();
    }

    this.arena.radarDish.rotation.y += dt * 1.1;
    const uavT = this.elapsedTime * 0.28;
    this.arena.uavDrone.position.set(
      Math.cos(uavT) * 26,
      24 + Math.sin(uavT * 2) * 0.8,
      Math.sin(uavT) * 26,
    );
    const prop = this.arena.uavDrone.userData.propeller as THREE.Object3D | undefined;
    if (prop) prop.rotation.z += dt * 28;
    this.arena.dustPoints.rotation.y += dt * 0.018;

    const showHeli = Boolean(beat.showHeli);
    this.arena.helicopter.root.visible = showHeli;
    if (showHeli) {
      this.arena.helicopter.root.position.set(
        Math.sin(this.elapsedTime * 0.6) * 2.5,
        10.5 + Math.cos(this.elapsedTime * 1.8) * 0.45,
        -4 + Math.cos(this.elapsedTime * 0.4) * 2,
      );
      this.arena.helicopter.root.rotation.y = Math.sin(this.elapsedTime * 0.3) * 0.25;
      this.arena.helicopter.mainRotor.rotation.y += dt * 22;
      this.arena.helicopter.tailRotor.rotation.x += dt * 26;
    }

    if (this.cutsceneBeatTimer >= beat.duration) {
      this.cutsceneBeatIdx += 1;
      this.cutsceneBeatTimer = 0;
      if (this.cutsceneBeatIdx >= spec.beats.length) {
        this.skipCutscene();
      } else {
        soundEngine.playRadioComms();
        if (spec.beats[this.cutsceneBeatIdx]?.showHeli) {
          soundEngine.playHelicopterPass();
        }
        this.emitHud();
      }
    }
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.graphicsQuality = quality;
    const w = Math.max(1, this.container.clientWidth || window.innerWidth);
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    if (this.arena.sunLight.castShadow) {
      const shadowSize = quality === 'ultra' && Math.min(w, h) >= 768 ? 2048 : 1024;
      this.arena.sunLight.shadow.mapSize.set(shadowSize, shadowSize);
      this.arena.sunLight.shadow.map?.dispose();
      this.arena.sunLight.shadow.map = null;
    }
    this.saveSettings();
    this.renderer.setPixelRatio(
      computeTargetPixelRatio(
        w,
        h,
        window.devicePixelRatio || 1,
        this.isSoftwareGl,
        this.graphicsQuality,
      ),
    );
    this.renderer.setSize(w, h);
  }

  private updatePlaying(dt: number): void {
    if (this.buyStationOpen) {
      return;
    }

    if (this.activeStoryChoice !== null) {
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock?.();
      }
      this.updateCameraVisuals(dt, 0);
      return;
    }

    this.outOfCombatTimer += dt;
    if (this.gameMode === 'campaign' && !this.isLastStand && this.outOfCombatTimer >= 4.5) {
      this.armor = Math.min(this.maxArmor, this.armor + dt * 14);
      this.hp = Math.min(this.maxHp, this.hp + dt * 8);
    }

    if (this.bossQte) {
      this.bossQte.timeLeftSec -= dt;
      if (this.bossQte.timeLeftSec <= 0) {
        const qteBoss = this.enemies.find((e) => e.id === this.bossQte?.bossId && e.state !== 'dying');
        this.bossQte = null;
        if (qteBoss) {
          qteBoss.hp = Math.min(qteBoss.maxHp, qteBoss.hp + Math.round(qteBoss.maxHp * 0.12));
          this.applyDamageToPlayer(18, qteBoss.x, qteBoss.z);
        } else {
          this.applyDamageToPlayer(14, this.playerX, this.playerZ - 4);
        }
        this.comboBanner = 'MÜQAVİMƏT QIRILDI! YENİDƏN MÖVQE TUTUN!';
        this.comboBannerTimer = 2.0;
      }
    }

    // Hitstop pauses simulation physics briefly while visual juice continues
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      this.updateCameraVisuals(dt, 0);
      return;
    }

    if (this.breachSlowMoTimer > 0) {
      this.breachSlowMoTimer = Math.max(0, this.breachSlowMoTimer - dt);
    }
    if (this.finalKillSlowMoTimer > 0) {
      this.finalKillSlowMoTimer = Math.max(0, this.finalKillSlowMoTimer - dt);
    }
    if (this.stimBoostTimer > 0) {
      this.stimBoostTimer = Math.max(0, this.stimBoostTimer - dt);
    }
    if (this.fieldUpgradeCooldown > 0) {
      this.fieldUpgradeCooldown = Math.max(0, this.fieldUpgradeCooldown - dt);
    }
    if (this.fieldUpgradeActiveTimer > 0) {
      this.fieldUpgradeActiveTimer = Math.max(0, this.fieldUpgradeActiveTimer - dt);
    }
    if (this.isLastStand) {
      this.isCrouching = true;
      this.isSprinting = false;
      this.lastStandTimer -= dt;
      this.lastStandPulseAccum += dt;
      if (this.lastStandPulseAccum >= 0.9) {
        this.lastStandPulseAccum = 0;
        soundEngine.playLastStandPulse();
      }
      if (this.lastStandTimer <= 0) {
        this.finishGame('defeat');
        return;
      }
    }
    if (this.inspectTimer > 0) {
      this.inspectTimer = Math.max(0, this.inspectTimer - dt);
      if (this.adsDesired || this.reloading) {
        this.inspectTimer = 0;
      }
    }
    const slowMoScale =
      this.finalKillSlowMoTimer > 0 ? 0.28 : this.breachSlowMoTimer > 0 ? 0.34 : 1.0;
    const simDt = dt * slowMoScale;

    this.elapsedTime += dt;
    this.arena.radarDish.rotation.y += simDt * 1.1;
    const uavT = this.elapsedTime * 0.28;
    this.arena.uavDrone.position.set(
      Math.cos(uavT) * 26,
      24 + Math.sin(uavT * 2) * 0.8,
      Math.sin(uavT) * 26,
    );
    this.arena.uavDrone.rotation.y = -uavT;
    this.arena.uavDrone.rotation.z = 0.18;
    const prop = this.arena.uavDrone.userData.propeller as THREE.Object3D | undefined;
    if (prop) prop.rotation.z += simDt * 28;
    this.arena.dustPoints.rotation.y += simDt * 0.018;

    // Animate breached doors swinging open
    for (const door of this.arena.breachDoors) {
      if (door.breached && door.openProgress < 1) {
        door.openProgress = Math.min(1, door.openProgress + dt * 3.8);
        door.doorPanel.rotation.y = -door.openProgress * (Math.PI * 0.62);
      }
    }

    if (this.waveBannerTimer > 0) {
      this.waveBannerTimer -= dt;
      if (this.waveBannerTimer <= 0) this.waveBanner = null;
    }
    if (this.medalBannerTimer > 0) {
      this.medalBannerTimer -= dt;
      if (this.medalBannerTimer <= 0) this.medalBanner = null;
    }
    if (this.radioTimer > 0) {
      this.radioTimer -= dt;
      if (this.radioTimer <= 0) this.radioMessage = null;
    }
    if (this.comboWindowTimer > 0) {
      this.comboWindowTimer = Math.max(0, this.comboWindowTimer - dt);
      if (this.comboWindowTimer <= 0) this.comboCount = 0;
    }
    if (this.comboBannerTimer > 0) {
      this.comboBannerTimer -= dt;
      if (this.comboBannerTimer <= 0) this.comboBanner = null;
    }
    if (this.hitmarkerTimer > 0) {
      this.hitmarkerTimer -= dt;
      if (this.hitmarkerTimer <= 0) this.hitmarkerKind = 'none';
    }
    if (this.damageFlash > 0) {
      this.damageFlash = Math.max(0, this.damageFlash - dt * 2.2);
    }
    if (this.slideCooldown > 0) {
      this.slideCooldown = Math.max(0, this.slideCooldown - dt);
    }
    if (this.uavActiveTimer > 0) {
      this.uavActiveTimer = Math.max(0, this.uavActiveTimer - dt);
    }
    if (this.checkpointBannerTimer > 0) {
      this.checkpointBannerTimer -= dt;
      if (this.checkpointBannerTimer <= 0) this.checkpointBanner = null;
    }

    // Pending UAV Drone Strike impacts
    for (let i = this.pendingStrikes.length - 1; i >= 0; i--) {
      const s = this.pendingStrikes[i];
      s.timer -= simDt;
      if (s.timer <= 0) {
        _v1.set(s.x, 0.5, s.z);
        this.triggerExplosion(_v1, 7.5, 190);
        this.pendingStrikes.splice(i, 1);
      }
    }

    // AC-130 Gunship Bombardment Mode
    if (this.gunshipActive) {
      this.gunshipTimer -= dt;
      this.gunshipCooldown = Math.max(0, this.gunshipCooldown - dt);
      let aimX = this.touchMoveX;
      let aimZ = -this.touchMoveY;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) aimX += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) aimX -= 1;
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) aimZ -= 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) aimZ += 1;
      this.gunshipAimX = Math.max(-34, Math.min(34, this.gunshipAimX + aimX * 22 * dt));
      this.gunshipAimZ = Math.max(-34, Math.min(34, this.gunshipAimZ + aimZ * 22 * dt));

      this.camera.position.set(this.gunshipAimX, 29, this.gunshipAimZ + 11);
      this.camera.lookAt(this.gunshipAimX, 0.5, this.gunshipAimZ);
      if (Math.abs(this.camera.fov - 52) > 0.1) {
        this.camera.fov = 52;
        this.camera.updateProjectionMatrix();
      }
      this.weaponMount.visible = false;

      if ((this.mouseFireHeld || this.touchFireHeld) && this.gunshipCooldown <= 0 && this.gunshipShells > 0) {
        this.gunshipShells -= 1;
        this.gunshipCooldown = 0.55;
        soundEngine.playAc130Cannon();
        _v1.set(this.gunshipAimX, 26, this.gunshipAimZ + 6);
        _v2.set(this.gunshipAimX, 0.4, this.gunshipAimZ);
        this.spawnTracer(_v1, _v2);
        this.triggerExplosion(_v2, 8.2, 220);
      }

      if (this.gunshipTimer <= 0 || this.gunshipShells <= 0) {
        this.gunshipActive = false;
        this.weaponMount.visible = true;
      }
    } else {
      // 1. Player Movement & Physics (or Humvee Mounted Turret)
      let moveRight = this.touchMoveX;
      let moveFwd = this.touchMoveY;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) moveRight += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) moveRight -= 1;
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) moveFwd += 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) moveFwd -= 1;

      const inputLen = Math.hypot(moveRight, moveFwd);
      if (inputLen > 1) {
        moveRight /= inputLen;
        moveFwd /= inputLen;
      }

      let actualMoveDist = 0;

      if (this.mountedTurret) {
        this.playerX = this.arena.jeepPos.x;
        this.playerZ = this.arena.jeepPos.z;
        this.playerY = 2.95;
        this.isSprinting = false;
      } else {
        const perkSpeedMult = this.selectedPerk === 'lightweight' ? 1.16 : 1.0;
        const stimSpeedMult = this.stimBoostTimer > 0 ? 1.24 : 1.0;
        const deadSilenceActive =
          this.fieldUpgrade === 'dead_silence' && this.fieldUpgradeActiveTimer > 0;
        const deadSilenceMult = deadSilenceActive ? 1.28 : 1.0;
        const lastStandMult = this.isLastStand ? 0.45 : 1.0;
        const stanceMods = computeStanceModifiers(this.isCrouching, this.slideTimer > 0);
        let vx = 0;
        let vz = 0;

        if (this.slideTimer > 0 && !this.isLastStand) {
          this.slideTimer = Math.max(0, this.slideTimer - dt);
          this.isSprinting = false;
          const slideSpeed =
            12.8 *
            perkSpeedMult *
            stimSpeedMult *
            deadSilenceMult *
            (0.45 + 0.55 * (this.slideTimer / 0.45));
          vx = this.slideDirX * slideSpeed;
          vz = this.slideDirZ * slideSpeed;
        } else {
          const sprinting =
            !this.isLastStand &&
            (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.touchMoveY > 0.85) &&
            !this.adsDesired &&
            !this.isCrouching &&
            moveFwd > 0.2;
          this.isSprinting = sprinting;
          const baseSpeed =
            (this.adsDesired ? 4.2 : sprinting ? 9.6 : 6.7) *
            perkSpeedMult *
            stimSpeedMult *
            deadSilenceMult *
            lastStandMult *
            stanceMods.speedMult;

          _vForward.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
          _vRight.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

          vx = (_vRight.x * moveRight + _vForward.x * moveFwd) * baseSpeed;
          vz = (_vRight.z * moveRight + _vForward.z * moveFwd) * baseSpeed;
        }

        const resolved = resolveAllCollisions(
          this.playerX + vx * dt,
          this.playerZ + vz * dt,
          PLAYER_RADIUS,
          this.arena.colliders,
        );
        actualMoveDist = Math.hypot(resolved.x - this.playerX, resolved.z - this.playerZ);
        this.playerX = resolved.x;
        this.playerZ = resolved.z;

        if (
          this.isGrounded &&
          this.slideTimer <= 0 &&
          !this.isCrouching &&
          !deadSilenceActive &&
          actualMoveDist > 0.002
        ) {
          this.walkDistance += actualMoveDist;
          this.footstepAccum += actualMoveDist;
          if (this.footstepAccum >= (this.isSprinting ? 1.8 : 2.15)) {
            this.footstepAccum = 0;
            soundEngine.playFootstep();
          }
        }

        // Jump & Gravity
        if (this.isGrounded) {
          this.coyoteTimer = 0.1;
        } else {
          this.coyoteTimer = Math.max(0, this.coyoteTimer - dt);
        }
        if (this.jumpBufferTimer > 0) {
          this.jumpBufferTimer -= dt;
          if (this.coyoteTimer > 0) {
            this.playerVelY = 6.6;
            this.isGrounded = false;
            this.coyoteTimer = 0;
            this.jumpBufferTimer = 0;
          }
        }
        if (!this.isGrounded) {
          this.playerVelY -= 18.5 * dt;
          this.playerY += this.playerVelY * dt;
          if (this.playerY <= 1.7) {
            this.playerY = 1.7;
            this.playerVelY = 0;
            this.isGrounded = true;
          }
        }
      }

      // 2. Reload & Weapon / Humvee Turret Firing
      if (this.reloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          this.reloading = false;
          const spec = this.getActiveWeaponSpec(this.activeWeapon);
          this.weaponStates[this.activeWeapon] = applyReload(
            this.weaponStates[this.activeWeapon],
            spec,
          );
        }
      }

      if (this.fireTimer > 0) this.fireTimer -= dt;
      if (this.turretFireTimer > 0) this.turretFireTimer -= dt;
      if (this.muzzleFlashTimer > 0) {
        this.muzzleFlashTimer -= dt;
        if (this.muzzleFlashTimer <= 0) {
          const activeVm = this.viewmodels[this.activeWeapon];
          activeVm.muzzleFlash.visible = false;
          activeVm.boltMesh.position.z = -0.02;
          this.muzzlePointLight.intensity = 0;
        }
      }

      this.updateCameraVisuals(dt, actualMoveDist / Math.max(dt, 0.001));

      const manualFire = this.mouseFireHeld || this.touchFireHeld || this.keyFireHeld;
      if (this.mountedTurret) {
        if ((manualFire || (this.autoFire && this.checkAutoFireSight())) && this.turretFireTimer <= 0) {
          this.fireHumveeTurret();
        }
      } else {
        const autoTargetLocked =
          this.autoFire &&
          this.gameMode !== 'firing_range' &&
          !this.reloading &&
          this.checkAutoFireSight();
        if ((manualFire || autoTargetLocked) && !this.reloading && this.fireTimer <= 0) {
          this.firePlayerWeapon();
        }
      }
    }

    // 3. Mode-Specific Loop: Firing Range / Spec Ops Bomb A&B / Story & Survival Stages
    if (this.gameMode === 'firing_range') {
      for (const w of WEAPON_LIST) {
        const ws = this.getActiveWeaponSpec(w);
        if (!ws.isMelee && this.weaponStates[w].reserve < ws.magSize) {
          this.weaponStates[w].reserve = ws.maxReserve;
        }
      }
      for (const rt of this.rangeTargets) {
        if (rt.isMoving && rt.knockedTimer <= 0) {
          rt.x = rt.baseX + Math.sin(this.elapsedTime * rt.moveSpeed) * rt.moveAmplitudeX;
          rt.rig.root.position.x = rt.x;
        }
        if (rt.knockedTimer > 0) {
          rt.knockedTimer = Math.max(0, rt.knockedTimer - dt);
        }
        const flipGoal = rt.knockedTimer > 0 ? 1 : 0;
        rt.flipBlend = THREE.MathUtils.damp(rt.flipBlend, flipGoal, 14, dt);
        rt.rig.pivotGroup.rotation.x = -rt.flipBlend * (Math.PI * 0.48);
      }
      this.updateRpgRockets(simDt);
      this.updateGrenades(simDt);
      return;
    }

    if (this.gameMode === 'spec_ops') {
      this.bombTimer = Math.max(0, this.bombTimer - dt);
      this.bombTickAccum += dt;
      const tickInterval = this.bombTimer < 25 ? 0.5 : 1.0;
      if (this.bombTickAccum >= tickInterval) {
        this.bombTickAccum = 0;
        soundEngine.playBombTick(this.bombTimer < 25);
      }
      if (this.bombTimer <= 0) {
        soundEngine.playExplosion();
        this.finishGame('defeat');
        return;
      }

      let nearestBomb: ActiveBombSite | null = null;
      let nearestDist = 3.2;
      for (const b of this.bombSites) {
        if (b.defused) continue;
        const d = Math.hypot(b.x - this.playerX, b.z - this.playerZ);
        if (d <= nearestDist) {
          nearestDist = d;
          nearestBomb = b;
        }
      }

      const holdingDefuse =
        (this.keys.has('KeyE') || this.touchDefuseHeld) && !this.isLastStand;

      for (const b of this.bombSites) {
        if (b.defused) continue;
        const ledBlink = Math.sin(this.elapsedTime * (this.bombTimer < 25 ? 14 : 6)) > 0;
        b.rig.ledMat.color.setHex(ledBlink ? 0xef4444 : 0x7f1d1d);
        const activeTarget = b === nearestBomb;
        b.progress = computeBombDefusalProgress(b.progress, dt, activeTarget && holdingDefuse);
        if (b.progress >= 100) {
          b.defused = true;
          b.rig.ledMat.color.setHex(0x22c55e);
          (b.rig.ringMesh.material as THREE.MeshBasicMaterial).color.setHex(0x22c55e);
          soundEngine.playBombDefused();
          this.score += 500;
          this.awardXp(180);
          this.comboBanner = `${b.site} BOMBASI ZƏRƏRSİZLƏŞDİRİLDİ! +500`;
          this.comboBannerTimer = 2.4;
        }
      }

      if (this.bombSites.length > 0 && this.bombSites.every((b) => b.defused)) {
        this.unlockMedal('veteran_hero');
        this.awardXp(300);
        this.finishGame('victory');
        return;
      }

      if (this.waveToSpawn < 12) {
        this.waveToSpawn += 12;
      }
      const aliveCount = this.enemies.filter((e) => e.state !== 'dying').length;
      this.waveSpawnTimer -= simDt;
      if (this.waveSpawnTimer <= 0 && aliveCount < 6) {
        this.spawnWaveEnemy();
        this.waveSpawnTimer = 2.4;
      }
    } else {
      if (this.escapeTimerSec !== null) {
        this.escapeTimerSec = Math.max(0, this.escapeTimerSec - simDt);
        this.escapeTickAccum += dt;
        const sirenInt = this.escapeTimerSec < 15 ? 0.5 : 1.0;
        if (this.escapeTickAccum >= sirenInt) {
          this.escapeTickAccum = 0;
          soundEngine.playEscapeSirenTick(this.escapeTimerSec < 15);
          if (this.escapeTimerSec < 15) {
            this.trauma = Math.min(1, this.trauma + 0.08);
          }
        }
        if (this.escapeTimerSec <= 0) {
          soundEngine.playExplosion();
          this.finishGame('defeat');
          return;
        }
      }

      for (const h of this.hostages) {
        if (h.alive && !h.rescued) {
          h.rig.ringMesh.rotation.z += dt * 2.4;
        }
      }

      this.updateChapterObjective(simDt);

      const activeStage = this.chapterStages[this.chapterStageIdx];
      const stageEnemyTotal =
        activeStage?.enemyCount ?? getWaveConfig(this.wave, this.gameMode).totalEnemies;
      const stageMaxConc =
        activeStage?.maxConcurrent ?? getWaveConfig(this.wave, this.gameMode).maxConcurrent;
      const stageSpawnInt =
        activeStage?.spawnInterval ?? getWaveConfig(this.wave, this.gameMode).spawnInterval;
      const stageHasBoss =
        this.gameMode === 'campaign' && (activeStage?.spawnBoss ?? this.wave === 5);

      if (this.waveToSpawn > 0) {
        const aliveCount = this.enemies.filter((e) => e.state !== 'dying').length;
        if (stageHasBoss && !this.bossSpawnedInWave && this.waveToSpawn <= stageEnemyTotal - 2) {
          this.spawnBossEnemy();
        }
        this.waveSpawnTimer -= simDt;
        if (this.waveSpawnTimer <= 0 && aliveCount < stageMaxConc) {
          this.spawnWaveEnemy();
          this.waveSpawnTimer = stageSpawnInt;
        }
      } else if (stageHasBoss && !this.bossSpawnedInWave) {
        this.spawnBossEnemy();
      } else if (this.enemies.length === 0 && this.objectiveCompleted) {
        if (this.gameMode === 'survival') {
          this.betweenWaveTimer += dt;
          if (!this.stageClearAwarded) {
            this.stageClearAwarded = true;
            this.credits += 150;
            this.awardXp(180);
            this.waveBanner = `DALĞA ${this.wave} TƏMİZLƏNDİ · +$150`;
            this.waveBannerTimer = 2.2;
            this.hp = Math.min(this.maxHp, this.hp + 25);
            this.stims = Math.min(this.maxStims, this.stims + 1);
            this.armorPlates = Math.min(this.maxArmorPlates, this.armorPlates + 1);
            soundEngine.playPickup();
          }
          if (this.betweenWaveTimer >= 2.2) {
            this.beginWave(this.wave + 1, 0);
          }
        } else {
          if (!this.stageDamaged) {
            this.unlockMedal('ghost_stage');
          }

          const hasNextStage = this.chapterStageIdx + 1 < this.chapterStages.length;
          if (
            this.gameMode === 'campaign' &&
            activeStage?.storyChoiceTrigger &&
            !this.triggeredChoiceIdsThisRun.has(activeStage.storyChoiceTrigger)
          ) {
            this.escapeTimerSec = null;
            this.activeStoryChoice = STORY_CHOICES[activeStage.storyChoiceTrigger];
            this.pendingEndingResolution =
              !hasNextStage && !this.endlessMode && this.wave >= MAX_STORY_WAVES;
            this.clearHeldInputs();
            if (document.pointerLockElement === this.renderer.domElement) {
              document.exitPointerLock?.();
            }
            soundEngine.playRadioComms();
            this.emitHud();
            return;
          }

          if (hasNextStage) {
            this.betweenWaveTimer += dt;
            if (!this.stageClearAwarded) {
              this.stageClearAwarded = true;
              const nextStageNum = this.chapterStageIdx + 2;
              this.awardXp(90);
              this.checkpointStage = nextStageNum;
              this.checkpointScore = this.score;
              this.checkpointKills = this.kills;
              this.checkpointHeadshots = this.headshots;
              this.checkpointBanner = `YOXLAMA NÖQTƏSİ SAXLANDI (${nextStageNum}/${this.chapterStages.length})`;
              this.checkpointBannerTimer = 2.6;
              this.hp = Math.min(this.maxHp, this.hp + 35);
              this.stims = Math.min(this.maxStims, this.stims + 1);
              this.armor = Math.min(this.maxArmor, this.armor + 25);
              this.grenades = Math.min(4, this.grenades + 1);
              this.flashbangs = Math.min(3, this.flashbangs + 1);
              for (const w of WEAPON_LIST) {
                const spec = this.getActiveWeaponSpec(w);
                this.weaponStates[w] = addAmmoPickup(
                  this.weaponStates[w],
                  spec,
                  Math.max(spec.magSize, Math.round(spec.maxReserve * 0.4)),
                );
              }
              soundEngine.playPickup();
            }
            if (this.betweenWaveTimer >= 1.8) {
              this.escapeTimerSec = null;
              const nextIdx = this.chapterStageIdx + 1;
              const isFinalStage = nextIdx === this.chapterStages.length - 1;
              if (isFinalStage && this.wave <= MAX_STORY_WAVES) {
                const climaxScene = getChapterCutscene(this.wave, 'climax');
                this.startCutscene(climaxScene, () => {
                  this.phase = 'playing';
                  this.weaponMount.visible = true;
                  this.camera.position.set(this.playerX, this.playerY, this.playerZ);
                  this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
                  this.camera.fov = this.fov;
                  this.camera.updateProjectionMatrix();
                  this.beginStage(nextIdx);
                  document.body.dataset.state = 'playing';
                  this.emitHud();
                });
              } else {
                this.beginStage(nextIdx);
              }
            }
          } else {
            this.escapeTimerSec = null;
            if (!this.endlessMode && this.wave >= MAX_STORY_WAVES) {
              const ending = resolveStoryEnding(
                this.storyDecisions,
                this.squadTrust,
                this.hostagesLostThisRun,
              );
              this.activeEnding = ending;
              if (!this.unlockedEndingIds.includes(ending.id)) {
                this.unlockedEndingIds.push(ending.id);
              }
              this.saveStoryProgress();
              this.unlockMedal('veteran_hero');
              this.awardXp(300);
              this.finishGame('victory');
              return;
            }
            this.betweenWaveTimer += dt;
            if (!this.stageClearAwarded) {
              this.stageClearAwarded = true;
              this.awardXp(200);
              this.waveBanner = `FƏSİL ${String(this.wave).padStart(2, '0')} TAMAMLANDI`;
              this.waveBannerTimer = 2.0;
              this.hp = Math.min(this.maxHp, this.hp + 20);
              this.stims = Math.min(this.maxStims, this.stims + 1);
              this.grenades = Math.min(4, this.grenades + 1);
              this.flashbangs = Math.min(3, this.flashbangs + 1);
              _v1.set(0, 0.35, 0);
              this.spawnParticleBurst(_v1, 20, 0x10b981, 5.5);
            }
            if (this.betweenWaveTimer >= 2.0) {
              this.prepareWaveBriefing(this.wave + 1);
            }
          }
        }
      }
    }

    // 4. Enemies, Allies, Sentries, Care Packages, Rockets, Mines, Mortar Rings, Grenades & Pickups
    this.updateEnemies(simDt);
    this.updateAlliedSquad(simDt);
    this.updateSentries(simDt);
    this.updateCarePackages(simDt);
    this.updateRpgRockets(simDt);
    this.updateMinesAndMortars(simDt);
    this.updateGrenades(simDt);
    this.updatePickups(simDt);
  }

  private updateChapterObjective(dt: number): void {
    if (this.objectiveProp) {
      this.objectiveProp.spinnerMesh.rotation.y += dt * 2.6;
      const pulse = 1 + Math.sin(this.elapsedTime * 4) * 0.06;
      this.objectiveProp.ringMesh.scale.set(pulse, pulse, 1);
    }

    const aliveEnemies = this.enemies.filter((e) => e.state !== 'dying').length;
    const combatCleared = this.waveToSpawn === 0 && aliveEnemies === 0;

    if (this.objectiveKind === 'uplink' && !this.objectiveCompleted) {
      if (combatCleared && !this.midWaveRadioSent) {
        this.midWaveRadioSent = true;
        this.triggerRadioComms(
          'Kapitan Şahin',
          'QARTAL-COMMS',
          'Bölgə təmizdir! İndi yaşıl Rabitə Terminalının yanına get!',
          'command',
        );
      }
      const dist = Math.hypot(this.playerX - this.objectiveX, this.playerZ - this.objectiveZ);
      if (dist <= 3.4) {
        this.objectiveHoldProgress = Math.min(100, this.objectiveHoldProgress + dt * 45);
        if (this.objectiveHoldProgress >= 100) {
          this.objectiveCompleted = true;
          this.score += 250;
          this.clearObjectiveProp();
          soundEngine.playPickup();
          this.comboBanner = 'RABİTƏ TERMİNALI BƏRPA OLUNDU +250';
          this.comboBannerTimer = 2.0;
          this.triggerRadioComms(
            'Overwatch',
            'PEYK DƏSTƏYİ',
            'Siqnal bərpa olundu! Növbəti sektora keçid açılır.',
            'ally',
          );
        }
      }
    } else if (this.objectiveKind === 'hold' && !this.objectiveCompleted) {
      if (combatCleared && !this.midWaveRadioSent) {
        this.midWaveRadioSent = true;
        this.triggerRadioComms(
          'Overwatch',
          'PEYK DƏSTƏYİ',
          'Hücum dəf edildi! Helipad mərkəzindəki qızılı siqnal zonasını tamamla!',
          'ally',
        );
      }
      const dist = Math.hypot(this.playerX - this.objectiveX, this.playerZ - this.objectiveZ);
      const pendingHostages = this.hostages.some((h) => h.alive && !h.rescued);
      if (dist <= 4.0) {
        const rate = combatCleared ? 48 : 22;
        this.objectiveHoldProgress = Math.min(100, this.objectiveHoldProgress + dt * rate);
        if (this.objectiveHoldProgress >= 100 && !pendingHostages) {
          this.objectiveCompleted = true;
          this.score += 300;
          this.clearObjectiveProp();
          soundEngine.playPickup();
          this.comboBanner = 'MƏNTƏQƏ TƏHLÜKƏSİZLƏŞDİRİLDİ +300';
          this.comboBannerTimer = 2.0;
        }
      }
      if (this.objectiveHoldProgress >= 100 && !pendingHostages && !this.objectiveCompleted) {
        this.objectiveCompleted = true;
        this.score += 300;
        this.clearObjectiveProp();
        soundEngine.playPickup();
      }
    } else if (this.objectiveKind === 'jammer' && !this.objectiveCompleted) {
      if (combatCleared && !this.midWaveRadioSent) {
        this.midWaveRadioSent = true;
        this.triggerRadioComms(
          'Overwatch',
          'PEYK DƏSTƏYİ',
          'Bütün əsgərlər məhv edildi — indi qırmızı Qarışdırıcı qutusunu atəşlə dağıt!',
          'ally',
        );
      }
    } else if (this.objectiveKind === 'boss' && !this.objectiveCompleted) {
      const boss = this.enemies.find((e) => e.archetype === 'boss' && e.state !== 'dying');
      if (boss) {
        this.objectiveX = boss.x;
        this.objectiveZ = boss.z;
      } else if (this.bossSpawnedInWave) {
        this.objectiveCompleted = true;
      }
    }
  }

  private damageObjective(dmg: number, hitPoint?: THREE.Vector3): void {
    if (this.objectiveKind !== 'jammer' || this.objectiveCompleted) return;
    this.objectiveHp = Math.max(0, this.objectiveHp - dmg);
    this.hitmarkerKind = 'hit';
    this.hitmarkerTimer = 0.14;
    soundEngine.playHitmarker(false, false);
    if (hitPoint) {
      this.spawnParticleBurst(hitPoint, 6, 0xf97316, 4.2);
    }
    if (this.objectiveHp <= 0) {
      this.objectiveCompleted = true;
      this.score += 300;
      const blastPos = new THREE.Vector3(this.objectiveX, 0.9, this.objectiveZ);
      this.clearObjectiveProp();
      this.triggerExplosion(blastPos, 5.2, 120);
      this.comboBanner = 'QARIŞDIRICI MƏHV EDİLDİ +300';
      this.comboBannerTimer = 2.2;
      this.triggerRadioComms(
        'Overwatch',
        'PEYK DƏSTƏYİ',
        'Qarışdırıcı sıradan çıxarıldı! Minimap və peyk bağlantısı tam təmizdir.',
        'ally',
      );
    }
  }

  private updateCameraVisuals(dt: number, moveSpeed: number): void {
    const spec = this.getActiveWeaponSpec(this.activeWeapon);
    this.adsBlend = THREE.MathUtils.damp(this.adsBlend, this.adsDesired ? 1 : 0, 14, dt);
    const leanTarget = this.lean === 'left' ? -1 : this.lean === 'right' ? 1 : 0;
    this.leanBlend = THREE.MathUtils.damp(this.leanBlend, leanTarget, 11, dt);
    this.swayX = THREE.MathUtils.damp(this.swayX, 0, 10, dt);
    this.swayY = THREE.MathUtils.damp(this.swayY, 0, 10, dt);

    const slidePhase = this.slideTimer > 0 ? Math.sin((this.slideTimer / 0.45) * Math.PI) : 0;
    const sprintTarget =
      this.isSprinting && !this.adsDesired && !this.reloading && this.fireTimer <= 0 && this.slideTimer <= 0
        ? 1
        : 0;
    this.sprintBlend = THREE.MathUtils.damp(this.sprintBlend, sprintTarget, 11, dt);

    const baseFov = this.fov + slidePhase * 8 + this.sprintBlend * 3.5;
    const targetFov = THREE.MathUtils.lerp(baseFov, spec.adsFov, this.adsBlend);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = targetFov;
      this.camera.updateProjectionMatrix();
    }

    this.recoilPitch = THREE.MathUtils.damp(this.recoilPitch, 0, 12, dt);
    this.recoilYaw = THREE.MathUtils.damp(this.recoilYaw, 0, 12, dt);
    this.trauma = Math.max(0, this.trauma - dt * 1.9);

    const shakeMag = this.trauma * this.trauma * 0.045;
    const shakeX = (Math.random() - 0.5) * 2 * shakeMag;
    const shakeY = (Math.random() - 0.5) * 2 * shakeMag;

    const stanceMods = computeStanceModifiers(this.isCrouching, this.slideTimer > 0);
    this.crouchOffset = THREE.MathUtils.damp(this.crouchOffset, stanceMods.eyeHeightOffset, 12, dt);
    const bobDip = this.slideTimer > 0 ? 0 : this.crouchOffset;
    const lastStandDip = this.isLastStand ? -0.42 : 0;

    const bobAmp =
      this.isGrounded && this.slideTimer <= 0
        ? Math.min(1, moveSpeed / 6.7) * (1 - this.adsBlend * 0.72) * (this.isCrouching ? 0.55 : 1)
        : 0;
    const bobY = Math.sin(this.walkDistance * 2.3) * 0.045 * bobAmp;
    const bobX = Math.cos(this.walkDistance * 1.15) * 0.03 * bobAmp;
    const slideDip = -slidePhase * 0.68;
    const slideRoll = -slidePhase * 0.085;
    const leanRoll = -this.leanBlend * 0.13;

    _vRight.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const leanDist = this.leanBlend * 0.42;
    const camPos = resolveAllCollisions(
      this.playerX + _vRight.x * leanDist,
      this.playerZ + _vRight.z * leanDist,
      0.28,
      this.arena.colliders,
    );

    const sniperBreath =
      this.activeWeapon === 'msr' && this.adsBlend > 0.35
        ? Math.sin(this.elapsedTime * 1.9) * 0.0028
        : 0;
    const sniperBreathYaw =
      this.activeWeapon === 'msr' && this.adsBlend > 0.35
        ? Math.cos(this.elapsedTime * 1.35) * 0.0022
        : 0;

    this.camera.position.set(
      camPos.x,
      this.playerY + bobY + slideDip + bobDip + lastStandDip,
      camPos.z,
    );
    _euler.set(
      THREE.MathUtils.clamp(this.pitch + this.recoilPitch + shakeY + sniperBreath, -1.4, 1.4),
      this.yaw + this.recoilYaw + shakeX + sniperBreathYaw,
      slideRoll + leanRoll,
      'YXZ',
    );
    this.camera.rotation.set(0, 0, 0);
    this.camera.quaternion.setFromEuler(_euler);

    if (this.cutsceneBlendTimer > 0) {
      this.cutsceneBlendTimer = Math.max(0, this.cutsceneBlendTimer - dt);
      const t = 1 - this.cutsceneBlendTimer / 0.48;
      const smooth = t * t * (3 - 2 * t);
      _v1.copy(this.camera.position);
      this.camera.position.lerpVectors(this.cutsceneExitPos, _v1, smooth);
      _quat.copy(this.camera.quaternion);
      this.camera.quaternion.copy(this.cutsceneExitQuat).slerp(_quat, smooth);
    }

    const hipX = 0.21 + bobX * 0.55 - this.sprintBlend * 0.05;
    const hipY = -0.19 + bobY * 0.45 - this.sprintBlend * 0.025;
    const hipZ = -0.39 + this.sprintBlend * 0.03;
    const adsX = 0;
    const adsY = -0.101;
    const adsZ = -0.28;

    const reloadDip = this.reloading ? Math.sin((this.reloadTimer / spec.reloadDuration) * Math.PI) * 0.12 : 0;
    const inspectWave = this.inspectTimer > 0 ? Math.sin(((2.2 - this.inspectTimer) / 2.2) * Math.PI) : 0;
    const recoilBack = this.recoilPitch * 1.5;
    const swayScale = 1 - this.adsBlend * 0.72;

    this.weaponMount.visible =
      this.phase === 'playing' &&
      !(this.activeWeapon === 'msr' && (this.adsDesired || this.adsBlend > 0.35));

    this.weaponMount.position.set(
      THREE.MathUtils.lerp(hipX, adsX, this.adsBlend) - inspectWave * 0.09 + this.swayX * swayScale,
      THREE.MathUtils.lerp(hipY, adsY, this.adsBlend) - reloadDip + inspectWave * 0.04 + this.swayY * swayScale,
      THREE.MathUtils.lerp(hipZ, adsZ, this.adsBlend) + recoilBack + inspectWave * 0.05,
    );
    this.weaponMount.rotation.set(
      this.recoilPitch * 1.8 - reloadDip * 2.8 + this.sprintBlend * 0.14 - slidePhase * 0.12 + inspectWave * 0.22 + this.swayY * 1.2 * swayScale,
      this.sprintBlend * 0.42 + inspectWave * 0.85 - this.swayX * 1.4 * swayScale,
      reloadDip * 1.6 + this.sprintBlend * 0.2 + slidePhase * 0.28 - inspectWave * 0.38 - this.leanBlend * 0.16,
    );
  }

  private checkAutoFireSight(): boolean {
    if (this.enemies.length === 0) return false;
    const st = this.weaponStates[this.activeWeapon];
    if (st.mag <= 0) return false;

    const spec = this.getActiveWeaponSpec(this.activeWeapon);
    if (spec.isMelee || spec.isExplosive) return false;
    this.raycaster.layers.set(1);
    this.raycaster.far = spec.range;
    this.raycaster.setFromCamera(_ndcCenter, this.camera);

    const targets: THREE.Object3D[] = [];
    for (const e of this.enemies) {
      if (e.state !== 'dying') {
        targets.push(e.rig.headCollider, e.rig.torsoCollider);
      }
    }
    if (targets.length === 0) return false;

    const enemyHits = this.raycaster.intersectObjects(targets, false);
    if (enemyHits.length === 0) return false;

    const hitDist = enemyHits[0].distance;
    this.raycaster.layers.set(0);
    const wallHits = this.raycaster.intersectObjects(this.arena.obstacleRayTargets, true);
    if (wallHits.length > 0 && wallHits[0].distance < hitDist) {
      return false;
    }
    return true;
  }

  private fireHumveeTurret(): void {
    this.turretFireTimer = 0.095;
    this.shotsFired += 1;
    soundEngine.playGunshot('m249', false);
    this.recoilPitch += 0.008;
    this.trauma = Math.min(1, this.trauma + 0.08);
    this.fireRaycastShot({ damage: 34, headshotMult: 1.8, range: 115 }, 0.009, 1);
  }

  private firePlayerWeapon(): void {
    const spec = this.getActiveWeaponSpec(this.activeWeapon);
    if (spec.isMelee) {
      this.triggerMeleeStrike();
      return;
    }

    const st = this.weaponStates[this.activeWeapon];
    if (st.mag <= 0) {
      this.triggerReload();
      return;
    }

    this.inspectTimer = 0;
    st.mag -= 1;
    this.shotsFired += 1;
    this.fireTimer = 1 / spec.fireRate;
    const isSuppressed = this.equippedAttachments[this.activeWeapon]?.includes('suppressor') ?? false;
    soundEngine.playGunshot(this.activeWeapon, isSuppressed);
    if (this.stealthActive && !this.stealthDetected && !spec.isMelee && !isSuppressed) {
      this.triggerStealthAlarm();
    }

    const vm = this.viewmodels[this.activeWeapon];
    vm.muzzleFlash.visible = true;
    vm.muzzleFlash.scale.setScalar(isSuppressed ? 0.38 : 1.0);
    vm.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    vm.boltMesh.position.z = 0.038;
    if (!this.isSoftwareGl) {
      this.muzzlePointLight.intensity = isSuppressed ? 1.5 : 4.2;
    }
    this.muzzleFlashTimer = 0.048;

    const adsMult = 1 - this.adsBlend * 0.45;
    this.recoilPitch += spec.recoilPitch * adsMult;
    this.recoilYaw += (Math.random() - 0.5) * 2 * spec.recoilYaw * adsMult;
    this.trauma = Math.min(1, this.trauma + (spec.id === 'msr' || spec.id === 'spas12' || spec.id === 'rpg7' ? 0.24 : 0.12));

    if (spec.isExplosive) {
      const rocket = createRpgRocket();
      this.camera.getWorldDirection(_vDir);
      const startPos = new THREE.Vector3(this.playerX, this.playerY - 0.08, this.playerZ).addScaledVector(_vDir, 0.9);
      rocket.position.copy(startPos);
      rocket.lookAt(startPos.clone().add(_vDir));
      this.scene.add(rocket);
      this.rpgRockets.push({
        mesh: rocket,
        pos: startPos,
        vel: _vDir.clone().multiplyScalar(42),
        age: 0,
      });
      if (st.mag === 0 && st.reserve > 0) {
        this.triggerReload();
      }
      return;
    }

    const stanceSpread = computeStanceModifiers(this.isCrouching, this.slideTimer > 0).spreadMult;
    const spread = THREE.MathUtils.lerp(spec.hipSpread, spec.adsSpread, this.adsBlend) * stanceSpread;
    this.fireRaycastShot(spec, spread, spec.pellets ?? 1, vm);

    vm.ejectionPoint.getWorldPosition(_v1);
    _vRight.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    _v2.set(
      _vRight.x * (2.2 + Math.random() * 1.2),
      1.8 + Math.random() * 0.9,
      _vRight.z * (2.2 + Math.random() * 1.2),
    );
    this.spawnSingleParticle(_v1, _v2, 0xfbbf24, 0.32, 0.48);

    if (st.mag === 0 && st.reserve > 0) {
      this.triggerReload();
    }
  }

  private fireRaycastShot(
    spec: { damage: number; headshotMult: number; range: number },
    spread: number,
    pellets: number,
    vm?: ViewmodelRig,
  ): void {

    const hitTargets: THREE.Object3D[] = [];
    for (const e of this.enemies) {
      if (e.state !== 'dying') {
        hitTargets.push(e.rig.headCollider, e.rig.torsoCollider);
        if (e.rig.shieldCollider && e.stunTimer <= 0) {
          hitTargets.push(e.rig.shieldCollider);
        }
      }
    }
    for (const b of this.arena.barrels) {
      if (!b.exploded) hitTargets.push(b.colliderMesh);
    }
    for (const c of this.arena.destructibleCrates) {
      if (!c.destroyed) hitTargets.push(c.colliderMesh);
    }
    if (this.objectiveKind === 'jammer' && !this.objectiveCompleted && this.objectiveProp) {
      hitTargets.push(this.objectiveProp.hitCollider);
    }
    for (const rt of this.rangeTargets) {
      if (rt.knockedTimer <= 0) {
        hitTargets.push(rt.rig.headCollider, rt.rig.bodyCollider);
      }
    }

    let countedHitThisShot = false;

    for (let pIdx = 0; pIdx < pellets; pIdx++) {
      const aimOffset = new THREE.Vector2(
        (Math.random() - 0.5) * 2 * spread,
        (Math.random() - 0.5) * 2 * spread,
      );

      this.raycaster.layers.set(0);
      this.raycaster.far = spec.range;
      this.raycaster.setFromCamera(aimOffset, this.camera);
      const wallHits = this.raycaster.intersectObjects(this.arena.obstacleRayTargets, true);
      const wallDist = wallHits.length > 0 ? wallHits[0].distance : spec.range;

      this.raycaster.layers.set(1);
      const actorHits = this.raycaster.intersectObjects(hitTargets, false);

      let impactPoint: THREE.Vector3 | null = null;

      if (actorHits.length > 0 && actorHits[0].distance <= wallDist) {
        const hit = actorHits[0];
        impactPoint = hit.point;
        if (!countedHitThisShot) {
          this.shotsHit += 1;
          countedHitThisShot = true;
        }

        if (hit.object.userData.rangeTargetId !== undefined) {
          const rtId = hit.object.userData.rangeTargetId as number;
          const rt = this.rangeTargets.find((r) => r.id === rtId);
          if (rt && rt.knockedTimer <= 0) {
            const isHeadshot = hit.object.userData.part === 'head';
            this.rangeHits += 1;
            if (isHeadshot) this.rangeHeadshots += 1;
            rt.knockedTimer = 1.6;
            this.score = computeFiringRangeScore(this.rangeHits, this.rangeHeadshots);
            if (this.score > this.bestScore) {
              this.bestScore = this.score;
            }
            this.hitmarkerKind = 'kill';
            this.hitmarkerTimer = 0.2;
            soundEngine.playRangeTargetHit(isHeadshot);
            this.spawnParticleBurst(
              hit.point,
              isHeadshot ? 10 : 6,
              isHeadshot ? 0xfef08a : 0x38bdf8,
              4.5,
            );
          }
        } else if (hit.object.userData.objectiveTarget) {
          this.damageObjective(spec.damage, hit.point);
        } else if (hit.object.userData.crateId !== undefined) {
          this.damageCrate(hit.object.userData.crateId as number, spec.damage, hit.point);
        } else if (hit.object.userData.barrelId !== undefined) {
          const barrel = this.arena.barrels[hit.object.userData.barrelId as number];
          if (barrel && !barrel.exploded) {
            barrel.hp -= spec.damage;
            this.spawnParticleBurst(hit.point, 6, 0xfacc15, 4.5);
            if (barrel.hp <= 0) {
              this.detonateBarrel(barrel.id);
            }
          }
        } else if (hit.object.userData.part === 'shield') {
          const shieldEnemy = this.enemies.find((e) => e.rig.shieldCollider === hit.object);
          soundEngine.playShieldRicochet();
          this.spawnParticleBurst(hit.point, 7, 0xbae6fd, 5.2);
          if (shieldEnemy) {
            const chip = Math.max(4, Math.round(spec.damage * 0.14));
            this.damageEnemy(shieldEnemy, chip, false, hit.point, false);
          }
        } else {
          const hitEnemy = this.enemies.find(
            (e) => e.rig.headCollider === hit.object || e.rig.torsoCollider === hit.object,
          );
          if (hitEnemy) {
            const isHeadshot = hit.object.userData.part === 'head';
            const dmg = computeShotDamage(spec as any, hit.distance, isHeadshot);
            this.damageEnemy(hitEnemy, dmg, isHeadshot, hit.point, false);
          }
        }
      } else if (wallHits.length > 0) {
        impactPoint = wallHits[0].point;
        this.spawnParticleBurst(wallHits[0].point, 3, 0xd6c7b0, 3.2);
      }

      if (pIdx < 3) {
        if (vm) {
          vm.muzzlePoint.getWorldPosition(_v1);
        } else {
          _v1.set(this.playerX, this.playerY - 0.15, this.playerZ);
        }
        if (!impactPoint) {
          _v2.copy(this.raycaster.ray.origin).addScaledVector(this.raycaster.ray.direction, 45);
        } else {
          _v2.copy(impactPoint);
        }
        this.spawnTracer(_v1, _v2);
      }
    }
  }

  private damageCrate(crateId: number, dmg: number, hitPoint: THREE.Vector3): void {
    const crate = this.arena.destructibleCrates[crateId];
    if (!crate || crate.destroyed) return;
    crate.hp -= dmg;
    this.spawnParticleBurst(hitPoint, 5, 0xd9b382, 3.6);
    if (crate.hp <= 0) {
      crate.destroyed = true;
      crate.mesh.visible = false;
      const boxIdx = this.arena.colliders.indexOf(crate.box);
      if (boxIdx >= 0) {
        this.arena.colliders.splice(boxIdx, 1);
      }
      soundEngine.playCrateBreak();
      _v1.set(crate.x, 0.65, crate.z);
      this.spawnParticleBurst(_v1, 14, 0xd9b382, 5.2);

      const kind = this.hp < 75 ? 'medkit' : 'ammo';
      const mesh = createPickupMesh(kind, this.textures);
      mesh.position.set(crate.x, 0, crate.z);
      this.scene.add(mesh);
      this.pickups.push({
        id: this.pickupIdSeq++,
        kind,
        mesh,
        x: crate.x,
        z: crate.z,
        age: 0,
      });
    }
  }

  private saveCareerStats(): void {
    try {
      localStorage.setItem(CAREER_STATS_KEY, JSON.stringify(this.careerStats));
    } catch {
      // ignore storage failures
    }
  }

  private awardXp(baseXp: number): void {
    const mult = DIFFICULTY_SPECS[this.selectedDifficulty].xpMult;
    this.careerStats.xp += Math.round(baseXp * mult);

    for (const chal of CHALLENGE_SPECS) {
      if (this.careerStats.completedChallengeIds.includes(chal.id)) continue;
      const metricVal =
        chal.metric === 'headshots'
          ? this.careerStats.totalHeadshots
          : chal.metric === 'explosives'
            ? this.careerStats.totalExplosiveKills
            : this.careerStats.totalKills;
      if (metricVal >= chal.target) {
        this.careerStats.completedChallengeIds.push(chal.id);
        this.careerStats.xp += chal.xpReward;
        this.comboBanner = `TAPŞIRIQ: ${chal.title.toUpperCase()} +${chal.xpReward} XP`;
        this.comboBannerTimer = 2.6;
      }
    }
    this.saveCareerStats();
  }

  private damageEnemy(
    enemy: ActiveEnemy,
    dmg: number,
    isHeadshot: boolean,
    hitPoint?: THREE.Vector3,
    isExplosive = false,
  ): void {
    if (enemy.state === 'dying') return;
    enemy.alerted = true;
    enemy.hp -= dmg;
    enemy.hitFlashTimer = 0.055;
    for (const m of enemy.rig.flashMeshes) {
      (m.material as THREE.MeshStandardMaterial).emissive.setHex(0xffffff);
      (m.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.85;
    }

    // Multi-Phase Boss transitions for Komandir Xəncər
    if (enemy.archetype === 'boss' && enemy.hp > 0) {
      if (
        this.gameMode === 'campaign' &&
        !this.bossQteTriggeredThisStage &&
        !this.bossQte &&
        enemy.hp <= enemy.maxHp * 0.25
      ) {
        this.bossQteTriggeredThisStage = true;
        this.bossQte = {
          bossId: enemy.id,
          bossName: this.currentBossName,
          timeLeftSec: 5.5,
          maxTimeSec: 5.5,
          hitsDone: 0,
          hitsRequired: 5,
        };
        soundEngine.playQteClash();
        this.comboBanner = 'YAXIN DÖYÜŞ QARŞIDURMASI! [F] BASIN!';
        this.comboBannerTimer = 2.4;
      }

      const bossPhase = computeBossPhase(enemy.hp, enemy.maxHp);
      if (bossPhase > this.lastBossPhase) {
        this.lastBossPhase = bossPhase;
        const bossTitle = this.currentBossName.toUpperCase();
        if (bossPhase === 2) {
          enemy.hp = Math.min(enemy.maxHp, enemy.hp + 120);
          _v1.set(enemy.x, 1.4, enemy.z);
          this.spawnParticleBurst(_v1, 24, 0x94a3b8, 7.5);
          this.comboBanner = `${bossTitle} FAZA 2: DƏMİR QALXAN & DƏSTƏ!`;
          this.comboBannerTimer = 2.4;
          this.triggerRadioComms(
            this.currentBossName,
            'DÜŞMƏN LİDERİ',
            'Mühafizəçilər, irəli! Bu sektoru sağ tərk etməyəcəksiniz!',
            'enemy',
          );
          this.waveToSpawn += 2;
        } else if (bossPhase === 3) {
          enemy.speed *= 1.3;
          this.comboBanner = `${bossTitle} FAZA 3: MİNAATAN ZƏRBƏSİ!`;
          this.comboBannerTimer = 2.6;
          this.triggerRadioComms(
            'Kapitan Şahin',
            'QARTAL-COMMS',
            `${this.currentBossName} ağır minaatan zərbəsi sifariş etdi — qırmızı halqalardan çıxın!`,
            'command',
          );
          for (let m = 0; m < 2; m++) {
            const mx = Math.max(-30, Math.min(30, this.playerX + (m === 0 ? -2.2 : 3.2)));
            const mz = Math.max(-30, Math.min(30, this.playerZ + (m === 0 ? 1.5 : -2.5)));
            const { root, ringMesh, coreMesh } = createMortarRing();
            root.position.set(mx, 0, mz);
            this.scene.add(root);
            this.mortarStrikes.push({ root, ringMesh, coreMesh, x: mx, z: mz, timer: 1.85 + m * 0.4 });
          }
        }
      }
    }

    if (hitPoint) {
      this.spawnParticleBurst(hitPoint, isHeadshot ? 10 : 6, isHeadshot ? 0xfef08a : 0xef4444, 4.5);
    }

    this.trauma = Math.min(1, this.trauma + (isHeadshot ? 0.24 : 0.08));

    if (enemy.hp <= 0) {
      enemy.state = 'dying';
      enemy.dyingTimer = 0.36;
      enemy.rig.telegraphBeam.visible = false;
      this.kills += 1;
      if (isHeadshot) this.headshots += 1;
      if (this.gameMode === 'survival') {
        this.credits += isHeadshot ? 65 : 45;
      }
      if (this.isLastStand) {
        this.isLastStand = false;
        this.lastStandTimer = 0;
        this.hp = 55;
        this.isCrouching = false;
        soundEngine.playStimShot();
        this.comboBanner = 'QƏLƏBƏ İLƏ AYAĞA QALXDINIZ!';
        this.comboBannerTimer = 2.2;
      }

      if (this.kills === 1) {
        this.unlockMedal('first_blood');
      }

      if (enemy.archetype === 'boss') {
        this.objectiveCompleted = true;
        if (this.bossQte?.bossId === enemy.id) {
          this.bossQte = null;
        }
        this.triggerRadioComms(
          'Kapitan Şahin',
          'QARTAL-COMMS',
          `${this.currentBossName} məhv edildi! Qalan qüvvələri təmizləyin!`,
          'command',
        );
      }

      if (this.gameMode !== 'campaign' && this.killstreakProgress < KILLSTREAK_THRESHOLD) {
        this.killstreakProgress += 1;
        if (this.killstreakProgress === UAV_THRESHOLD && !this.uavReady) {
          this.uavReady = true;
          soundEngine.playKillstreakReady();
          this.comboBanner = 'UAV KƏŞFİYYATI HAZIRDIR [U]';
          this.comboBannerTimer = 2.0;
        } else if (this.killstreakProgress === CARE_PACKAGE_THRESHOLD && !this.carePackageReady) {
          this.carePackageReady = true;
          soundEngine.playKillstreakReady();
          this.comboBanner = 'YARDIM PAKETİ HAZIRDIR [J]';
          this.comboBannerTimer = 2.2;
        } else if (this.killstreakProgress >= KILLSTREAK_THRESHOLD) {
          this.gunshipReady = true;
          soundEngine.playKillstreakReady();
          this.comboBanner = 'AC-130 DRON [E] VƏ GUNSHIP [Y] HAZIRDIR!';
          this.comboBannerTimer = 2.4;
        }
      }

      const aliveRemaining = this.enemies.filter((e) => e.state !== 'dying').length;
      if ((this.waveToSpawn === 0 && aliveRemaining === 0) || enemy.archetype === 'boss') {
        this.finalKillSlowMoTimer = 0.85;
        if (enemy.archetype !== 'boss') {
          this.comboBanner = 'SON HƏDƏF MƏHV EDİLDİ!';
          this.comboBannerTimer = 1.9;
        }
      }

      if (this.gameMode !== 'campaign') {
        this.comboCount = this.comboWindowTimer > 0 ? this.comboCount + 1 : 1;
        this.comboWindowTimer = 3.2;
        const comboLabel = getComboLabel(this.comboCount);
        if (comboLabel) {
          this.comboBanner = comboLabel;
          this.comboBannerTimer = 1.8;
        }
      }

      const pts = ENEMY_SPECS[enemy.archetype].scoreValue + (isHeadshot ? 50 : 0);
      this.score += pts;
      if (this.score > this.bestScore) {
        this.bestScore = this.score;
        try {
          localStorage.setItem(BEST_SCORE_KEY, String(this.bestScore));
        } catch {
          // ignore storage failures
        }
      }

      const prevStats: CareerStats = {
        ...this.careerStats,
        completedChallengeIds: [...this.careerStats.completedChallengeIds],
      };
      this.careerStats.totalKills += 1;
      if (isHeadshot) this.careerStats.totalHeadshots += 1;
      if (isExplosive) this.careerStats.totalExplosiveKills += 1;
      this.careerStats.bestScore = Math.max(this.careerStats.bestScore, this.bestScore);
      this.awardXp(25 + (isHeadshot ? 15 : 0));

      if (this.careerStats.totalHeadshots >= 5) {
        this.unlockMedal('sniper_master');
      }
      if (this.careerStats.totalExplosiveKills >= 4) {
        this.unlockMedal('boom_master');
      }

      const unlockedCamos = getNewlyUnlockedCamos(prevStats, this.careerStats);
      if (unlockedCamos.length > 0) {
        this.comboBanner = `YENİ KAMUFLYAJ: ${WEAPON_CAMOS[unlockedCamos[0]].name.toUpperCase()}`;
        this.comboBannerTimer = 2.4;
      }

      this.hitmarkerKind = 'kill';
      this.hitmarkerTimer = 0.2;
      this.hitstopTimer = 0.036;
      soundEngine.playHitmarker(isHeadshot, true);

      if (this.gameMode !== 'campaign') {
        const label = ENEMY_SPECS[enemy.archetype].label;
        this.killFeed.unshift({
          id: this.killFeedSeq++,
          text: isHeadshot ? `${label} · BAŞDAN ZƏRBƏ +${pts}` : `${label} məhv edildi +${pts}`,
          isHeadshot,
          timestamp: this.elapsedTime,
        });
        if (this.killFeed.length > 3) this.killFeed.pop();
      }

      if (Math.random() < 0.4) {
        const kind = this.hp < 65 && Math.random() < 0.65 ? 'medkit' : 'ammo';
        const mesh = createPickupMesh(kind, this.textures);
        mesh.position.set(enemy.x, 0, enemy.z);
        this.scene.add(mesh);
        this.pickups.push({
          id: this.pickupIdSeq++,
          kind,
          mesh,
          x: enemy.x,
          z: enemy.z,
          age: 0,
        });
      }
    } else {
      this.hitmarkerKind = 'hit';
      this.hitmarkerTimer = 0.14;
      soundEngine.playHitmarker(isHeadshot, false);
    }
  }

  private detonateBarrel(barrelId: number): void {
    const barrel = this.arena.barrels[barrelId];
    if (!barrel || barrel.exploded) return;
    barrel.exploded = true;
    barrel.mesh.visible = false;
    _v1.set(barrel.x, 0.8, barrel.z);
    this.triggerExplosion(_v1, 7.2, 165);
  }

  private detonateFlashbang(center: THREE.Vector3): void {
    soundEngine.playFlashbang();
    this.trauma = Math.min(1, this.trauma + 0.22);
    this.spawnParticleBurst(center, 22, 0xf8fafc, 8.5);
    let stunnedCount = 0;
    for (const e of this.enemies) {
      if (e.state === 'dying') continue;
      const d = Math.hypot(e.x - center.x, e.z - center.z);
      if (d <= 9.5) {
        e.stunTimer = 3.6;
        e.state = 'moving';
        e.rig.telegraphBeam.visible = false;
        stunnedCount += 1;
      }
    }
    if (stunnedCount > 0) {
      this.comboBanner = `FLASHBANG: ${stunnedCount} DÜŞMƏN İFLİC OLDU!`;
      this.comboBannerTimer = 1.6;
    }
  }

  private triggerExplosion(center: THREE.Vector3, radius: number, maxDmg: number): void {
    soundEngine.playExplosion();
    this.hitstopTimer = 0.048;
    this.trauma = Math.min(1, this.trauma + 0.75);
    this.spawnParticleBurst(center, 28, 0xff6b1a, 10.5);
    this.spawnParticleBurst(center, 16, 0x334155, 6.0);

    for (const e of this.enemies) {
      if (e.state === 'dying') continue;
      const d = Math.hypot(e.x - center.x, e.z - center.z);
      const dmg = computeExplosionDamage(d, radius, maxDmg);
      if (dmg > 0) {
        this.damageEnemy(e, dmg, false, undefined, true);
      }
    }

    if (this.objectiveKind === 'jammer' && !this.objectiveCompleted) {
      const jd = Math.hypot(this.objectiveX - center.x, this.objectiveZ - center.z);
      const jDmg = computeExplosionDamage(jd, radius, maxDmg);
      if (jDmg > 0) {
        this.damageObjective(jDmg, center);
      }
    }

    for (const b of this.arena.barrels) {
      if (b.exploded) continue;
      const d = Math.hypot(b.x - center.x, b.z - center.z);
      if (d < radius * 0.85) {
        this.detonateBarrel(b.id);
      }
    }

    const playerDist = Math.hypot(this.playerX - center.x, this.playerZ - center.z);
    if (playerDist < radius * 0.75) {
      const selfDmg = Math.round(computeExplosionDamage(playerDist, radius * 0.75, 42));
      if (selfDmg > 0) this.applyDamageToPlayer(selfDmg, center.x, center.z);
    }
  }

  private updateEnemies(dt: number): void {
    let activeTelegraphs = this.enemies.filter((e) => e.state === 'telegraph').length;

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];

      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        if (e.hitFlashTimer <= 0) {
          for (const m of e.rig.flashMeshes) {
            (m.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
            (m.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;
          }
        }
      }

      if (e.rig.rotors) {
        for (const r of e.rig.rotors) {
          r.rotation.y += dt * 26;
        }
      }

      if (e.state === 'dying') {
        e.dyingTimer -= dt;
        const p = 1 - Math.max(0, e.dyingTimer) / 0.36;
        e.rig.bodyGroup.rotation.x = -p * (Math.PI * 0.48);
        e.rig.bodyGroup.position.y = -p * 0.35;
        if (e.dyingTimer <= 0) {
          this.scene.remove(e.rig.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }

      if (e.stunTimer > 0) {
        e.stunTimer = Math.max(0, e.stunTimer - dt);
        e.rig.bodyGroup.rotation.z = Math.sin(this.elapsedTime * 18) * 0.14;
        continue;
      }
      e.rig.bodyGroup.rotation.z = 0;

      const dx = this.playerX - e.x;
      const dz = this.playerZ - e.z;
      const dist = Math.max(0.01, Math.hypot(dx, dz));
      const spec = ENEMY_SPECS[e.archetype];
      e.fireCooldown = Math.max(0, e.fireCooldown - dt);
      e.grenadeThrowCooldown = Math.max(0, e.grenadeThrowCooldown - dt);

      _v1.set(e.x, 1.45, e.z);
      _v2.set(this.playerX, this.playerY - 0.15, this.playerZ);
      _vDir.subVectors(_v2, _v1).normalize();
      this.raycaster.layers.set(0);
      this.raycaster.far = dist;
      this.raycaster.set(_v1, _vDir);
      const blocked = this.raycaster.intersectObjects(this.arena.obstacleRayTargets, true).length > 0;

      if (this.stealthActive && !this.stealthDetected && !e.alerted) {
        e.strafeTimer -= dt;
        if (e.strafeTimer <= 0) {
          e.strafeTimer = 2.4 + Math.random() * 1.4;
          e.strafeDir *= -1;
        }
        const patrolAngle = e.strafeDir > 0 ? 0.5 : -0.5 + Math.PI;
        e.yaw = patrolAngle;
        e.rig.root.rotation.y = e.yaw;
        const pvx = Math.sin(e.yaw) * 1.35 * dt;
        const pvz = Math.cos(e.yaw) * 1.35 * dt;
        const patPos = resolveAllCollisions(e.x + pvx, e.z + pvz, ENEMY_RADIUS, this.arena.colliders);
        e.x = patPos.x;
        e.z = patPos.z;
        e.rig.root.position.set(e.x, 0, e.z);
        e.gaitPhase += 1.35 * dt * 3.0;
        e.rig.leftLeg.rotation.x = Math.sin(e.gaitPhase) * 0.4;
        e.rig.rightLeg.rotation.x = -Math.sin(e.gaitPhase) * 0.4;

        const guardFwdX = Math.sin(e.yaw);
        const guardFwdZ = Math.cos(e.yaw);
        const toPlayerDot = (dx * guardFwdX + dz * guardFwdZ) / dist;
        if (!blocked && (dist < 4.5 || (dist < 18 && toPlayerDot > 0.25))) {
          const prevPct = this.stealthSuspicionPct;
          const riseRate = (dist < 8 ? 55 : 28) * (this.isCrouching ? 0.65 : 1.0);
          this.stealthSuspicionPct = Math.min(100, this.stealthSuspicionPct + dt * riseRate);
          if (prevPct < 40 && this.stealthSuspicionPct >= 40) {
            soundEngine.playStealthPing();
          }
          if (this.stealthSuspicionPct >= 100) {
            this.triggerStealthAlarm();
          }
        }
        continue;
      }

      const targetYaw = Math.atan2(dx, dz);
      e.yaw = targetYaw;
      e.rig.root.rotation.y = e.yaw;

      // Kamikaze Drone detonates if within close proximity
      if (e.archetype === 'drone' && dist <= 2.1) {
        _v1.set(e.x, 1.4, e.z);
        this.spawnParticleBurst(_v1, 18, 0xff6b1a, 8.2);
        soundEngine.playExplosion();
        this.applyDamageToPlayer(e.damage, e.x, e.z);
        this.scene.remove(e.rig.root);
        this.enemies.splice(i, 1);
        continue;
      }

      // Enemy tactical frag grenade throw (rifleman/heavy/boss mid-range pressure)
      if (
        (e.archetype === 'rifleman' || e.archetype === 'heavy' || e.archetype === 'boss') &&
        e.state === 'moving' &&
        e.grenadeThrowCooldown <= 0 &&
        dist >= 7.5 &&
        dist <= 22 &&
        !blocked &&
        this.activeGrenades.filter((g) => g.kind === 'enemy_frag').length < 2
      ) {
        e.grenadeThrowCooldown = 11 + Math.random() * 6;
        const gMesh = new THREE.Mesh(this.grenadeGeo, this.enemyGrenadeMat);
        const startPos = new THREE.Vector3(e.x, 1.45, e.z);
        gMesh.position.copy(startPos);
        this.scene.add(gMesh);
        const flightTime = 1.05;
        const vx = (this.playerX - e.x) / flightTime;
        const vz = (this.playerZ - e.z) / flightTime;
        const vy = 4.9;
        this.activeGrenades.push({
          mesh: gMesh,
          pos: startPos,
          vel: new THREE.Vector3(vx, vy, vz),
          fuse: 2.35,
          kind: 'enemy_frag',
        });
        soundEngine.playGrenadeWarningBeep();
      }

      if (e.state === 'telegraph') {
        e.telegraphTimer -= dt;
        e.rig.telegraphBeam.visible = true;
        e.rig.rightArm.rotation.x = 0.06;
        if (e.telegraphTimer <= 0) {
          e.rig.telegraphBeam.visible = false;
          e.state = 'moving';
          e.fireCooldown = spec.fireCooldown;
          if (!blocked && dist < 44) {
            soundEngine.playEnemyShot();
            _v3.set(e.x, 1.35, e.z);
            this.spawnTracer(_v3, _v2);
            const stanceAccuracyMult = computeStanceModifiers(
              this.isCrouching,
              this.slideTimer > 0,
            ).incomingAccuracyMult;
            const leanMult = this.lean !== 'none' ? 0.82 : 1;
            const stealthMult =
              this.fieldUpgrade === 'dead_silence' && this.fieldUpgradeActiveTimer > 0 ? 0.62 : 1;
            const accuracy =
              (e.archetype === 'sniper' ? 0.84 : e.archetype === 'heavy' ? 0.8 : 0.68) *
              stanceAccuracyMult *
              leanMult *
              stealthMult;
            if (Math.random() < accuracy) {
              this.applyDamageToPlayer(e.damage, e.x, e.z);
            }
          }
        }
        continue;
      }

      let moveX = 0;
      let moveZ = 0;
      const dirX = dx / dist;
      const dirZ = dz / dist;
      const perpX = -dirZ;
      const perpZ = dirX;

      e.strafeTimer -= dt;
      if (e.strafeTimer <= 0) {
        e.strafeTimer = 1.4 + Math.random() * 1.4;
        e.strafeDir *= -1;
      }

      if (e.archetype === 'rusher' || e.archetype === 'drone') {
        const approach = dist > spec.preferredRange ? 1.0 : 0.25;
        moveX = dirX * approach + perpX * e.strafeDir * (e.archetype === 'drone' ? 0.4 : 0.55);
        moveZ = dirZ * approach + perpZ * e.strafeDir * (e.archetype === 'drone' ? 0.4 : 0.55);
      } else if (e.archetype === 'sniper') {
        if (dist > spec.preferredRange || blocked) {
          moveX = dirX * 0.75 + perpX * e.strafeDir * 0.25;
          moveZ = dirZ * 0.75 + perpZ * e.strafeDir * 0.25;
        } else if (dist < 14) {
          moveX = -dirX * 0.8 + perpX * e.strafeDir * 0.4;
          moveZ = -dirZ * 0.8 + perpZ * e.strafeDir * 0.4;
        } else {
          moveX = perpX * e.strafeDir * 0.35;
          moveZ = perpZ * e.strafeDir * 0.35;
        }
      } else if (e.archetype === 'heavy' || e.archetype === 'shield') {
        if (dist > spec.preferredRange || blocked) {
          moveX = dirX * 0.92;
          moveZ = dirZ * 0.92;
        } else {
          moveX = perpX * e.strafeDir * 0.22;
          moveZ = perpZ * e.strafeDir * 0.22;
        }
      } else {
        if (dist > spec.preferredRange || blocked) {
          moveX = dirX * 0.85 + perpX * e.strafeDir * 0.35;
          moveZ = dirZ * 0.85 + perpZ * e.strafeDir * 0.35;
        } else if (dist < 8) {
          moveX = -dirX * 0.5 + perpX * e.strafeDir * 0.7;
          moveZ = -dirZ * 0.5 + perpZ * e.strafeDir * 0.7;
        } else {
          moveX = perpX * e.strafeDir * 0.75;
          moveZ = perpZ * e.strafeDir * 0.75;
        }
      }

      const mLen = Math.hypot(moveX, moveZ);
      if (mLen > 0.01) {
        moveX /= mLen;
        moveZ /= mLen;
        const nextPos = resolveAllCollisions(
          e.x + moveX * e.speed * dt,
          e.z + moveZ * e.speed * dt,
          ENEMY_RADIUS,
          this.arena.colliders,
        );
        const stepDist = Math.hypot(nextPos.x - e.x, nextPos.z - e.z);
        e.x = nextPos.x;
        e.z = nextPos.z;
        e.rig.root.position.set(e.x, 0, e.z);
        e.gaitPhase += stepDist * 3.1;
        e.rig.leftLeg.rotation.x = Math.sin(e.gaitPhase) * 0.55;
        e.rig.rightLeg.rotation.x = -Math.sin(e.gaitPhase) * 0.55;
        e.rig.leftArm.rotation.x = -Math.sin(e.gaitPhase) * 0.25;
      }

      if (
        e.archetype !== 'drone' &&
        e.archetype !== 'zombie' &&
        !blocked &&
        dist <= spec.preferredRange + 14 &&
        e.fireCooldown <= 0 &&
        activeTelegraphs < 3
      ) {
        e.state = 'telegraph';
        e.telegraphTimer = spec.telegraphTime;
        activeTelegraphs += 1;
        soundEngine.playTelegraph();
      } else if (e.archetype === 'zombie' && dist <= 1.95 && e.fireCooldown <= 0) {
        e.fireCooldown = spec.fireCooldown;
        soundEngine.playKnifeSlash();
        this.applyDamageToPlayer(e.damage, e.x, e.z);
      }
    }
  }

  private updateAlliedSquad(dt: number): void {
    const livingEnemies = this.enemies.filter((e) => e.state !== 'dying');
    if (this.stealthActive && !this.stealthDetected && this.stealthSuspicionPct > 0) {
      this.stealthSuspicionPct = Math.max(0, this.stealthSuspicionPct - dt * 10);
    }

    this.allies.forEach((ally, idx) => {
      if (ally.downed) {
        ally.bleedoutTimer -= dt;
        ally.rig.bodyGroup.position.y = -0.58;
        ally.rig.bodyGroup.rotation.x = -0.45;
        if (ally.bleedoutTimer <= 0) {
          ally.downed = false;
          ally.hp = 45;
          ally.downedCooldown = 36;
          ally.rig.bodyGroup.position.y = 0;
          ally.rig.bodyGroup.rotation.x = 0;
          this.squadTrust = Math.max(0, this.squadTrust - 12);
          this.saveStoryProgress();
          this.comboBanner = `${ally.name.toUpperCase()} YARALANDI (-12 GÜVƏN)`;
          this.comboBannerTimer = 2.4;
        }
        return;
      }

      ally.downedCooldown = Math.max(0, ally.downedCooldown - dt);
      if (
        this.gameMode === 'campaign' &&
        !this.stealthActive &&
        livingEnemies.length >= 3 &&
        ally.downedCooldown <= 0 &&
        !this.allies.some((a) => a.downed) &&
        Math.random() < dt * 0.045
      ) {
        ally.downed = true;
        ally.bleedoutTimer = 22;
        ally.hp = 20;
        soundEngine.playPlayerHurt();
        this.triggerRadioComms(
          ally.name,
          'QARTAL-SQUAD',
          'Vuruldum! [E] ilə yaxınlaşıb tibbi yardım göstərin!',
          'enemy',
        );
        return;
      }

      ally.fireCooldown = Math.max(0, ally.fireCooldown - dt);
      const flankOffsetX = idx === 0 ? -4.2 : 4.2;
      const flankOffsetZ = 2.8;
      const goalX = Math.max(-33, Math.min(33, this.playerX + flankOffsetX));
      const goalZ = Math.max(-33, Math.min(33, this.playerZ + flankOffsetZ));

      const dx = goalX - ally.x;
      const dz = goalZ - ally.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 1.2) {
        const moveStep = Math.min(dist, 5.4 * dt);
        const nx = (dx / dist) * moveStep;
        const nz = (dz / dist) * moveStep;
        const res = resolveAllCollisions(ally.x + nx, ally.z + nz, ENEMY_RADIUS, this.arena.colliders);
        ally.x = res.x;
        ally.z = res.z;
        ally.gaitPhase += moveStep * 3.0;
        ally.rig.leftLeg.rotation.x = Math.sin(ally.gaitPhase) * 0.5;
        ally.rig.rightLeg.rotation.x = -Math.sin(ally.gaitPhase) * 0.5;
      }

      // Target nearest enemy (don't break stealth before player engages)
      let nearest: ActiveEnemy | null = null;
      let minEd = 26;
      if (!this.stealthActive || this.stealthDetected) {
        for (const e of livingEnemies) {
          const d = Math.hypot(e.x - ally.x, e.z - ally.z);
          if (d < minEd) {
            minEd = d;
            nearest = e;
          }
        }
      }
      if (nearest) {
        ally.yaw = Math.atan2(nearest.x - ally.x, nearest.z - ally.z);
        if (ally.fireCooldown <= 0) {
          ally.fireCooldown = 1.15 + Math.random() * 0.45;
          _v1.set(ally.x, 1.35, ally.z);
          _v2.set(nearest.x, 1.3, nearest.z);
          this.spawnTracer(_v1, _v2);
          this.damageEnemy(nearest, 14, false, _v2, false);
        }
      } else if (dist > 0.5) {
        ally.yaw = Math.atan2(dx, dz);
      }

      ally.rig.root.position.set(ally.x, 0, ally.z);
      ally.rig.root.rotation.y = ally.yaw;
    });
  }

  private updateSentries(dt: number): void {
    const livingEnemies = this.enemies.filter((e) => e.state !== 'dying');
    for (let i = this.sentries.length - 1; i >= 0; i--) {
      const s = this.sentries[i];
      s.timer -= dt;
      s.fireCooldown = Math.max(0, s.fireCooldown - dt);
      if (s.flashTimer > 0) {
        s.flashTimer -= dt;
        if (s.flashTimer <= 0) s.rig.barrelFlash.visible = false;
      }
      if (s.timer <= 0) {
        this.scene.remove(s.rig.root);
        this.sentries.splice(i, 1);
        continue;
      }

      let nearest: ActiveEnemy | null = null;
      let minEd = 28;
      for (const e of livingEnemies) {
        const d = Math.hypot(e.x - s.x, e.z - s.z);
        if (d < minEd) {
          minEd = d;
          nearest = e;
        }
      }
      if (nearest) {
        s.rig.headGroup.rotation.y = Math.atan2(nearest.x - s.x, nearest.z - s.z);
        if (s.fireCooldown <= 0) {
          s.fireCooldown = 0.24;
          s.rig.barrelFlash.visible = true;
          s.flashTimer = 0.045;
          soundEngine.playSentryShot();
          _v1.set(s.x, 0.78, s.z);
          _v2.set(nearest.x, 1.2, nearest.z);
          this.spawnTracer(_v1, _v2);
          this.damageEnemy(nearest, 16, false, _v2, false);
        }
      } else {
        s.rig.headGroup.rotation.y += dt * 1.1;
      }
    }
  }

  private updateRpgRockets(dt: number): void {
    for (let i = this.rpgRockets.length - 1; i >= 0; i--) {
      const r = this.rpgRockets[i];
      r.age += dt;
      r.pos.addScaledVector(r.vel, dt);
      r.mesh.position.copy(r.pos);
      if (Math.random() < 0.65) {
        this.spawnSingleParticle(r.pos, new THREE.Vector3(0, 0.5, 0), 0xcbd5e1, 0.42, 0.3);
      }

      let hit = r.pos.y <= 0.15 || r.age > 3.2 || Math.abs(r.pos.x) >= 38 || Math.abs(r.pos.z) >= 38;
      if (!hit) {
        for (const e of this.enemies) {
          if (e.state !== 'dying' && Math.hypot(e.x - r.pos.x, e.z - r.pos.z) <= 1.25 && r.pos.y <= 2.4) {
            hit = true;
            break;
          }
        }
      }

      if (hit) {
        this.scene.remove(r.mesh);
        this.rpgRockets.splice(i, 1);
        this.triggerExplosion(r.pos, 7.2, 240);
      }
    }
  }

  private updateMinesAndMortars(dt: number): void {
    // Claymores triggered by enemy proximity
    for (let i = this.claymores.length - 1; i >= 0; i--) {
      const cl = this.claymores[i];
      for (const e of this.enemies) {
        if (e.state !== 'dying' && Math.hypot(e.x - cl.x, e.z - cl.z) <= 2.45) {
          this.scene.remove(cl.root);
          this.claymores.splice(i, 1);
          _v1.set(cl.x, 0.3, cl.z);
          this.triggerExplosion(_v1, 5.8, 200);
          break;
        }
      }
    }

    // Enemy Landmines triggered by player stepping close
    for (let i = this.landmines.length - 1; i >= 0; i--) {
      const lm = this.landmines[i];
      if (lm.exploded) continue;
      lm.ledMesh.visible = Math.sin(this.elapsedTime * 8 + i) > 0;
      if (Math.hypot(this.playerX - lm.x, this.playerZ - lm.z) <= 1.45 && this.isGrounded) {
        lm.exploded = true;
        this.scene.remove(lm.root);
        _v1.set(lm.x, 0.2, lm.z);
        this.triggerExplosion(_v1, 4.4, 95);
        this.landmines.splice(i, 1);
      }
    }

    // Intel rotation animation
    for (const ip of this.intelPickups) {
      if (!ip.collected) {
        ip.root.rotation.y += dt * 1.4;
      }
    }

    // Boss Phase 3 Mortar Warning Rings
    for (let i = this.mortarStrikes.length - 1; i >= 0; i--) {
      const ms = this.mortarStrikes[i];
      ms.timer -= dt;
      const pulse = 0.85 + Math.sin(this.elapsedTime * 14) * 0.15;
      ms.ringMesh.scale.set(pulse, pulse, 1);
      if (ms.timer <= 0) {
        this.scene.remove(ms.root);
        this.mortarStrikes.splice(i, 1);
        _v1.set(ms.x, 0.3, ms.z);
        this.triggerExplosion(_v1, 4.5, 90);
      }
    }
  }

  private applyDamageToPlayer(dmg: number, sourceX: number, sourceZ: number): void {
    this.stageDamaged = true;
    this.outOfCombatTimer = 0;
    const shieldMitigated =
      this.fieldUpgrade === 'shield' && this.fieldUpgradeActiveTimer > 0
        ? Math.max(1, Math.round(dmg * 0.35))
        : dmg;
    const res = applyPlayerDamage(this.hp, this.armor, shieldMitigated);
    this.hp = res.hp;
    this.armor = res.armor;
    this.damageFlash = 1.0;
    this.trauma = Math.min(1, this.trauma + 0.42);
    soundEngine.playPlayerHurt();

    const worldAngle = Math.atan2(sourceX - this.playerX, sourceZ - this.playerZ);
    this.damageDirectionAngle = worldAngle - this.yaw;

    if (this.hp <= 0) {
      if (!this.isLastStand && this.selfReviveKit) {
        this.isLastStand = true;
        this.hp = 25;
        this.lastStandTimer = 10;
        this.lastStandPulseAccum = 0;
        this.isCrouching = true;
        this.adsDesired = false;
        this.switchWeapon('deagle');
        soundEngine.playLastStandPulse();
        this.comboBanner = 'SON DAYAQ! ÖZÜNÜ QALDIR [H] VƏ YA DÜŞMƏNİ ÖLDÜR!';
        this.comboBannerTimer = 3.0;
      } else {
        this.finishGame('defeat');
      }
    }
  }

  private collectCarePackage(idx: number): void {
    const cp = this.carePackages[idx];
    if (!cp) return;
    this.scene.remove(cp.root);
    this.carePackages.splice(idx, 1);

    soundEngine.playBuyStation();
    const reward = pickCarePackageReward(Math.random());
    if (reward.id === 'juggernaut') {
      this.hp = this.maxHp;
      this.maxArmor = Math.max(this.maxArmor, 100);
      this.armor = this.maxArmor;
      this.armorPlates = this.maxArmorPlates;
      this.stims = Math.min(this.maxStims, this.stims + 1);
      this.comboBanner = 'YARDIM PAKETİ: JUGGERNAUT ZİREH & STİM!';
    } else if (reward.id === 'sentry') {
      const rig = createSentryTurret();
      rig.root.position.set(cp.x, 0, cp.z);
      this.scene.add(rig.root);
      this.sentries.push({ rig, x: cp.x, z: cp.z, timer: 38, fireCooldown: 0.2, flashTimer: 0 });
      this.comboBanner = 'YARDIM PAKETİ: AVTO-TURET QURULDU!';
    } else if (reward.id === 'arsenal_drop') {
      for (const w of WEAPON_LIST) {
        const spec = this.getActiveWeaponSpec(w);
        this.weaponStates[w] = { id: w, mag: spec.magSize, reserve: spec.maxReserve };
      }
      this.grenades = Math.min(4, this.grenades + 2);
      this.flashbangs = Math.min(3, this.flashbangs + 1);
      this.stims = Math.min(this.maxStims, this.stims + 1);
      this.comboBanner = 'YARDIM PAKETİ: TAM ARSENAL & STİM!';
    } else {
      this.gunshipReady = true;
      this.comboBanner = 'YARDIM PAKETİ: AC-130 GUNSHIP HAZIR [Y]!';
    }
    this.comboBannerTimer = 2.4;
    this.emitHud();
  }

  private updateCarePackages(dt: number): void {
    for (let i = this.carePackages.length - 1; i >= 0; i--) {
      const cp = this.carePackages[i];
      cp.age += dt;
      if (!cp.landed) {
        cp.y = Math.max(0, cp.y - dt * 6.5);
        cp.root.position.y = cp.y;
        cp.chuteGroup.rotation.z = Math.sin(cp.age * 3.2) * 0.08;
        if (cp.y <= 0.01) {
          cp.landed = true;
          cp.y = 0;
          cp.root.position.y = 0;
          cp.chuteGroup.visible = false;
          soundEngine.playCrateBreak();
          _v1.set(cp.x, 0.6, cp.z);
          this.spawnParticleBurst(_v1, 14, 0x10b981, 4.5);
        }
      } else {
        cp.beaconMesh.visible = Math.sin(cp.age * 9) > 0;
        if (Math.random() < dt * 4.5) {
          _v1.set(cp.x, 0.9, cp.z);
          _v2.set((Math.random() - 0.5) * 0.8, 2.2, (Math.random() - 0.5) * 0.8);
          this.spawnSingleParticle(_v1, _v2, 0x34d399, 0.55, 0.7);
        }
        if (Math.hypot(cp.x - this.playerX, cp.z - this.playerZ) <= 1.85) {
          this.collectCarePackage(i);
          continue;
        }
        if (cp.age > 45) {
          this.scene.remove(cp.root);
          this.carePackages.splice(i, 1);
        }
      }
    }
  }

  private updateGrenades(dt: number): void {
    for (let i = this.activeGrenades.length - 1; i >= 0; i--) {
      const g = this.activeGrenades[i];
      g.fuse -= dt;
      g.vel.y -= 16 * dt;
      g.pos.addScaledVector(g.vel, dt);
      if (g.pos.y <= 0.12) {
        g.pos.y = 0.12;
        g.vel.y = Math.abs(g.vel.y) * 0.35;
        g.vel.x *= 0.6;
        g.vel.z *= 0.6;
      }
      const bounced = resolveAllCollisions(g.pos.x, g.pos.z, 0.18, this.arena.colliders);
      g.pos.x = bounced.x;
      g.pos.z = bounced.z;
      g.mesh.position.copy(g.pos);
      g.mesh.rotation.x += dt * 8;

      if (g.fuse <= 0) {
        this.scene.remove(g.mesh);
        this.activeGrenades.splice(i, 1);
        if (g.kind === 'flash') {
          this.detonateFlashbang(g.pos);
        } else if (g.kind === 'enemy_frag') {
          soundEngine.playExplosion();
          this.trauma = Math.min(1, this.trauma + 0.52);
          this.spawnParticleBurst(g.pos, 24, 0xef4444, 9.5);
          const pd = Math.hypot(this.playerX - g.pos.x, this.playerZ - g.pos.z);
          const dmg = computeExplosionDamage(pd, 5.6, 48);
          if (dmg > 0) {
            this.applyDamageToPlayer(dmg, g.pos.x, g.pos.z);
          }
        } else {
          this.triggerExplosion(g.pos, 6.8, 160);
        }
      }
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.age += dt;
      p.mesh.rotation.y += dt * 2.2;
      p.mesh.position.y = Math.sin(p.age * 3.5) * 0.08;

      const d = Math.hypot(p.x - this.playerX, p.z - this.playerZ);
      if (d < 2.15) {
        soundEngine.playPickup();
        if (p.kind === 'medkit') {
          this.hp = Math.min(this.maxHp, this.hp + 32);
          this.armor = Math.min(this.maxArmor, this.armor + 16);
        } else {
          for (const w of WEAPON_LIST) {
            const spec = this.getActiveWeaponSpec(w);
            const grant = Math.max(spec.magSize, Math.round(spec.maxReserve * 0.3));
            this.weaponStates[w] = addAmmoPickup(this.weaponStates[w], spec, grant);
          }
        }
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      } else if (p.age > 24) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }
  }

  private spawnSingleParticle(
    origin: THREE.Vector3,
    vel: THREE.Vector3,
    colorHex: number,
    size: number,
    maxAge: number,
  ): void {
    const idx = this.particleCursor;
    const slot = this.particles[idx];
    this.particleCursor = (this.particleCursor + 1) % PARTICLE_POOL_SIZE;
    slot.active = true;
    slot.pos.copy(origin);
    slot.vel.copy(vel);
    slot.age = 0;
    slot.maxAge = maxAge;
    slot.size = size;
    slot.color.setHex(colorHex);
    slot.gravity = 13;
    this.particleMesh.setColorAt(idx, slot.color);
    if (this.particleMesh.instanceColor) {
      this.particleMesh.instanceColor.needsUpdate = true;
    }
  }

  private spawnParticleBurst(
    origin: THREE.Vector3,
    count: number,
    colorHex: number,
    speed: number,
  ): void {
    for (let i = 0; i < count; i++) {
      const idx = this.particleCursor;
      const slot = this.particles[idx];
      this.particleCursor = (this.particleCursor + 1) % PARTICLE_POOL_SIZE;
      slot.active = true;
      slot.pos.copy(origin);
      slot.vel.set(
        (Math.random() - 0.5) * 2 * speed,
        Math.random() * speed * 0.9 + 1.2,
        (Math.random() - 0.5) * 2 * speed,
      );
      slot.age = 0;
      slot.maxAge = 0.25 + Math.random() * 0.35;
      slot.size = 0.65 + Math.random() * 1.1;
      slot.color.setHex(colorHex);
      slot.gravity = 12;
      this.particleMesh.setColorAt(idx, slot.color);
    }
    if (this.particleMesh.instanceColor) {
      this.particleMesh.instanceColor.needsUpdate = true;
    }
  }

  private updateParticles(dt: number): void {
    let anyUpdated = false;
    for (let i = 0; i < PARTICLE_POOL_SIZE; i++) {
      const p = this.particles[i];
      if (!p.active) continue;
      anyUpdated = true;
      p.age += dt;
      if (p.age >= p.maxAge) {
        p.active = false;
        _mat4.makeScale(0, 0, 0);
        this.particleMesh.setMatrixAt(i, _mat4);
        continue;
      }
      p.vel.y -= p.gravity * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y *= -0.3;
      }
      const s = p.size * (1 - p.age / p.maxAge);
      _scale.set(s, s, s);
      _quat.identity();
      _mat4.compose(p.pos, _quat, _scale);
      this.particleMesh.setMatrixAt(i, _mat4);
    }
    if (anyUpdated) {
      this.particleMesh.instanceMatrix.needsUpdate = true;
    }
  }

  private spawnTracer(start: THREE.Vector3, end: THREE.Vector3): void {
    const slot = this.tracers[this.tracerCursor];
    this.tracerCursor = (this.tracerCursor + 1) % TRACER_POOL_SIZE;
    const dist = start.distanceTo(end);
    if (dist < 0.2) return;
    slot.mesh.position.lerpVectors(start, end, 0.5);
    slot.mesh.scale.set(1, 1, dist);
    slot.mesh.lookAt(end);
    slot.mesh.visible = true;
    slot.timer = 0.055;
  }

  private updateTracers(dt: number): void {
    for (let i = 0; i < TRACER_POOL_SIZE; i++) {
      const t = this.tracers[i];
      if (t.timer > 0) {
        t.timer -= dt;
        if (t.timer <= 0) {
          t.mesh.visible = false;
        }
      }
    }
  }

  private finishGame(outcome: 'victory' | 'defeat'): void {
    this.phase = 'gameover';
    this.outcome = outcome;
    this.isNvgActive = false;
    this.renderer.toneMappingExposure = 1.16;
    this.weaponMount.visible = false;
    this.clearHeldInputs();
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock?.();
    }
    soundEngine.playSting(outcome === 'victory');
    document.body.dataset.state = 'gameover';
    this.emitHud();
  }

  private emitHud(): void {
    const spec = this.getActiveWeaponSpec(this.activeWeapon);
    const reloadProgress = this.reloading
      ? Math.max(0, Math.min(1, 1 - this.reloadTimer / spec.reloadDuration))
      : 0;

    const activeEnemies = this.enemies.filter((e) => e.state !== 'dying');
    const radarEnemies = activeEnemies.map((e) => ({
      x: e.x,
      z: e.z,
      archetype: e.archetype,
    }));

    const uavActive = this.uavActiveTimer > 0;
    const minimalHud = DIFFICULTY_SPECS[this.selectedDifficulty].minimalHud;
    const projectedEnemies: ProjectedEnemyMarker[] = [];
    if (this.phase === 'playing') {
      this.camera.updateMatrixWorld(true);
      for (const e of activeEnemies) {
        const showAlways = e.archetype === 'boss' || uavActive || e.stunTimer > 0;
        if (!showAlways && (minimalHud || e.hp >= e.maxHp)) continue;
        _v1.set(e.x, e.archetype === 'boss' ? 2.65 : 2.25, e.z).project(this.camera);
        if (_v1.z < -1 || _v1.z > 1) continue;
        const xPct = (_v1.x * 0.5 + 0.5) * 100;
        const yPct = (-_v1.y * 0.5 + 0.5) * 100;
        if (xPct < 5 || xPct > 95 || yPct < 6 || yPct > 90) continue;
        projectedEnemies.push({
          id: e.id,
          xPct,
          yPct,
          hpPct: Math.max(0, Math.min(100, (e.hp / e.maxHp) * 100)),
          archetype: e.archetype,
          stunned: e.stunTimer > 0,
        });
        if (projectedEnemies.length >= 6) break;
      }
    }

    const slideMaxCd = this.selectedPerk === 'lightweight' ? 0.9 : 1.25;
    const slideCooldownPct =
      this.slideCooldown <= 0 ? 1 : Math.max(0, 1 - this.slideCooldown / slideMaxCd);

    const remainingTotal = this.waveToSpawn + activeEnemies.length;
    const combatCleared = remainingTotal === 0;
    const bossEnemy = activeEnemies.find((e) => e.archetype === 'boss');

    let objectiveStage: HudSnapshot['objectiveStage'] = 'combat';
    let objectiveProgressPct = 0;
    let activeObjectiveText = '';
    let objectiveWaypoint: HudSnapshot['objectiveWaypoint'] = null;

    if (this.gameMode === 'firing_range') {
      objectiveStage = 'combat';
      objectiveProgressPct = Math.min(100, Math.round((this.rangeHits / 12) * 100));
      activeObjectiveText = `Təlim Poliqonu · 9 Silah [1-9] · Vuruş: ${this.rangeHits}`;
    } else if (this.gameMode === 'spec_ops') {
      const defusedCount = this.bombSites.filter((b) => b.defused).length;
      const targetBomb =
        this.bombSites
          .filter((b) => !b.defused)
          .sort(
            (a, b) =>
              Math.hypot(a.x - this.playerX, a.z - this.playerZ) -
              Math.hypot(b.x - this.playerX, b.z - this.playerZ),
          )[0] ?? null;
      if (targetBomb) {
        objectiveStage = 'interact';
        objectiveProgressPct = Math.round(targetBomb.progress);
        activeObjectiveText = `${targetBomb.site} Nöqtəsi · Zərərsizləşdir: ${defusedCount}/${this.bombSites.length} · [E] Basılı tut`;
        if (this.phase === 'playing') {
          _v1.set(targetBomb.x, 1.4, targetBomb.z);
          _v2.copy(_v1).applyMatrix4(this.camera.matrixWorldInverse);
          _v3.copy(_v1).project(this.camera);
          let nx = _v3.x;
          let ny = _v3.y;
          const behind = _v2.z > -0.1;
          if (behind) {
            nx = -nx;
            ny = -0.88;
          }
          const rawX = (nx * 0.5 + 0.5) * 100;
          const rawY = (-ny * 0.5 + 0.5) * 100;
          const xPct = Math.max(8, Math.min(92, rawX));
          const yPct = Math.max(16, Math.min(82, rawY));
          objectiveWaypoint = {
            label: `BOMBA ${targetBomb.site}`,
            distanceMeters: Math.max(
              1,
              Math.round(Math.hypot(targetBomb.x - this.playerX, targetBomb.z - this.playerZ)),
            ),
            xPct,
            yPct,
            clamped: behind || rawX < 8 || rawX > 92 || rawY < 16 || rawY > 82,
            kind: 'hold',
          };
        }
      }
    } else if (this.objectiveKind === 'uplink') {
      if (this.objectiveCompleted) {
        objectiveStage = 'done';
        objectiveProgressPct = 100;
        activeObjectiveText = `Rabitə bərpa olundu · Qalan düşmən: ${remainingTotal}`;
      } else {
        objectiveStage = combatCleared ? 'interact' : 'combat';
        objectiveProgressPct = Math.round(this.objectiveHoldProgress);
        activeObjectiveText = combatCleared
          ? `Yaşıl Rabitə Terminalına yaxınlaşın (${objectiveProgressPct}%)`
          : `Keşikçiləri məhv edin (${remainingTotal}) · Rabitə Terminalını qoruyun`;
      }
    } else if (this.objectiveKind === 'jammer') {
      if (this.objectiveCompleted) {
        objectiveStage = 'done';
        objectiveProgressPct = 100;
        activeObjectiveText = `Qarışdırıcı dağıdıldı · Qalan düşmən: ${remainingTotal}`;
      } else {
        objectiveStage = combatCleared ? 'interact' : 'combat';
        objectiveProgressPct = Math.round(
          ((this.objectiveMaxHp - this.objectiveHp) / Math.max(1, this.objectiveMaxHp)) * 100,
        );
        activeObjectiveText = `${this.objectiveLabel}-nı atəşlə sıradan çıxarın (${this.objectiveHp} HP)`;
      }
    } else if (this.objectiveKind === 'hold') {
      const zoneName = this.objectiveLabel || 'HELİPAD MƏRKƏZİ';
      if (this.objectiveCompleted) {
        objectiveStage = 'done';
        objectiveProgressPct = 100;
        activeObjectiveText = `${zoneName} siqnalı aktivdir · Qalan düşmən: ${remainingTotal}`;
      } else {
        objectiveStage = combatCleared ? 'interact' : 'combat';
        objectiveProgressPct = Math.round(this.objectiveHoldProgress);
        activeObjectiveText = combatCleared
          ? `${zoneName} zonasını tamamlayın (${objectiveProgressPct}%)`
          : `${zoneName} zonasını saxlayın (${objectiveProgressPct}%) · Düşmən: ${remainingTotal}`;
      }
    } else if (this.objectiveKind === 'boss') {
      if (bossEnemy) {
        objectiveStage = 'boss';
        objectiveProgressPct = Math.max(
          0,
          Math.min(100, Math.round((bossEnemy.hp / bossEnemy.maxHp) * 100)),
        );
        activeObjectiveText = `${this.currentBossName} · Zireh/Can ${Math.round(bossEnemy.hp)}/${bossEnemy.maxHp}`;
      } else if (this.objectiveCompleted) {
        objectiveStage = 'done';
        objectiveProgressPct = 100;
        activeObjectiveText = `${this.currentBossName} zərərsizləşdirildi · Qalan mühafizə: ${remainingTotal}`;
      } else {
        objectiveStage = 'combat';
        objectiveProgressPct = 0;
        activeObjectiveText = `Şimal xəttini yarın — ${this.currentBossName} yaxınlaşır (${remainingTotal})`;
      }
    }

    if (
      this.gameMode !== 'spec_ops' &&
      this.gameMode !== 'firing_range' &&
      this.phase === 'playing' &&
      this.objectiveKind &&
      !this.objectiveCompleted &&
      (this.objectiveProp || bossEnemy)
    ) {
      const tx = bossEnemy ? bossEnemy.x : this.objectiveX;
      const tz = bossEnemy ? bossEnemy.z : this.objectiveZ;
      _v1.set(tx, bossEnemy ? 2.45 : 1.9, tz);
      _v2.copy(_v1).applyMatrix4(this.camera.matrixWorldInverse);
      _v3.copy(_v1).project(this.camera);
      let nx = _v3.x;
      let ny = _v3.y;
      const behind = _v2.z > -0.1;
      if (behind) {
        nx = -nx;
        ny = -0.88;
      }
      const rawX = (nx * 0.5 + 0.5) * 100;
      const rawY = (-ny * 0.5 + 0.5) * 100;
      const xPct = Math.max(8, Math.min(92, rawX));
      const yPct = Math.max(16, Math.min(82, rawY));
      const clamped = behind || rawX < 8 || rawX > 92 || rawY < 16 || rawY > 82;
      objectiveWaypoint = {
        label: this.objectiveLabel,
        distanceMeters: Math.max(1, Math.round(Math.hypot(tx - this.playerX, tz - this.playerZ))),
        xPct,
        yPct,
        clamped,
        kind: this.objectiveKind,
      };
    }

    const bossPhase = bossEnemy ? computeBossPhase(bossEnemy.hp, bossEnemy.maxHp) : null;
    const interactPrompt = this.phase === 'playing' ? this.getNearestInteraction() : null;
    const enemyFrags = this.activeGrenades
      .filter((g) => g.kind === 'enemy_frag')
      .map((g) => ({ x: g.pos.x, z: g.pos.z, fuse: g.fuse }));
    const grenadeWarning =
      this.phase === 'playing'
        ? computeGrenadeThreat(this.playerX, this.playerZ, this.yaw, enemyFrags)
        : null;

    const fuSpec = FIELD_UPGRADE_SPECS[this.fieldUpgrade];
    const fieldUpgradeCooldownPct =
      this.fieldUpgradeCooldown <= 0
        ? 1
        : Math.max(0, 1 - this.fieldUpgradeCooldown / Math.max(1, fuSpec.cooldownSec));

    const nearestActiveBomb =
      this.gameMode === 'spec_ops'
        ? (this.bombSites
            .filter((b) => !b.defused)
            .sort(
              (a, b) =>
                Math.hypot(a.x - this.playerX, a.z - this.playerZ) -
                Math.hypot(b.x - this.playerX, b.z - this.playerZ),
            )[0] ?? null)
        : null;

    this.onHudUpdate({
      phase: this.phase,
      gameMode: this.gameMode,
      outcome: this.outcome,
      hp: Math.round(this.hp),
      maxHp: this.maxHp,
      armor: Math.round(this.armor),
      maxArmor: this.maxArmor,
      wave: this.wave,
      maxWaves: MAX_STORY_WAVES,
      enemiesRemaining: remainingTotal,
      waveBanner: this.waveBanner,
      comboBanner: this.comboBanner,
      score: Math.round(this.score),
      bestScore: Math.round(this.bestScore),
      credits: this.credits,
      kills: this.kills,
      headshots: this.headshots,
      shotsFired: this.shotsFired,
      shotsHit: this.shotsHit,
      grenades: this.grenades,
      flashbangs: this.flashbangs,
      c4Count: this.c4Count,
      c4PlantedCount: this.c4Charges.length,
      claymoreCount: this.claymoreCount,
      killstreakProgress: this.killstreakProgress,
      killstreakThreshold: KILLSTREAK_THRESHOLD,
      uavThreshold: UAV_THRESHOLD,
      uavReady: this.uavReady,
      uavActiveTimer: Number(this.uavActiveTimer.toFixed(1)),
      killstreakReady: this.killstreakProgress >= KILLSTREAK_THRESHOLD,
      gunshipReady: this.gunshipReady || this.killstreakProgress >= KILLSTREAK_THRESHOLD,
      gunshipActive: this.gunshipActive,
      gunshipTimer: Number(this.gunshipTimer.toFixed(1)),
      gunshipShells: this.gunshipShells,
      carePackageReady: this.carePackageReady,
      carePackageActive: this.carePackages.length > 0,
      stims: this.stims,
      maxStims: this.maxStims,
      stimBoostTimer: Number(this.stimBoostTimer.toFixed(1)),
      isCrouching: this.isCrouching,
      isInspecting: this.inspectTimer > 0,
      lean: this.lean,
      isLastStand: this.isLastStand,
      selfReviveKit: this.selfReviveKit,
      fieldUpgrade: this.fieldUpgrade,
      fieldUpgradeCooldownPct,
      fieldUpgradeActiveTimer: Number(this.fieldUpgradeActiveTimer.toFixed(1)),
      sensitivity: this.sensitivity,
      fov: this.fov,
      volume: this.volume,
      touchControlsEnabled: this.touchControlsEnabled,
      bombObjective: nearestActiveBomb
        ? {
            active: true,
            site: nearestActiveBomb.site,
            progress: Math.round(nearestActiveBomb.progress),
            timer: Math.max(0, Math.ceil(this.bombTimer)),
          }
        : null,
      firingRangeStats:
        this.gameMode === 'firing_range'
          ? {
              hits: this.rangeHits,
              headshots: this.rangeHeadshots,
              score: Math.round(this.score),
              accuracyPct: computeAccuracyPct(this.shotsFired, this.shotsHit),
            }
          : null,
      grenadeWarning,
      mountedTurret: this.mountedTurret,
      thermalActive: this.thermalActive,
      blackoutActive: this.blackoutActive,
      breachSlowMoTimer: Number(this.breachSlowMoTimer.toFixed(1)),
      sentryActiveCount: this.sentries.length,
      buyStationOpen: this.buyStationOpen,
      interactPrompt: interactPrompt ? { kind: interactPrompt.kind, label: interactPrompt.label } : null,
      bossPhase,
      allySquad: this.allies.map((a) => ({
        name: a.name,
        hpPct: Math.round((a.hp / a.maxHp) * 100),
        downed: a.downed,
      })),
      unlockedMedalIds: [...this.unlockedMedalIds],
      medalBanner: this.medalBanner,
      collectedIntelIds: [...this.collectedIntelIds],
      activeWeapon: this.activeWeapon,
      loadoutWeapons: [...this.loadoutWeapons] as [WeaponId, WeaponId],
      weapons: {
        m4a1: { ...this.weaponStates.m4a1 },
        mp5: { ...this.weaponStates.mp5 },
        scarh: { ...this.weaponStates.scarh },
        spas12: { ...this.weaponStates.spas12 },
        msr: { ...this.weaponStates.msr },
        m249: { ...this.weaponStates.m249 },
        deagle: { ...this.weaponStates.deagle },
        rpg7: { ...this.weaponStates.rpg7 },
        knife: { ...this.weaponStates.knife },
      },
      reloading: this.reloading,
      reloadProgress,
      isAds: this.adsDesired,
      isSprinting: this.isSprinting,
      isSliding: this.slideTimer > 0,
      isNvgActive: this.isNvgActive,
      slideCooldownPct,
      crosshairSpread: Math.round(
        12 +
          (1 - this.adsBlend) * 14 +
          this.sprintBlend * 7 +
          this.recoilPitch * 240,
      ),
      hitmarkerKind: this.hitmarkerKind,
      damageFlash: this.damageFlash,
      damageDirectionAngle: this.damageDirectionAngle,
      playerX: this.playerX,
      playerZ: this.playerZ,
      playerYaw: this.yaw,
      radarEnemies: [
        ...radarEnemies,
        ...this.allies.map((a) => ({ x: a.x, z: a.z, archetype: 'ally' as const })),
        ...this.sentries.map((s) => ({ x: s.x, z: s.z, archetype: 'sentry' as const })),
      ],
      projectedEnemies,
      killFeed: [...this.killFeed],
      autoFire: this.autoFire,
      elapsedTime: this.elapsedTime,
      pointerLocked: this.pointerLocked,
      careerStats: {
        ...this.careerStats,
        completedChallengeIds: [...this.careerStats.completedChallengeIds],
      },
      rankInfo: computeRankFromXp(this.careerStats.xp),
      equippedCamos: { ...this.equippedCamos },
      equippedAttachments: {
        m4a1: [...this.equippedAttachments.m4a1],
        mp5: [...this.equippedAttachments.mp5],
        scarh: [...this.equippedAttachments.scarh],
        spas12: [...this.equippedAttachments.spas12],
        msr: [...this.equippedAttachments.msr],
        m249: [...this.equippedAttachments.m249],
        deagle: [...this.equippedAttachments.deagle],
        rpg7: [...this.equippedAttachments.rpg7],
        knife: [...this.equippedAttachments.knife],
      },
      selectedPerk: this.selectedPerk,
      selectedDifficulty: this.selectedDifficulty,
      campaignPace: this.campaignPace,
      chapterStage: this.chapterStageIdx + 1,
      chapterTotalStages: Math.max(1, this.chapterStages.length),
      checkpointStage: this.checkpointStage,
      checkpointBanner: this.checkpointBanner,
      cutscene:
        this.phase === 'cutscene' && this.activeCutscene
          ? {
              title: this.activeCutscene.title,
              locationTime: this.activeCutscene.locationTime,
              speaker: this.activeCutscene.beats[this.cutsceneBeatIdx]?.speaker ?? '',
              callsign: this.activeCutscene.beats[this.cutsceneBeatIdx]?.callsign ?? '',
              subtitle: this.activeCutscene.beats[this.cutsceneBeatIdx]?.subtitle ?? '',
              beatIndex: this.cutsceneBeatIdx,
              totalBeats: this.activeCutscene.beats.length,
            }
          : null,
      unlockedChapter: this.unlockedChapter,
      armorPlates: this.armorPlates,
      maxArmorPlates: this.maxArmorPlates,
      compassHeadingDeg: computeCompassHeadingDeg(this.yaw),
      activeObjectiveText,
      objectiveStage,
      objectiveProgressPct,
      objectiveWaypoint,
      radioMessage: this.radioMessage ? { ...this.radioMessage } : null,
      canonLoadoutEnabled: this.canonLoadoutEnabled,
      activeStoryChoice: this.activeStoryChoice,
      storyDecisions: [...this.storyDecisions],
      squadTrust: this.squadTrust,
      unlockedEndingIds: [...this.unlockedEndingIds],
      activeEnding: this.activeEnding,
      setPieceKind: this.currentSetPieceKind,
      hostagesAlive: this.hostages.filter((h) => h.alive).length,
      hostagesRescued: this.hostages.filter((h) => h.rescued).length,
      hostagesTotal: this.hostages.length,
      woundedAlly: (() => {
        const downed = this.allies.find((a) => a.downed);
        return downed
          ? {
              name: downed.name,
              bleedoutSec: Math.max(0, Math.ceil(downed.bleedoutTimer)),
              distanceMeters: Math.round(Math.hypot(downed.x - this.playerX, downed.z - this.playerZ)),
            }
          : null;
      })(),
      escapeTimerSec:
        this.escapeTimerSec !== null ? Math.max(0, Math.ceil(this.escapeTimerSec)) : null,
      stealthSuspicionPct: Math.round(this.stealthSuspicionPct),
      stealthDetected: this.stealthDetected,
      bossQte: this.bossQte
        ? {
            bossName: this.bossQte.bossName,
            prompt: 'YAXIN DÖYÜŞ ZƏRBƏSİ: [F] BAS!',
            timeLeftSec: this.bossQte.timeLeftSec,
            maxTimeSec: this.bossQte.maxTimeSec,
            progressPct: Math.min(
              100,
              Math.round((this.bossQte.hitsDone / Math.max(1, this.bossQte.hitsRequired)) * 100),
            ),
            hitsDone: this.bossQte.hitsDone,
            hitsRequired: this.bossQte.hitsRequired,
          }
        : null,
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.unbindEvents();
    this.clearTitlePatrollers();
    this.clearDynamicEntities();
    this.arena.dispose();
    this.textures.dispose();
    this.envMap.dispose();
    this.grenadeGeo.dispose();
    this.grenadeMat.dispose();
    this.enemyGrenadeMat.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
