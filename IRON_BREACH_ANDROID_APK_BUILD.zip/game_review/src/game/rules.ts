import type {
  Aabb2D,
  AttachmentId,
  AttachmentSpec,
  BuyStationItemId,
  BuyStationItemSpec,
  CampaignPace,
  CarePackageRewardId,
  CareerStats,
  ChallengeSpec,
  ChapterStageSpec,
  CutsceneSpec,
  DifficultyId,
  DifficultySpec,
  EnemyArchetype,
  FieldUpgradeId,
  GameMode,
  IntelSpec,
  MedalId,
  MedalSpec,
  PerkId,
  PerkSpec,
  RankInfo,
  SetPieceKind,
  StoryChoiceId,
  StoryChoiceSpec,
  StoryDecisionRecord,
  StoryEndingId,
  StoryEndingSpec,
  WaveBriefingSpec,
  WaveConfig,
  WeaponCamoId,
  WeaponCamoSpec,
  WeaponId,
  WeaponSpec,
  WeaponState,
} from './types';

export const ARENA_HALF_SIZE = 38;
export const PLAYER_RADIUS = 0.55;
export const ENEMY_RADIUS = 0.55;
export const MAX_STORY_WAVES = 10;
export const UAV_THRESHOLD = 3;
export const CARE_PACKAGE_THRESHOLD = 4;
export const KILLSTREAK_THRESHOLD = 6;

export const WEAPON_LIST: WeaponId[] = [
  'm4a1',
  'mp5',
  'scarh',
  'spas12',
  'msr',
  'm249',
  'deagle',
  'rpg7',
  'knife',
];

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  m4a1: {
    id: 'm4a1',
    name: 'M4A1 Taktiki',
    role: 'Orta məsafə · Dəqiq',
    damage: 34,
    pellets: 1,
    headshotMult: 2.0,
    fireRate: 9.2,
    magSize: 30,
    maxReserve: 150,
    reloadDuration: 1.4,
    hipSpread: 0.025,
    adsSpread: 0.0045,
    recoilPitch: 0.016,
    recoilYaw: 0.0055,
    range: 95,
    adsFov: 52,
  },
  mp5: {
    id: 'mp5',
    name: 'MP5 Səssiz',
    role: 'Yaxın döyüş · Sürətli',
    damage: 25,
    pellets: 1,
    headshotMult: 1.85,
    fireRate: 13.5,
    magSize: 36,
    maxReserve: 180,
    reloadDuration: 1.15,
    hipSpread: 0.018,
    adsSpread: 0.0075,
    recoilPitch: 0.011,
    recoilYaw: 0.0045,
    range: 70,
    adsFov: 56,
  },
  scarh: {
    id: 'scarh',
    name: 'SCAR-H Ağır',
    role: 'Uzaq məsafə · Yüksək zərbə',
    damage: 48,
    pellets: 1,
    headshotMult: 2.15,
    fireRate: 6.4,
    magSize: 20,
    maxReserve: 120,
    reloadDuration: 1.6,
    hipSpread: 0.032,
    adsSpread: 0.003,
    recoilPitch: 0.023,
    recoilYaw: 0.006,
    range: 115,
    adsFov: 48,
  },
  spas12: {
    id: 'spas12',
    name: 'SPAS-12 Pompalı',
    role: 'Yaxın partlayış · 6 qırma',
    damage: 20,
    pellets: 6,
    headshotMult: 1.5,
    fireRate: 1.55,
    magSize: 8,
    maxReserve: 48,
    reloadDuration: 1.75,
    hipSpread: 0.065,
    adsSpread: 0.042,
    recoilPitch: 0.038,
    recoilYaw: 0.012,
    range: 34,
    adsFov: 60,
  },
  msr: {
    id: 'msr',
    name: 'MSR Snayper',
    role: 'Snayper · Optik nişangah',
    damage: 115,
    pellets: 1,
    headshotMult: 2.5,
    fireRate: 0.95,
    magSize: 5,
    maxReserve: 35,
    reloadDuration: 1.9,
    hipSpread: 0.055,
    adsSpread: 0.0008,
    recoilPitch: 0.048,
    recoilYaw: 0.008,
    range: 150,
    adsFov: 26,
  },
  m249: {
    id: 'm249',
    name: 'M249 SAW Pulemyot',
    role: 'Ağır dəstək · 100 güllə',
    damage: 29,
    pellets: 1,
    headshotMult: 1.8,
    fireRate: 11.2,
    magSize: 100,
    maxReserve: 300,
    reloadDuration: 2.45,
    hipSpread: 0.036,
    adsSpread: 0.0085,
    recoilPitch: 0.015,
    recoilYaw: 0.007,
    range: 95,
    adsFov: 56,
  },
  deagle: {
    id: 'deagle',
    name: 'Desert Eagle',
    role: 'Tapança · Yüksək kalibr',
    damage: 64,
    pellets: 1,
    headshotMult: 2.25,
    fireRate: 3.8,
    magSize: 7,
    maxReserve: 56,
    reloadDuration: 1.1,
    hipSpread: 0.022,
    adsSpread: 0.0035,
    recoilPitch: 0.032,
    recoilYaw: 0.008,
    range: 72,
    adsFov: 58,
  },
  rpg7: {
    id: 'rpg7',
    name: 'RPG-7 Raketatan',
    role: 'Partlayıcı · Zireh əleyhinə',
    damage: 240,
    pellets: 1,
    headshotMult: 1.2,
    fireRate: 0.72,
    magSize: 1,
    maxReserve: 5,
    reloadDuration: 2.1,
    hipSpread: 0.015,
    adsSpread: 0.002,
    recoilPitch: 0.055,
    recoilYaw: 0.01,
    range: 110,
    adsFov: 54,
    isExplosive: true,
  },
  knife: {
    id: 'knife',
    name: 'Taktiki Bıçaq',
    role: 'Gizli yaxın döyüş · Səssiz',
    damage: 140,
    pellets: 1,
    headshotMult: 1.5,
    fireRate: 2.4,
    magSize: 1,
    maxReserve: 0,
    reloadDuration: 0.25,
    hipSpread: 0.001,
    adsSpread: 0.001,
    recoilPitch: 0.006,
    recoilYaw: 0.003,
    range: 3.4,
    adsFov: 68,
    isMelee: true,
  },
};

const WEAPON_SHORT_NAMES: Record<WeaponId, string> = {
  m4a1: 'M4A1',
  mp5: 'MP5',
  scarh: 'SCAR-H',
  spas12: 'SPAS-12',
  msr: 'MSR',
  m249: 'M249',
  deagle: 'Deagle',
  rpg7: 'RPG-7',
  knife: 'Bıçaq',
};

export function getWeaponShortName(id: WeaponId): string {
  return WEAPON_SHORT_NAMES[id] ?? WEAPON_SPECS[id].name.split(' ')[0];
}

export const ATTACHMENT_LIST: AttachmentId[] = [
  'suppressor',
  'ext_mag',
  'laser',
  'acog',
];

export const ATTACHMENT_SPECS: Record<AttachmentId, AttachmentSpec> = {
  suppressor: {
    id: 'suppressor',
    name: 'Səsboğucu',
    shortName: 'Səsboğucu',
    description: 'Atəş səsini və alovu azaldır, +10% dəqiqlik',
  },
  ext_mag: {
    id: 'ext_mag',
    name: 'Böyüdülmüş Daraq',
    shortName: 'Böyük Daraq',
    description: '+40% daraq tutumu və ehtiyat güllə',
  },
  laser: {
    id: 'laser',
    name: 'Taktiki Lazer',
    shortName: 'Lazer',
    description: '-35% yaxın atəş səpələnməsi və yaşıl lazer şüası',
  },
  acog: {
    id: 'acog',
    name: 'ACOG Optik',
    shortName: 'ACOG',
    description: 'Daha dərin yaxınlaşdırma və uzaq məsafə stabilliyi',
  },
};

export const PERK_LIST: PerkId[] = [
  'fast_reload',
  'heavy_armor',
  'lightweight',
];

export const PERK_SPECS: Record<PerkId, PerkSpec> = {
  fast_reload: {
    id: 'fast_reload',
    name: 'Cəld Doldurma',
    shortName: 'Cəld Əl',
    description: 'Silahı 35% daha sürətli doldurur',
  },
  heavy_armor: {
    id: 'heavy_armor',
    name: 'Ağır Zireh',
    shortName: 'Ağır Zireh',
    description: '75 Maks Zireh və 3 Zireh Lövhəsi ilə başlayır',
  },
  lightweight: {
    id: 'lightweight',
    name: 'Sürətli Manivr',
    shortName: 'Yüngül',
    description: '+16% hərəkət sürəti və sürətli sürüş bərpası',
  },
};

export const DIFFICULTY_LIST: DifficultyId[] = ['recruit', 'regular', 'veteran'];

export const DIFFICULTY_SPECS: Record<DifficultyId, DifficultySpec> = {
  recruit: {
    id: 'recruit',
    name: 'Asan',
    description: 'Daha aşağı düşmən zərəri · 1.0x XP',
    enemyHpScale: 0.85,
    enemyDamageScale: 0.72,
    xpMult: 1.0,
    minimalHud: false,
  },
  regular: {
    id: 'regular',
    name: 'Normal',
    description: 'Balanslı taktiki döyüş · 1.2x XP',
    enemyHpScale: 1.0,
    enemyDamageScale: 1.0,
    xpMult: 1.2,
    minimalHud: false,
  },
  veteran: {
    id: 'veteran',
    name: 'Veteran',
    description: 'Yüksək zərər & minimal HUD · 1.5x XP',
    enemyHpScale: 1.2,
    enemyDamageScale: 1.45,
    xpMult: 1.5,
    minimalHud: true,
  },
};

export const RANK_LEVELS: { level: number; title: string; minXp: number }[] = [
  { level: 1, title: 'Əsgər', minXp: 0 },
  { level: 2, title: 'Onbaşı', minXp: 300 },
  { level: 3, title: 'Çavuş', minXp: 750 },
  { level: 4, title: 'Leytenant', minXp: 1400 },
  { level: 5, title: 'Kapitan', minXp: 2300 },
  { level: 6, title: 'Mayor', minXp: 3500 },
  { level: 7, title: 'Polkovnik', minXp: 5000 },
];

export const CHALLENGE_SPECS: ChallengeSpec[] = [
  {
    id: 'chal_headshots',
    title: '10 Başdan Zərbə',
    metric: 'headshots',
    target: 10,
    xpReward: 300,
  },
  {
    id: 'chal_explosives',
    title: '6 Partlayış Məhvi (Qumbara / Çəllək / Dron)',
    metric: 'explosives',
    target: 6,
    xpReward: 250,
  },
  {
    id: 'chal_kills',
    title: '25 Düşmən Zərərsizləşdir',
    metric: 'kills',
    target: 25,
    xpReward: 400,
  },
];

export interface ArchetypeSpec {
  archetype: EnemyArchetype;
  label: string;
  hp: number;
  speed: number;
  damage: number;
  telegraphTime: number;
  fireCooldown: number;
  preferredRange: number;
  scoreValue: number;
}

export const ENEMY_SPECS: Record<EnemyArchetype, ArchetypeSpec> = {
  rifleman: {
    archetype: 'rifleman',
    label: 'Əsgər',
    hp: 95,
    speed: 3.8,
    damage: 11,
    telegraphTime: 0.42,
    fireCooldown: 1.45,
    preferredRange: 16,
    scoreValue: 100,
  },
  rusher: {
    archetype: 'rusher',
    label: 'Hücumçu',
    hp: 75,
    speed: 5.8,
    damage: 13,
    telegraphTime: 0.3,
    fireCooldown: 1.05,
    preferredRange: 5.5,
    scoreValue: 130,
  },
  heavy: {
    archetype: 'heavy',
    label: 'Ağır Zirehli',
    hp: 210,
    speed: 2.5,
    damage: 20,
    telegraphTime: 0.65,
    fireCooldown: 1.9,
    preferredRange: 20,
    scoreValue: 220,
  },
  sniper: {
    archetype: 'sniper',
    label: 'Snayper',
    hp: 80,
    speed: 2.9,
    damage: 24,
    telegraphTime: 0.78,
    fireCooldown: 2.4,
    preferredRange: 30,
    scoreValue: 180,
  },
  shield: {
    archetype: 'shield',
    label: 'Qalxanlı Əsgər',
    hp: 150,
    speed: 2.35,
    damage: 12,
    telegraphTime: 0.48,
    fireCooldown: 1.65,
    preferredRange: 9,
    scoreValue: 190,
  },
  drone: {
    archetype: 'drone',
    label: 'Kamikadze Dron',
    hp: 55,
    speed: 6.4,
    damage: 20,
    telegraphTime: 0.25,
    fireCooldown: 1.0,
    preferredRange: 2.0,
    scoreValue: 150,
  },
  zombie: {
    archetype: 'zombie',
    label: 'Yoluxmuş Mutant',
    hp: 115,
    speed: 6.2,
    damage: 16,
    telegraphTime: 0.24,
    fireCooldown: 0.85,
    preferredRange: 2.1,
    scoreValue: 140,
  },
  boss: {
    archetype: 'boss',
    label: 'Komandir Xəncər',
    hp: 620,
    speed: 2.8,
    damage: 26,
    telegraphTime: 0.58,
    fireCooldown: 1.45,
    preferredRange: 18,
    scoreValue: 750,
  },
};

export function createDefaultEquippedAttachments(): Record<WeaponId, AttachmentId[]> {
  return {
    m4a1: [],
    mp5: [],
    scarh: [],
    spas12: [],
    msr: [],
    m249: [],
    deagle: [],
    rpg7: [],
    knife: [],
  };
}

export function sanitizeEquippedAttachments(
  raw: Partial<Record<WeaponId, AttachmentId[]>> | null | undefined,
): Record<WeaponId, AttachmentId[]> {
  const out = createDefaultEquippedAttachments();
  for (const w of WEAPON_LIST) {
    const list = raw?.[w];
    if (Array.isArray(list)) {
      const valid = list.filter(
        (id, idx): id is AttachmentId =>
          id in ATTACHMENT_SPECS && list.indexOf(id) === idx,
      );
      out[w] = valid;
    }
  }
  return out;
}

export function getEffectiveWeaponSpec(
  weaponId: WeaponId,
  attachments: readonly AttachmentId[] = [],
  perk?: PerkId,
): WeaponSpec {
  const base = WEAPON_SPECS[weaponId];
  const hasSuppressor = attachments.includes('suppressor');
  const hasExtMag = attachments.includes('ext_mag');
  const hasLaser = attachments.includes('laser');
  const hasAcog = attachments.includes('acog');

  return {
    ...base,
    magSize: hasExtMag ? Math.round(base.magSize * 1.4) : base.magSize,
    maxReserve: hasExtMag ? Math.round(base.maxReserve * 1.4) : base.maxReserve,
    reloadDuration:
      perk === 'fast_reload'
        ? Number((base.reloadDuration * 0.65).toFixed(2))
        : base.reloadDuration,
    hipSpread:
      base.hipSpread *
      (hasLaser ? 0.65 : 1.0) *
      (hasSuppressor ? 0.9 : 1.0),
    adsSpread: base.adsSpread * (hasSuppressor ? 0.9 : 1.0),
    adsFov: hasAcog ? Math.max(18, Math.round(base.adsFov * 0.78)) : base.adsFov,
    range: hasAcog ? Math.round(base.range * 1.15) : base.range,
  };
}

export function createInitialWeaponStates(
  attachments: Partial<Record<WeaponId, AttachmentId[]>> = {},
  perk?: PerkId,
): Record<WeaponId, WeaponState> {
  const out = {} as Record<WeaponId, WeaponState>;
  for (const w of WEAPON_LIST) {
    const spec = getEffectiveWeaponSpec(w, attachments[w] ?? [], perk);
    out[w] = {
      id: w,
      mag: spec.magSize,
      reserve: spec.maxReserve,
    };
  }
  return out;
}

export function getLoadoutPair(primary: WeaponId): [WeaponId, WeaponId] {
  return primary === 'mp5' ? ['mp5', 'm4a1'] : [primary, 'mp5'];
}

export function getWaveConfig(wave: number, mode: GameMode = 'campaign'): WaveConfig {
  const w = Math.max(1, Math.floor(wave));
  if (mode === 'survival') {
    const totalEnemies = 10 + w * 4;
    const maxConcurrent = Math.min(12, 4 + w);
    const spawnInterval = Math.max(0.65, 1.85 - w * 0.14);
    const zombieShare = Math.max(0.45, 0.75 - w * 0.04);
    const rusherShare = 0.14;
    const heavyShare = w >= 2 ? Math.min(0.18, 0.06 + (w - 2) * 0.03) : 0;
    const droneShare = w >= 2 ? 0.12 : 0.06;
    const shieldShare = w >= 3 ? 0.08 : 0;
    const sniperShare = Math.max(0, 1 - zombieShare - rusherShare - heavyShare - droneShare - shieldShare);
    return {
      wave: w,
      totalEnemies,
      maxConcurrent,
      spawnInterval,
      mix: {
        rifleman: 0,
        rusher: rusherShare,
        heavy: heavyShare,
        sniper: sniperShare,
        shield: shieldShare,
        drone: droneShare,
        zombie: zombieShare,
      },
      speedScale: Math.min(1.38, 1.0 + (w - 1) * 0.07),
      damageScale: Math.min(1.4, 0.95 + (w - 1) * 0.08),
    };
  }

  const totalEnemies = 5 + w * 3;
  const maxConcurrent = Math.min(9, 3 + Math.floor(w * 0.95));
  const spawnInterval = Math.max(0.75, 2.2 - w * 0.24);

  if (w === 1) {
    return {
      wave: w,
      totalEnemies,
      maxConcurrent,
      spawnInterval,
      mix: {
        rifleman: 0.85,
        rusher: 0.15,
        heavy: 0,
        sniper: 0,
        shield: 0,
        drone: 0,
        zombie: 0,
      },
      speedScale: 0.92,
      damageScale: 0.85,
    };
  }
  if (w === 2) {
    return {
      wave: w,
      totalEnemies,
      maxConcurrent,
      spawnInterval,
      mix: {
        rifleman: 0.48,
        rusher: 0.28,
        heavy: 0.08,
        sniper: 0.08,
        shield: 0,
        drone: 0.08,
        zombie: 0,
      },
      speedScale: 1.0,
      damageScale: 0.95,
    };
  }
  if (w === 3) {
    return {
      wave: w,
      totalEnemies,
      maxConcurrent,
      spawnInterval,
      mix: {
        rifleman: 0.34,
        rusher: 0.24,
        heavy: 0.14,
        sniper: 0.1,
        shield: 0.1,
        drone: 0.08,
        zombie: 0,
      },
      speedScale: 1.06,
      damageScale: 1.05,
    };
  }
  const heavyShare = Math.min(0.22, 0.14 + (w - 3) * 0.03);
  const sniperShare = 0.11;
  const shieldShare = 0.12;
  const droneShare = 0.11;
  const rusherShare = Math.min(0.26, 0.22 + (w - 3) * 0.02);
  const riflemanShare = Math.max(
    0.18,
    1 - heavyShare - sniperShare - shieldShare - droneShare - rusherShare,
  );
  return {
    wave: w,
    totalEnemies,
    maxConcurrent,
    spawnInterval,
    mix: {
      rifleman: riflemanShare,
      rusher: rusherShare,
      heavy: heavyShare,
      sniper: sniperShare,
      shield: shieldShare,
      drone: droneShare,
      zombie: 0,
    },
    speedScale: Math.min(1.3, 1.0 + (w - 2) * 0.06),
    damageScale: Math.min(1.35, 1.0 + (w - 2) * 0.08),
  };
}

export function pickArchetypeForWave(
  wave: number,
  roll: number,
  mode: GameMode = 'campaign',
): EnemyArchetype {
  const cfg = getWaveConfig(wave, mode);
  const r = Math.max(0, Math.min(0.9999, roll));
  let acc = cfg.mix.rifleman;
  if (r < acc) return 'rifleman';
  acc += cfg.mix.rusher;
  if (r < acc) return 'rusher';
  acc += cfg.mix.heavy;
  if (r < acc) return 'heavy';
  acc += cfg.mix.sniper;
  if (r < acc) return 'sniper';
  acc += cfg.mix.shield;
  if (r < acc) return 'shield';
  acc += cfg.mix.drone;
  if (r < acc) return 'drone';
  if (cfg.mix.zombie > 0) return 'zombie';
  return 'drone';
}

export function computeShotDamage(
  weapon: WeaponSpec,
  distance: number,
  isHeadshot: boolean,
): number {
  const falloffStart = weapon.range * 0.45;
  let falloff = 1.0;
  if (distance > falloffStart) {
    const t = Math.min(1, (distance - falloffStart) / (weapon.range - falloffStart));
    falloff = 1.0 - t * 0.42;
  }
  const headMult = isHeadshot ? weapon.headshotMult : 1.0;
  return Math.max(1, Math.round(weapon.damage * falloff * headMult));
}

export function computeExplosionDamage(
  distance: number,
  maxRadius = 6.5,
  maxDamage = 150,
): number {
  if (distance >= maxRadius) return 0;
  const t = 1 - distance / maxRadius;
  return Math.round(maxDamage * (t * t * 0.65 + t * 0.35));
}

export function applyReload(state: WeaponState, spec: WeaponSpec): WeaponState {
  if (state.mag >= spec.magSize || state.reserve <= 0) {
    return state;
  }
  const needed = spec.magSize - state.mag;
  const loaded = Math.min(needed, state.reserve);
  return {
    ...state,
    mag: state.mag + loaded,
    reserve: state.reserve - loaded,
  };
}

export function addAmmoPickup(
  state: WeaponState,
  spec: WeaponSpec,
  amount: number,
): WeaponState {
  const capped = Math.min(spec.maxReserve, state.reserve + Math.max(0, Math.round(amount)));
  return {
    ...state,
    reserve: capped,
  };
}

export function applyPlayerDamage(
  hp: number,
  armor: number,
  incomingDamage: number,
): { hp: number; armor: number } {
  const dmg = Math.max(0, incomingDamage);
  const absorbedByArmor = Math.min(armor, Math.round(dmg * 0.55));
  const nextArmor = Math.max(0, armor - absorbedByArmor);
  const hpDmg = Math.max(0, dmg - absorbedByArmor);
  const nextHp = Math.max(0, hp - hpDmg);
  return { hp: nextHp, armor: nextArmor };
}

export function getComboLabel(streakCount: number): string | null {
  if (streakCount >= 4) return 'DÖRDQAT MƏHV!';
  if (streakCount === 3) return 'ÜÇLÜ MƏHV!';
  if (streakCount === 2) return 'İKİLİ MƏHV!';
  return null;
}

export function resolveCircleAabbCollision(
  x: number,
  z: number,
  radius: number,
  box: Aabb2D,
): { x: number; z: number; collided: boolean } {
  const closestX = Math.max(box.minX, Math.min(x, box.maxX));
  const closestZ = Math.max(box.minZ, Math.min(z, box.maxZ));

  const dx = x - closestX;
  const dz = z - closestZ;
  const distSq = dx * dx + dz * dz;

  if (distSq >= radius * radius) {
    return { x, z, collided: false };
  }

  if (distSq > 1e-8) {
    const dist = Math.sqrt(distSq);
    const overlap = radius - dist;
    return {
      x: x + (dx / dist) * overlap,
      z: z + (dz / dist) * overlap,
      collided: true,
    };
  }

  const leftPen = x - box.minX;
  const rightPen = box.maxX - x;
  const topPen = z - box.minZ;
  const bottomPen = box.maxZ - z;
  const minPen = Math.min(leftPen, rightPen, topPen, bottomPen);

  if (minPen === leftPen) return { x: box.minX - radius, z, collided: true };
  if (minPen === rightPen) return { x: box.maxX + radius, z, collided: true };
  if (minPen === topPen) return { x, z: box.minZ - radius, collided: true };
  return { x, z: box.maxZ + radius, collided: true };
}

export function resolveAllCollisions(
  x: number,
  z: number,
  radius: number,
  colliders: readonly Aabb2D[],
  arenaHalfSize = ARENA_HALF_SIZE,
): { x: number; z: number } {
  let nx = x;
  let nz = z;

  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < colliders.length; i++) {
      const res = resolveCircleAabbCollision(nx, nz, radius, colliders[i]);
      nx = res.x;
      nz = res.z;
    }
    const limit = arenaHalfSize - radius;
    nx = Math.max(-limit, Math.min(limit, nx));
    nz = Math.max(-limit, Math.min(limit, nz));
  }

  return { x: nx, z: nz };
}

export function computeAccuracyPct(shotsFired: number, shotsHit: number): number {
  if (shotsFired <= 0) return 0;
  return Math.min(100, Math.round((shotsHit / shotsFired) * 100));
}

export type GraphicsQuality = '720p' | 'ultra';

export function computeTargetPixelRatio(
  viewportWidth: number,
  viewportHeight: number,
  devicePixelRatio: number,
  isSoftwareGl: boolean,
  quality: GraphicsQuality = '720p',
): number {
  if (isSoftwareGl) return 1;
  const dpr = Math.max(1, devicePixelRatio || 1);
  if (quality === 'ultra') {
    return Math.min(dpr, 2);
  }
  const shortSide = Math.max(1, Math.min(viewportWidth, viewportHeight));
  const targetRatioFor720p = 720 / shortSide;
  return Math.max(1, Math.min(dpr, targetRatioFor720p, 2));
}

export const WEAPON_CAMO_LIST: WeaponCamoId[] = [
  'standard',
  'desert',
  'cobalt',
  'crimson',
  'gold',
];

export const WEAPON_CAMOS: Record<WeaponCamoId, WeaponCamoSpec> = {
  standard: {
    id: 'standard',
    name: 'Standart Taktiki',
    shortName: 'Standart',
    swatchHex: '#32373f',
    accentHex: '#525864',
    receiverHex: 0x2b3038,
    polymerHex: 0x3b3830,
    metalness: 0.78,
    roughness: 0.32,
    unlockType: 'default',
    unlockThreshold: 0,
    unlockLabel: 'Açıqdır',
  },
  desert: {
    id: 'desert',
    name: 'Səhra Qumu',
    shortName: 'Səhra',
    swatchHex: '#c2a371',
    accentHex: '#7d6340',
    receiverHex: 0xd4b98c,
    polymerHex: 0x7c6544,
    metalness: 0.38,
    roughness: 0.48,
    unlockType: 'kills',
    unlockThreshold: 5,
    unlockLabel: '5 Məhv',
  },
  cobalt: {
    id: 'cobalt',
    name: 'Kobalt Taktiki',
    shortName: 'Kobalt',
    swatchHex: '#2563eb',
    accentHex: '#0f172a',
    receiverHex: 0x3b82f6,
    polymerHex: 0x1e293b,
    metalness: 0.68,
    roughness: 0.28,
    unlockType: 'headshots',
    unlockThreshold: 3,
    unlockLabel: '3 Başdan Zərbə',
  },
  crimson: {
    id: 'crimson',
    name: 'Qan Qırmızısı',
    shortName: 'Qırmızı',
    swatchHex: '#dc2626',
    accentHex: '#260d0d',
    receiverHex: 0xef4444,
    polymerHex: 0x271315,
    metalness: 0.64,
    roughness: 0.3,
    unlockType: 'score',
    unlockThreshold: 1500,
    unlockLabel: '1500 Xal',
  },
  gold: {
    id: 'gold',
    name: 'Qızılı Elit',
    shortName: 'Qızılı',
    swatchHex: '#eab308',
    accentHex: '#78350f',
    receiverHex: 0xfacc15,
    polymerHex: 0x272014,
    metalness: 0.92,
    roughness: 0.2,
    unlockType: 'kills',
    unlockThreshold: 20,
    unlockLabel: '20 Məhv',
  },
};

export function createDefaultCareerStats(bestScore = 0): CareerStats {
  return {
    totalKills: 0,
    totalHeadshots: 0,
    bestScore,
    totalExplosiveKills: 0,
    xp: 0,
    completedChallengeIds: [],
  };
}

export function createDefaultEquippedCamos(): Record<WeaponId, WeaponCamoId> {
  return {
    m4a1: 'standard',
    mp5: 'standard',
    scarh: 'standard',
    spas12: 'standard',
    msr: 'standard',
    m249: 'standard',
    deagle: 'standard',
    rpg7: 'standard',
    knife: 'standard',
  };
}

export function getCamoProgress(
  camoId: WeaponCamoId,
  stats: CareerStats,
): { unlocked: boolean; current: number; target: number } {
  const spec = WEAPON_CAMOS[camoId];
  if (spec.unlockType === 'default') {
    return { unlocked: true, current: 1, target: 1 };
  }
  const current =
    spec.unlockType === 'kills'
      ? Math.max(0, stats.totalKills)
      : spec.unlockType === 'headshots'
        ? Math.max(0, stats.totalHeadshots)
        : Math.max(0, stats.bestScore);
  return {
    unlocked: current >= spec.unlockThreshold,
    current: Math.min(current, spec.unlockThreshold),
    target: spec.unlockThreshold,
  };
}

export function isCamoUnlocked(camoId: WeaponCamoId, stats: CareerStats): boolean {
  return getCamoProgress(camoId, stats).unlocked;
}

export function getUnlockedCamoIds(stats: CareerStats): WeaponCamoId[] {
  return WEAPON_CAMO_LIST.filter((id) => isCamoUnlocked(id, stats));
}

export function getNewlyUnlockedCamos(
  prevStats: CareerStats,
  nextStats: CareerStats,
): WeaponCamoId[] {
  return WEAPON_CAMO_LIST.filter(
    (id) => !isCamoUnlocked(id, prevStats) && isCamoUnlocked(id, nextStats),
  );
}

export function sanitizeEquippedCamos(
  equipped: Partial<Record<WeaponId, WeaponCamoId>> | null | undefined,
  stats: CareerStats,
): Record<WeaponId, WeaponCamoId> {
  const defaults = createDefaultEquippedCamos();
  for (const w of WEAPON_LIST) {
    const candidate = equipped?.[w];
    if (candidate && candidate in WEAPON_CAMOS && isCamoUnlocked(candidate, stats)) {
      defaults[w] = candidate;
    }
  }
  return defaults;
}

export function computeRankFromXp(xp: number): RankInfo {
  const safeXp = Math.max(0, Math.floor(xp));
  let current = RANK_LEVELS[0];
  let next = RANK_LEVELS[1];

  for (let i = 0; i < RANK_LEVELS.length; i++) {
    if (safeXp >= RANK_LEVELS[i].minXp) {
      current = RANK_LEVELS[i];
      next = RANK_LEVELS[i + 1] ?? RANK_LEVELS[i];
    }
  }

  if (next.level === current.level) {
    return {
      level: current.level,
      title: current.title,
      xp: safeXp,
      currentFloorXp: current.minXp,
      nextLevelXp: current.minXp,
      progressPct: 100,
    };
  }

  const span = Math.max(1, next.minXp - current.minXp);
  const progressPct = Math.max(
    0,
    Math.min(100, Math.round(((safeXp - current.minXp) / span) * 100)),
  );
  return {
    level: current.level,
    title: current.title,
    xp: safeXp,
    currentFloorXp: current.minXp,
    nextLevelXp: next.minXp,
    progressPct,
  };
}

export function getChallengeProgress(
  challenge: ChallengeSpec,
  stats: CareerStats,
): { completed: boolean; current: number; target: number } {
  const raw =
    challenge.metric === 'headshots'
      ? stats.totalHeadshots
      : challenge.metric === 'explosives'
        ? stats.totalExplosiveKills
        : stats.totalKills;
  const current = Math.max(0, Math.min(challenge.target, raw));
  const completed =
    stats.completedChallengeIds.includes(challenge.id) || raw >= challenge.target;
  return {
    completed,
    current,
    target: challenge.target,
  };
}

export function applyArmorPlate(
  armor: number,
  maxArmor: number,
  plates: number,
  plateAmount = 35,
): { armor: number; plates: number; applied: boolean } {
  if (plates <= 0 || armor >= maxArmor) {
    return { armor, plates, applied: false };
  }
  return {
    armor: Math.min(maxArmor, armor + plateAmount),
    plates: plates - 1,
    applied: true,
  };
}

export function computeCompassHeadingDeg(yawRadians: number): number {
  const deg = Math.round(((-yawRadians * 180) / Math.PI) % 360);
  return (deg + 360) % 360;
}

export function clampChapterSelection(
  requestedChapter: number,
  unlockedChapter: number,
): number {
  const maxUnlocked = Math.max(1, Math.min(MAX_STORY_WAVES, Math.floor(unlockedChapter)));
  return Math.max(1, Math.min(maxUnlocked, Math.floor(requestedChapter)));
}

export function resolvePlayableChapter(requestedChapter: number): number {
  const ch = Number.isFinite(requestedChapter) ? Math.floor(requestedChapter) : 1;
  return Math.max(1, Math.min(MAX_STORY_WAVES, ch));
}

export function getChapterStageSpecs(
  chapter: number,
  pace: CampaignPace = 'marathon',
): ChapterStageSpec[] {
  const ch = Math.max(1, Math.floor(chapter));
  const cfg = getWaveConfig(ch);

  if (pace === 'standard' || ch > MAX_STORY_WAVES) {
    const kind =
      ch === 1 || ch === 6
        ? 'uplink'
        : ch === 2 || ch === 3 || ch === 9
          ? 'jammer'
          : ch === 5 || ch === 10
            ? 'boss'
            : 'hold';
    const label =
      ch === 1
        ? 'RABİTƏ TERMİNALI'
        : ch === 2
          ? 'QARIŞDIRICI ALPHA'
          : ch === 3
            ? 'QARIŞDIRICI BETA'
            : ch === 4
              ? 'HELİPAD SİQNALI'
              : ch === 5
                ? 'HƏDƏF: XƏNCƏR'
                : ch === 6
                  ? 'SEKTOR-7 TERMİNALI'
                  : ch === 7
                    ? 'ANBAR GÜVERTE'
                    : ch === 8
                      ? 'MƏBƏD GİRİŞİ'
                      : ch === 9
                        ? 'HANGAR POZUCU'
                        : ch === 10
                          ? 'SİNDİKAT LİDERİ'
                          : 'MÖVQE MÜDAFİƏSİ';
    return [
      {
        stage: 1,
        totalStages: 1,
        title: `Əsas Hücum`,
        objectiveKind: kind,
        objectiveLabel: label,
        objectiveX: ch === 1 ? 1.5 : ch === 2 ? -9.5 : ch === 3 ? 10.5 : 0,
        objectiveZ:
          ch === 1
            ? 2.2
            : ch === 2
              ? 7.5
              : ch === 3
                ? -7.5
                : ch === 5
                  ? -22
                  : ch === 10
                    ? -24
                    : ch === 9
                      ? -12
                      : 0,
        enemyCount: cfg.totalEnemies,
        maxConcurrent: cfg.maxConcurrent,
        spawnInterval: cfg.spawnInterval,
        radioSpeaker:
          ch === 5 || ch === 10
            ? 'Komandir Xəncər'
            : ch % 2 === 1
              ? 'Kapitan Şahin'
              : 'Overwatch',
        radioCallsign:
          ch === 5
            ? 'QARA QARTAL'
            : ch === 10
              ? 'SİNDİKAT LİDERİ'
              : ch % 2 === 1
                ? 'QARTAL-COMMS'
                : 'PEYK DƏSTƏYİ',
        radioText:
          ch === 5 || ch === 10
            ? 'Qala-04 bizə məxsusdur! Mühafizəçilər, onu dayandırın!'
            : 'Qartal-1, sektoru təmizlə və əsas tapşırığı icra et!',
        radioTone: ch === 5 || ch === 10 ? 'enemy' : ch % 2 === 1 ? 'command' : 'ally',
        spawnBoss: ch === 5 || ch === 10,
      },
    ];
  }

  // CoD-style Extended 4-Stage Campaign Operation per Chapter (with Checkpoints)
  const baseCount = 12 + ch * 2;
  const maxConc = Math.min(10, 4 + Math.floor(ch * 0.9));
  const interval = Math.max(0.85, 1.95 - ch * 0.16);

  if (ch === 1) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Giriş Perimetri',
        objectiveKind: 'hold',
        objectiveLabel: 'QALA GİRİŞİ',
        objectiveX: 0,
        objectiveZ: 12,
        enemyCount: baseCount,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Qartal-1, əvvəl giriş xəttini yar və keşikçiləri təmizlə!',
        radioTone: 'command',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Rabitə Terminalı',
        objectiveKind: 'uplink',
        objectiveLabel: 'RABİTƏ TERMİNALI',
        objectiveX: 1.5,
        objectiveZ: 2.2,
        enemyCount: baseCount + 4,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Yoxlama nöqtəsi saxlandı! Yaşıl Rabitə Terminalını bərpa et.',
        radioTone: 'ally',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Diversiya Qarışdırıcısı',
        objectiveKind: 'jammer',
        objectiveLabel: 'QARIŞDIRICI-01',
        objectiveX: -10.5,
        objectiveZ: -4.5,
        enemyCount: baseCount + 6,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.92,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Düşmən siqnalı kəsdi — qırmızı qarışdırıcını atəşlə dağıt!',
        radioTone: 'command',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Helipad Müdafiəsi',
        objectiveKind: 'hold',
        objectiveLabel: 'HELİPAD MƏRKƏZİ',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 8,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.88,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Son dəstə hücuma keçib! Helipadı əlində saxla, dəstək yoldadır!',
        radioTone: 'ally',
      },
    ];
  }

  if (ch === 2) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Səssiz Anbar Sızması',
        objectiveKind: 'uplink',
        objectiveLabel: 'ANBAR TERMİNALI',
        objectiveX: -11,
        objectiveZ: 10,
        enemyCount: baseCount,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Səssiz qalın! Keşikçilərə arxadan [F] bıçaq və ya səsboğucu ilə yaxınlaşın.',
        radioTone: 'command',
        setPieceKind: 'stealth_infil',
        stealthAlertLimit: 100,
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Qarışdırıcı Alpha',
        objectiveKind: 'jammer',
        objectiveLabel: 'QARIŞDIRICI ALPHA',
        objectiveX: -9.5,
        objectiveZ: 7.5,
        enemyCount: baseCount + 4,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Alpha qarışdırıcısı tapıldı — güllə və qumbara ilə partlat!',
        radioTone: 'command',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Dron Sürüsü',
        objectiveKind: 'jammer',
        objectiveLabel: 'DRON ÖTÜRÜCÜSÜ',
        objectiveX: 11,
        objectiveZ: -9,
        enemyCount: baseCount + 6,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.9,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Kamikadze dronları şərqdən qalxır! Ötürücünü sıradan çıxar!',
        radioTone: 'ally',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Çıxış Koordinatı',
        objectiveKind: 'hold',
        objectiveLabel: 'TƏXLİYƏ MEYDANI',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 8,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.85,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Bütün düşmən dəstələrini dəf et və sektordan çıxışı təmin et!',
        radioTone: 'command',
      },
    ];
  }

  if (ch === 3) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Toz Fırtınası Xətti',
        objectiveKind: 'hold',
        objectiveLabel: 'ÖN SƏNGƏR',
        objectiveX: 0,
        objectiveZ: 6,
        enemyCount: baseCount,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Qalxanlı əsgərlər fırtınadan çıxır! Flashbang [X] işlət.',
        radioTone: 'command',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Girovlar & Beta Pozucu',
        objectiveKind: 'jammer',
        objectiveLabel: 'QARIŞDIRICI BETA',
        objectiveX: 10.5,
        objectiveZ: -7.5,
        enemyCount: baseCount + 4,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.94,
        radioSpeaker: 'Çavuş Rəşad',
        radioCallsign: 'ALFA-2',
        radioText: 'Bölmədə girovlar saxlanılır! [E] ilə girovları xilas et və Beta pozucunu vur!',
        radioTone: 'ally',
        setPieceKind: 'hostage_rescue',
        hostageCount: 2,
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Qərargah Şifrələməsi',
        objectiveKind: 'uplink',
        objectiveLabel: 'QƏRARGAH TERMİNALI',
        objectiveX: -6,
        objectiveZ: -12,
        enemyCount: baseCount + 6,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.9,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Ağır zirehliləri vur, sonra şimal-qərb terminalını yüklə!',
        radioTone: 'command',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Zirehli Mühasirə',
        objectiveKind: 'hold',
        objectiveLabel: 'MƏRKƏZİ HELİPAD',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 9,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.85,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'AC-130 Dron [E] və UAV [U] hazırdır — son dalğanı qır!',
        radioTone: 'ally',
      },
    ];
  }

  if (ch === 4) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Uzaq Məsafə Dəstəyi',
        objectiveKind: 'jammer',
        objectiveLabel: 'RADAR POZUCU-A',
        objectiveX: 12,
        objectiveZ: 5,
        enemyCount: baseCount,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Sindikat iki cinahdan gəlir! Uzaqdan nişan alıb şərq radar pozucusunu vur!',
        radioTone: 'ally',
        setPieceKind: 'overwatch_sniper',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Qərb Cinahı Müdafiəsi',
        objectiveKind: 'jammer',
        objectiveLabel: 'RADAR POZUCU-B',
        objectiveX: -12,
        objectiveZ: -6,
        enemyCount: baseCount + 5,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.92,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'İkinci pozucu qərbdədir — snayper lazerlərindən qorun!',
        radioTone: 'command',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Peyk Paketi Yükləməsi',
        objectiveKind: 'uplink',
        objectiveLabel: 'PEYK ÖTÜRÜCÜSÜ',
        objectiveX: 0,
        objectiveZ: -11,
        enemyCount: baseCount + 7,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.88,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Xəncərin koordinatları şimal terminalındadır — yükləməni tamamla!',
        radioTone: 'ally',
        storyChoiceTrigger: 'ch4_mercy_intel',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Təxliyə Dəhlizi',
        objectiveKind: 'hold',
        objectiveLabel: 'HELİPAD SİQNALI',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 10,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.84,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Helipad mərkəzini 100%-ə çatdır — sabah Gecə Əməliyyatına keçirik!',
        radioTone: 'command',
      },
    ];
  }

  if (ch === 5) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Gecə Qapı Partlatması',
        objectiveKind: 'uplink',
        objectiveLabel: 'PROJEKTOR RELESİ',
        objectiveX: -8,
        objectiveZ: 9,
        enemyCount: baseCount,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Gecə Görüşü [N] aç! Qapını partladıb releyi ələ keçir.',
        radioTone: 'command',
        setPieceKind: 'door_breach_slowmo',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · İşıqların Kəsilməsi (Blackout)',
        objectiveKind: 'jammer',
        objectiveLabel: 'GECƏ QARIŞDIRICISI',
        objectiveX: 9.5,
        objectiveZ: -8.5,
        enemyCount: baseCount + 5,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.92,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'EMP işıqları söndürdü! NVG [N] və ya Termal [T] açın və qarışdırıcını partladın!',
        radioTone: 'ally',
        blackout: true,
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Elit Qvardiya Döyüşü',
        objectiveKind: 'hold',
        objectiveLabel: 'MƏRKƏZİ MEYDAN',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 8,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.86,
        radioSpeaker: 'Komandir Xəncər',
        radioCallsign: 'QARA QARTAL',
        radioText: 'Mühafizəçilərimi keçə bilməyəcəksən, əsgər!',
        radioTone: 'enemy',
        blackout: true,
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Komandir Xəncər Finalı',
        objectiveKind: 'boss',
        objectiveLabel: 'HƏDƏF: XƏNCƏR',
        objectiveX: 0,
        objectiveZ: -22,
        enemyCount: baseCount + 10,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.85,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Komandir Xəncər meydandadır! Bütün atəşi üzərinə cəmlə!',
        radioTone: 'command',
        spawnBoss: true,
        bossName: 'Komandir Xəncər',
      },
    ];
  }

  if (ch === 6) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Bunker Tunel Sızması',
        objectiveKind: 'uplink',
        objectiveLabel: 'SEKTOR-7 TERMİNALI',
        objectiveX: -10,
        objectiveZ: 11,
        enemyCount: baseCount,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Yeraltı sığınacağa daxil olduq. Tunel girişini təmin et!',
        radioTone: 'command',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Qapalı Dəhliz Müdafiəsi',
        objectiveKind: 'hold',
        objectiveLabel: 'BUNKER MƏRKƏZİ',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 5,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.9,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Düşmən qaz bombaları atır! Stim [H] istifadə edərək irəlilə.',
        radioTone: 'ally',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Xəyanət Şifrəsi (Mole Reveal)',
        objectiveKind: 'jammer',
        objectiveLabel: 'SİNDİKAT SERVERİ',
        objectiveX: 9,
        objectiveZ: -9,
        enemyCount: baseCount + 7,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.88,
        radioSpeaker: 'Leytenant Tural',
        radioCallsign: 'ALFA-3',
        radioText: 'Serverdə Overwatch şifrəsi çıxdı! Koordinatlarımızı düşmənə o ötürürmüş!',
        radioTone: 'enemy',
        storyChoiceTrigger: 'ch6_mole_confront',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Vaxtlı Bunker Təxliyyəsi',
        objectiveKind: 'hold',
        objectiveLabel: 'ACİL LİFT ÇIXIŞI',
        objectiveX: 0,
        objectiveZ: -20,
        enemyCount: baseCount + 9,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.84,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Bunker özünü məhv edir! 60 saniyəyə acil lift meydanına çat!',
        radioTone: 'command',
        setPieceKind: 'escape_timer',
        escapeTimeSec: 60,
      },
    ];
  }

  if (ch === 7) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Platforma Enişi',
        objectiveKind: 'hold',
        objectiveLabel: 'HELİPAD GÜVERTE',
        objectiveX: 0,
        objectiveZ: 14,
        enemyCount: baseCount,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Overwatch kanalı bağlandı — indi yalnız öz dəstəmizə güvənirik. Güvertəni təmizlə!',
        radioTone: 'command',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Yanacaq Boru Xətti',
        objectiveKind: 'jammer',
        objectiveLabel: 'YANACAQ VANA',
        objectiveX: -11,
        objectiveZ: 2,
        enemyCount: baseCount + 4,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.92,
        radioSpeaker: 'Çavuş Rəşad',
        radioCallsign: 'ALFA-2',
        radioText: 'Düşmən yanacaq xəttini partlatmağa hazırlaşır — vanaları bağla!',
        radioTone: 'ally',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Platforma İdarəetmə Otağı',
        objectiveKind: 'uplink',
        objectiveLabel: 'KOMANDA KONSOLU',
        objectiveX: 10,
        objectiveZ: -6,
        enemyCount: baseCount + 7,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.88,
        radioSpeaker: 'Leytenant Tural',
        radioCallsign: 'ALFA-3',
        radioText: 'İdarəetmə konsolundan köstəbəyin gəmisinin marşrutunu tapdıq!',
        radioTone: 'ally',
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Partlayan Güvertədən Qaçış',
        objectiveKind: 'hold',
        objectiveLabel: 'ANBAR TƏXLİYƏSİ',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 10,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.84,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Platforma yanır! 55 saniyə ərzində təxliyə helipadına yetiş!',
        radioTone: 'command',
        setPieceKind: 'escape_timer',
        escapeTimeSec: 55,
      },
    ];
  }

  if (ch === 8) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Qum Fırtınasında Gizli Sızma',
        objectiveKind: 'hold',
        objectiveLabel: 'MƏBƏD GİRİŞİ',
        objectiveX: 0,
        objectiveZ: 10,
        enemyCount: baseCount + 4,
        maxConcurrent: maxConc,
        spawnInterval: interval,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Qum fırtınasından istifadə edib səssiz irəliləyin — aşkarlansanız pusqu açılacaq!',
        radioTone: 'command',
        setPieceKind: 'stealth_infil',
        stealthAlertLimit: 100,
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Qərb Obeliski Pozucusu',
        objectiveKind: 'jammer',
        objectiveLabel: 'OBELİSK POZUCU',
        objectiveX: -11,
        objectiveZ: 2,
        enemyCount: baseCount + 6,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.92,
        radioSpeaker: 'Çavuş Rəşad',
        radioCallsign: 'ALFA-2',
        radioText: 'Qərb sütunu dibində siqnal boğucusu var — partlat!',
        radioTone: 'ally',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · Əsirlərin Xilası & Terminal',
        objectiveKind: 'uplink',
        objectiveLabel: 'MƏBƏD TERMİNALI',
        objectiveX: 9.5,
        objectiveZ: -9,
        enemyCount: baseCount + 8,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.88,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Səhra məbədində əsir zabitlər var — [E] ilə onları azad et və terminalı aç!',
        radioTone: 'command',
        setPieceKind: 'hostage_rescue',
        hostageCount: 3,
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Günəş Qapısı Müdafiəsi',
        objectiveKind: 'hold',
        objectiveLabel: 'MƏRKƏZİ MEYDAN',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 11,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.84,
        radioSpeaker: 'Leytenant Tural',
        radioCallsign: 'ALFA-3',
        radioText: 'Çöl kolonnaları hücuma keçdi — meydanı əlində saxla!',
        radioTone: 'ally',
      },
    ];
  }

  if (ch === 9) {
    return [
      {
        stage: 1,
        totalStages: 4,
        title: 'Mərhələ 1/4 · Uçuş Zolağı Təmizləməsi',
        objectiveKind: 'hold',
        objectiveLabel: 'ZOLAQ SEKTORU',
        objectiveX: 0,
        objectiveZ: 12,
        enemyCount: baseCount + 5,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.95,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Uçuş zolağına çıxdıq! Zirehli patrulları məhv et.',
        radioTone: 'command',
      },
      {
        stage: 2,
        totalStages: 4,
        title: 'Mərhələ 2/4 · Hangar Radar Pozucusu',
        objectiveKind: 'jammer',
        objectiveLabel: 'HANGAR POZUCU',
        objectiveX: 0,
        objectiveZ: -12,
        enemyCount: baseCount + 7,
        maxConcurrent: maxConc + 1,
        spawnInterval: interval * 0.9,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Hərbi təyyarələrin qaldırılmasının qarşısını al!',
        radioTone: 'ally',
      },
      {
        stage: 3,
        totalStages: 4,
        title: 'Mərhələ 3/4 · İdarə Qülləsi Bağlantısı',
        objectiveKind: 'uplink',
        objectiveLabel: 'RADAR QÜLLƏSİ',
        objectiveX: -12,
        objectiveZ: -8,
        enemyCount: baseCount + 9,
        maxConcurrent: maxConc + 2,
        spawnInterval: interval * 0.86,
        radioSpeaker: 'Kapitan Şahin',
        radioCallsign: 'QARTAL-COMMS',
        radioText: 'Hava məkanını bağlamaq üçün qüllə terminalını yüklə!',
        radioTone: 'command',
        blackout: true,
      },
      {
        stage: 4,
        totalStages: 4,
        title: 'Mərhələ 4/4 · Aerodrom Elit Dəstə',
        objectiveKind: 'hold',
        objectiveLabel: 'UÇUŞ MEYDANI',
        objectiveX: 0,
        objectiveZ: 0,
        enemyCount: baseCount + 12,
        maxConcurrent: maxConc + 2,
        spawnInterval: interval * 0.82,
        radioSpeaker: 'Overwatch',
        radioCallsign: 'PEYK DƏSTƏYİ',
        radioText: 'Son Sindikat qüvvələri zolaqda! Citadel yolunu aç!',
        radioTone: 'ally',
      },
    ];
  }

  // Chapter 10: Ultimate Syndicate Citadel Boss Finale
  return [
    {
      stage: 1,
      totalStages: 4,
      title: 'Mərhələ 1/4 · Sitadel Darvaza Partlatması',
      objectiveKind: 'hold',
      objectiveLabel: 'SİNDİKAT QAPI',
      objectiveX: 0,
      objectiveZ: 15,
      enemyCount: baseCount + 6,
      maxConcurrent: maxConc,
      spawnInterval: interval,
      radioSpeaker: 'Kapitan Şahin',
      radioCallsign: 'QARTAL-COMMS',
      radioText: 'Sindikat baş qərargahındayıq! Darvazanı partladıb Taxt Salonuna gir!',
      radioTone: 'command',
      setPieceKind: 'door_breach_slowmo',
    },
    {
      stage: 2,
      totalStages: 4,
      title: 'Mərhələ 2/4 · Lazer Şəbəkə Otağı',
      objectiveKind: 'jammer',
      objectiveLabel: 'LAZER İDARƏSİ',
      objectiveX: -9,
      objectiveZ: 4,
      enemyCount: baseCount + 8,
      maxConcurrent: maxConc + 1,
      spawnInterval: interval * 0.9,
      radioSpeaker: 'Çavuş Rəşad',
      radioCallsign: 'ALFA-2',
      radioText: 'Lazer tələləri aktivdir! İdarəetmə qutusunu partlat!',
      radioTone: 'ally',
      blackout: true,
    },
    {
      stage: 3,
      totalStages: 4,
      title: 'Mərhələ 3/4 · Elit Qvardiya Hücumu',
      objectiveKind: 'hold',
      objectiveLabel: 'TAXT SALONU',
      objectiveX: 0,
      objectiveZ: -4,
      enemyCount: baseCount + 10,
      maxConcurrent: maxConc + 1,
      spawnInterval: interval * 0.85,
      radioSpeaker: 'Sindikat Lideri',
      radioCallsign: 'SİNDİKAT LİDERİ',
      radioText: 'Overwatch belə səni qoruya bilməyəcək, Qartal-1! Bura mənim qalamdır!',
      radioTone: 'enemy',
      blackout: true,
    },
    {
      stage: 4,
      totalStages: 4,
      title: 'Mərhələ 4/4 · Əsas Sindikat Boss Döyüşü',
      objectiveKind: 'boss',
      objectiveLabel: 'SİNDİKAT LİDERİ',
      objectiveX: 0,
      objectiveZ: -24,
      enemyCount: baseCount + 14,
      maxConcurrent: maxConc + 2,
      spawnInterval: interval * 0.8,
      radioSpeaker: 'Kapitan Şahin',
      radioCallsign: 'QARTAL-COMMS',
      radioText: 'Sindikat lideri qarşındadır! Zərbə anında [F] ilə qılınc duelində qalib gəl!',
      radioTone: 'command',
      spawnBoss: true,
      bossName: 'Sindikat Lideri',
      blackout: true,
      storyChoiceTrigger: 'ch10_leader_fate',
    },
  ];
}

export function getChapterCutscene(
  chapter: number,
  kind: 'intro' | 'climax',
): CutsceneSpec {
  const ch = clampChapterSelection(chapter, MAX_STORY_WAVES);
  const chPad = String(ch).padStart(2, '0');

  if (kind === 'climax') {
    if (ch === 5) {
      return {
        id: `ch${ch}-climax`,
        chapter: ch,
        title: 'SƏHNƏ · KOMANDİR XƏNCƏRİN ÇIXIŞI',
        locationTime: '22:38 · QALA-04 ŞİMAL QAPISI',
        beats: [
          {
            speaker: 'Komandir Xəncər',
            callsign: 'QARA QARTAL',
            subtitle: 'Qala-04 artıq bizim qalamızdır. Bu gecə buradan heç kim sağ çıxmayacaq!',
            camFrom: [-10, 4.2, -30],
            camTo: [0, 3.2, -16],
            lookAt: [0, 1.8, -26],
            duration: 3.4,
          },
          {
            speaker: 'Kapitan Şahin',
            callsign: 'QARTAL-COMMS',
            subtitle: 'Qartal-1, bu bizim şansımızdır! AC-130 Dronu hazır saxla və Xəncəri zərərsizləşdir!',
            camFrom: [12, 5.5, 10],
            camTo: [4, 2.8, 16],
            lookAt: [0, 1.5, -18],
            duration: 3.2,
          },
        ],
      };
    }
    if (ch === 10) {
      return {
        id: `ch${ch}-climax`,
        chapter: ch,
        title: 'FİNAL SƏHNƏ · SİNDİKAT LİDERİ İLƏ ÜZLƏŞMƏ',
        locationTime: '00:15 · QIRMIZI SİTADEL TAXT SALONU',
        beats: [
          {
            speaker: 'Komandir Xəncər',
            callsign: 'SİNDİKAT LİDERİ',
            subtitle: 'Sən bizim imperiyamızın ürəyinə qədər gəldin, Qartal-1... Amma buradan çıxış yoxdur!',
            camFrom: [-14, 5.2, -32],
            camTo: [0, 3.4, -18],
            lookAt: [0, 2.0, -26],
            duration: 3.5,
          },
          {
            speaker: 'Kapitan Şahin',
            callsign: 'QARTAL-COMMS',
            subtitle: 'Bütün atəş gücü sərbəstdir! AC-130 [E], RPG-7 [7] və Taktiki Güclə [O] Sitadeli bitir!',
            camFrom: [14, 6.0, 14],
            camTo: [2, 2.6, 18],
            lookAt: [0, 1.6, -20],
            duration: 3.3,
          },
        ],
      };
    }
    if (ch >= 6 && ch <= 9) {
      const climaxMeta: Record<number, { title: string; loc: string; sub1: string; sub2: string }> = {
        6: {
          title: 'SƏHNƏ · BUNKER LİFTİ TƏXLİYƏSİ',
          loc: '01:20 · SEKTOR-7 YERALTI BUNKERİ',
          sub1: 'Bunker serverləri məhv edildi, lakin elit mühafizəçilər təxliyə liftini mühasirəyə alıb!',
          sub2: 'Qartal-1, lift şaxtasını qoru və səthə çıxış xəttini təmizlə!',
        },
        7: {
          title: 'SƏHNƏ · ATLANTİK QASIRĞASI',
          loc: '04:10 · AÇIQ DƏNİZ NEFT PLATFORMASI',
          sub1: 'Dəniz fırtınası güclənir! Düşmən hücum gəmiləri platformaya əlavə qüvvə çıxarır.',
          sub2: 'Güvertəni son saniyəyə qədər saxla — helikopter dəstəyi yoldadır!',
        },
        8: {
          title: 'SƏHNƏ · QƏDİM MƏBƏD MÜHASİRƏSİ',
          loc: '15:45 · QIZIL ÇÖL MƏBƏDİ',
          sub1: 'Qum fırtınasının içindən Sindikat snayperləri və dronları məbədin mərkəzinə axışır!',
          sub2: 'Sütunların arasından mövqe seç və meydanı azad et!',
        },
        9: {
          title: 'SƏHNƏ · AERODROM SON HÜCUMU',
          loc: '23:30 · HƏRBİ HAVA LİMANI HANGARI',
          sub1: 'Radar qülləsi ələ keçirildi! Düşmən son gücü ilə uçuş zolağını geri almağa çalışır.',
          sub2: 'Bu xətti keçsək, birbaşa Sindikatın əsas Sitadelinə enəcəyik!',
        },
      };
      const m = climaxMeta[ch];
      return {
        id: `ch${ch}-climax`,
        chapter: ch,
        title: m.title,
        locationTime: m.loc,
        beats: [
          {
            speaker: 'Overwatch',
            callsign: 'PEYK DƏSTƏYİ',
            subtitle: m.sub1,
            camFrom: [-18, 9.2, -16],
            camTo: [15, 6.8, 12],
            lookAt: [0, 1.3, 0],
            duration: 3.2,
          },
          {
            speaker: 'Kapitan Şahin',
            callsign: 'QARTAL-COMMS',
            subtitle: m.sub2,
            camFrom: [7, 3.6, 24],
            camTo: [0, 2.2, 18],
            lookAt: [0, 1.5, -6],
            duration: 2.9,
          },
        ],
      };
    }

    return {
      id: `ch${ch}-climax`,
      chapter: ch,
      title: `SƏHNƏ · SON HƏMLƏ (FƏSİL ${chPad})`,
      locationTime: `QALA-04 · MƏRHƏLƏ 4/4`,
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Bütün ehtiyat düşmən qüvvələri əsas meydana yönəlir. Müdafiə mövqeyini möhkəmləndirin!',
          camFrom: [-18, 9.5, -14],
          camTo: [16, 7.0, 14],
          lookAt: [0, 1.2, 0],
          duration: 3.2,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Son mərhələ başladı, Qartal-1! Mövqeni saxla və əməliyyatı tamamla!',
          camFrom: [6, 3.5, 24],
          camTo: [0, 2.2, 18],
          lookAt: [0, 1.5, -6],
          duration: 2.8,
        },
      ],
    };
  }

  // Opening Story Cutscenes per Chapter
  if (ch === 1) {
    return {
      id: 'ch1-intro',
      chapter: 1,
      title: 'FƏSİL 01 · İLKİN TƏMAS',
      locationTime: '05:40 · QALA-04 SƏRHƏD RADAR POSTU',
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK KƏŞFİYYATI',
          subtitle: 'Saat 05:40. Qartal-1 helikopterlə Qala-04 sərhədinə enir. Çavuş Rəşad və Leytenant Tural cinahlardadır!',
          camFrom: [-22, 11, 28],
          camTo: [-10, 6.5, 10],
          lookAt: [0, 4.5, -2],
          duration: 3.5,
          showHeli: true,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Qartal-1, hədəf aydındır: perimetri təmizlə, terminalı bərpa et və helipadı azad et.',
          camFrom: [14, 4.2, 16],
          camTo: [2.5, 2.4, 21],
          lookAt: [0, 1.6, 0],
          duration: 3.3,
        },
      ],
    };
  }

  if (ch === 2) {
    return {
      id: 'ch2-intro',
      chapter: 2,
      title: 'FƏSİL 02 · KÖLGƏ CİNAHI',
      locationTime: '06:15 · KONTEYNER ANBARI SEKTORU',
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Düşmən snayperləri və dronları anbar ərazisinə yerləşib. Alpha qarışdırıcısı siqnalı boğur.',
          camFrom: [20, 9.5, -18],
          camTo: [-14, 5.0, 12],
          lookAt: [-9.5, 1.5, 7.5],
          duration: 3.4,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Səssiz sız, snayper lazerlərindən yayın və Alpha qarışdırıcısını partlat!',
          camFrom: [-8, 3.0, 25],
          camTo: [0, 2.1, 20],
          lookAt: [0, 1.5, -2],
          duration: 3.0,
        },
      ],
    };
  }

  if (ch === 3) {
    return {
      id: 'ch3-intro',
      chapter: 3,
      title: 'FƏSİL 03 · DƏMİR YAĞIŞI',
      locationTime: '17:50 · MƏRKƏZİ QƏRARGAH XƏTTİ',
      beats: [
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Toz fırtınası güclənir. Düşmən Qalxanlı əsgərlər və ağır zirehli dəstə ilə irəliləyir.',
          camFrom: [22, 8.5, 20],
          camTo: [12, 4.5, -12],
          lookAt: [0, 1.4, -4],
          duration: 3.4,
        },
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Flashbang [X] ilə qalxanları aç, 6 məhvdə AC-130 Dron [E] dəstəyini çağır!',
          camFrom: [-14, 4.0, 18],
          camTo: [0, 2.2, 20],
          lookAt: [0, 1.5, 0],
          duration: 3.0,
        },
      ],
    };
  }

  if (ch === 4) {
    return {
      id: 'ch4-intro',
      chapter: 4,
      title: 'FƏSİL 04 · MÜHASİRƏ XƏTTİ',
      locationTime: '18:45 · HELİPAD TƏXLİYƏ MEYDANI',
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Bütün cinahlar təzyiq altındadır. Radar pozucularını dağıtmadan təxliyə mümkün deyil.',
          camFrom: [-20, 11, -18],
          camTo: [16, 7.5, -10],
          lookAt: [0, 1.2, 0],
          duration: 3.4,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Döyüşə hazır ol, Qartal-1! Bu xətti saxlasaq, Xəncərin yerini təsbit edəcəyik.',
          camFrom: [10, 3.8, 24],
          camTo: [0, 2.2, 20],
          lookAt: [0, 1.6, -4],
          duration: 3.0,
        },
      ],
    };
  }

  if (ch === 5) {
    return {
      id: 'ch5-intro',
      chapter: 5,
      title: 'FƏSİL 05 · GECƏ ƏMƏLİYYATI',
      locationTime: '22:10 · QALA-04 GECƏ HÜCUMU',
      beats: [
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Saat 22:10. Gecə Görüş Eynəyi [N] aktivləşdirildi. "Xəncər" bazanın şimalında gizlənir.',
          camFrom: [-20, 10.5, 22],
          camTo: [-10, 5.5, -10],
          lookAt: [0, 1.8, -16],
          duration: 3.5,
        },
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Projektor sektorunu yar, elit qvardiyanı aş və Komandir Xəncərə son qoy!',
          camFrom: [16, 4.5, 16],
          camTo: [0, 2.2, 20],
          lookAt: [0, 1.6, -8],
          duration: 3.2,
        },
      ],
    };
  }

  if (ch === 6) {
    return {
      id: 'ch6-intro',
      chapter: 6,
      title: 'FƏSİL 06 · SEKTOR-7 BUNKERİ',
      locationTime: '00:55 · YERALTI SİNDİKAT BUNKERİ',
      beats: [
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Xəncərin ehtiyat qərargahı yeraltındadır. Zirehli dəhlizlərdən keçərək server nüvəsinə çat!',
          camFrom: [-18, 7.5, 22],
          camTo: [-6, 3.8, 8],
          lookAt: [0, 1.8, -4],
          duration: 3.4,
        },
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Yaxın məsafə toqquşmaları olacaq — [Q] ilə əyilib bax, [O] taktiki qalxanı hazır saxla!',
          camFrom: [12, 3.5, 22],
          camTo: [0, 2.2, 19],
          lookAt: [0, 1.5, -6],
          duration: 3.0,
        },
      ],
    };
  }

  if (ch === 7) {
    return {
      id: 'ch7-intro',
      chapter: 7,
      title: 'FƏSİL 07 · OKEAN PLATFORMASI',
      locationTime: '03:40 · ATLANTİK NEFT PLATFORMASI',
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Fırtınalı okean platformasına eniş edirik! Yanacaq boruları arasında snayperlər gizlənib.',
          camFrom: [-24, 12, 24],
          camTo: [-10, 6.2, 8],
          lookAt: [0, 2.2, -2],
          duration: 3.5,
          showHeli: true,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Sabotaj vanalarını bağla və idarəetmə konsolunu ələ keçir, Qartal-1!',
          camFrom: [16, 4.2, 18],
          camTo: [0, 2.2, 20],
          lookAt: [0, 1.5, -5],
          duration: 3.1,
        },
      ],
    };
  }

  if (ch === 8) {
    return {
      id: 'ch8-intro',
      chapter: 8,
      title: 'FƏSİL 08 · QƏDİM ÇÖL MƏBƏDİ',
      locationTime: '15:10 · QIZIL QUM VADİSİ',
      beats: [
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Sindikat qədim məbəd xarabalıqlarında gizli rabitə mərkəzi qurub. Qızmar qum altında pusqu var!',
          camFrom: [22, 10, 24],
          camTo: [8, 4.8, 6],
          lookAt: [0, 2.0, -8],
          duration: 3.4,
        },
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Daş sütunları örtük kimi işlət, obelisk pozucusunu partlat və terminalı aç!',
          camFrom: [-14, 3.8, 22],
          camTo: [0, 2.2, 19],
          lookAt: [0, 1.6, 0],
          duration: 3.0,
        },
      ],
    };
  }

  if (ch === 9) {
    return {
      id: 'ch9-intro',
      chapter: 9,
      title: 'FƏSİL 09 · HƏRBİ AERODROM',
      locationTime: '23:05 · ŞİMAL AVİASİYA HƏRBİ BAZASI',
      beats: [
        {
          speaker: 'Overwatch',
          callsign: 'PEYK DƏSTƏYİ',
          subtitle: 'Sindikat hərbi nəqliyyat təyyarələrini qaldırmağa hazırlaşır! Uçuş zolağı ağır mühafizə altındadır.',
          camFrom: [-22, 11, -20],
          camTo: [12, 5.2, 10],
          lookAt: [0, 2.0, -10],
          duration: 3.4,
        },
        {
          speaker: 'Kapitan Şahin',
          callsign: 'QARTAL-COMMS',
          subtitle: 'Hangar pozucusunu məhv et, radar qülləsini ələ keçir və Sitadelə gedən yolu aç!',
          camFrom: [12, 3.8, 24],
          camTo: [0, 2.2, 19],
          lookAt: [0, 1.6, -12],
          duration: 3.0,
        },
      ],
    };
  }

  return {
    id: 'ch10-intro',
    chapter: 10,
    title: 'FƏSİL 10 · QIRMIZI SİTADEL FİNALI',
    locationTime: '00:00 · SİNDİKAT BAŞ QƏRARGAHI',
    beats: [
      {
        speaker: 'Komandir Xəncər',
        callsign: 'SİNDİKAT LİDERİ',
        subtitle: 'Qırmızı Sitadelə xoş gəlmisən, Qartal-1! Bütün ordum səni burada gözləyir.',
        camFrom: [-22, 12, 26],
        camTo: [-10, 6.0, 10],
        lookAt: [0, 2.2, -16],
        duration: 3.6,
        showHeli: true,
      },
      {
        speaker: 'Kapitan Şahin',
        callsign: 'QARTAL-COMMS',
        subtitle: 'Bu həlledici döyüşdür! Lazer şəbəkəsini qır, taxt salonuna gir və Sindikata əbədi son qoy!',
        camFrom: [16, 4.5, 18],
        camTo: [0, 2.2, 20],
        lookAt: [0, 1.6, -12],
        duration: 3.3,
      },
    ],
  };
}

export function getWaveBriefing(
  wave: number,
  pace: CampaignPace = 'standard',
): WaveBriefingSpec {
  const cfg = getWaveConfig(wave);
  const stages = getChapterStageSpecs(wave, pace);
  const totalStageEnemies = stages.reduce((sum, s) => sum + s.enemyCount, 0);
  const expectedEnemyTypes: EnemyArchetype[] = [];
  if (cfg.mix.rifleman > 0) expectedEnemyTypes.push('rifleman');
  if (cfg.mix.rusher > 0) expectedEnemyTypes.push('rusher');
  if (cfg.mix.heavy > 0) expectedEnemyTypes.push('heavy');
  if (cfg.mix.sniper > 0) expectedEnemyTypes.push('sniper');
  if (cfg.mix.shield > 0) expectedEnemyTypes.push('shield');
  if (cfg.mix.drone > 0) expectedEnemyTypes.push('drone');

  const stageNote = pace === 'marathon' && cfg.wave <= MAX_STORY_WAVES
    ? ` (4 Mərhələ · Yoxlama Nöqtəli)`
    : '';

  if (cfg.wave === 1) {
    return {
      wave: cfg.wave,
      codeName: 'İLKİN TƏMAS',
      title: `Fəsil 01 · Qulaq Kəsmə${stageNote}`,
      locationTime: '05:40 · QALA-04 SƏRHƏD RADAR POSTU',
      context:
        '"Qara Qartal" diversiya qrupu sərhəd bazasına sızıb və peyk rabitəsini kəsib. 4 mərhələli əməliyyatla giriş xəttini yarın, rabitə terminalını bərpa edin və helipadı azad edin.',
      storyDialogue:
        'Kapitan Şahin: "Qartal-1, bazaya giriş təmizlənməlidir — rabitə terminalını geri almasaq, hava dəstəyi kor qalacaq."',
      primaryObjective: `${totalStageEnemies} keşikçini məhv edin və Rabitə Terminalını bərpa edin`,
      tacticalObjective:
        'Hər mərhələdə yoxlama nöqtəsi saxlanır · Taxta qutulardan sursat çıxarın',
      objectiveKind: 'uplink',
      objectiveLabel: 'RABİTƏ TERMİNALI',
      threatLevel: 'Aşağı',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 2) {
    return {
      wave: cfg.wave,
      codeName: 'KÖLGƏ CİNAHI',
      title: `Fəsil 02 · Səssiz Sızma${stageNote}`,
      locationTime: '06:15 · KONTEYNER ANBARI SEKTORU',
      context:
        'Düşmən snayperləri, kamikadze dronları və hücumçuları anbar arasına siqnal qarışdırıcısı yerləşdirib. 4 döyüş mərhələsini keçin və Alpha qarışdırıcısını sıradan çıxarın.',
      storyDialogue:
        'Overwatch: "Uzaqda snayper lazerləri və havada dronlar görünür! Alpha qarışdırıcısını dağıdın."',
      primaryObjective: `Alpha Qarışdırıcısını məhv edin və ${totalStageEnemies} düşməni zərərsizləşdirin`,
      tacticalObjective:
        'Snayper lazerindən qorunun · Qırmızı Qarışdırıcı qutusunu atəşlə partladın',
      objectiveKind: 'jammer',
      objectiveLabel: 'QARIŞDIRICI ALPHA',
      threatLevel: 'Orta',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 3) {
    return {
      wave: cfg.wave,
      codeName: 'DƏMİR YAĞIŞI',
      title: `Fəsil 03 · Zirehli Təzyiq${stageNote}`,
      locationTime: '17:50 · MƏRKƏZİ QƏRARGAH XƏTTİ',
      context:
        'Axşamçağı toz fırtınası qalxır. Düşmən Qalxanlı əsgərlər, ağır zirehlilər və Beta qarışdırıcısı ilə irəliləyir. Flashbang [X] və Dron zərbəsindən [E] yararlanın.',
      storyDialogue:
        'Kapitan Şahin: "Qalxanlı əsgərlər gəlir! Flashbang [X] atıb onları iflic edin və yanlardan vurun!"',
      primaryObjective: `Beta Qarışdırıcısını dağıdın və ${totalStageEnemies} düşməni məhv edin`,
      tacticalObjective:
        'Qalxanlılara Flashbang [X] atın · [E] ilə bölmədəki 2 girovu azad edin',
      objectiveKind: 'jammer',
      objectiveLabel: 'QARIŞDIRICI BETA',
      threatLevel: 'Yüksək',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 4) {
    return {
      wave: cfg.wave,
      codeName: 'MÜHASİRƏ XƏTTİ',
      title: `Fəsil 04 · Son Xəbərdarlıq${stageNote}`,
      locationTime: '18:45 · HELİPAD TƏXLİYƏ MEYDANI',
      context:
        'Sindikat əsas qüvvələri hər iki cinahdan hücuma keçib. İki radar pozucunu məhv edib Helipad təxliyə siqnalını qoruyun — döyüşdə əsir düşənlər və şifrəli fayl arasında qərar verməli olacaqsınız.',
      storyDialogue:
        'Kapitan Şahin: "Qartal-1, bu sektordakı seçim bütün dəstənin gələcəyini müəyyən edəcək!"',
      primaryObjective: `${totalStageEnemies} hücumçunu dəf edin və Helipad köçürmə nöqtəsini saxlayın`,
      tacticalObjective:
        'Təbii zireh bərpası üçün örtük arxasında gözləyin · [H] Stim və [Q] əyilmə işlədin',
      objectiveKind: 'hold',
      objectiveLabel: 'HELİPAD SİQNALI',
      threatLevel: 'Yüksək',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 5) {
    return {
      wave: cfg.wave,
      codeName: 'XƏNCƏRİN SONU',
      title: `Fəsil 05 · Gecə Əməliyyatı${stageNote}`,
      locationTime: '22:10 · QALA-04 GECƏ HÜCUMU',
      context:
        'Gecə qaranlığında projektorlar yanır. "Qara Qartal" lideri Komandir "Xəncər" şəxsi mühafizəçiləri ilə final döyüşünə girir. Gecə Görüş Eynəyi [N] ilə qapını partladıb onu duelə çəkin.',
      storyDialogue:
        'Komandir Xəncər: "Qala-04 artıq bizimdir, əsgər." — Kapitan Şahin: "Qartal-1, [N] ilə Gecə Görüşünü aç və Xəncəri zərərsizləşdir!"',
      primaryObjective: `Komandir "Xəncər"i və ${totalStageEnemies} mühafizəçini məhv edin`,
      tacticalObjective:
        'Gecə Görüşü [N] açın · Xəncər zəifləyəndə [F] ilə yaxın QTE duelini tamamlayın',
      objectiveKind: 'boss',
      objectiveLabel: 'HƏDƏF: XƏNCƏR',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes: [...expectedEnemyTypes, 'boss'],
    };
  }

  if (cfg.wave === 6) {
    return {
      wave: cfg.wave,
      codeName: 'XƏYANƏT ŞİFRƏSİ',
      title: `Fəsil 06 · Sektor-7 Bunkeri${stageNote}`,
      locationTime: '00:55 · YERALTI SİNDİKAT BUNKERİ',
      context:
        'Beton tunellərdə Sindikatın gizli serverini açanda sarsıdıcı həqiqət üzə çıxır: Overwatch içimizdəki köstəbək imiş. Serveri partladın və 60 saniyəyə bunker liftinə qaçın!',
      storyDialogue:
        'Leytenant Tural: "Koordinatlarımızı Sindikata Overwatch satıb! Tez bunker dağılmadan liftə qaçmalıyıq!"',
      primaryObjective: `Sektor-7 serverlərini sıradan çıxarın və ${totalStageEnemies} düşməni yarıb təxliyə olun`,
      tacticalObjective:
        'Künclərdən [Q] əyilmə ilə atəş açın · Vaxtlı təxliyədə sprintlə [Shift] liftə yetişin',
      objectiveKind: 'uplink',
      objectiveLabel: 'SEKTOR-7 TERMİNALI',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 7) {
    return {
      wave: cfg.wave,
      codeName: 'ATLANTİK FIRTINASI',
      title: `Fəsil 07 · Neft Platforması${stageNote}`,
      locationTime: '03:40 · AÇIQ DƏNİZ NEFT PLATFORMASI',
      context:
        'Overwatch xəyanətindən sonra dəstə tək qalıb. Fırtınalı gecədə okean ortasındakı neft platformasında sabotaj xəttini kəsin və yanacaq çənləri partlamadan helipadə qaçın.',
      storyDialogue:
        'Kapitan Şahin: "İndi özümüzü yalnız özümüz xilas edərik! Termal görüş [T] açın və yaralı yoldaşlara baxın!"',
      primaryObjective: `Platforma konsolunu ələ keçirin və ${totalStageEnemies} düşməni dəf edin`,
      tacticalObjective:
        'Termal görüş [T] ilə dumanda hədəf tapın · Yaralı yoldaşları [E] ilə ayağa qaldırın',
      objectiveKind: 'hold',
      objectiveLabel: 'ANBAR GÜVERTE',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 8) {
    return {
      wave: cfg.wave,
      codeName: 'GÜNƏŞ SÜTUNLARI',
      title: `Fəsil 08 · Qədim Çöl Məbədi${stageNote}`,
      locationTime: '15:10 · QIZIL QUM MƏBƏDİ',
      context:
        'Qum fırtınası içində səssizcə məbəd xarabalıqlarına sızın, əsir düşmüş 3 zabiti azad edin və Sindikatın səhra əlaqə terminalını ələ keçirin.',
      storyDialogue:
        'Kapitan Şahin: "Qızıl qum sütunlarının arxasında səssiz qalın [F], sonra əsir yoldaşlarımızı [E] ilə qurtarın!"',
      primaryObjective: `Girovları xilas edin, terminalı yükləyin və ${totalStageEnemies} düşməni zərərsizləşdirin`,
      tacticalObjective:
        'İlk mərhələdə səssiz Bıçaq [F] və səsboğucu işlədin · Girovları [E] ilə azad edin',
      objectiveKind: 'hold',
      objectiveLabel: 'MƏBƏD GİRİŞİ',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 9) {
    return {
      wave: cfg.wave,
      codeName: 'GÖY QAPISI',
      title: `Fəsil 09 · Hərbi Aerodrom${stageNote}`,
      locationTime: '23:05 · ŞİMAL AVİASİYA HƏRBİ BAZASI',
      context:
        'Sindikatın strateji hava körpüsünü bağlamaq vaxtıdır. Hangar pozucusunu məhv edin, radar qülləsini yükləyin və Sitadelə uçuş yolunu açın.',
      storyDialogue:
        'Çavuş Rəşad: "Uçuş zolağı qarşımızda açılır! Bu döyüşü qazansaq, Sitadelin qapıları bizimdir."',
      primaryObjective: `Hangar pozucusunu məhv edin və ${totalStageEnemies} düşməni dəf edin`,
      tacticalObjective:
        'Yaralı yoldaşları [E] ilə xilas edib dəstə etibarını yüksək saxlayın · Taktiki Güc [O] işlədin',
      objectiveKind: 'jammer',
      objectiveLabel: 'HANGAR POZUCU',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes,
    };
  }

  if (cfg.wave === 10) {
    return {
      wave: cfg.wave,
      codeName: 'QIRMIZI SİTADEL',
      title: `Fəsil 10 · Sindikat Finalı${stageNote}`,
      locationTime: '00:00 · SİNDİKAT BAŞ QƏRARGAHI',
      context:
        'Hekayənin böyük finalı! Qırmızı Sitadelin darvazasını partladın, Elit Qvardiyanı aşın və Sindikat Lideri ilə son qarşıdurmada hekayənin final seçimini verin.',
      storyDialogue:
        'Kapitan Şahin: "Qartal-1, bu bütün əməliyyatın son nöqtəsidir! Seçimlərinə sadiq qal və Sindikata son qoy!"',
      primaryObjective: `Sindikat Liderini və ${totalStageEnemies} elit qvardiyaçını məhv edin`,
      tacticalObjective:
        'RPG-7 [7], Taktiki Güc [O] və son zərbədə [F] duel müqaviməti ilə finalı bitirin',
      objectiveKind: 'boss',
      objectiveLabel: 'SİNDİKAT LİDERİ',
      threatLevel: 'Kritik',
      enemyCount: totalStageEnemies,
      expectedEnemyTypes: [...expectedEnemyTypes, 'boss'],
    };
  }

  return {
    wave: cfg.wave,
    codeName: 'XÜSUSİ ƏMƏLİYYAT',
    title: `Sonsuz Dalğa ${cfg.wave} · Dərin Müdafiə`,
    locationTime: `GECƏ ${cfg.wave} · QALA-04 SEKTORU`,
    context:
      'Əsas hekayə missiyası tamamlanıb, lakin düşmənin əlavə xüsusi təyinatlıları yüksək sürətlə sektoru yenidən ələ keçirməyə çalışır.',
    storyDialogue:
      'Overwatch: "Bütün bölmələrə — sektoru rekord xal üçün maksimum müddət əldə saxlayın!"',
    primaryObjective: `Artan gücdə ${cfg.totalEnemies} düşmənə qarşı sağ qalın`,
    tacticalObjective: 'UAV [U], AC-130 Dron [E] və zireh lövhələri [V] ilə sağ qalın',
    objectiveKind: 'hold',
    objectiveLabel: 'MÖVQE MÜDAFİƏSİ',
    threatLevel: 'Kritik',
    enemyCount: cfg.totalEnemies,
    expectedEnemyTypes,
  };
}

export const MEDAL_LIST: MedalId[] = [
  'first_blood',
  'ghost_stage',
  'sniper_master',
  'boom_master',
  'blade_master',
  'intel_hunter',
  'veteran_hero',
];

export const MEDAL_SPECS: Record<MedalId, MedalSpec> = {
  first_blood: {
    id: 'first_blood',
    title: 'İlk Qan',
    description: 'İlk düşmən hədəfini zərərsizləşdirin',
    xpReward: 100,
  },
  ghost_stage: {
    id: 'ghost_stage',
    title: 'Kabus',
    description: 'Bir döyüş mərhələsini heç zərər almadan tamamlayın',
    xpReward: 250,
  },
  sniper_master: {
    id: 'sniper_master',
    title: 'Snayper Ustası',
    description: 'Cəmi 5 başdan zərbə (Headshot) edin',
    xpReward: 220,
  },
  boom_master: {
    id: 'boom_master',
    title: 'Partlayış Ustası',
    description: 'Qumbara, C4, RPG-7 və ya Dron ilə 4 düşmən məhv edin',
    xpReward: 220,
  },
  blade_master: {
    id: 'blade_master',
    title: 'Səssiz Kölgə',
    description: 'Taktiki Bıçaq [F] ilə 2 yaxın və ya gizli məhv edin',
    xpReward: 240,
  },
  intel_hunter: {
    id: 'intel_hunter',
    title: 'Kəşfiyyatçı',
    description: 'Bütün 10 Fəsildə gizlədilmiş 10 Məlumat Paketini (Intel) toplayın',
    xpReward: 500,
  },
  veteran_hero: {
    id: 'veteran_hero',
    title: 'Qala-04 Qəhrəmanı',
    description: 'Kampaniyada Boss qarşıdurmasını tam qələbə ilə bitirin',
    xpReward: 500,
  },
};

export const INTEL_SPECS: IntelSpec[] = [
  {
    id: 'intel_1',
    chapter: 1,
    title: 'Məlumat #01 · Radar Şifrəsi',
    summary: 'Qara Qartal bölməsi 05:30-da sərhəd radarını daxili icazə kodu ilə söndürüb.',
    x: -18,
    z: 18,
  },
  {
    id: 'intel_2',
    chapter: 2,
    title: 'Məlumat #02 · Anbar Manifesti',
    summary: 'Konteynerlərdə EMP qarışdırıcı komponentləri gizli müqavilə ilə gətirilib.',
    x: 19,
    z: -16,
  },
  {
    id: 'intel_3',
    chapter: 3,
    title: 'Məlumat #03 · Xəncər Planı',
    summary: 'Sindikat Qala-04 qarnizonunun yerini peyk rabitəsi üzərindən izləyirmiş.',
    x: -22,
    z: -2,
  },
  {
    id: 'intel_4',
    chapter: 4,
    title: 'Məlumat #04 · Təxliyə Kodu',
    summary: 'Helipad ötürücüsü bilərəkdən minaatan hədəfinə bağlanıb — qərargahda sızma var.',
    x: 21,
    z: 12,
  },
  {
    id: 'intel_5',
    chapter: 5,
    title: 'Məlumat #05 · Əmr №9',
    summary: 'Komandir Xəncərin son şifrəli zəngi "PEYK DƏSTƏYİ" tezliyindən gəlib.',
    x: 3,
    z: -25,
  },
  {
    id: 'intel_6',
    chapter: 6,
    title: 'Məlumat #06 · Overwatch Xəyanəti',
    summary: 'Overwatch zabiti "Köstəbək" Qartal-1 dəstəsini Sindikata satmaq qarşılığında sığınacaq alıb.',
    x: -14,
    z: -14,
  },
  {
    id: 'intel_7',
    chapter: 7,
    title: 'Məlumat #07 · Atlantik Marşrutu',
    summary: 'Platformadan göndərilən yanacaq gəmiləri birbaşa Qırmızı Sitadelə yanacaq daşıyırmış.',
    x: 15,
    z: 8,
  },
  {
    id: 'intel_8',
    chapter: 8,
    title: 'Məlumat #08 · Səhra Əsirləri',
    summary: 'Qədim məbəddə saxlanılan zabitlər Overwatch-un xəyanətini ifşa edən sübutlara sahibdir.',
    x: -16,
    z: 14,
  },
  {
    id: 'intel_9',
    chapter: 9,
    title: 'Məlumat #09 · Qara Uçuş Planı',
    summary: 'Aerodromdakı gizli reys Sitadelə son müdafiə texnikası çatdırır — yol bağlandı.',
    x: 17,
    z: -15,
  },
  {
    id: 'intel_10',
    chapter: 10,
    title: 'Məlumat #10 · Sindikat Arxivi',
    summary: 'Sitadelin tam sənədləri Overwatch və Sindikat Liderinin bütün şəbəkəsini ələ verir.',
    x: 4,
    z: -22,
  },
];

export const STORY_CHOICES: Record<StoryChoiceId, StoryChoiceSpec> = {
  ch4_mercy_intel: {
    id: 'ch4_mercy_intel',
    chapter: 4,
    speaker: 'Çavuş Rəşad',
    callsign: 'ALFA-2',
    title: 'TƏCİLİ QƏRAR · KƏŞFİYYAT VƏ YA TƏXLİYƏ',
    prompt:
      'Mühafizə qrupunun arxasında yaralı təxliyə ekipajı mühasirədə qalıb, amma şimal terminalında Sindikatın gizli şifrəsi yüklənir.',
    options: [
      {
        index: 0,
        label: 'Yaralı ekipajı təxliyə et',
        consequenceHint: 'Dəstə Etibarı +18 · Mərhəmət və sadiqlik yolu',
        trustDelta: 18,
        tag: 'honor',
      },
      {
        index: 1,
        label: 'Şifrəli peyk faylını zorla götür',
        consequenceHint: 'Dəstə Etibarı -14 · Soyuqqanlı qisas yolu',
        trustDelta: -14,
        tag: 'ruthless',
      },
    ],
  },
  ch6_mole_confront: {
    id: 'ch6_mole_confront',
    chapter: 6,
    speaker: 'Leytenant Tural',
    callsign: 'ALFA-3',
    title: 'XƏYANƏT ÜZLƏŞMƏSİ · OVERWATCH ŞİFRƏSİ',
    prompt:
      'Bunker serverində Overwatch-un Sindikata koordinat satdığı təsdiqləndi. Dəstə xəyanətdən sarsılıb — növbəti addım necə olsun?',
    options: [
      {
        index: 0,
        label: 'Dəstə ilə əl-ələ açıq ədalət quraq',
        consequenceHint: 'Dəstə Etibarı +20 · Dəstə bütövlüyü qorunur',
        trustDelta: 20,
        tag: 'honor',
      },
      {
        index: 1,
        label: 'Bütün sənədləri gizli saxla və qisas planı qur',
        consequenceHint: 'Dəstə Etibarı -18 · Kölgədə təkbaşına hesablaşma',
        trustDelta: -18,
        tag: 'ruthless',
      },
    ],
  },
  ch10_leader_fate: {
    id: 'ch10_leader_fate',
    chapter: 10,
    speaker: 'Kapitan Şahin',
    callsign: 'QARTAL-COMMS',
    title: 'SON SEÇİM · SİNDİKAT LİDERİNİN TALEYİ',
    prompt:
      'Sindikat Lideri diz çöküb və Overwatch-un gizli əlaqələrini etiraf edir. Qırmızı Sitadelin taleyini sən həll edirsən.',
    options: [
      {
        index: 0,
        label: 'Sağ saxla və Hərbi Tribunala təslim et',
        consequenceHint: 'Dəstə Etibarı +12 · Qəhrəmanlıq / Qanuni Zəfər',
        trustDelta: 12,
        tag: 'honor',
      },
      {
        index: 1,
        label: 'Hesabı elə yerində bağla (Məhv et)',
        consequenceHint: 'Dəstə Etibarı -16 · Qisas və ya Xəyanət Sonu',
        trustDelta: -16,
        tag: 'ruthless',
      },
    ],
  },
};

export const STORY_ENDING_LIST: StoryEndingId[] = ['heroic', 'vengeance', 'betrayal'];

export const STORY_ENDINGS: Record<StoryEndingId, StoryEndingSpec> = {
  heroic: {
    id: 'heroic',
    title: 'QƏHRƏMANLIQ SONU · DƏMİR ŞƏRƏF',
    subtitle: 'Dəstə sağ qaldı, girovlar azad edildi və şəbəkə məhkəməyə verildi.',
    epilogue:
      'Qartal-1 dəstəsinin sadiqliyi və vaxtında xilas edilən girovlar sayəsində Overwatch xəyanəti tam sənədlərlə məhkəməyə çıxarıldı. Çavuş Rəşad və Leytenant Tural Qala-04 bayrağını yenidən qaldırdılar.',
    tone: 'emerald',
  },
  vengeance: {
    id: 'vengeance',
    title: 'QİSAS SONU · QANLI HESABLAŞMA',
    subtitle: 'Sindikat Lideri yerində məhv edildi, lakin müharibənin kölgəsi qaldı.',
    epilogue:
      'Qırmızı Sitadel dağıntılar altında qaldı. Sindikat Liderinin sonu qisas hissini söndürsə də, itirilmiş şifrələr və sərt qərarlar dəstə arasında dərin sükut buraxdı.',
    tone: 'amber',
  },
  betrayal: {
    id: 'betrayal',
    title: 'GİZLİ XƏYANƏT SONU · KÖLGƏDƏ TƏK',
    subtitle: 'Dəstə etibarı qırıldı və Overwatch-un gizli sövdələşməsi qaranlıqda qaldı.',
    epilogue:
      'Qartal-1 gizli faylları təkbaşına götürüb Sitadeli tərk etdi. Düşmən lideri susduruldu, amma yaralı yoldaşların itkisi və etibarsızlıq nəticəsində Alfa dəstəsi dağıldı.',
    tone: 'red',
  },
};

export function resolveStoryEnding(
  decisions: readonly StoryDecisionRecord[],
  squadTrust: number,
  hostagesLost = 0,
): StoryEndingSpec {
  const ch6 = decisions.find((d) => d.choiceId === 'ch6_mole_confront');
  const ch10 = decisions.find((d) => d.choiceId === 'ch10_leader_fate');
  const clampedTrust = Math.max(0, Math.min(100, Math.round(squadTrust)));

  if (clampedTrust < 40 || (ch6?.optionIndex === 1 && ch10?.optionIndex === 1 && clampedTrust < 55)) {
    return STORY_ENDINGS.betrayal;
  }
  if (ch10?.optionIndex === 1 || hostagesLost >= 2 || clampedTrust < 65) {
    return STORY_ENDINGS.vengeance;
  }
  return STORY_ENDINGS.heroic;
}

export function getChapterCanonLoadout(chapter: number): [WeaponId, WeaponId] {
  const ch = resolvePlayableChapter(chapter);
  if (ch === 1) return ['m4a1', 'deagle'];
  if (ch === 2) return ['mp5', 'knife'];
  if (ch === 3) return ['scarh', 'spas12'];
  if (ch === 4) return ['msr', 'deagle'];
  if (ch === 5) return ['m4a1', 'knife'];
  if (ch === 6) return ['spas12', 'mp5'];
  if (ch === 7) return ['scarh', 'm249'];
  if (ch === 8) return ['mp5', 'msr'];
  if (ch === 9) return ['m4a1', 'rpg7'];
  return ['scarh', 'rpg7'];
}

export function getSetPieceLabel(kind?: SetPieceKind | null): string {
  switch (kind) {
    case 'stealth_infil':
      return 'GİZLİ SIZMA';
    case 'hostage_rescue':
      return 'GİROV XİLASETMƏ';
    case 'overwatch_sniper':
      return 'UZAQ MƏSAFƏ DƏSTƏYİ';
    case 'escape_timer':
      return 'VAXTLI TƏXLİYƏ';
    case 'door_breach_slowmo':
      return 'QAPI PARTLATMA';
    default:
      return 'TAKTİKİ HÜCUM';
  }
}

export const BUY_STATION_ITEMS: BuyStationItemSpec[] = [
  {
    id: 'ammo',
    title: 'Tam Sursat & Qumbara',
    description: 'Bütün silahları doldurur + 2 Qumbara + 1 Flash',
    cost: 150,
  },
  {
    id: 'explosives',
    title: 'C4 & Claymore Paketi',
    description: '+2 Uzaqdan Partlayan C4 + 2 Claymore Minası',
    cost: 200,
  },
  {
    id: 'juggernaut',
    title: 'Juggernaut Zireh Paketi',
    description: 'Can 100%, Zireh 100% + Zireh Lövhələri',
    cost: 300,
  },
  {
    id: 'care_package',
    title: 'Yardım Paketi (Care Package)',
    description: 'Paraşütlə təsadüfi ağır mükafat (Turet, Juggernaut və ya AC-130)',
    cost: 350,
  },
  {
    id: 'sentry',
    title: 'Avto-Turet Qurğusu',
    description: '35 saniyəlik avtomatik hədəf vuran 3D Turet yerləşdirir',
    cost: 450,
  },
  {
    id: 'ac130',
    title: 'AC-130 Gunship Dəstəyi',
    description: 'Havadan 10 saniyəlik ağır termal top bombardmanı',
    cost: 600,
  },
];

export function computeBossPhase(hp: number, maxHp: number): 1 | 2 | 3 {
  if (maxHp <= 0) return 1;
  const pct = hp / maxHp;
  if (pct <= 0.32) return 3;
  if (pct <= 0.66) return 2;
  return 1;
}

export function purchaseBuyStationItem(
  credits: number,
  itemId: BuyStationItemId,
): { ok: boolean; remainingCredits: number; cost: number } {
  const item = BUY_STATION_ITEMS.find((i) => i.id === itemId);
  if (!item || credits < item.cost) {
    return { ok: false, remainingCredits: credits, cost: item?.cost ?? 0 };
  }
  return {
    ok: true,
    remainingCredits: credits - item.cost,
    cost: item.cost,
  };
}

export function computeStealthTakedownDamage(
  baseMeleeDmg: number,
  distance: number,
  maxRange = 3.4,
  isBehindTarget = false,
): { hit: boolean; damage: number; isStealthKill: boolean } {
  if (distance > maxRange) {
    return { hit: false, damage: 0, isStealthKill: false };
  }
  const mult = isBehindTarget ? 2.5 : 1.0;
  return {
    hit: true,
    damage: Math.round(baseMeleeDmg * mult),
    isStealthKill: isBehindTarget,
  };
}

export function applyStimShot(
  hp: number,
  maxHp: number,
  stims: number,
  healAmount = 45,
): { hp: number; stims: number; applied: boolean } {
  if (stims <= 0) {
    return { hp, stims, applied: false };
  }
  return {
    hp: Math.min(maxHp, Math.max(0, hp) + healAmount),
    stims: stims - 1,
    applied: true,
  };
}

export function computeStanceModifiers(
  isCrouching: boolean,
  isSliding: boolean,
): {
  spreadMult: number;
  speedMult: number;
  incomingAccuracyMult: number;
  eyeHeightOffset: number;
} {
  if (isSliding) {
    return {
      spreadMult: 0.85,
      speedMult: 1.0,
      incomingAccuracyMult: 0.65,
      eyeHeightOffset: -0.68,
    };
  }
  if (isCrouching) {
    return {
      spreadMult: 0.68,
      speedMult: 0.62,
      incomingAccuracyMult: 0.72,
      eyeHeightOffset: -0.55,
    };
  }
  return {
    spreadMult: 1.0,
    speedMult: 1.0,
    incomingAccuracyMult: 1.0,
    eyeHeightOffset: 0,
  };
}

export function pickCarePackageReward(roll: number): {
  id: CarePackageRewardId;
  label: string;
  description: string;
} {
  const r = Math.max(0, Math.min(0.9999, roll));
  if (r < 0.28) {
    return {
      id: 'juggernaut',
      label: 'JUGGERNAUT TƏCHİZATI',
      description: 'Tam Can + 100 Zireh + 2 Stim İynəsi',
    };
  }
  if (r < 0.56) {
    return {
      id: 'sentry',
      label: 'AVTO-TURET QURĞUSU',
      description: '35 saniyəlik avtomatik 3D Turet yerləşdirildi',
    };
  }
  if (r < 0.82) {
    return {
      id: 'arsenal_drop',
      label: 'AĞIR SURSAT & PARTLAYICI',
      description: 'Bütün silahlar tam + RPG-7 + C4 + Qumbara',
    };
  }
  return {
    id: 'ac130',
    label: 'AC-130 GUNSHIP HAZIR!',
    description: 'Havadan 105mm top zərbəsi [Y] aktiv edildi',
  };
}

export function computeGrenadeThreat(
  playerX: number,
  playerZ: number,
  playerYaw: number,
  grenades: readonly { x: number; z: number }[],
  maxWarnDist = 9.0,
): { distanceMeters: number; angleRad: number } | null {
  let closestDist = maxWarnDist;
  let closestAngle = 0;
  let found = false;

  for (const g of grenades) {
    const dx = g.x - playerX;
    const dz = g.z - playerZ;
    const dist = Math.hypot(dx, dz);
    if (dist <= closestDist) {
      closestDist = dist;
      closestAngle = Math.atan2(dx, dz) - playerYaw;
      found = true;
    }
  }

  if (!found) return null;
  return {
    distanceMeters: Math.max(1, Math.round(closestDist)),
    angleRad: closestAngle,
  };
}

export function applyFieldUpgrade(
  type: string,
  stims: number,
  maxStims: number,
): { stims: number; message: string } {
  if (type === 'ammo_box') {
    return {
      stims: Math.min(maxStims, stims + 1),
      message: 'SURSAT QUTUSU: +1 Stim və Tam Güllələr!',
    };
  }
  if (type === 'dead_silence') {
    return {
      stims,
      message: 'SƏSSİZ ADDIM: 15s Ayaq səsləri yoxdur və sürət artdı!',
    };
  }
  return {
    stims,
    message: 'BALLİSTİK QALXAN: Ön sədd aktivləşdirildi!',
  };
}

export function computeFiringRangeScore(hits: number, headshots: number): number {
  return Math.max(0, hits * 100 + headshots * 250);
}

export function computeBombDefusalProgress(current: number, dt: number, holding: boolean): number {
  if (!holding) return Math.max(0, current - dt * 25);
  return Math.min(100, current + dt * 32);
}

export interface FieldUpgradeSpec {
  id: FieldUpgradeId;
  name: string;
  shortName: string;
  description: string;
  cooldownSec: number;
  durationSec: number;
}

export const FIELD_UPGRADE_LIST: FieldUpgradeId[] = [
  'shield',
  'dead_silence',
  'ammo_box',
];

export const FIELD_UPGRADE_SPECS: Record<FieldUpgradeId, FieldUpgradeSpec> = {
  shield: {
    id: 'shield',
    name: 'Ballistik Qalxan',
    shortName: 'QALXAN',
    description: '10 saniyə ön zərbələrin 65%-ni udur və +35 Zireh verir',
    cooldownSec: 28,
    durationSec: 10,
  },
  dead_silence: {
    id: 'dead_silence',
    name: 'Səssiz Addım',
    shortName: 'SƏSSİZ',
    description: '15 saniyə sürəti +28% artırır və düşmənin yayınma nişanını pozur',
    cooldownSec: 25,
    durationSec: 15,
  },
  ammo_box: {
    id: 'ammo_box',
    name: 'Taktiki Sursat Qutusu',
    shortName: 'SURSAT',
    description: 'Bütün silahları tam doldurur, +1 Stim və +1 Qumbara verir',
    cooldownSec: 32,
    durationSec: 1,
  },
};

export function resolveNextLean(current: 'left' | 'right' | 'none'): 'left' | 'right' | 'none' {
  if (current === 'none') return 'left';
  if (current === 'left') return 'right';
  return 'none';
}

export interface BombSiteSpec {
  site: 'A' | 'B';
  label: string;
  x: number;
  z: number;
}

export function getSpecOpsBombSites(): BombSiteSpec[] {
  return [
    { site: 'A', label: 'A NÖQTƏSİ · ŞİMAL-QƏRB KONTEYNER', x: -17, z: -13 },
    { site: 'B', label: 'B NÖQTƏSİ · CƏNUB-ŞƏRQ ANGAR', x: 16, z: 12 },
  ];
}

export interface FiringRangeTargetSpec {
  id: number;
  x: number;
  z: number;
  distanceLabel: string;
  isArmored: boolean;
  isMoving: boolean;
  moveAmplitudeX: number;
  moveSpeed: number;
}

export function getFiringRangeTargets(): FiringRangeTargetSpec[] {
  return [
    { id: 0, x: -7.5, z: -12, distanceLabel: '15m', isArmored: false, isMoving: false, moveAmplitudeX: 0, moveSpeed: 0 },
    { id: 1, x: 7.5, z: -12, distanceLabel: '15m', isArmored: false, isMoving: false, moveAmplitudeX: 0, moveSpeed: 0 },
    { id: 2, x: -4.0, z: -20, distanceLabel: '30m', isArmored: true, isMoving: true, moveAmplitudeX: 3.4, moveSpeed: 1.35 },
    { id: 3, x: 4.0, z: -20, distanceLabel: '30m', isArmored: false, isMoving: true, moveAmplitudeX: 3.8, moveSpeed: 1.75 },
    { id: 4, x: -9.5, z: -28, distanceLabel: '45m', isArmored: true, isMoving: false, moveAmplitudeX: 0, moveSpeed: 0 },
    { id: 5, x: 9.5, z: -28, distanceLabel: '45m', isArmored: true, isMoving: false, moveAmplitudeX: 0, moveSpeed: 0 },
  ];
}

export function resolveModeStartLabel(gameMode: GameMode, selectedChapter: number): string {
  const ch = String(resolvePlayableChapter(selectedChapter)).padStart(2, '0');
  if (gameMode === 'survival') return 'ZOMBİ MÜDAFİƏSİ · BAŞLA';
  if (gameMode === 'firing_range') return 'TƏLİM POLİQONU · BAŞLA';
  if (gameMode === 'spec_ops') return 'XÜSUSİ ƏMƏLİYYAT · BAŞLA';
  return `FƏSİL ${ch} · BAŞLA`;
}


