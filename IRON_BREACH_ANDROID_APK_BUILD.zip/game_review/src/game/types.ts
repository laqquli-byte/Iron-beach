export type GamePhase =
  | 'title'
  | 'briefing'
  | 'cutscene'
  | 'playing'
  | 'paused'
  | 'gameover';

export type GameMode = 'campaign' | 'survival' | 'firing_range' | 'spec_ops';

export type FieldUpgradeId = 'shield' | 'dead_silence' | 'ammo_box';

export type CampaignPace = 'marathon' | 'standard';

export type WeaponId =
  | 'm4a1'
  | 'mp5'
  | 'scarh'
  | 'spas12'
  | 'msr'
  | 'm249'
  | 'deagle'
  | 'rpg7'
  | 'knife';

export type WeaponCamoId = 'standard' | 'desert' | 'cobalt' | 'crimson' | 'gold';

export type AttachmentId = 'suppressor' | 'ext_mag' | 'laser' | 'acog';

export type PerkId = 'fast_reload' | 'heavy_armor' | 'lightweight';

export type DifficultyId = 'recruit' | 'regular' | 'veteran';

export type EnemyArchetype =
  | 'rifleman'
  | 'rusher'
  | 'heavy'
  | 'sniper'
  | 'shield'
  | 'drone'
  | 'zombie'
  | 'boss';

export type MissionObjectiveKind = 'uplink' | 'jammer' | 'hold' | 'boss';

export type SetPieceKind =
  | 'assault'
  | 'stealth_infil'
  | 'hostage_rescue'
  | 'overwatch_sniper'
  | 'escape_timer'
  | 'door_breach_slowmo';

export type StoryChoiceId = 'ch4_mercy_intel' | 'ch6_mole_confront' | 'ch10_leader_fate';

export type StoryEndingId = 'heroic' | 'vengeance' | 'betrayal';

export interface StoryChoiceOption {
  index: 0 | 1;
  label: string;
  consequenceHint: string;
  trustDelta: number;
  tag: 'honor' | 'ruthless' | 'tactical';
}

export interface StoryChoiceSpec {
  id: StoryChoiceId;
  chapter: number;
  speaker: string;
  callsign: string;
  title: string;
  prompt: string;
  options: [StoryChoiceOption, StoryChoiceOption];
}

export interface StoryDecisionRecord {
  choiceId: StoryChoiceId;
  optionIndex: 0 | 1;
  label: string;
  tag: 'honor' | 'ruthless' | 'tactical';
}

export interface StoryEndingSpec {
  id: StoryEndingId;
  title: string;
  subtitle: string;
  epilogue: string;
  tone: 'emerald' | 'amber' | 'red';
}

export interface StoryProgressSave {
  squadTrust: number;
  storyDecisions: StoryDecisionRecord[];
  unlockedEndingIds: StoryEndingId[];
  canonLoadoutEnabled: boolean;
}

export interface BossQteHud {
  bossName: string;
  prompt: string;
  timeLeftSec: number;
  maxTimeSec: number;
  progressPct: number;
  hitsDone: number;
  hitsRequired: number;
}

export interface WoundedAllyHud {
  name: string;
  bleedoutSec: number;
  distanceMeters: number;
}

export type MedalId =
  | 'first_blood'
  | 'ghost_stage'
  | 'sniper_master'
  | 'boom_master'
  | 'blade_master'
  | 'intel_hunter'
  | 'veteran_hero';

export type BuyStationItemId =
  | 'ammo'
  | 'juggernaut'
  | 'sentry'
  | 'explosives'
  | 'care_package'
  | 'ac130';

export type CarePackageRewardId = 'juggernaut' | 'sentry' | 'arsenal_drop' | 'ac130';

export interface MedalSpec {
  id: MedalId;
  title: string;
  description: string;
  xpReward: number;
}

export interface IntelSpec {
  id: string;
  chapter: number;
  title: string;
  summary: string;
  x: number;
  z: number;
}

export interface BuyStationItemSpec {
  id: BuyStationItemId;
  title: string;
  description: string;
  cost: number;
}

export interface CutsceneBeat {
  speaker: string;
  callsign: string;
  subtitle: string;
  camFrom: [number, number, number];
  camTo: [number, number, number];
  lookAt: [number, number, number];
  duration: number;
  showHeli?: boolean;
}

export interface CutsceneSpec {
  id: string;
  chapter: number;
  title: string;
  locationTime: string;
  beats: CutsceneBeat[];
}

export interface ChapterStageSpec {
  stage: number;
  totalStages: number;
  title: string;
  objectiveKind: MissionObjectiveKind;
  objectiveLabel: string;
  objectiveX: number;
  objectiveZ: number;
  enemyCount: number;
  maxConcurrent: number;
  spawnInterval: number;
  radioSpeaker: string;
  radioCallsign: string;
  radioText: string;
  radioTone: 'ally' | 'command' | 'enemy';
  spawnBoss?: boolean;
  bossName?: string;
  blackout?: boolean;
  setPieceKind?: SetPieceKind;
  hostageCount?: number;
  escapeTimeSec?: number;
  stealthAlertLimit?: number;
  storyChoiceTrigger?: StoryChoiceId;
  canonWeapon?: WeaponId;
}

export interface WeaponCamoSpec {
  id: WeaponCamoId;
  name: string;
  shortName: string;
  swatchHex: string;
  accentHex: string;
  receiverHex: number;
  polymerHex: number;
  metalness: number;
  roughness: number;
  unlockType: 'default' | 'kills' | 'headshots' | 'score';
  unlockThreshold: number;
  unlockLabel: string;
}

export interface AttachmentSpec {
  id: AttachmentId;
  name: string;
  shortName: string;
  description: string;
}

export interface PerkSpec {
  id: PerkId;
  name: string;
  shortName: string;
  description: string;
}

export interface DifficultySpec {
  id: DifficultyId;
  name: string;
  description: string;
  enemyHpScale: number;
  enemyDamageScale: number;
  xpMult: number;
  minimalHud: boolean;
}

export interface CareerStats {
  totalKills: number;
  totalHeadshots: number;
  bestScore: number;
  totalExplosiveKills: number;
  xp: number;
  completedChallengeIds: string[];
}

export interface RankInfo {
  level: number;
  title: string;
  xp: number;
  currentFloorXp: number;
  nextLevelXp: number;
  progressPct: number;
}

export interface ChallengeSpec {
  id: string;
  title: string;
  metric: 'kills' | 'headshots' | 'explosives';
  target: number;
  xpReward: number;
}

export interface WeaponSpec {
  id: WeaponId;
  name: string;
  role: string;
  damage: number;
  pellets?: number;
  headshotMult: number;
  fireRate: number; // rounds per second
  magSize: number;
  maxReserve: number;
  reloadDuration: number; // seconds
  hipSpread: number; // radians
  adsSpread: number; // radians
  recoilPitch: number; // radians per shot
  recoilYaw: number;
  range: number;
  adsFov: number;
  isMelee?: boolean;
  isExplosive?: boolean;
}

export interface WeaponState {
  id: WeaponId;
  mag: number;
  reserve: number;
}

export interface Aabb2D {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  height: number;
  label?: string;
}

export interface RadarBlip {
  x: number;
  z: number;
  archetype: EnemyArchetype | 'ally' | 'sentry';
}

export interface ProjectedEnemyMarker {
  id: number;
  xPct: number;
  yPct: number;
  hpPct: number;
  archetype: EnemyArchetype;
  stunned?: boolean;
  stealthUnaware?: boolean;
}

export interface KillFeedItem {
  id: number;
  text: string;
  isHeadshot: boolean;
  timestamp: number;
}

export interface HudSnapshot {
  phase: GamePhase;
  gameMode: GameMode;
  outcome: 'victory' | 'defeat' | null;
  hp: number;
  maxHp: number;
  armor: number;
  maxArmor: number;
  wave: number;
  maxWaves: number;
  enemiesRemaining: number;
  waveBanner: string | null;
  comboBanner: string | null;
  score: number;
  bestScore: number;
  credits: number;
  kills: number;
  headshots: number;
  shotsFired: number;
  shotsHit: number;
  grenades: number;
  flashbangs: number;
  c4Count: number;
  c4PlantedCount: number;
  claymoreCount: number;
  killstreakProgress: number; // 0..6
  killstreakThreshold: number; // 6 for Heavy Drone Strike
  uavThreshold: number; // 3 for UAV Sweep
  uavReady: boolean;
  uavActiveTimer: number;
  killstreakReady: boolean;
  gunshipReady: boolean;
  gunshipActive: boolean;
  gunshipTimer: number;
  gunshipShells: number;
  mountedTurret: boolean;
  thermalActive: boolean;
  blackoutActive: boolean;
  breachSlowMoTimer: number;
  sentryActiveCount: number;
  carePackageReady: boolean;
  carePackageActive: boolean;
  stims: number;
  maxStims: number;
  stimBoostTimer: number;
  isCrouching: boolean;
  isInspecting: boolean;
  lean: 'left' | 'right' | 'none';
  isLastStand: boolean;
  selfReviveKit: boolean;
  fieldUpgrade: FieldUpgradeId;
  fieldUpgradeCooldownPct: number;
  fieldUpgradeActiveTimer: number;
  sensitivity: number;
  fov: number;
  volume: number;
  touchControlsEnabled: boolean;
  bombObjective: {
    active: boolean;
    site: 'A' | 'B';
    progress: number;
    timer: number;
  } | null;
  firingRangeStats: {
    hits: number;
    headshots: number;
    score: number;
    accuracyPct: number;
  } | null;
  grenadeWarning: {
    distanceMeters: number;
    angleRad: number;
  } | null;
  buyStationOpen: boolean;
  interactPrompt: {
    kind: 'intel' | 'breach' | 'turret' | 'care_package' | 'hostage' | 'revive_ally';
    label: string;
  } | null;
  bossPhase: 1 | 2 | 3 | null;
  allySquad: {
    name: string;
    hpPct: number;
    downed?: boolean;
  }[];
  unlockedMedalIds: MedalId[];
  medalBanner: {
    title: string;
    description: string;
  } | null;
  collectedIntelIds: string[];
  activeWeapon: WeaponId;
  loadoutWeapons: [WeaponId, WeaponId];
  weapons: Record<WeaponId, WeaponState>;
  reloading: boolean;
  reloadProgress: number; // 0..1
  isAds: boolean;
  isSprinting: boolean;
  isSliding: boolean;
  isNvgActive: boolean;
  slideCooldownPct: number; // 0..1 (1 = ready)
  crosshairSpread: number; // pixels
  hitmarkerKind: 'none' | 'hit' | 'kill';
  damageFlash: number; // 0..1
  damageDirectionAngle: number | null; // radians relative to player forward
  playerX: number;
  playerZ: number;
  playerYaw: number;
  radarEnemies: RadarBlip[];
  projectedEnemies: ProjectedEnemyMarker[];
  killFeed: KillFeedItem[];
  autoFire: boolean;
  elapsedTime: number;
  pointerLocked: boolean;
  careerStats: CareerStats;
  rankInfo: RankInfo;
  equippedCamos: Record<WeaponId, WeaponCamoId>;
  equippedAttachments: Record<WeaponId, AttachmentId[]>;
  selectedPerk: PerkId;
  selectedDifficulty: DifficultyId;
  campaignPace: CampaignPace;
  chapterStage: number;
  chapterTotalStages: number;
  checkpointStage: number;
  checkpointBanner: string | null;
  cutscene: {
    title: string;
    locationTime: string;
    speaker: string;
    callsign: string;
    subtitle: string;
    beatIndex: number;
    totalBeats: number;
  } | null;
  unlockedChapter: number;
  armorPlates: number;
  maxArmorPlates: number;
  compassHeadingDeg: number;
  activeObjectiveText: string;
  objectiveStage: 'combat' | 'interact' | 'boss' | 'done';
  objectiveProgressPct: number;
  objectiveWaypoint: {
    label: string;
    distanceMeters: number;
    xPct: number;
    yPct: number;
    clamped: boolean;
    kind: MissionObjectiveKind;
  } | null;
  radioMessage: {
    speaker: string;
    callsign: string;
    text: string;
    tone: 'ally' | 'command' | 'enemy';
  } | null;
  canonLoadoutEnabled: boolean;
  activeStoryChoice: StoryChoiceSpec | null;
  storyDecisions: StoryDecisionRecord[];
  squadTrust: number;
  unlockedEndingIds: StoryEndingId[];
  activeEnding: StoryEndingSpec | null;
  setPieceKind: SetPieceKind | null;
  hostagesAlive: number;
  hostagesRescued: number;
  hostagesTotal: number;
  woundedAlly: WoundedAllyHud | null;
  escapeTimerSec: number | null;
  stealthSuspicionPct: number;
  stealthDetected: boolean;
  bossQte: BossQteHud | null;
}

export interface WaveConfig {
  wave: number;
  totalEnemies: number;
  maxConcurrent: number;
  spawnInterval: number;
  mix: {
    rifleman: number;
    rusher: number;
    heavy: number;
    sniper: number;
    shield: number;
    drone: number;
    zombie: number;
  };
  speedScale: number;
  damageScale: number;
}

export interface WaveBriefingSpec {
  wave: number;
  codeName: string;
  title: string;
  locationTime: string;
  context: string;
  storyDialogue: string;
  primaryObjective: string;
  tacticalObjective: string;
  objectiveKind: MissionObjectiveKind;
  objectiveLabel: string;
  threatLevel: 'Aşağı' | 'Orta' | 'Yüksək' | 'Kritik';
  enemyCount: number;
  expectedEnemyTypes: EnemyArchetype[];
}
