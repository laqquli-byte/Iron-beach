import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BUY_STATION_ITEMS,
  CHALLENGE_SPECS,
  DIFFICULTY_SPECS,
  FIELD_UPGRADE_LIST,
  FIELD_UPGRADE_SPECS,
  INTEL_SPECS,
  MAX_STORY_WAVES,
  MEDAL_LIST,
  MEDAL_SPECS,
  STORY_CHOICES,
  STORY_ENDING_LIST,
  STORY_ENDINGS,
  WEAPON_LIST,
  WEAPON_SPECS,
  applyArmorPlate,
  applyFieldUpgrade,
  applyPlayerDamage,
  applyReload,
  applyStimShot,
  computeBombDefusalProgress,
  computeFiringRangeScore,
  clampChapterSelection,
  computeAccuracyPct,
  computeBossPhase,
  computeCompassHeadingDeg,
  computeExplosionDamage,
  computeGrenadeThreat,
  computeRankFromXp,
  computeShotDamage,
  computeStanceModifiers,
  computeStealthTakedownDamage,
  computeTargetPixelRatio,
  createDefaultCareerStats,
  getCamoProgress,
  getChallengeProgress,
  getChapterCanonLoadout,
  getChapterCutscene,
  getChapterStageSpecs,
  getComboLabel,
  getEffectiveWeaponSpec,
  getFiringRangeTargets,
  getSetPieceLabel,
  resolveStoryEnding,
  getLoadoutPair,
  getNewlyUnlockedCamos,
  getSpecOpsBombSites,
  getUnlockedCamoIds,
  getWaveBriefing,
  getWaveConfig,
  isCamoUnlocked,
  pickArchetypeForWave,
  pickCarePackageReward,
  purchaseBuyStationItem,
  resolveAllCollisions,
  resolveCircleAabbCollision,
  resolveModeStartLabel,
  resolveNextLean,
  resolvePlayableChapter,
  sanitizeEquippedAttachments,
  sanitizeEquippedCamos,
} from './rules';
import type { Aabb2D, CareerStats } from './types';

test('computeShotDamage applies headshot multiplier and distance falloff', () => {
  const m4 = WEAPON_SPECS.m4a1;
  const scar = WEAPON_SPECS.scarh;
  const msr = WEAPON_SPECS.msr;
  const bodyClose = computeShotDamage(m4, 10, false);
  const headClose = computeShotDamage(m4, 10, true);
  const bodyFar = computeShotDamage(m4, m4.range, false);

  assert.equal(bodyClose, m4.damage);
  assert.equal(headClose, Math.round(m4.damage * m4.headshotMult));
  assert.ok(bodyFar < bodyClose);
  assert.ok(bodyFar >= Math.round(m4.damage * 0.55));
  assert.ok(computeShotDamage(scar, 15, true) > headClose);
  assert.equal(computeShotDamage(msr, 25, true), Math.round(msr.damage * msr.headshotMult));
  assert.equal(WEAPON_SPECS.spas12.pellets, 6);
});

test('getEffectiveWeaponSpec applies Gunsmith attachments and fast_reload perk cleanly', () => {
  const base = WEAPON_SPECS.m4a1;
  const modded = getEffectiveWeaponSpec('m4a1', ['ext_mag', 'laser', 'acog', 'suppressor'], 'fast_reload');
  assert.equal(modded.magSize, Math.round(base.magSize * 1.4));
  assert.equal(modded.maxReserve, Math.round(base.maxReserve * 1.4));
  assert.ok(modded.hipSpread < base.hipSpread * 0.65);
  assert.ok(modded.adsFov < base.adsFov);
  assert.ok(modded.range > base.range);
  assert.ok(modded.reloadDuration < base.reloadDuration);

  const sanitized = sanitizeEquippedAttachments({
    m4a1: ['laser', 'laser', 'suppressor'],
    msr: ['acog'],
  });
  assert.deepEqual(sanitized.m4a1, ['laser', 'suppressor']);
  assert.deepEqual(sanitized.msr, ['acog']);
  assert.deepEqual(sanitized.spas12, []);
});

test('getLoadoutPair pairs primary weapon with SMG or M4A1', () => {
  assert.deepEqual(getLoadoutPair('m4a1'), ['m4a1', 'mp5']);
  assert.deepEqual(getLoadoutPair('scarh'), ['scarh', 'mp5']);
  assert.deepEqual(getLoadoutPair('spas12'), ['spas12', 'mp5']);
  assert.deepEqual(getLoadoutPair('msr'), ['msr', 'mp5']);
  assert.deepEqual(getLoadoutPair('mp5'), ['mp5', 'm4a1']);
});

test('getComboLabel returns multi-kill callouts at thresholds', () => {
  assert.equal(getComboLabel(1), null);
  assert.equal(getComboLabel(2), 'İKİLİ MƏHV!');
  assert.equal(getComboLabel(3), 'ÜÇLÜ MƏHV!');
  assert.equal(getComboLabel(5), 'DÖRDQAT MƏHV!');
});

test('applyReload transfers only needed rounds from reserve', () => {
  const m4 = WEAPON_SPECS.m4a1;
  const partial = applyReload({ id: 'm4a1', mag: 18, reserve: 60 }, m4);
  assert.equal(partial.mag, 30);
  assert.equal(partial.reserve, 48);

  const lowReserve = applyReload({ id: 'm4a1', mag: 5, reserve: 10 }, m4);
  assert.equal(lowReserve.mag, 15);
  assert.equal(lowReserve.reserve, 0);

  const alreadyFull = applyReload({ id: 'm4a1', mag: 30, reserve: 60 }, m4);
  assert.equal(alreadyFull.mag, 30);
  assert.equal(alreadyFull.reserve, 60);
});

test('applyPlayerDamage splits absorption with armor and floors at zero', () => {
  const hit1 = applyPlayerDamage(100, 50, 20);
  assert.equal(hit1.armor, 39);
  assert.equal(hit1.hp, 91);

  const lethal = applyPlayerDamage(10, 0, 50);
  assert.equal(lethal.hp, 0);
  assert.equal(lethal.armor, 0);
});

test('computeExplosionDamage drops off smoothly to zero outside blast radius', () => {
  const center = computeExplosionDamage(0, 6.5, 150);
  const mid = computeExplosionDamage(3.25, 6.5, 150);
  const edge = computeExplosionDamage(7.0, 6.5, 150);

  assert.equal(center, 150);
  assert.ok(mid > 0 && mid < center);
  assert.equal(edge, 0);
});

test('getWaveConfig scales enemy count, speed, and includes sniper/shield/drone archetypes', () => {
  const w1 = getWaveConfig(1);
  const w3 = getWaveConfig(3);
  const w5 = getWaveConfig(5);

  assert.ok(w1.totalEnemies < w3.totalEnemies);
  assert.ok(w3.totalEnemies < w5.totalEnemies);
  assert.equal(w1.mix.heavy, 0);
  assert.ok(w5.mix.heavy > 0.15);
  assert.ok(w3.mix.shield > 0);
  assert.ok(w3.mix.sniper > 0);
  assert.ok(w3.mix.drone > 0);
  assert.equal(pickArchetypeForWave(1, 0.1), 'rifleman');
  assert.equal(pickArchetypeForWave(5, 0.99), 'drone');
});

test('resolveCircleAabbCollision pushes entity outside obstacle and arena bounds', () => {
  const box: Aabb2D = { minX: -2, maxX: 2, minZ: -2, maxZ: 2, height: 2.5 };
  const pushed = resolveCircleAabbCollision(1.9, 0, 0.55, box);
  assert.equal(pushed.collided, true);
  assert.ok(pushed.x >= 2.549);

  const clamped = resolveAllCollisions(100, -100, 0.55, [box], 38);
  assert.ok(clamped.x <= 37.45);
  assert.ok(clamped.z >= -37.45);
});

test('computeAccuracyPct handles zero shots safely', () => {
  assert.equal(computeAccuracyPct(0, 0), 0);
  assert.equal(computeAccuracyPct(20, 10), 50);
  assert.equal(computeAccuracyPct(10, 15), 100);
});

test('computeTargetPixelRatio caps high-DPR phones to crisp 720p render budget', () => {
  assert.equal(computeTargetPixelRatio(390, 844, 3, true, '720p'), 1);
  const mobile720 = computeTargetPixelRatio(390, 844, 3, false, '720p');
  assert.ok(Math.abs(mobile720 * 390 - 720) < 2);
  assert.equal(computeTargetPixelRatio(390, 844, 3, false, 'ultra'), 2);
  assert.equal(computeTargetPixelRatio(1440, 900, 2, false, '720p'), 1);
});

test('weapon camo unlock thresholds, newly unlocked detection, and sanitization', () => {
  const rookie: CareerStats = createDefaultCareerStats(0);
  assert.deepEqual(getUnlockedCamoIds(rookie), ['standard']);
  assert.equal(isCamoUnlocked('desert', rookie), false);
  assert.deepEqual(getCamoProgress('desert', { ...rookie, totalKills: 3 }), {
    unlocked: false,
    current: 3,
    target: 5,
  });

  const mid: CareerStats = {
    ...rookie,
    totalKills: 6,
    totalHeadshots: 3,
    bestScore: 1600,
  };
  assert.deepEqual(getNewlyUnlockedCamos(rookie, mid), ['desert', 'cobalt', 'crimson']);
  assert.equal(isCamoUnlocked('gold', mid), false);

  const sanitized = sanitizeEquippedCamos(
    { m4a1: 'desert', mp5: 'gold', scarh: 'cobalt', spas12: 'crimson', msr: 'gold' },
    mid,
  );
  assert.deepEqual(sanitized, {
    m4a1: 'desert',
    mp5: 'standard',
    scarh: 'cobalt',
    spas12: 'crimson',
    msr: 'standard',
    m249: 'standard',
    deagle: 'standard',
    rpg7: 'standard',
    knife: 'standard',
  });
});

test('getWaveBriefing aligns enemy count and archetypes with wave config', () => {
  const b1 = getWaveBriefing(1);
  assert.equal(b1.wave, 1);
  assert.equal(b1.enemyCount, getWaveConfig(1).totalEnemies);
  assert.equal(b1.threatLevel, 'Aşağı');
  assert.deepEqual(b1.expectedEnemyTypes, ['rifleman', 'rusher']);
  assert.ok(b1.primaryObjective.includes(String(b1.enemyCount)));

  const b3 = getWaveBriefing(3);
  assert.equal(b3.threatLevel, 'Yüksək');
  assert.equal(b3.objectiveKind, 'jammer');
  assert.ok(b3.expectedEnemyTypes.includes('shield'));
  assert.ok(b3.expectedEnemyTypes.includes('sniper'));
  assert.ok(b3.expectedEnemyTypes.includes('drone'));

  const b5 = getWaveBriefing(5);
  assert.equal(b5.objectiveKind, 'boss');
  assert.ok(b5.expectedEnemyTypes.includes('boss'));

  const b6 = getWaveBriefing(6);
  assert.equal(b6.wave, 6);
  assert.equal(b6.threatLevel, 'Kritik');
  assert.equal(b6.enemyCount, getWaveConfig(6).totalEnemies);
});

test('computeRankFromXp, getChallengeProgress, and DIFFICULTY_SPECS behave deterministically', () => {
  const r1 = computeRankFromXp(0);
  assert.equal(r1.level, 1);
  assert.equal(r1.title, 'Əsgər');
  assert.equal(r1.progressPct, 0);

  const r2 = computeRankFromXp(525);
  assert.equal(r2.level, 2);
  assert.equal(r2.title, 'Onbaşı');
  assert.equal(r2.progressPct, 50);

  const maxR = computeRankFromXp(9999);
  assert.equal(maxR.level, 7);
  assert.equal(maxR.title, 'Polkovnik');
  assert.equal(maxR.progressPct, 100);

  const stats: CareerStats = {
    totalKills: 12,
    totalHeadshots: 10,
    bestScore: 900,
    totalExplosiveKills: 4,
    xp: 600,
    completedChallengeIds: [],
  };
  const headChal = getChallengeProgress(CHALLENGE_SPECS[0], stats);
  assert.equal(headChal.completed, true);
  assert.equal(headChal.current, 10);

  const expChal = getChallengeProgress(CHALLENGE_SPECS[1], stats);
  assert.equal(expChal.completed, false);
  assert.equal(expChal.current, 4);

  assert.ok(DIFFICULTY_SPECS.veteran.enemyDamageScale > DIFFICULTY_SPECS.regular.enemyDamageScale);
  assert.equal(DIFFICULTY_SPECS.veteran.minimalHud, true);
});

test('applyArmorPlate, computeCompassHeadingDeg, and clampChapterSelection behave deterministically', () => {
  const plated = applyArmorPlate(20, 50, 2, 35);
  assert.deepEqual(plated, { armor: 50, plates: 1, applied: true });

  const full = applyArmorPlate(50, 50, 2, 35);
  assert.deepEqual(full, { armor: 50, plates: 2, applied: false });

  const empty = applyArmorPlate(10, 50, 0, 35);
  assert.deepEqual(empty, { armor: 10, plates: 0, applied: false });

  assert.equal(computeCompassHeadingDeg(0), 0);
  assert.equal(computeCompassHeadingDeg(-Math.PI / 2), 90);
  assert.equal(computeCompassHeadingDeg(Math.PI / 2), 270);

  assert.equal(clampChapterSelection(4, 2), 2);
  assert.equal(clampChapterSelection(2, 5), 2);
  assert.equal(clampChapterSelection(0, 3), 1);
});

test('getChapterStageSpecs and getChapterCutscene provide 4-stage CoD missions and 3D scenes', () => {
  const marathonCh1 = getChapterStageSpecs(1, 'marathon');
  assert.equal(marathonCh1.length, 4);
  assert.equal(marathonCh1[0].totalStages, 4);
  const totalMarathon = marathonCh1.reduce((acc, s) => acc + s.enemyCount, 0);
  assert.ok(totalMarathon >= 60);

  const marathonCh5 = getChapterStageSpecs(5, 'marathon');
  assert.equal(marathonCh5.length, 4);
  assert.equal(marathonCh5[3].spawnBoss, true);

  const quickCh1 = getChapterStageSpecs(1, 'standard');
  assert.equal(quickCh1.length, 1);
  assert.equal(quickCh1[0].enemyCount, getWaveConfig(1).totalEnemies);

  const intro1 = getChapterCutscene(1, 'intro');
  assert.ok(intro1.beats.length >= 2);
  assert.ok(intro1.beats[0].duration > 0);

  const climax5 = getChapterCutscene(5, 'climax');
  assert.ok(climax5.title.includes('XƏNCƏR'));
  assert.ok(climax5.beats.length >= 2);
});

test('expanded 9-weapon roster includes M249, Deagle, RPG-7, and Knife with valid specs', () => {
  assert.equal(WEAPON_LIST.length, 9);
  assert.equal(WEAPON_SPECS.m249.magSize, 100);
  assert.equal(WEAPON_SPECS.deagle.magSize, 7);
  assert.equal(WEAPON_SPECS.rpg7.isExplosive, true);
  assert.equal(WEAPON_SPECS.knife.isMelee, true);
  assert.ok(WEAPON_SPECS.rpg7.damage >= 200);
});

test('survival wave config spawns zombies and Buy Station purchases validate credits', () => {
  const s1 = getWaveConfig(1, 'survival');
  assert.ok(s1.mix.zombie > 0.5);
  assert.equal(pickArchetypeForWave(1, 0.9, 'survival'), 'zombie');

  const buyOk = purchaseBuyStationItem(500, 'sentry');
  assert.equal(buyOk.ok, true);
  assert.equal(buyOk.remainingCredits, 50);

  const buyFail = purchaseBuyStationItem(200, 'ac130');
  assert.equal(buyFail.ok, false);
  assert.equal(buyFail.remainingCredits, 200);
  assert.ok(BUY_STATION_ITEMS.length >= 5);
});

test('boss phases, stealth takedown, medals, and intel specs are deterministic', () => {
  assert.equal(computeBossPhase(620, 620), 1);
  assert.equal(computeBossPhase(380, 620), 2);
  assert.equal(computeBossPhase(150, 620), 3);

  const stealthBack = computeStealthTakedownDamage(140, 2.2, 3.4, true);
  assert.equal(stealthBack.hit, true);
  assert.equal(stealthBack.isStealthKill, true);
  assert.equal(stealthBack.damage, 350);

  const missFar = computeStealthTakedownDamage(140, 4.5, 3.4, true);
  assert.equal(missFar.hit, false);

  assert.equal(MEDAL_LIST.length, 7);
  assert.ok(MEDAL_SPECS.veteran_hero.xpReward >= 400);
  assert.equal(INTEL_SPECS.length, 10);
});

test('free chapter resolution, Stim Shot, Crouch stance, Care Package, and Grenade threat helpers work deterministically', () => {
  assert.equal(resolvePlayableChapter(1), 1);
  assert.equal(resolvePlayableChapter(3), 3);
  assert.equal(resolvePlayableChapter(5), 5);
  assert.equal(resolvePlayableChapter(99), 10);
  assert.equal(resolvePlayableChapter(0), 1);

  const stimmed = applyStimShot(40, 100, 2, 45);
  assert.deepEqual(stimmed, { hp: 85, stims: 1, applied: true });
  const stimEmpty = applyStimShot(40, 100, 0, 45);
  assert.deepEqual(stimEmpty, { hp: 40, stims: 0, applied: false });

  const standing = computeStanceModifiers(false, false);
  const crouched = computeStanceModifiers(true, false);
  const sliding = computeStanceModifiers(false, true);
  assert.equal(standing.spreadMult, 1.0);
  assert.ok(crouched.spreadMult < 0.75);
  assert.ok(crouched.eyeHeightOffset < -0.4);
  assert.ok(sliding.incomingAccuracyMult < crouched.incomingAccuracyMult);

  assert.equal(pickCarePackageReward(0.1).id, 'juggernaut');
  assert.equal(pickCarePackageReward(0.4).id, 'sentry');
  assert.equal(pickCarePackageReward(0.7).id, 'arsenal_drop');
  assert.equal(pickCarePackageReward(0.95).id, 'ac130');

  const noThreat = computeGrenadeThreat(0, 0, 0, [{ x: 15, z: 0 }], 9.0);
  assert.equal(noThreat, null);
  const nearThreat = computeGrenadeThreat(0, 0, 0, [{ x: 4, z: 3 }], 9.0);
  assert.ok(nearThreat !== null);
  assert.equal(nearThreat.distanceMeters, 5);
});

test('field upgrades, firing range scoring, and bomb defusal work deterministically', () => {
  const upgrade = applyFieldUpgrade('ammo_box', 2, 3);
  assert.equal(upgrade.stims, 3);
  assert.ok(upgrade.message.includes('SURSAT'));

  const rangeScore = computeFiringRangeScore(10, 4);
  assert.equal(rangeScore, 10 * 100 + 4 * 250);

  const defusalProgress = computeBombDefusalProgress(50, 1.0, true);
  assert.equal(defusalProgress, 82);
  const defusalDecay = computeBombDefusalProgress(50, 1.0, false);
  assert.equal(defusalDecay, 25);
});

test('all 10 chapters have 4-stage marathon ops, bespoke briefings, and cutscenes without F010 typos', () => {
  assert.equal(MAX_STORY_WAVES, 10);
  for (let ch = 1; ch <= MAX_STORY_WAVES; ch++) {
    const marathon = getChapterStageSpecs(ch, 'marathon');
    assert.equal(marathon.length, 4, `Chapter ${ch} marathon should have 4 stages`);
    assert.equal(marathon[0].totalStages, 4);

    const briefing = getWaveBriefing(ch, 'marathon');
    assert.ok(!briefing.title.includes('Sonsuz Dalğa'), `Chapter ${ch} briefing should be bespoke`);
    assert.equal(
      briefing.enemyCount,
      marathon.reduce((sum, s) => sum + s.enemyCount, 0),
    );

    const intro = getChapterCutscene(ch, 'intro');
    assert.equal(intro.chapter, ch);
    assert.ok(intro.beats.length >= 2);
    assert.ok(!intro.title.includes('010'), `Chapter ${ch} intro title should pad properly`);

    const climax = getChapterCutscene(ch, 'climax');
    assert.equal(climax.chapter, ch);
    assert.ok(climax.beats.length >= 2);
    assert.ok(!climax.title.includes('010'), `Chapter ${ch} climax title should pad properly`);
  }
  const ch10BossStages = getChapterStageSpecs(10, 'marathon');
  assert.equal(ch10BossStages[3].spawnBoss, true);
  assert.equal(getWaveBriefing(10, 'standard').objectiveKind, 'boss');
});

test('AAA mode helpers: lean cycle, field upgrade specs, bomb sites, firing range targets, and start labels', () => {
  assert.equal(resolveNextLean('none'), 'left');
  assert.equal(resolveNextLean('left'), 'right');
  assert.equal(resolveNextLean('right'), 'none');

  assert.equal(FIELD_UPGRADE_LIST.length, 3);
  assert.ok(FIELD_UPGRADE_SPECS.shield.cooldownSec > 0);
  assert.ok(FIELD_UPGRADE_SPECS.dead_silence.durationSec >= 10);

  const sites = getSpecOpsBombSites();
  assert.equal(sites.length, 2);
  assert.equal(sites[0].site, 'A');
  assert.equal(sites[1].site, 'B');

  const targets = getFiringRangeTargets();
  assert.ok(targets.length >= 6);
  assert.ok(targets.some((t) => t.isMoving));
  assert.ok(targets.some((t) => t.isArmored));

  assert.equal(resolveModeStartLabel('campaign', 10), 'FƏSİL 10 · BAŞLA');
  assert.equal(resolveModeStartLabel('firing_range', 1), 'TƏLİM POLİQONU · BAŞLA');
  assert.equal(resolveModeStartLabel('spec_ops', 1), 'XÜSUSİ ƏMƏLİYYAT · BAŞLA');
  assert.equal(resolveModeStartLabel('survival', 1), 'ZOMBİ MÜDAFİƏSİ · BAŞLA');
});

test('Story Campaign: choices, 3 endings, 10 intel dossiers, canon loadouts, and set-piece stages', () => {
  assert.equal(INTEL_SPECS.length, 10);
  for (let ch = 1; ch <= 10; ch++) {
    assert.ok(INTEL_SPECS.some((intel) => intel.chapter === ch), `Missing intel for chapter ${ch}`);
    const canon = getChapterCanonLoadout(ch);
    assert.equal(canon.length, 2);
    assert.notEqual(canon[0], canon[1]);
  }

  assert.equal(STORY_ENDING_LIST.length, 3);
  assert.ok(STORY_CHOICES.ch4_mercy_intel.options.length === 2);
  assert.ok(STORY_CHOICES.ch6_mole_confront.options.length === 2);
  assert.ok(STORY_CHOICES.ch10_leader_fate.options.length === 2);

  // Heroic ending: high trust, tribunal surrender, low hostage losses
  const heroic = resolveStoryEnding(
    [
      { choiceId: 'ch6_mole_confront', optionIndex: 0, label: 'Ədalət', tag: 'honor' },
      { choiceId: 'ch10_leader_fate', optionIndex: 0, label: 'Tribunal', tag: 'honor' },
    ],
    85,
    0,
  );
  assert.equal(heroic.id, 'heroic');

  // Vengeance ending: execute leader while maintaining decent trust
  const vengeance = resolveStoryEnding(
    [
      { choiceId: 'ch6_mole_confront', optionIndex: 0, label: 'Ədalət', tag: 'honor' },
      { choiceId: 'ch10_leader_fate', optionIndex: 1, label: 'Məhv et', tag: 'ruthless' },
    ],
    72,
    0,
  );
  assert.equal(vengeance.id, 'vengeance');

  // Betrayal ending: broken trust < 40
  const betrayal = resolveStoryEnding(
    [
      { choiceId: 'ch6_mole_confront', optionIndex: 1, label: 'Gizli saxla', tag: 'ruthless' },
      { choiceId: 'ch10_leader_fate', optionIndex: 1, label: 'Məhv et', tag: 'ruthless' },
    ],
    28,
    1,
  );
  assert.equal(betrayal.id, 'betrayal');
  assert.equal(STORY_ENDINGS.betrayal.id, 'betrayal');

  // Verify set-pieces in campaign chapters
  assert.equal(getChapterStageSpecs(2, 'marathon')[0].setPieceKind, 'stealth_infil');
  assert.equal(getChapterStageSpecs(3, 'marathon')[1].setPieceKind, 'hostage_rescue');
  assert.equal(getChapterStageSpecs(3, 'marathon')[1].hostageCount, 2);
  assert.equal(getChapterStageSpecs(4, 'marathon')[2].storyChoiceTrigger, 'ch4_mercy_intel');
  assert.equal(getChapterStageSpecs(5, 'marathon')[0].setPieceKind, 'door_breach_slowmo');
  assert.equal(getChapterStageSpecs(6, 'marathon')[2].storyChoiceTrigger, 'ch6_mole_confront');
  assert.equal(getChapterStageSpecs(6, 'marathon')[3].setPieceKind, 'escape_timer');
  assert.equal(getChapterStageSpecs(7, 'marathon')[3].setPieceKind, 'escape_timer');
  assert.equal(getChapterStageSpecs(8, 'marathon')[0].setPieceKind, 'stealth_infil');
  assert.equal(getChapterStageSpecs(8, 'marathon')[2].setPieceKind, 'hostage_rescue');
  assert.equal(getChapterStageSpecs(10, 'marathon')[3].storyChoiceTrigger, 'ch10_leader_fate');
  assert.equal(getSetPieceLabel('stealth_infil'), 'GİZLİ SIZMA');
  assert.equal(getSetPieceLabel('hostage_rescue'), 'GİROV XİLASETMƏ');
  assert.equal(getSetPieceLabel('escape_timer'), 'VAXTLI TƏXLİYƏ');
});




