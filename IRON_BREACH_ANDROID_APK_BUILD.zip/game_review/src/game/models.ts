import * as THREE from 'three';
import { WEAPON_CAMOS } from './rules';
import type { AttachmentId, EnemyArchetype, WeaponCamoId, WeaponId } from './types';
import type { MaterialTextures } from './textures';

export interface ViewmodelRig {
  root: THREE.Group;
  muzzleFlash: THREE.Mesh;
  muzzlePoint: THREE.Object3D;
  ejectionPoint: THREE.Object3D;
  boltMesh: THREE.Mesh;
  receiverMat: THREE.MeshStandardMaterial;
  polymerMat: THREE.MeshStandardMaterial;
  suppressorGroup: THREE.Group;
  extMagMesh: THREE.Mesh;
  laserBeam: THREE.Mesh;
  acogGroup: THREE.Group;
}

function getDefaultWeaponColors(weapon: WeaponId): { receiver: number; polymer: number; metalness: number } {
  if (weapon === 'scarh') return { receiver: 0xb89c6e, polymer: 0x524634, metalness: 0.62 };
  if (weapon === 'm4a1') return { receiver: 0x2b3038, polymer: 0x3b3830, metalness: 0.86 };
  if (weapon === 'spas12') return { receiver: 0x26292e, polymer: 0x16181c, metalness: 0.8 };
  if (weapon === 'msr') return { receiver: 0x5f634f, polymer: 0x2a2d24, metalness: 0.68 };
  if (weapon === 'm249') return { receiver: 0x2f362d, polymer: 0x242820, metalness: 0.78 };
  if (weapon === 'deagle') return { receiver: 0xbac2cc, polymer: 0x181a1e, metalness: 0.92 };
  if (weapon === 'rpg7') return { receiver: 0x3f4e36, polymer: 0x5c3a21, metalness: 0.56 };
  if (weapon === 'knife') return { receiver: 0xcbd5e1, polymer: 0x1e2024, metalness: 0.92 };
  return { receiver: 0x1b1e23, polymer: 0x121417, metalness: 0.86 };
}

export function createViewmodelWeapon(weapon: WeaponId): ViewmodelRig {
  const root = new THREE.Group();
  const baseCol = getDefaultWeaponColors(weapon);

  const gunMetal = new THREE.MeshStandardMaterial({
    color: baseCol.receiver,
    roughness: 0.3,
    metalness: baseCol.metalness,
  });
  const darkSteel = new THREE.MeshStandardMaterial({
    color: 0x171a1e,
    roughness: 0.25,
    metalness: 0.92,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xd4a84f,
    roughness: 0.26,
    metalness: 0.9,
  });
  const polymerMat = new THREE.MeshStandardMaterial({
    color: baseCol.polymer,
    roughness: 0.82,
    metalness: 0.08,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x101214,
    roughness: 0.95,
    metalness: 0.04,
  });
  const opticGlass = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.24,
    side: THREE.DoubleSide,
  });
  const reticleColor = weapon === 'scarh' || weapon === 'msr' ? 0xf59e0b : 0xff3b30;
  const redDotMat = new THREE.MeshBasicMaterial({
    color: reticleColor,
    side: THREE.DoubleSide,
  });
  const laserEmitMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });
  const laserBeamMat = new THREE.MeshBasicMaterial({
    color: 0x22c55e,
    transparent: true,
    opacity: 0.34,
    depthWrite: false,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: 0x343930,
    roughness: 0.86,
    metalness: 0.05,
  });
  const sleeveMat = new THREE.MeshStandardMaterial({
    color: 0x3c4335,
    roughness: 0.9,
    metalness: 0.04,
  });

  // Dedicated Tactical Knife viewmodel
  if (weapon === 'knife') {
    const kArm = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.082, 0.28), sleeveMat);
    kArm.position.set(0.06, -0.14, 0.05);
    kArm.rotation.set(0.32, 0.25, -0.18);
    root.add(kArm);

    const kGlove = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.078, 0.095), gloveMat);
    kGlove.position.set(0.02, -0.075, -0.1);
    kGlove.rotation.set(0.45, 0.15, -0.2);
    root.add(kGlove);

    const kHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 0.14, 10), polymerMat);
    kHandle.position.set(0.015, -0.055, -0.12);
    kHandle.rotation.set(0.55, 0, -0.22);
    root.add(kHandle);

    const kGuard = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.055, 0.016), darkSteel);
    kGuard.position.set(0.008, -0.002, -0.17);
    kGuard.rotation.set(0.55, 0, -0.22);
    root.add(kGuard);

    const kBlade = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.036, 0.22), gunMetal);
    kBlade.position.set(-0.005, 0.055, -0.27);
    kBlade.rotation.set(0.35, 0.12, -0.22);
    root.add(kBlade);

    const boltMesh = new THREE.Mesh(new THREE.BoxGeometry(0.001, 0.001, 0.001), brassMat);
    boltMesh.visible = false;
    root.add(boltMesh);
    const ejectionPoint = new THREE.Object3D();
    const muzzlePoint = new THREE.Object3D();
    muzzlePoint.position.set(0, 0.04, -0.35);
    root.add(ejectionPoint, muzzlePoint);
    const muzzleFlash = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.01, 0),
      new THREE.MeshBasicMaterial({ visible: false }),
    );
    const suppressorGroup = new THREE.Group();
    const extMagMesh = new THREE.Mesh();
    const laserBeam = new THREE.Mesh();
    const acogGroup = new THREE.Group();
    suppressorGroup.visible = false;
    extMagMesh.visible = false;
    laserBeam.visible = false;
    acogGroup.visible = false;
    root.add(muzzleFlash, suppressorGroup, extMagMesh, laserBeam, acogGroup);

    return {
      root,
      muzzleFlash,
      muzzlePoint,
      ejectionPoint,
      boltMesh,
      receiverMat: gunMetal,
      polymerMat,
      suppressorGroup,
      extMagMesh,
      laserBeam,
      acogGroup,
    };
  }

  // Dedicated RPG-7 Rocket Launcher viewmodel
  if (weapon === 'rpg7') {
    const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.92, 14), gunMetal);
    tube.rotation.x = Math.PI / 2;
    tube.position.set(0, 0.02, -0.12);
    root.add(tube);

    const woodWrap = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.052, 0.34, 12), polymerMat);
    woodWrap.rotation.x = Math.PI / 2;
    woodWrap.position.set(0, 0.02, -0.02);
    root.add(woodWrap);

    const rearCone = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.045, 0.14, 12), darkSteel);
    rearCone.rotation.x = Math.PI / 2;
    rearCone.position.set(0, 0.02, 0.38);
    root.add(rearCone);

    const warheadBody = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.062, 0.16, 12), darkSteel);
    warheadBody.rotation.x = Math.PI / 2;
    warheadBody.position.set(0, 0.02, -0.64);
    root.add(warheadBody);

    const warheadTip = new THREE.Mesh(new THREE.ConeGeometry(0.062, 0.18, 12), gunMetal);
    warheadTip.rotation.x = -Math.PI / 2;
    warheadTip.position.set(0, 0.02, -0.8);
    root.add(warheadTip);

    const rpgGrip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 0.05), rubberMat);
    rpgGrip.position.set(0, -0.08, -0.18);
    rpgGrip.rotation.x = 0.22;
    root.add(rpgGrip);

    const rpgRearGrip = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.1, 0.048), rubberMat);
    rpgRearGrip.position.set(0, -0.075, 0.02);
    root.add(rpgRearGrip);

    const kArm = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.24), sleeveMat);
    kArm.position.set(-0.1, -0.11, -0.14);
    kArm.rotation.set(0.22, -0.4, 0.14);
    root.add(kArm);
    const kGlove = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.07, 0.08), gloveMat);
    kGlove.position.set(0.01, -0.08, -0.18);
    root.add(kGlove);

    const boltMesh = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.01, 0.02), brassMat);
    boltMesh.visible = false;
    root.add(boltMesh);
    const ejectionPoint = new THREE.Object3D();
    ejectionPoint.position.set(0, 0.02, 0.42);
    const muzzlePoint = new THREE.Object3D();
    muzzlePoint.position.set(0, 0.02, -0.88);
    root.add(ejectionPoint, muzzlePoint);

    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xff9f1c,
      transparent: true,
      opacity: 0.92,
      depthWrite: false,
    });
    const muzzleFlash = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), flashMat);
    muzzleFlash.position.set(0, 0.02, -0.88);
    muzzleFlash.visible = false;
    root.add(muzzleFlash);

    const suppressorGroup = new THREE.Group();
    const extMagMesh = new THREE.Mesh();
    const laserBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.0016, 0.0026, 14, 6),
      laserBeamMat,
    );
    laserBeam.rotation.x = Math.PI / 2;
    laserBeam.position.set(-0.055, 0.02, -7.4);
    const acogGroup = new THREE.Group();
    suppressorGroup.visible = false;
    extMagMesh.visible = false;
    laserBeam.visible = false;
    acogGroup.visible = false;
    root.add(suppressorGroup, extMagMesh, laserBeam, acogGroup);

    return {
      root,
      muzzleFlash,
      muzzlePoint,
      ejectionPoint,
      boltMesh,
      receiverMat: gunMetal,
      polymerMat,
      suppressorGroup,
      extMagMesh,
      laserBeam,
      acogGroup,
    };
  }

  // 1. Upper & Lower Receiver + Brass Bolt
  const recLen =
    weapon === 'msr'
      ? 0.42
      : weapon === 'm249'
        ? 0.4
        : weapon === 'scarh'
          ? 0.38
          : weapon === 'spas12'
            ? 0.35
            : weapon === 'm4a1'
              ? 0.34
              : weapon === 'deagle'
                ? 0.22
                : 0.27;
  const recWidth =
    weapon === 'm249'
      ? 0.088
      : weapon === 'scarh' || weapon === 'spas12'
        ? 0.072
        : weapon === 'deagle'
          ? 0.044
          : 0.064;
  const upperReceiver = new THREE.Mesh(
    new THREE.BoxGeometry(recWidth, weapon === 'm249' ? 0.072 : 0.056, recLen),
    gunMetal,
  );
  upperReceiver.position.set(0, 0.018, 0);
  root.add(upperReceiver);

  const lowerReceiver = new THREE.Mesh(
    new THREE.BoxGeometry(recWidth * 0.92, 0.048, recLen * 0.82),
    gunMetal,
  );
  lowerReceiver.position.set(0, -0.025, 0.018);
  root.add(lowerReceiver);

  const boltMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.014, 0.024, 0.072),
    brassMat,
  );
  boltMesh.position.set(recWidth * 0.44, 0.02, -0.02);
  root.add(boltMesh);

  const portLip = new THREE.Mesh(
    new THREE.BoxGeometry(0.012, 0.008, 0.078),
    darkSteel,
  );
  portLip.position.set(recWidth * 0.5, 0.004, -0.02);
  root.add(portLip);

  const ejectionPoint = new THREE.Object3D();
  ejectionPoint.position.set(0.055, 0.024, -0.02);
  root.add(ejectionPoint);

  const chargingHandle = new THREE.Mesh(
    new THREE.BoxGeometry(0.048, 0.014, 0.024),
    darkSteel,
  );
  chargingHandle.position.set(0, 0.036, recLen * 0.52);
  root.add(chargingHandle);

  // 2. Handguard / Pump Forend + Top Rail
  const hgLen =
    weapon === 'msr'
      ? 0.33
      : weapon === 'm249'
        ? 0.31
        : weapon === 'scarh'
          ? 0.31
          : weapon === 'spas12'
            ? 0.27
            : weapon === 'm4a1'
              ? 0.28
              : weapon === 'deagle'
                ? 0.11
                : 0.17;
  const hgZ = weapon === 'deagle' ? -0.13 : weapon === 'mp5' ? -0.21 : -0.31;
  const handguard = new THREE.Mesh(
    new THREE.BoxGeometry(weapon === 'spas12' ? 0.068 : weapon === 'deagle' ? 0.042 : 0.058, 0.064, hgLen),
    weapon === 'scarh' || weapon === 'msr' || weapon === 'deagle' ? gunMetal : polymerMat,
  );
  handguard.position.set(0, weapon === 'spas12' ? -0.004 : 0.012, hgZ);
  root.add(handguard);

  const slotGeo = new THREE.BoxGeometry(0.072, 0.014, 0.026);
  if (weapon !== 'deagle') {
    for (let i = 0; i < 3; i++) {
      const slot = new THREE.Mesh(slotGeo, darkSteel);
      slot.position.set(0, weapon === 'spas12' ? -0.002 : 0.014, hgZ + 0.07 - i * 0.065);
      root.add(slot);
    }
  }

  if (weapon === 'm249') {
    // M249 Box Drum Magazine + Brass Belt Links + Carry Handle
    const drumBox = new THREE.Mesh(new THREE.BoxGeometry(0.115, 0.13, 0.14), polymerMat);
    drumBox.position.set(-0.02, -0.095, -0.04);
    root.add(drumBox);

    const ammoBelt = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.02, 0.065), brassMat);
    ammoBelt.position.set(-0.052, 0.005, -0.02);
    ammoBelt.rotation.z = 0.55;
    root.add(ammoBelt);

    const handleBar = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.018, 0.14), darkSteel);
    handleBar.position.set(0.055, 0.072, -0.2);
    root.add(handleBar);
  }

  const topRail = new THREE.Mesh(
    new THREE.BoxGeometry(0.028, 0.012, recLen + hgLen - 0.09),
    darkSteel,
  );
  topRail.position.set(0, 0.052, weapon === 'deagle' ? -0.06 : -0.13);
  root.add(topRail);

  // 3. PEQ Laser Module + Long Toggleable Green Beam
  const peqZ = weapon === 'deagle' ? -0.14 : weapon === 'mp5' ? -0.22 : -0.35;
  const peqBox = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.028, 0.088), polymerMat);
  peqBox.position.set(-0.044, 0.022, peqZ);
  root.add(peqBox);

  const peqLaser = new THREE.Mesh(
    new THREE.CylinderGeometry(0.005, 0.005, 0.014, 8),
    laserEmitMat,
  );
  peqLaser.rotation.x = Math.PI / 2;
  peqLaser.position.set(-0.044, 0.022, peqZ - 0.048);
  root.add(peqLaser);

  const laserBeam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.0018, 0.0032, 14.0, 6),
    laserBeamMat,
  );
  laserBeam.rotation.x = Math.PI / 2;
  laserBeam.position.set(-0.044, 0.022, peqZ - 7.05);
  laserBeam.visible = false;
  root.add(laserBeam);

  // 4. Barrel + Underbarrel Tube (SPAS-12) + Muzzle + Optional Suppressor
  const barrelLen =
    weapon === 'msr'
      ? 0.44
      : weapon === 'm249'
        ? 0.34
        : weapon === 'scarh'
          ? 0.29
          : weapon === 'spas12'
            ? 0.34
            : weapon === 'm4a1'
              ? 0.26
              : weapon === 'deagle'
                ? 0.13
                : 0.22;
  const barrelZ =
    weapon === 'deagle' ? -0.22 : weapon === 'mp5' ? -0.38 : weapon === 'msr' ? -0.63 : -0.54;
  const barrel = new THREE.Mesh(
    new THREE.CylinderGeometry(
      weapon === 'mp5' ? 0.024 : weapon === 'spas12' ? 0.02 : 0.013,
      weapon === 'mp5' ? 0.024 : weapon === 'spas12' ? 0.02 : 0.015,
      barrelLen,
      12,
    ),
    darkSteel,
  );
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.016, barrelZ);
  root.add(barrel);

  if (weapon === 'spas12') {
    const tubeMag = new THREE.Mesh(new THREE.CylinderGeometry(0.017, 0.017, 0.46, 10), darkSteel);
    tubeMag.rotation.x = Math.PI / 2;
    tubeMag.position.set(0, -0.018, -0.42);
    root.add(tubeMag);
  }

  const muzzleZ =
    weapon === 'deagle' ? -0.28 : weapon === 'mp5' ? -0.5 : weapon === 'msr' ? -0.84 : -0.68;
  const comp = new THREE.Mesh(
    new THREE.CylinderGeometry(0.021, 0.018, 0.062, 10),
    darkSteel,
  );
  comp.rotation.x = Math.PI / 2;
  comp.position.set(0, 0.016, muzzleZ);
  root.add(comp);

  // Gunsmith Attachable Suppressor Can
  const suppressorGroup = new THREE.Group();
  const supTube = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.2, 12), darkSteel);
  supTube.rotation.x = Math.PI / 2;
  suppressorGroup.add(supTube);
  const supRing = new THREE.Mesh(new THREE.CylinderGeometry(0.027, 0.027, 0.03, 12), rubberMat);
  supRing.rotation.x = Math.PI / 2;
  supRing.position.z = 0.07;
  suppressorGroup.add(supRing);
  suppressorGroup.position.set(0, 0.016, muzzleZ - 0.11);
  suppressorGroup.visible = false;
  root.add(suppressorGroup);

  // 5. Foregrip, Standard Mag + Ext Mag Drum/Extension, Trigger, Grip
  if (weapon !== 'spas12' && weapon !== 'deagle' && weapon !== 'm249') {
    const foregrip = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.072, 0.044), polymerMat);
    foregrip.position.set(0, -0.048, weapon === 'mp5' ? -0.21 : -0.3);
    foregrip.rotation.x = -0.26;
    root.add(foregrip);

    const magTop = new THREE.Mesh(
      new THREE.BoxGeometry(0.036, 0.088, weapon === 'scarh' || weapon === 'msr' ? 0.078 : 0.06),
      polymerMat,
    );
    magTop.position.set(0, -0.085, -0.072);
    magTop.rotation.x = weapon === 'scarh' || weapon === 'msr' ? 0.08 : 0.18;
    root.add(magTop);

    const magBottom = new THREE.Mesh(
      new THREE.BoxGeometry(0.035, 0.08, weapon === 'scarh' || weapon === 'msr' ? 0.076 : 0.058),
      polymerMat,
    );
    magBottom.position.set(0, -0.15, -0.056);
    magBottom.rotation.x = weapon === 'scarh' || weapon === 'msr' ? 0.14 : 0.34;
    root.add(magBottom);
  }

  const extMagMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.056, 0.095, 0.068),
    darkSteel,
  );
  extMagMesh.position.set(0, -0.19, weapon === 'deagle' ? 0.06 : -0.046);
  extMagMesh.rotation.x = 0.24;
  extMagMesh.visible = false;
  root.add(extMagMesh);

  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.118, 0.052), rubberMat);
  grip.position.set(0, -0.096, 0.088);
  grip.rotation.x = 0.28;
  root.add(grip);

  // 6. Tactical Stock + Buttpad (omitted on pistol Deagle)
  if (weapon !== 'deagle') {
    const stockBody = new THREE.Mesh(
      new THREE.BoxGeometry(0.05, 0.095, 0.19),
      weapon === 'scarh' || weapon === 'msr' ? gunMetal : polymerMat,
    );
    stockBody.position.set(0, -0.01, 0.26);
    root.add(stockBody);

    const buttpad = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.11, 0.024), rubberMat);
    buttpad.position.set(0, -0.014, 0.36);
    root.add(buttpad);
  }

  // 7. Sight / Scope (Sniper Long Scope for MSR, Holo for others + Toggleable ACOG Magnifier)
  const sightFrame = new THREE.Group();
  sightFrame.position.set(0, 0.074, -0.02);

  if (weapon === 'msr') {
    const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.26, 12), darkSteel);
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.026, -0.03);
    sightFrame.add(scopeTube);
    const scopeFront = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.024, 0.07, 12), darkSteel);
    scopeFront.rotation.x = Math.PI / 2;
    scopeFront.position.set(0, 0.026, -0.16);
    sightFrame.add(scopeFront);
    const scopeMount = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.024, 0.14), gunMetal);
    scopeMount.position.set(0, 0.005, -0.02);
    sightFrame.add(scopeMount);
  } else {
    const sightBase = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.018, 0.088), darkSteel);
    sightFrame.add(sightBase);
    const leftPost = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.044, 0.062), darkSteel);
    leftPost.position.set(-0.023, 0.026, 0);
    sightFrame.add(leftPost);
    const rightPost = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.044, 0.062), darkSteel);
    rightPost.position.set(0.023, 0.026, 0);
    sightFrame.add(rightPost);
    const topHood = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.009, 0.064), gunMetal);
    topHood.position.set(0, 0.048, 0);
    sightFrame.add(topHood);
    const lens = new THREE.Mesh(new THREE.PlaneGeometry(0.038, 0.036), opticGlass);
    lens.position.set(0, 0.027, 0);
    sightFrame.add(lens);
    const reticleRing = new THREE.Mesh(new THREE.RingGeometry(0.0065, 0.008, 20), redDotMat);
    reticleRing.position.set(0, 0.027, -0.005);
    sightFrame.add(reticleRing);
    const dot = new THREE.Mesh(new THREE.CircleGeometry(0.0018, 10), redDotMat);
    dot.position.set(0, 0.027, -0.005);
    sightFrame.add(dot);
  }
  root.add(sightFrame);

  // Gunsmith Attachable ACOG Magnifier Tube
  const acogGroup = new THREE.Group();
  const acogBody = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.02, 0.12, 10), gunMetal);
  acogBody.rotation.x = Math.PI / 2;
  acogGroup.add(acogBody);
  const acogFiber = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.075, 6), laserEmitMat);
  acogFiber.rotation.x = Math.PI / 2;
  acogFiber.position.set(0, 0.024, 0);
  acogGroup.add(acogFiber);
  acogGroup.position.set(0, 0.102, 0.085);
  acogGroup.visible = false;
  root.add(acogGroup);

  // 8. Tactical Arms & Gloves
  const leftSleeve = new THREE.Mesh(new THREE.BoxGeometry(0.076, 0.076, 0.24), sleeveMat);
  leftSleeve.position.set(-0.11, -0.11, weapon === 'mp5' ? -0.05 : -0.1);
  leftSleeve.rotation.set(0.22, -0.42, 0.15);
  root.add(leftSleeve);

  const foreHand = new THREE.Mesh(new THREE.BoxGeometry(0.074, 0.06, 0.115), gloveMat);
  foreHand.position.set(-0.018, -0.042, weapon === 'mp5' ? -0.21 : -0.29);
  foreHand.rotation.z = 0.22;
  root.add(foreHand);

  const rightGlove = new THREE.Mesh(new THREE.BoxGeometry(0.054, 0.075, 0.075), gloveMat);
  rightGlove.position.set(0.012, -0.088, 0.095);
  rightGlove.rotation.x = 0.25;
  root.add(rightGlove);

  // 9. Muzzle flash star
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffc046,
    transparent: true,
    opacity: 0.92,
    depthWrite: false,
  });
  const muzzleFlash = new THREE.Mesh(new THREE.OctahedronGeometry(0.085, 0), flashMat);
  muzzleFlash.scale.set(1.1, 1.1, 2.3);
  muzzleFlash.position.set(0, 0.016, muzzleZ - 0.05);
  muzzleFlash.visible = false;
  root.add(muzzleFlash);

  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.copy(muzzleFlash.position);
  root.add(muzzlePoint);

  return {
    root,
    muzzleFlash,
    muzzlePoint,
    ejectionPoint,
    boltMesh,
    receiverMat: gunMetal,
    polymerMat,
    suppressorGroup,
    extMagMesh,
    laserBeam,
    acogGroup,
  };
}

export function applyWeaponCamoToRig(
  rig: ViewmodelRig,
  weapon: WeaponId,
  camoId: WeaponCamoId,
  textures: MaterialTextures,
): void {
  const camo = WEAPON_CAMOS[camoId];
  const tex = textures.weaponCamos[camoId];
  if (camoId === 'standard' || !tex) {
    const baseCol = getDefaultWeaponColors(weapon);
    rig.receiverMat.map = null;
    rig.receiverMat.color.setHex(baseCol.receiver);
    rig.receiverMat.roughness = 0.3;
    rig.receiverMat.metalness = baseCol.metalness;
    rig.polymerMat.map = null;
    rig.polymerMat.color.setHex(baseCol.polymer);
  } else {
    rig.receiverMat.map = tex;
    rig.receiverMat.color.setHex(0xffffff);
    rig.receiverMat.roughness = camo.roughness;
    rig.receiverMat.metalness = camo.metalness;
    rig.polymerMat.map = tex;
    rig.polymerMat.color.setHex(camo.polymerHex);
  }
  rig.receiverMat.needsUpdate = true;
  rig.polymerMat.needsUpdate = true;
}

export function applyWeaponAttachmentsToRig(
  rig: ViewmodelRig,
  attachments: readonly AttachmentId[],
): void {
  rig.suppressorGroup.visible = attachments.includes('suppressor');
  rig.extMagMesh.visible = attachments.includes('ext_mag');
  rig.laserBeam.visible = attachments.includes('laser');
  rig.acogGroup.visible = attachments.includes('acog');
}

export interface EnemyRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  visorMat: THREE.MeshStandardMaterial;
  flashMeshes: THREE.Mesh[];
  headCollider: THREE.Mesh;
  torsoCollider: THREE.Mesh;
  shieldCollider?: THREE.Mesh;
  rotors?: THREE.Mesh[];
  telegraphBeam: THREE.Mesh;
}

export function createEnemySoldier(
  archetype: EnemyArchetype,
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): EnemyRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const flashMeshes: THREE.Mesh[] = [];
  const hitMat = new THREE.MeshBasicMaterial({ visible: false });

  // Dedicated hovering quad-rotor Kamikaze Drone rig
  if (archetype === 'drone') {
    const hullMat = new THREE.MeshStandardMaterial({
      color: 0x1e2229,
      roughness: 0.36,
      metalness: 0.78,
    });
    const visorMat = new THREE.MeshStandardMaterial({
      color: 0xff2d20,
      emissive: 0xff2d20,
      emissiveIntensity: 2.0,
    });
    const rotorMat = new THREE.MeshBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.75,
    });

    const coreGroup = new THREE.Group();
    coreGroup.position.set(0, 1.55, 0);
    bodyGroup.add(coreGroup);

    const chassis = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.22, 0.52), hullMat);
    chassis.castShadow = !isSoftwareGl;
    coreGroup.add(chassis);
    flashMeshes.push(chassis);

    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), visorMat);
    eye.position.set(0, -0.02, 0.25);
    coreGroup.add(eye);

    const rotors: THREE.Mesh[] = [];
    const armCoords: [number, number][] = [
      [-0.36, 0.32],
      [0.36, 0.32],
      [-0.36, -0.32],
      [0.36, -0.32],
    ];
    for (const [ax, az] of armCoords) {
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.05, 0.07), hullMat);
      arm.position.set(ax * 0.55, 0.04, az * 0.55);
      arm.rotation.y = Math.atan2(az, ax);
      coreGroup.add(arm);

      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.02, 0.07), rotorMat);
      blade.position.set(ax, 0.1, az);
      coreGroup.add(blade);
      rotors.push(blade);
    }

    const headCollider = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.35, 0.55), hitMat);
    headCollider.position.set(0, 1.65, 0);
    headCollider.layers.set(1);
    headCollider.userData = { part: 'head' };
    bodyGroup.add(headCollider);

    const torsoCollider = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.55, 0.85), hitMat);
    torsoCollider.position.set(0, 1.5, 0);
    torsoCollider.layers.set(1);
    torsoCollider.userData = { part: 'body' };
    bodyGroup.add(torsoCollider);

    const telegraphBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.012, 0.012, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0xff2d20, transparent: true, opacity: 0.7 }),
    );
    telegraphBeam.rotation.x = Math.PI / 2;
    telegraphBeam.position.set(0, 1.55, 4);
    telegraphBeam.visible = false;
    bodyGroup.add(telegraphBeam);

    const shadowPlane = new THREE.Mesh(
      new THREE.CircleGeometry(0.5, 14),
      new THREE.MeshBasicMaterial({
        map: textures.shadowDiscMap,
        transparent: true,
        opacity: 0.38,
        depthWrite: false,
      }),
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.018;
    root.add(shadowPlane);

    return {
      root,
      bodyGroup,
      leftLeg: new THREE.Group(),
      rightLeg: new THREE.Group(),
      leftArm: new THREE.Group(),
      rightArm: new THREE.Group(),
      visorMat,
      flashMeshes,
      headCollider,
      torsoCollider,
      rotors,
      telegraphBeam,
    };
  }

  const palette =
    archetype === 'boss'
      ? { uniform: 0x16181d, armor: 0x2a1414, visor: 0xfacc15, accent: 0x991b1b }
      : archetype === 'zombie'
        ? { uniform: 0x28362a, armor: 0x3b2222, visor: 0x4ade80, accent: 0x451a1a }
        : archetype === 'rusher'
          ? { uniform: 0x3f2e2b, armor: 0x1b1918, visor: 0xff3b30, accent: 0x7f1d1d }
          : archetype === 'heavy'
            ? { uniform: 0x2c3239, armor: 0x4b5563, visor: 0xf59e0b, accent: 0x92400e }
            : archetype === 'sniper'
              ? { uniform: 0x263323, armor: 0x1f281d, visor: 0x38bdf8, accent: 0x365314 }
              : archetype === 'shield'
                ? { uniform: 0x1e2530, armor: 0x334155, visor: 0x38bdf8, accent: 0x0f172a }
                : { uniform: 0x454e3a, armor: 0x282d23, visor: 0xef4444, accent: 0x363d2d };

  const scaleFactor =
    archetype === 'boss'
      ? 1.28
      : archetype === 'heavy'
        ? 1.2
        : archetype === 'shield'
          ? 1.08
          : archetype === 'rusher' || archetype === 'zombie'
            ? 0.98
            : 1.0;
  bodyGroup.scale.setScalar(scaleFactor);

  const uniformMat = new THREE.MeshStandardMaterial({
    color: palette.uniform,
    map: textures.camoMap,
    roughness: 0.84,
    metalness: 0.06,
  });
  const armorMat = new THREE.MeshStandardMaterial({
    color: palette.armor,
    roughness: 0.38,
    metalness: 0.62,
  });
  const bootMat = new THREE.MeshStandardMaterial({
    color: 0x171615,
    roughness: 0.88,
    metalness: 0.1,
  });
  const pouchMat = new THREE.MeshStandardMaterial({
    color: palette.accent,
    roughness: 0.78,
    metalness: 0.12,
  });
  const maskMat = new THREE.MeshStandardMaterial({
    color: 0x1e2022,
    roughness: 0.9,
    metalness: 0.05,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: palette.visor,
    emissive: palette.visor,
    emissiveIntensity: 1.5,
    roughness: 0.18,
    metalness: 0.35,
  });
  const gunMat = new THREE.MeshStandardMaterial({
    color: 0x181b1f,
    roughness: 0.32,
    metalness: 0.86,
  });

  const buildLeg = (sideX: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(sideX, 0.82, 0);

    const thigh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.42, 0.22), uniformMat);
    thigh.position.set(0, -0.2, 0);
    thigh.castShadow = !isSoftwareGl;
    legPivot.add(thigh);

    const shin = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.36, 0.19), uniformMat);
    shin.position.set(0, -0.54, 0);
    shin.castShadow = !isSoftwareGl;
    legPivot.add(shin);

    const kneePad = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.13, 0.06), armorMat);
    kneePad.position.set(0, -0.4, 0.11);
    legPivot.add(kneePad);

    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.14, 0.27), bootMat);
    boot.position.set(0, -0.75, 0.04);
    legPivot.add(boot);

    return legPivot;
  };

  const leftLeg = buildLeg(-0.14);
  bodyGroup.add(leftLeg);
  const rightLeg = buildLeg(0.14);
  bodyGroup.add(rightLeg);

  const rightHolster = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.22, 0.14), bootMat);
  rightHolster.position.set(0.11, -0.2, 0.02);
  rightLeg.add(rightHolster);

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.31), bootMat);
  belt.position.set(0, 0.84, 0);
  bodyGroup.add(belt);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.58, 0.28), uniformMat);
  torso.position.set(0, 1.15, 0);
  torso.castShadow = !isSoftwareGl;
  bodyGroup.add(torso);
  flashMeshes.push(torso);

  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.44, 0.33), armorMat);
  vest.position.set(0, 1.17, 0.01);
  vest.castShadow = !isSoftwareGl;
  bodyGroup.add(vest);
  flashMeshes.push(vest);

  // Beveled front ballistic trauma plate & shoulder harness straps
  const frontPlate = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.34, 0.055), armorMat);
  frontPlate.position.set(0, 1.2, 0.185);
  bodyGroup.add(frontPlate);
  for (const sx of [-0.14, 0.14]) {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.06, 0.36), bootMat);
    strap.position.set(sx, 1.44, 0);
    bodyGroup.add(strap);
  }

  for (const px of [-0.14, 0, 0.14]) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.16, 0.06), pouchMat);
    pouch.position.set(px, 1.04, 0.21);
    bodyGroup.add(pouch);
  }

  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.4, 0.18), pouchMat);
  backpack.position.set(0, 1.18, -0.24);
  bodyGroup.add(backpack);

  // Tactical comms radio + whip antenna on left shoulder pack
  const radioBox = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.17, 0.07), bootMat);
  radioBox.position.set(-0.14, 1.38, -0.26);
  bodyGroup.add(radioBox);
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.01, 0.36, 5), gunMat);
  antenna.position.set(-0.14, 1.62, -0.26);
  antenna.rotation.x = -0.14;
  bodyGroup.add(antenna);

  if (archetype === 'heavy' || archetype === 'boss') {
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.24, 0.12, 10), armorMat);
    collar.position.set(0, 1.44, 0);
    bodyGroup.add(collar);
  }

  if (archetype === 'boss') {
    // Twin shoulder micro-rocket pods & gold armor crest on Boss exoskeleton
    for (const sx of [-0.36, 0.36]) {
      const pod = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.18, 0.28), gunMat);
      pod.position.set(sx, 1.56, -0.02);
      bodyGroup.add(pod);
      const tip = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.04), visorMat);
      tip.position.set(sx, 1.56, 0.13);
      bodyGroup.add(tip);
    }
  }

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.23, 0.24, 0.23), maskMat);
  head.position.set(0, 1.57, 0);
  bodyGroup.add(head);
  flashMeshes.push(head);

  const jawGuard = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.1, 0.16), armorMat);
  jawGuard.position.set(0, 1.51, 0.06);
  bodyGroup.add(jawGuard);

  const helmetDome = new THREE.Mesh(
    new THREE.SphereGeometry(0.175, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.62),
    armorMat,
  );
  helmetDome.position.set(0, 1.62, -0.01);
  helmetDome.castShadow = !isSoftwareGl;
  bodyGroup.add(helmetDome);

  const helmetRim = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.07, 0.31), armorMat);
  helmetRim.position.set(0, 1.62, -0.01);
  bodyGroup.add(helmetRim);

  // Quad-tube / dual tactical NVG optics mount on helmet front (not for zombies)
  if (archetype !== 'zombie') {
    const nvgMount = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 0.07), bootMat);
    nvgMount.position.set(0, 1.67, 0.14);
    bodyGroup.add(nvgMount);
    for (const nx of [-0.045, 0.045]) {
      const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.022, 0.09, 6), gunMat);
      tube.rotation.x = Math.PI / 2;
      tube.position.set(nx, 1.66, 0.18);
      bodyGroup.add(tube);
    }
  }

  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.068, 0.05), visorMat);
  visor.position.set(0, 1.59, 0.125);
  bodyGroup.add(visor);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.33, 1.33, 0.02);
  bodyGroup.add(leftArm);

  const lPauldron = new THREE.Mesh(
    new THREE.BoxGeometry(
      archetype === 'heavy' || archetype === 'boss' ? 0.22 : 0.17,
      0.16,
      0.22,
    ),
    armorMat,
  );
  lPauldron.position.set(-0.02, -0.02, 0);
  leftArm.add(lPauldron);

  const lUpper = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.15), uniformMat);
  lUpper.position.set(-0.01, -0.2, 0.12);
  lUpper.rotation.x = -0.65;
  lUpper.rotation.z = -0.2;
  leftArm.add(lUpper);

  // Ballistic Riot Shield for 'shield' archetype
  let shieldCollider: THREE.Mesh | undefined;
  if (archetype === 'shield') {
    const shieldMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.35,
      metalness: 0.78,
    });
    const shieldMesh = new THREE.Mesh(new THREE.BoxGeometry(0.76, 1.24, 0.08), shieldMat);
    shieldMesh.position.set(-0.06, 0.96, 0.44);
    shieldMesh.castShadow = !isSoftwareGl;
    bodyGroup.add(shieldMesh);

    const glassViewport = new THREE.Mesh(
      new THREE.BoxGeometry(0.46, 0.18, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1, metalness: 0.85 }),
    );
    glassViewport.position.set(-0.06, 1.36, 0.44);
    bodyGroup.add(glassViewport);

    const stripe = new THREE.Mesh(
      new THREE.BoxGeometry(0.77, 0.09, 0.09),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 }),
    );
    stripe.position.set(-0.06, 0.68, 0.44);
    bodyGroup.add(stripe);

    shieldCollider = new THREE.Mesh(new THREE.BoxGeometry(0.84, 1.34, 0.18), hitMat);
    shieldCollider.position.set(-0.06, 0.96, 0.46);
    shieldCollider.layers.set(1);
    shieldCollider.userData = { part: 'shield' };
    bodyGroup.add(shieldCollider);
  }

  const rightArm = new THREE.Group();
  rightArm.position.set(0.32, 1.33, 0.02);
  bodyGroup.add(rightArm);

  const rPauldron = new THREE.Mesh(
    new THREE.BoxGeometry(
      archetype === 'heavy' || archetype === 'boss' ? 0.22 : 0.17,
      0.16,
      0.22,
    ),
    armorMat,
  );
  rPauldron.position.set(0.02, -0.02, 0);
  rightArm.add(rPauldron);

  const rArmMesh = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.15), uniformMat);
  rArmMesh.position.set(0, -0.16, 0.18);
  rArmMesh.rotation.x = -Math.PI / 2 + 0.15;
  rightArm.add(rArmMesh);

  // Enemy Rifle (hidden for zombie archetype which uses raised arms)
  const rifleGroup = new THREE.Group();
  rifleGroup.visible = archetype !== 'zombie';
  rifleGroup.position.set(-0.08, -0.15, 0.46);
  const rBody = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.095, 0.46), gunMat);
  rifleGroup.add(rBody);
  const barrelLen = archetype === 'sniper' ? 0.52 : 0.28;
  const rBarrel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.014, 0.016, barrelLen, 8),
    gunMat,
  );
  rBarrel.rotation.x = Math.PI / 2;
  rBarrel.position.set(0, 0.015, archetype === 'sniper' ? 0.45 : 0.34);
  rifleGroup.add(rBarrel);
  const rOptic = new THREE.Mesh(
    new THREE.BoxGeometry(0.04, 0.04, archetype === 'sniper' ? 0.2 : 0.08),
    bootMat,
  );
  rOptic.position.set(0, 0.065, -0.02);
  rifleGroup.add(rOptic);
  rightArm.add(rifleGroup);

  const beamLength = archetype === 'sniper' ? 32 : 16;
  const telegraphGeo = new THREE.CylinderGeometry(0.012, 0.012, beamLength, 6);
  telegraphGeo.rotateX(Math.PI / 2);
  telegraphGeo.translate(0, 0, beamLength / 2);
  const telegraphMat = new THREE.MeshBasicMaterial({
    color:
      archetype === 'boss'
        ? 0xfacc15
        : archetype === 'sniper'
          ? 0xef4444
          : archetype === 'heavy'
            ? 0xf59e0b
            : 0xff2d20,
    transparent: true,
    opacity: archetype === 'sniper' ? 0.88 : 0.78,
    depthWrite: false,
  });
  const telegraphBeam = new THREE.Mesh(telegraphGeo, telegraphMat);
  telegraphBeam.position.set(-0.08, -0.13, 0.88);
  telegraphBeam.visible = false;
  rightArm.add(telegraphBeam);

  const headCollider = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.36, 0.36), hitMat);
  headCollider.position.set(0, 1.6, 0);
  headCollider.layers.set(1);
  headCollider.userData = { part: 'head' };
  bodyGroup.add(headCollider);

  const torsoCollider = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.34, 0.48), hitMat);
  torsoCollider.position.set(0, 0.72, 0);
  torsoCollider.layers.set(1);
  torsoCollider.userData = { part: 'body' };
  bodyGroup.add(torsoCollider);

  const shadowPlane = new THREE.Mesh(
    new THREE.CircleGeometry(0.68 * scaleFactor, 16),
    new THREE.MeshBasicMaterial({
      map: textures.shadowDiscMap,
      transparent: true,
      opacity: 0.52,
      depthWrite: false,
    }),
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.018;
  root.add(shadowPlane);

  return {
    root,
    bodyGroup,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    visorMat,
    flashMeshes,
    headCollider,
    torsoCollider,
    shieldCollider,
    telegraphBeam,
  };
}

export function createDestructibleCrate(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): { group: THREE.Group; colliderMesh: THREE.Mesh } {
  const group = new THREE.Group();
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0xd9b382,
    map: textures.crateMap,
    roughness: 0.84,
    metalness: 0.06,
  });
  const strapMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.5,
    metalness: 0.3,
  });

  const box = new THREE.Mesh(new THREE.BoxGeometry(1.15, 1.1, 1.15), woodMat);
  box.position.y = 0.55;
  box.castShadow = !isSoftwareGl;
  box.receiveShadow = true;
  group.add(box);

  const strap = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.14, 1.18), strapMat);
  strap.position.y = 0.55;
  group.add(strap);

  const colliderMesh = new THREE.Mesh(
    new THREE.BoxGeometry(1.22, 1.18, 1.22),
    new THREE.MeshBasicMaterial({ visible: false }),
  );
  colliderMesh.position.y = 0.59;
  colliderMesh.layers.set(1);
  group.add(colliderMesh);

  return { group, colliderMesh };
}

export function createArmoredVehicle(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): THREE.Group {
  const group = new THREE.Group();

  const hullMat = new THREE.MeshStandardMaterial({
    color: 0xb0966b,
    roughness: 0.62,
    metalness: 0.28,
  });
  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x22252a,
    roughness: 0.36,
    metalness: 0.82,
  });
  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x151618,
    roughness: 0.92,
    metalness: 0.05,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x1a2c3a,
    roughness: 0.12,
    metalness: 0.75,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff7dc,
    emissive: 0xffe4a0,
    emissiveIntensity: 1.8,
  });
  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    emissive: 0xef4444,
    emissiveIntensity: 1.4,
  });

  const chassis = new THREE.Mesh(new THREE.BoxGeometry(2.48, 0.85, 5.15), hullMat);
  chassis.position.set(0, 0.88, 0);
  chassis.castShadow = !isSoftwareGl;
  chassis.receiveShadow = true;
  group.add(chassis);

  const hood = new THREE.Mesh(new THREE.BoxGeometry(2.18, 0.32, 1.55), hullMat);
  hood.position.set(0, 1.38, 1.78);
  hood.rotation.x = 0.15;
  hood.castShadow = !isSoftwareGl;
  group.add(hood);

  const cab = new THREE.Mesh(new THREE.BoxGeometry(2.26, 0.84, 2.72), hullMat);
  cab.position.set(0, 1.78, -0.05);
  cab.castShadow = !isSoftwareGl;
  cab.receiveShadow = true;
  group.add(cab);

  const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.94, 0.48, 0.08), glassMat);
  windshield.position.set(0, 1.78, 1.32);
  windshield.rotation.x = -0.18;
  group.add(windshield);

  for (const sx of [-1.14, 1.14]) {
    const sideWinFront = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.42, 0.85), glassMat);
    sideWinFront.position.set(sx, 1.8, 0.62);
    group.add(sideWinFront);
    const sideWinRear = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.42, 0.85), glassMat);
    sideWinRear.position.set(sx, 1.8, -0.58);
    group.add(sideWinRear);
  }

  for (let gx = -0.54; gx <= 0.54; gx += 0.18) {
    const slat = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.36, 0.08), darkMetal);
    slat.position.set(gx, 1.04, 2.58);
    group.add(slat);
  }
  for (const hx of [-0.84, 0.84]) {
    const hl = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.08, 10), headlightMat);
    hl.rotation.x = Math.PI / 2;
    hl.position.set(hx, 1.05, 2.58);
    group.add(hl);

    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.08), taillightMat);
    tl.position.set(hx, 1.02, -2.58);
    group.add(tl);
  }

  const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.52, 0.3, 0.34), darkMetal);
  bumper.position.set(0, 0.66, 2.68);
  group.add(bumper);

  const wheelGeo = new THREE.CylinderGeometry(0.56, 0.56, 0.44, 16);
  wheelGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.47, 10);
  rimGeo.rotateZ(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.5, 8);
  hubGeo.rotateZ(Math.PI / 2);

  const wheelCoords: [number, number][] = [
    [-1.32, 1.68],
    [1.32, 1.68],
    [-1.32, -1.68],
    [1.32, -1.68],
  ];
  for (const [wx, wz] of wheelCoords) {
    const tire = new THREE.Mesh(wheelGeo, tireMat);
    tire.position.set(wx, 0.56, wz);
    tire.castShadow = !isSoftwareGl;
    group.add(tire);
    const rim = new THREE.Mesh(rimGeo, darkMetal);
    rim.position.set(wx, 0.56, wz);
    group.add(rim);
    const hub = new THREE.Mesh(hubGeo, hullMat);
    hub.position.set(wx, 0.56, wz);
    group.add(hub);
  }

  const turretRing = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.65, 0.22, 14), darkMetal);
  turretRing.position.set(0, 2.28, -0.1);
  group.add(turretRing);

  const gunShield = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.48, 0.1), hullMat);
  gunShield.position.set(0, 2.58, 0.42);
  group.add(gunShield);

  const mgReceiver = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.16, 0.55), darkMetal);
  mgReceiver.position.set(0, 2.55, 0.18);
  group.add(mgReceiver);

  const mgBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.045, 1.15, 8), darkMetal);
  mgBarrel.rotation.x = Math.PI / 2;
  mgBarrel.position.set(0, 2.56, 0.72);
  group.add(mgBarrel);

  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.018, 1.85, 6), darkMetal);
  antenna.position.set(-0.98, 2.25, -2.15);
  group.add(antenna);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(3.45, 20),
    new THREE.MeshBasicMaterial({
      map: textures.shadowDiscMap,
      transparent: true,
      opacity: 0.48,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.scale.set(0.95, 1.52, 1);
  shadow.position.y = 0.015;
  group.add(shadow);

  return group;
}

export function createJerseyBarrier(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): THREE.Group {
  const group = new THREE.Group();
  const baseMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.concreteMap,
    bumpMap: textures.concreteBump,
    bumpScale: 0.04,
    roughness: 0.86,
    metalness: 0.06,
  });
  const upperMat = new THREE.MeshStandardMaterial({
    color: 0x949087,
    bumpMap: textures.concreteBump,
    bumpScale: 0.04,
    roughness: 0.86,
    metalness: 0.05,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.34, 0.92), baseMat);
  base.position.y = 0.17;
  base.castShadow = !isSoftwareGl;
  base.receiveShadow = true;
  group.add(base);

  const mid = new THREE.Mesh(new THREE.BoxGeometry(3.96, 0.44, 0.66), upperMat);
  mid.position.y = 0.56;
  mid.castShadow = !isSoftwareGl;
  mid.receiveShadow = true;
  group.add(mid);

  const top = new THREE.Mesh(new THREE.BoxGeometry(3.92, 0.48, 0.4), upperMat);
  top.position.y = 1.02;
  top.castShadow = !isSoftwareGl;
  top.receiveShadow = true;
  group.add(top);

  return group;
}

export function createShippingContainer(
  colorHex: number,
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): THREE.Group {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: colorHex,
    bumpMap: textures.containerRibBump,
    bumpScale: 0.075,
    roughness: 0.54,
    metalness: 0.48,
  });
  const frameMat = new THREE.MeshStandardMaterial({
    color: 0x202327,
    roughness: 0.38,
    metalness: 0.78,
  });

  const body = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.7, 6.2), bodyMat);
  body.position.y = 1.35;
  body.castShadow = !isSoftwareGl;
  body.receiveShadow = true;
  group.add(body);

  const postGeo = new THREE.BoxGeometry(0.2, 2.76, 0.2);
  for (const sx of [-1.25, 1.25]) {
    for (const sz of [-3.04, 3.04]) {
      const post = new THREE.Mesh(postGeo, frameMat);
      post.position.set(sx, 1.38, sz);
      group.add(post);
    }
  }

  const roofTrim = new THREE.Mesh(new THREE.BoxGeometry(2.72, 0.14, 6.32), frameMat);
  roofTrim.position.y = 2.69;
  group.add(roofTrim);

  const baseTrim = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.12, 6.3), frameMat);
  baseTrim.position.y = 0.06;
  group.add(baseTrim);

  const barGeo = new THREE.CylinderGeometry(0.032, 0.032, 2.45, 8);
  for (const endZ of [-3.12, 3.12]) {
    for (const bx of [-0.36, 0.36]) {
      const bar = new THREE.Mesh(barGeo, frameMat);
      bar.position.set(bx, 1.35, endZ);
      group.add(bar);
    }
  }

  return group;
}

export function createWatchtower(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): THREE.Group {
  const group = new THREE.Group();
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x383d44,
    roughness: 0.4,
    metalness: 0.78,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x72583b,
    map: textures.crateMap,
    roughness: 0.84,
    metalness: 0.06,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    color: 0x4f5646,
    roughness: 0.66,
    metalness: 0.32,
  });

  const legGeo = new THREE.BoxGeometry(0.24, 6.2, 0.24);
  for (const lx of [-1.42, 1.42]) {
    for (const lz of [-1.42, 1.42]) {
      const leg = new THREE.Mesh(legGeo, steelMat);
      leg.position.set(lx, 3.1, lz);
      leg.castShadow = !isSoftwareGl;
      group.add(leg);
    }
  }

  for (const hy of [1.8, 3.6]) {
    const beamF = new THREE.Mesh(new THREE.BoxGeometry(2.84, 0.12, 0.12), steelMat);
    beamF.position.set(0, hy, 1.42);
    group.add(beamF);
    const beamB = beamF.clone();
    beamB.position.set(0, hy, -1.42);
    group.add(beamB);
  }
  for (let ry = 0.5; ry <= 3.7; ry += 0.45) {
    const rung = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.65, 6), steelMat);
    rung.rotation.z = Math.PI / 2;
    rung.position.set(0, ry, 1.52);
    group.add(rung);
  }

  const deck = new THREE.Mesh(new THREE.BoxGeometry(3.45, 0.24, 3.45), woodMat);
  deck.position.y = 3.9;
  deck.castShadow = !isSoftwareGl;
  deck.receiveShadow = true;
  group.add(deck);

  const paraFront = new THREE.Mesh(new THREE.BoxGeometry(3.45, 0.92, 0.2), woodMat);
  paraFront.position.set(0, 4.46, 1.62);
  group.add(paraFront);
  const paraBack = paraFront.clone();
  paraBack.position.set(0, 4.46, -1.62);
  group.add(paraBack);
  const paraLeft = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.92, 3.1), woodMat);
  paraLeft.position.set(-1.62, 4.46, 0);
  group.add(paraLeft);
  const paraRight = paraLeft.clone();
  paraRight.position.set(1.62, 4.46, 0);
  group.add(paraRight);

  const roof = new THREE.Mesh(new THREE.BoxGeometry(3.95, 0.16, 3.95), roofMat);
  roof.position.y = 6.2;
  roof.rotation.x = 0.08;
  roof.castShadow = !isSoftwareGl;
  group.add(roof);

  return group;
}

export function createFloodlightTower(isSoftwareGl: boolean): THREE.Group {
  const group = new THREE.Group();
  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x2b3036,
    roughness: 0.38,
    metalness: 0.82,
  });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xfff3d1,
    emissive: 0xffd180,
    emissiveIntensity: 2.3,
    roughness: 0.2,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.65, 0.95), steelMat);
  base.position.y = 0.325;
  base.castShadow = !isSoftwareGl;
  group.add(base);

  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.14, 8.2, 8), steelMat);
  mast.position.y = 4.4;
  group.add(mast);

  const crossbar = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.14, 0.16), steelMat);
  crossbar.position.y = 8.4;
  group.add(crossbar);

  for (const lx of [-0.55, 0, 0.55]) {
    const housing = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.25, 0.22), steelMat);
    housing.position.set(lx, 8.56, 0);
    group.add(housing);

    const panel = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.18), lampMat);
    panel.position.set(lx, 8.56, 0.12);
    panel.rotation.x = 0.3;
    group.add(panel);
  }

  return group;
}

export function createRadarDish(): THREE.Group {
  const group = new THREE.Group();
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x565d66,
    roughness: 0.32,
    metalness: 0.82,
  });
  const tipMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xef4444,
    emissiveIntensity: 1.9,
  });

  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 1.15, 8), metalMat);
  mast.position.y = 0.57;
  group.add(mast);

  const dish = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.38, 0.14), metalMat);
  dish.position.y = 1.16;
  group.add(dish);

  const feedHorn = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.07, 0.32, 8), metalMat);
  feedHorn.rotation.x = Math.PI / 2;
  feedHorn.position.set(0, 1.16, 0.2);
  group.add(feedHorn);

  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), tipMat);
  beacon.position.y = 1.48;
  group.add(beacon);

  return group;
}

export function createReconUavDrone(): THREE.Group {
  const group = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({
    color: 0x353c45,
    roughness: 0.34,
    metalness: 0.78,
  });
  const sensorMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.3,
  });
  const wingTipMat = new THREE.MeshBasicMaterial({ color: 0x22c55e });

  const fuselage = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 2.7, 10), hullMat);
  fuselage.rotation.x = Math.PI / 2;
  group.add(fuselage);

  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.21, 10, 8), hullMat);
  nose.scale.set(0.95, 0.85, 1.7);
  nose.position.z = 1.35;
  group.add(nose);

  const wings = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.07, 0.65), hullMat);
  wings.position.z = 0.1;
  group.add(wings);

  for (const side of [-1, 1]) {
    const vTail = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.06, 0.34), hullMat);
    vTail.position.set(side * 0.38, 0.24, -1.12);
    vTail.rotation.z = side * 0.55;
    group.add(vTail);
  }

  const strobe = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), wingTipMat);
  strobe.position.set(2.38, 0.04, 0.1);
  group.add(strobe);

  const sensor = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 10), sensorMat);
  sensor.position.set(0, -0.2, 0.58);
  group.add(sensor);

  const propeller = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.07, 0.03), hullMat);
  propeller.position.set(0, 0, -1.42);
  group.add(propeller);
  group.userData.propeller = propeller;

  return group;
}

export function createFuelBarrel(isSoftwareGl: boolean): THREE.Group {
  const group = new THREE.Group();
  const drumMat = new THREE.MeshStandardMaterial({
    color: 0xb91c1c,
    roughness: 0.42,
    metalness: 0.48,
  });
  const bandMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    roughness: 0.52,
    metalness: 0.25,
  });
  const capMat = new THREE.MeshStandardMaterial({
    color: 0x26292e,
    roughness: 0.4,
    metalness: 0.8,
  });

  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 1.24, 16), drumMat);
  body.position.y = 0.62;
  body.castShadow = !isSoftwareGl;
  body.receiveShadow = true;
  group.add(body);

  const ring1 = new THREE.Mesh(new THREE.CylinderGeometry(0.445, 0.445, 0.13, 16), bandMat);
  ring1.position.y = 0.88;
  group.add(ring1);

  const ring2 = new THREE.Mesh(new THREE.CylinderGeometry(0.445, 0.445, 0.09, 16), bandMat);
  ring2.position.y = 0.34;
  group.add(ring2);

  const topRim = new THREE.Mesh(new THREE.TorusGeometry(0.41, 0.025, 8, 16), capMat);
  topRim.rotation.x = Math.PI / 2;
  topRim.position.y = 1.24;
  group.add(topRim);

  const bung = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 8), capMat);
  bung.position.set(0.18, 1.25, 0.1);
  group.add(bung);

  return group;
}

export function createPickupMesh(
  kind: 'medkit' | 'ammo',
  textures: MaterialTextures,
): THREE.Group {
  const group = new THREE.Group();
  const accentHex = kind === 'medkit' ? 0x10b981 : 0xf59e0b;
  const baseMat = new THREE.MeshStandardMaterial({
    color: kind === 'medkit' ? 0xf1f5f9 : 0x365314,
    roughness: 0.32,
    metalness: 0.3,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 0.85,
    roughness: 0.25,
  });

  const box = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.32, 0.42), baseMat);
  box.position.y = 0.38;
  group.add(box);

  if (kind === 'medkit') {
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.045, 0.08), accentMat);
    crossH.position.y = 0.55;
    group.add(crossH);
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.045, 0.24), accentMat);
    crossV.position.y = 0.55;
    group.add(crossV);
  } else {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.08, 0.44), accentMat);
    band.position.y = 0.38;
    group.add(band);
  }

  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.18, 2.2, 10, 1, true),
    new THREE.MeshBasicMaterial({
      color: accentHex,
      transparent: true,
      opacity: 0.24,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
  );
  beam.position.y = 1.25;
  group.add(beam);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.48, 12),
    new THREE.MeshBasicMaterial({
      map: textures.shadowDiscMap,
      transparent: true,
      opacity: 0.44,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  group.add(shadow);

  return group;
}

export interface MissionObjectiveProp {
  root: THREE.Group;
  ringMesh: THREE.Mesh;
  spinnerMesh: THREE.Object3D;
  hitCollider: THREE.Mesh;
}

export function createMissionObjectiveProp(
  kind: 'uplink' | 'jammer' | 'hold',
): MissionObjectiveProp {
  const root = new THREE.Group();
  const isHostile = kind === 'jammer';
  const accentColor = isHostile ? 0xef4444 : kind === 'hold' ? 0xf59e0b : 0x10b981;

  const caseMat = new THREE.MeshStandardMaterial({
    color: isHostile ? 0x261d1d : 0x1c2529,
    roughness: 0.48,
    metalness: 0.62,
  });
  const glowMat = new THREE.MeshStandardMaterial({
    color: accentColor,
    emissive: accentColor,
    emissiveIntensity: 1.8,
    roughness: 0.2,
  });

  const ringMesh = new THREE.Mesh(
    new THREE.RingGeometry(2.6, 2.9, 32),
    new THREE.MeshBasicMaterial({
      color: accentColor,
      transparent: true,
      opacity: 0.68,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.03;
  root.add(ringMesh);

  const base = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.75, 0.72), caseMat);
  base.position.y = 0.375;
  root.add(base);

  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.36, 0.06), glowMat);
  screen.position.set(0, 0.92, 0.14);
  screen.rotation.x = -0.3;
  root.add(screen);

  const spinnerMesh = new THREE.Group();
  spinnerMesh.position.set(0, 1.38, 0);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.55, 8), caseMat);
  spinnerMesh.add(mast);
  const beaconBar = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.1, 0.1), glowMat);
  beaconBar.position.y = 0.24;
  spinnerMesh.add(beaconBar);
  root.add(spinnerMesh);

  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.22, 4.8, 12, 1, true),
    new THREE.MeshBasicMaterial({
      color: accentColor,
      transparent: true,
      opacity: 0.18,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
  );
  beam.position.y = 2.4;
  root.add(beam);

  const hitCollider = new THREE.Mesh(
    new THREE.BoxGeometry(1.15, 1.75, 0.95),
    new THREE.MeshBasicMaterial({ visible: false }),
  );
  hitCollider.position.y = 0.88;
  hitCollider.layers.set(1);
  hitCollider.userData = { objectiveTarget: true };
  root.add(hitCollider);

  return {
    root,
    ringMesh,
    spinnerMesh,
    hitCollider,
  };
}

export interface HelicopterRig {
  root: THREE.Group;
  mainRotor: THREE.Group;
  tailRotor: THREE.Mesh;
  rappelRopes: THREE.Group;
}

export function createTacticalHelicopter(isSoftwareGl: boolean): HelicopterRig {
  const root = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({
    color: 0x262d35,
    roughness: 0.46,
    metalness: 0.68,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.45,
    metalness: 0.3,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x1e3a5f,
    roughness: 0.14,
    metalness: 0.85,
  });

  const fuselage = new THREE.Mesh(new THREE.BoxGeometry(2.1, 1.5, 5.2), hullMat);
  fuselage.position.y = 1.6;
  fuselage.castShadow = !isSoftwareGl;
  root.add(fuselage);

  const nose = new THREE.Mesh(new THREE.BoxGeometry(1.75, 1.05, 1.5), glassMat);
  nose.position.set(0, 1.4, 3.0);
  nose.rotation.x = 0.25;
  root.add(nose);

  const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.15, 0.16, 4.6), trimMat);
  stripe.position.set(0, 1.3, 0);
  root.add(stripe);

  const tailBoom = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.55, 4.4), hullMat);
  tailBoom.position.set(0, 1.9, -4.4);
  root.add(tailBoom);

  const tailFin = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.45, 0.75), hullMat);
  tailFin.position.set(0, 2.55, -6.3);
  tailFin.rotation.x = -0.3;
  root.add(tailFin);

  for (const sx of [-1.05, 1.05]) {
    const skid = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 4.2, 8), hullMat);
    skid.rotation.x = Math.PI / 2;
    skid.position.set(sx, 0.25, 0.2);
    root.add(skid);
  }

  const mainRotor = new THREE.Group();
  mainRotor.position.set(0, 2.75, 0);
  const bladeMat = new THREE.MeshStandardMaterial({ color: 0x111418, roughness: 0.4, metalness: 0.7 });
  const bladeA = new THREE.Mesh(new THREE.BoxGeometry(8.6, 0.05, 0.34), bladeMat);
  const bladeB = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.05, 8.6), bladeMat);
  mainRotor.add(bladeA, bladeB);
  root.add(mainRotor);

  const tailRotor = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.45, 0.16), bladeMat);
  tailRotor.position.set(0.24, 2.7, -6.35);
  root.add(tailRotor);

  const rappelRopes = new THREE.Group();
  const ropeMat = new THREE.MeshStandardMaterial({ color: 0xa89f8d, roughness: 0.9 });
  for (const rx of [-1.2, 1.2]) {
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 8.5, 6), ropeMat);
    rope.position.set(rx, -3.2, 0.4);
    rappelRopes.add(rope);
  }
  root.add(rappelRopes);

  return { root, mainRotor, tailRotor, rappelRopes };
}

export interface AlliedRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
}

export function createAlliedSoldier(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): AlliedRig {
  const rig = createEnemySoldier('rifleman', textures, isSoftwareGl);
  // Recolor visor & shoulder stripes to friendly Cobalt Blue / Emerald
  rig.visorMat.color.setHex(0x38bdf8);
  rig.visorMat.emissive.setHex(0x38bdf8);
  rig.visorMat.emissiveIntensity = 1.6;
  rig.headCollider.visible = false;
  rig.torsoCollider.visible = false;
  rig.headCollider.layers.set(0);
  rig.torsoCollider.layers.set(0);

  const badgeMat = new THREE.MeshStandardMaterial({
    color: 0x22c55e,
    emissive: 0x16a34a,
    emissiveIntensity: 1.25,
  });
  const beacon = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.08, 0.14), badgeMat);
  beacon.position.set(0, 1.92, 0);
  rig.bodyGroup.add(beacon);

  // Friendly IFF chest patch & shoulder chevrons for immediate squad readability
  const chestIff = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.04), badgeMat);
  chestIff.position.set(0, 1.28, 0.2);
  rig.bodyGroup.add(chestIff);
  for (const sx of [-0.34, 0.34]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.11, 0.14), badgeMat);
    strip.position.set(sx, 1.32, 0.02);
    rig.bodyGroup.add(strip);
  }

  return {
    root: rig.root,
    bodyGroup: rig.bodyGroup,
    leftLeg: rig.leftLeg,
    rightLeg: rig.rightLeg,
    leftArm: rig.leftArm,
    rightArm: rig.rightArm,
  };
}

export interface SentryTurretRig {
  root: THREE.Group;
  headGroup: THREE.Group;
  barrelFlash: THREE.Mesh;
}

export function createSentryTurret(): SentryTurretRig {
  const root = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({ color: 0x272c34, roughness: 0.35, metalness: 0.8 });
  const accent = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0ea5e9,
    emissiveIntensity: 1.4,
  });

  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI * 2;
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.72, 0.08), metal);
    leg.position.set(Math.cos(a) * 0.28, 0.32, Math.sin(a) * 0.28);
    leg.rotation.z = Math.cos(a) * 0.35;
    leg.rotation.x = -Math.sin(a) * 0.35;
    root.add(leg);
  }

  const headGroup = new THREE.Group();
  headGroup.position.y = 0.76;
  const turretBox = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.24, 0.48), metal);
  headGroup.add(turretBox);

  const sensorEye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), accent);
  sensorEye.position.set(0, 0.13, 0.16);
  headGroup.add(sensorEye);

  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.032, 0.56, 8), metal);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0, 0.42);
  headGroup.add(barrel);

  const barrelFlash = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.09, 0),
    new THREE.MeshBasicMaterial({ color: 0xfef08a }),
  );
  barrelFlash.position.set(0, 0, 0.72);
  barrelFlash.visible = false;
  headGroup.add(barrelFlash);

  root.add(headGroup);
  return { root, headGroup, barrelFlash };
}

export function createIntelLaptop(): { root: THREE.Group; screenMesh: THREE.Mesh } {
  const root = new THREE.Group();
  const caseMat = new THREE.MeshStandardMaterial({ color: 0x1e242b, roughness: 0.4, metalness: 0.7 });
  const screenMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0ea5e9,
    emissiveIntensity: 1.5,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.04, 0.34), caseMat);
  base.position.y = 0.26;
  root.add(base);

  const screenMesh = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.3, 0.03), screenMat);
  screenMesh.position.set(0, 0.41, -0.14);
  screenMesh.rotation.x = -0.25;
  root.add(screenMesh);

  const pedestal = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.24, 0.48), caseMat);
  pedestal.position.y = 0.12;
  root.add(pedestal);

  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.55, 0.68, 24),
    new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.65, side: THREE.DoubleSide }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.03;
  root.add(ring);

  return { root, screenMesh };
}

export function createLandmine(): { root: THREE.Group; ledMesh: THREE.Mesh } {
  const root = new THREE.Group();
  const disc = new THREE.Mesh(
    new THREE.CylinderGeometry(0.24, 0.28, 0.08, 14),
    new THREE.MeshStandardMaterial({ color: 0x363b2e, roughness: 0.6, metalness: 0.4 }),
  );
  disc.position.y = 0.04;
  root.add(disc);

  const ledMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.045, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xef4444 }),
  );
  ledMesh.position.y = 0.095;
  root.add(ledMesh);
  return { root, ledMesh };
}

export function createClaymoreMine(): { root: THREE.Group; laserFan: THREE.Mesh } {
  const root = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(0.32, 0.18, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x2f3b2a, roughness: 0.65, metalness: 0.3 }),
  );
  body.position.y = 0.15;
  root.add(body);

  const laserFan = new THREE.Mesh(
    new THREE.ConeGeometry(0.75, 2.2, 4, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  laserFan.rotation.x = -Math.PI / 2;
  laserFan.position.set(0, 0.18, 1.12);
  root.add(laserFan);
  return { root, laserFan };
}

export function createC4Pack(): { root: THREE.Group; ledMesh: THREE.Mesh } {
  const root = new THREE.Group();
  const brick = new THREE.Mesh(
    new THREE.BoxGeometry(0.28, 0.09, 0.18),
    new THREE.MeshStandardMaterial({ color: 0x847a5b, roughness: 0.8 }),
  );
  brick.position.y = 0.05;
  root.add(brick);

  const ledMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 0.03, 0.05),
    new THREE.MeshBasicMaterial({ color: 0x22c55e }),
  );
  ledMesh.position.y = 0.105;
  root.add(ledMesh);
  return { root, ledMesh };
}

export function createBreachDoor(): { root: THREE.Group; doorPanel: THREE.Group } {
  const root = new THREE.Group();
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x26292e, roughness: 0.45, metalness: 0.75 });
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x6b2d22, roughness: 0.55, metalness: 0.45 });

  const leftPost = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.7, 0.26), frameMat);
  leftPost.position.set(-1.1, 1.35, 0);
  const rightPost = new THREE.Mesh(new THREE.BoxGeometry(0.22, 2.7, 0.26), frameMat);
  rightPost.position.set(1.1, 1.35, 0);
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(2.42, 0.24, 0.28), frameMat);
  lintel.position.set(0, 2.7, 0);
  root.add(leftPost, rightPost, lintel);

  const doorPanel = new THREE.Group();
  doorPanel.position.set(-0.98, 0, 0);
  const slab = new THREE.Mesh(new THREE.BoxGeometry(1.96, 2.56, 0.14), doorMat);
  slab.position.set(0.98, 1.28, 0);
  doorPanel.add(slab);
  const stripe = new THREE.Mesh(
    new THREE.BoxGeometry(1.86, 0.16, 0.16),
    new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 0.55 }),
  );
  stripe.position.set(0.98, 1.28, 0);
  doorPanel.add(stripe);
  root.add(doorPanel);

  return { root, doorPanel };
}

export function createMortarRing(): { root: THREE.Group; ringMesh: THREE.Mesh; coreMesh: THREE.Mesh } {
  const root = new THREE.Group();
  const ringMesh = new THREE.Mesh(
    new THREE.RingGeometry(3.2, 3.6, 28),
    new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.04;
  root.add(ringMesh);

  const coreMesh = new THREE.Mesh(
    new THREE.CircleGeometry(3.2, 24),
    new THREE.MeshBasicMaterial({
      color: 0xdc2626,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  coreMesh.rotation.x = -Math.PI / 2;
  coreMesh.position.y = 0.03;
  root.add(coreMesh);

  return { root, ringMesh, coreMesh };
}

export function createRpgRocket(): THREE.Group {
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.05, 0.52, 8),
    new THREE.MeshStandardMaterial({ color: 0x365314, metalness: 0.5, roughness: 0.4 }),
  );
  body.rotation.x = Math.PI / 2;
  g.add(body);
  const cone = new THREE.Mesh(
    new THREE.ConeGeometry(0.07, 0.18, 8),
    new THREE.MeshBasicMaterial({ color: 0xf97316 }),
  );
  cone.rotation.x = Math.PI / 2;
  cone.position.z = 0.34;
  g.add(cone);
  return g;
}

export function createCarePackageCrate(): {
  root: THREE.Group;
  chuteGroup: THREE.Group;
  beaconMesh: THREE.Mesh;
} {
  const root = new THREE.Group();

  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x3f4f38,
    roughness: 0.72,
    metalness: 0.28,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.45,
    metalness: 0.4,
  });
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.88, 1.18), crateMat);
  body.position.y = 0.44;
  root.add(body);

  const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.16, 1.22), trimMat);
  stripe.position.y = 0.56;
  root.add(stripe);

  const beaconMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
  const beaconMesh = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 10), beaconMat);
  beaconMesh.position.set(0, 0.96, 0);
  root.add(beaconMesh);

  const chuteGroup = new THREE.Group();
  const canopy = new THREE.Mesh(
    new THREE.SphereGeometry(1.45, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.48),
    new THREE.MeshStandardMaterial({
      color: 0xd6cfc2,
      roughness: 0.85,
      side: THREE.DoubleSide,
    }),
  );
  canopy.position.y = 2.85;
  chuteGroup.add(canopy);

  const ropeMat = new THREE.MeshBasicMaterial({ color: 0x64748b });
  const ropeOffsets: [number, number][] = [
    [-0.5, -0.5],
    [0.5, -0.5],
    [-0.5, 0.5],
    [0.5, 0.5],
  ];
  for (const [rx, rz] of ropeOffsets) {
    const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 2.2, 5), ropeMat);
    rope.position.set(rx * 1.15, 1.82, rz * 1.15);
    rope.rotation.z = rx * 0.36;
    rope.rotation.x = -rz * 0.36;
    chuteGroup.add(rope);
  }
  root.add(chuteGroup);

  return { root, chuteGroup, beaconMesh };
}

export interface BombDeviceRig {
  root: THREE.Group;
  ledMat: THREE.MeshBasicMaterial;
  ringMesh: THREE.Mesh;
}

export function createBombDevice(): BombDeviceRig {
  const root = new THREE.Group();

  const caseMat = new THREE.MeshStandardMaterial({
    color: 0x1e242c,
    roughness: 0.42,
    metalness: 0.72,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.5,
    metalness: 0.55,
  });

  const crate = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.72, 0.85), caseMat);
  crate.position.y = 0.36;
  root.add(crate);

  const panel = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.08, 0.56), trimMat);
  panel.position.set(0, 0.74, 0);
  root.add(panel);

  const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.52, 10), trimMat);
  cyl.rotation.z = Math.PI / 2;
  cyl.position.set(0, 0.82, -0.1);
  root.add(cyl);

  const ledMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 10), ledMat);
  beacon.position.set(0, 1.0, 0.14);
  root.add(beacon);

  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.02, 0.65, 6), caseMat);
  antenna.position.set(0.32, 1.05, -0.2);
  root.add(antenna);

  const ringMesh = new THREE.Mesh(
    new THREE.RingGeometry(1.9, 2.25, 28),
    new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.68,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.04;
  root.add(ringMesh);

  return { root, ledMat, ringMesh };
}

export interface FiringRangeTargetRig {
  root: THREE.Group;
  pivotGroup: THREE.Group;
  headCollider: THREE.Mesh;
  bodyCollider: THREE.Mesh;
  ringMat: THREE.MeshBasicMaterial;
}

export function createFiringRangeTarget(isArmored: boolean): FiringRangeTargetRig {
  const root = new THREE.Group();
  const hitMat = new THREE.MeshBasicMaterial({ visible: false });

  const standMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.55,
    metalness: 0.7,
  });
  const plateMat = new THREE.MeshStandardMaterial({
    color: isArmored ? 0x1d4ed8 : 0xe2e8f0,
    roughness: 0.45,
    metalness: isArmored ? 0.55 : 0.2,
  });
  const bullMat = new THREE.MeshStandardMaterial({
    color: isArmored ? 0xf59e0b : 0xef4444,
    emissive: isArmored ? 0xb45309 : 0x991b1b,
    emissiveIntensity: 0.5,
  });

  const base = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.14, 0.6), standMat);
  base.position.y = 0.07;
  root.add(base);

  const pivotGroup = new THREE.Group();
  pivotGroup.position.y = 0.14;
  root.add(pivotGroup);

  const post = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.58, 0.12), standMat);
  post.position.y = 0.29;
  pivotGroup.add(post);

  const torsoBoard = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.92, 0.09), plateMat);
  torsoBoard.position.y = 1.02;
  pivotGroup.add(torsoBoard);

  const bullseye = new THREE.Mesh(new THREE.CircleGeometry(0.2, 16), bullMat);
  bullseye.position.set(0, 1.04, 0.052);
  pivotGroup.add(bullseye);

  const headBoard = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.09, 14), bullMat);
  headBoard.rotation.x = Math.PI / 2;
  headBoard.position.set(0, 1.66, 0);
  pivotGroup.add(headBoard);

  const ringMat = new THREE.MeshBasicMaterial({
    color: isArmored ? 0x38bdf8 : 0xf59e0b,
    transparent: true,
    opacity: 0.65,
    side: THREE.DoubleSide,
  });
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.68, 24), ringMat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.025;
  root.add(ring);

  const headCollider = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, 0.24), hitMat);
  headCollider.position.set(0, 1.66, 0);
  headCollider.layers.set(1);
  headCollider.userData = { part: 'head' };
  pivotGroup.add(headCollider);

  const bodyCollider = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.96, 0.24), hitMat);
  bodyCollider.position.set(0, 1.02, 0);
  bodyCollider.layers.set(1);
  bodyCollider.userData = { part: 'body' };
  pivotGroup.add(bodyCollider);

  return { root, pivotGroup, headCollider, bodyCollider, ringMat };
}

export interface HostageRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  ringMesh: THREE.Mesh;
  beaconMat: THREE.MeshBasicMaterial;
}

export function createHostageModel(
  textures: MaterialTextures,
  isSoftwareGl: boolean,
): HostageRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const jacketMat = new THREE.MeshStandardMaterial({
    color: 0x3b82f6,
    roughness: 0.65,
    metalness: 0.12,
  });
  const trousersMat = new THREE.MeshStandardMaterial({
    color: 0x262930,
    roughness: 0.78,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xd6a88c,
    roughness: 0.7,
  });
  const vestMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.45,
    metalness: 0.25,
  });

  // Kneeling prisoner posture (distinct silhouette from enemy combatants)
  const leftKnee = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.48, 0.22), trousersMat);
  leftKnee.position.set(-0.14, 0.24, 0.06);
  leftKnee.castShadow = !isSoftwareGl;
  const rightKnee = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.48, 0.22), trousersMat);
  rightKnee.position.set(0.14, 0.24, 0.06);
  rightKnee.castShadow = !isSoftwareGl;

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.54, 0.28), jacketMat);
  torso.position.set(0, 0.72, 0);
  torso.castShadow = !isSoftwareGl;

  const safetyStripe = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.12, 0.3), vestMat);
  safetyStripe.position.set(0, 0.76, 0);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 10), skinMat);
  head.position.set(0, 1.15, 0.02);
  head.castShadow = !isSoftwareGl;

  // Bound hands behind back
  for (const sx of [-0.26, 0.26]) {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.44, 0.14), jacketMat);
    arm.position.set(sx, 0.68, -0.06);
    arm.rotation.x = 0.35;
    bodyGroup.add(arm);
  }

  bodyGroup.add(leftKnee, rightKnee, torso, safetyStripe, head);

  const beaconMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const ringMesh = new THREE.Mesh(new THREE.RingGeometry(0.85, 1.05, 28), beaconMat);
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.03;
  root.add(ringMesh);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.5, 12),
    new THREE.MeshBasicMaterial({
      map: textures.shadowDiscMap,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  return { root, bodyGroup, ringMesh, beaconMat };
}



