import * as THREE from 'three';
import {
  createArmoredVehicle,
  createBreachDoor,
  createDestructibleCrate,
  createFloodlightTower,
  createFuelBarrel,
  createJerseyBarrier,
  createRadarDish,
  createReconUavDrone,
  createShippingContainer,
  createTacticalHelicopter,
  createWatchtower,
  type HelicopterRig,
} from './models';
import type { MaterialTextures } from './textures';
import type { Aabb2D, GameMode } from './types';

export interface ExplosiveBarrel {
  id: number;
  mesh: THREE.Group;
  colliderMesh: THREE.Mesh;
  x: number;
  z: number;
  hp: number;
  exploded: boolean;
}

export interface DestructibleCrate {
  id: number;
  mesh: THREE.Group;
  colliderMesh: THREE.Mesh;
  box: Aabb2D;
  x: number;
  z: number;
  hp: number;
  destroyed: boolean;
}

export interface BreachDoorEntity {
  id: number;
  root: THREE.Group;
  doorPanel: THREE.Group;
  box: Aabb2D;
  x: number;
  z: number;
  breached: boolean;
  openProgress: number;
}

export interface ArenaWorld {
  colliders: Aabb2D[];
  obstacleRayTargets: THREE.Object3D[];
  barrels: ExplosiveBarrel[];
  destructibleCrates: DestructibleCrate[];
  breachDoors: BreachDoorEntity[];
  helicopter: HelicopterRig;
  jeepPos: { x: number; z: number };
  spawnPoints: { x: number; z: number }[];
  uavDrone: THREE.Group;
  radarDish: THREE.Group;
  dustPoints: THREE.Points;
  sunLight: THREE.DirectionalLight;
  setChapterAtmosphere: (chapter: number, blackoutActive?: boolean, mode?: GameMode) => void;
  dispose: () => void;
}

export function buildTacticalArena(
  scene: THREE.Scene,
  textures: MaterialTextures,
  isSoftwareGl: boolean,
  shadowResolution = 1024,
): ArenaWorld {
  const colliders: Aabb2D[] = [];
  const obstacleRayTargets: THREE.Object3D[] = [];
  const barrels: ExplosiveBarrel[] = [];
  const destructibleCrates: DestructibleCrate[] = [];
  const breachDoors: BreachDoorEntity[] = [];
  const floodlightCones: THREE.Mesh[] = [];

  // 1. Golden-hour tactical dusk sky dome + matching horizon haze fog
  const horizonColor = new THREE.Color(0xd2a374);
  scene.background = horizonColor;
  scene.fog = new THREE.FogExp2(0xd2a374, 0.0102);

  const skyGeo = new THREE.SphereGeometry(180, 24, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      topColor: { value: new THREE.Color(0x284364) },
      midColor: { value: new THREE.Color(0x7c8594) },
      bottomColor: { value: horizonColor },
      sunDir: { value: new THREE.Vector3(28, 22, -45).normalize() },
    },
    vertexShader: `
      varying vec3 vWorldPos;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 midColor;
      uniform vec3 bottomColor;
      uniform vec3 sunDir;
      varying vec3 vWorldPos;
      void main() {
        vec3 dir = normalize(vWorldPos);
        float h = clamp(dir.y, 0.0, 1.0);
        vec3 col = mix(bottomColor, midColor, smoothstep(0.0, 0.24, h));
        col = mix(col, topColor, smoothstep(0.22, 0.78, h));
        float sunAmt = max(dot(dir, sunDir), 0.0);
        col += vec3(1.0, 0.78, 0.48) * pow(sunAmt, 24.0) * 0.55;
        col += vec3(1.0, 0.92, 0.78) * pow(sunAmt, 240.0) * 1.1;
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  scene.add(skyDome);

  const hemi = new THREE.HemisphereLight(0x9fc2ea, 0x6b533b, 0.95);
  scene.add(hemi);

  const sun = new THREE.DirectionalLight(0xffdfb0, 2.4);
  sun.position.set(28, 36, -24);
  if (!isSoftwareGl) {
    sun.castShadow = true;
    sun.shadow.mapSize.set(shadowResolution, shadowResolution);
    sun.shadow.radius = 3;
    sun.shadow.camera.near = 5;
    sun.shadow.camera.far = 115;
    const d = 44;
    sun.shadow.camera.left = -d;
    sun.shadow.camera.right = d;
    sun.shadow.camera.top = d;
    sun.shadow.camera.bottom = -d;
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.02;
  }
  scene.add(sun);

  const rimLight = new THREE.DirectionalLight(0x78aee6, 0.62);
  rimLight.position.set(-26, 18, 28);
  scene.add(rimLight);

  const outerGroundMat = new THREE.MeshStandardMaterial({
    color: 0xa48966,
    roughness: 0.94,
    metalness: 0.02,
  });
  const outerGround = new THREE.Mesh(new THREE.PlaneGeometry(280, 280), outerGroundMat);
  outerGround.rotation.x = -Math.PI / 2;
  outerGround.position.y = -0.03;
  outerGround.receiveShadow = true;
  scene.add(outerGround);

  const courtMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.groundMap,
    bumpMap: textures.groundBump,
    bumpScale: 0.035,
    roughness: 0.85,
    metalness: 0.06,
  });
  const courtyard = new THREE.Mesh(new THREE.PlaneGeometry(78, 78), courtMat);
  courtyard.rotation.x = -Math.PI / 2;
  courtyard.position.y = 0;
  courtyard.receiveShadow = true;
  scene.add(courtyard);
  obstacleRayTargets.push(courtyard);

  const lineMat = new THREE.MeshStandardMaterial({
    color: 0xd9a84e,
    roughness: 0.76,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const padRing = new THREE.Mesh(new THREE.RingGeometry(4.2, 4.65, 32), lineMat);
  padRing.rotation.x = -Math.PI / 2;
  padRing.position.set(0, 0.02, 0);
  scene.add(padRing);

  const padHBar1 = new THREE.Mesh(new THREE.PlaneGeometry(0.45, 3.6), lineMat);
  padHBar1.rotation.x = -Math.PI / 2;
  padHBar1.position.set(-1.1, 0.02, 0);
  scene.add(padHBar1);
  const padHBar2 = padHBar1.clone();
  padHBar2.position.set(1.1, 0.02, 0);
  scene.add(padHBar2);
  const padHCross = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.45), lineMat);
  padHCross.rotation.x = -Math.PI / 2;
  padHCross.position.set(0, 0.02, 0);
  scene.add(padHCross);

  const registerBox = (
    cx: number,
    cz: number,
    w: number,
    d: number,
    h: number,
    rayMesh: THREE.Object3D,
    label?: string,
  ) => {
    colliders.push({
      minX: cx - w / 2,
      maxX: cx + w / 2,
      minZ: cz - d / 2,
      maxZ: cz + d / 2,
      height: h,
      label,
    });
    obstacleRayTargets.push(rayMesh);
  };

  // 2. Shipping Containers
  const containerDefs: {
    x: number;
    z: number;
    rotY: number;
    color: number;
  }[] = [
    { x: -13, z: 4, rotY: 0, color: 0x4b5d44 },
    { x: 14, z: -3, rotY: 0, color: 0x8b3a2b },
    { x: -16, z: -18, rotY: Math.PI / 2, color: 0x3b4d5e },
    { x: 15, z: 16, rotY: Math.PI / 2, color: 0x7c6848 },
    { x: 0, z: -22, rotY: Math.PI / 2, color: 0x4b5d44 },
  ];

  for (const c of containerDefs) {
    const mesh = createShippingContainer(c.color, textures, isSoftwareGl);
    mesh.position.set(c.x, 0, c.z);
    mesh.rotation.y = c.rotY;
    scene.add(mesh);

    const isRotated = Math.abs(Math.sin(c.rotY)) > 0.7;
    const w = isRotated ? 6.2 : 2.6;
    const d = isRotated ? 2.6 : 6.2;
    registerBox(c.x, c.z, w, d, 2.7, mesh, 'container');
  }

  // 3. Central Armored Vehicle
  const jeep = createArmoredVehicle(textures, isSoftwareGl);
  jeep.position.set(-2.5, 0, -2.5);
  jeep.rotation.y = 0.35;
  scene.add(jeep);
  registerBox(-2.5, -2.5, 3.2, 5.2, 2.3, jeep, 'vehicle');

  // 4. Two Watchtowers + Radar Dish
  const towerPositions: [number, number][] = [
    [-25, -24],
    [25, -20],
  ];
  for (const [tx, tz] of towerPositions) {
    const tower = createWatchtower(textures, isSoftwareGl);
    tower.position.set(tx, 0, tz);
    scene.add(tower);
    registerBox(tx, tz, 3.4, 3.4, 6.2, tower, 'watchtower');
  }

  const radarDish = createRadarDish();
  radarDish.position.set(-25, 6.3, -24);
  scene.add(radarDish);

  const uavDrone = createReconUavDrone();
  uavDrone.position.set(0, 18, 0);
  uavDrone.visible = false;
  scene.add(uavDrone);

  // 5. Floodlight Towers + Night-Ops Volumetric Beam Cones
  const coneGeo = new THREE.ConeGeometry(7.2, 9.5, 16, 1, true);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xffe4a0,
    transparent: true,
    opacity: 0.14,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const floodSpots: { x: number; z: number; rotY: number }[] = [
    { x: -33, z: 28, rotY: 2.3 },
    { x: 33, z: 28, rotY: -2.3 },
  ];
  for (const f of floodSpots) {
    const tower = createFloodlightTower(isSoftwareGl);
    tower.position.set(f.x, 0, f.z);
    tower.rotation.y = f.rotY;
    scene.add(tower);
    registerBox(f.x, f.z, 1.0, 1.0, 8.5, tower, 'floodlight');

    const cone = new THREE.Mesh(coneGeo, coneMat);
    cone.position.set(f.x * 0.86, 4.4, f.z * 0.86);
    cone.visible = false;
    scene.add(cone);
    floodlightCones.push(cone);
  }

  // 6. Jersey Barriers + Static Crate Stacks
  const barrierDefs: { x: number; z: number; rotY: number }[] = [
    { x: 5.5, z: 10.5, rotY: 0 },
    { x: -6.5, z: 12.0, rotY: 0.15 },
    { x: 7.5, z: -11.5, rotY: -0.2 },
    { x: -7.5, z: -10.5, rotY: 0.2 },
    { x: -24, z: 11, rotY: Math.PI / 2 },
    { x: 24, z: 3, rotY: Math.PI / 2 },
  ];
  for (const b of barrierDefs) {
    const barrier = createJerseyBarrier(textures, isSoftwareGl);
    barrier.position.set(b.x, 0, b.z);
    barrier.rotation.y = b.rotY;
    scene.add(barrier);
    const rotated = Math.abs(Math.sin(b.rotY)) > 0.7;
    registerBox(b.x, b.z, rotated ? 0.92 : 4.0, rotated ? 4.0 : 0.92, 1.26, barrier, 'barrier');
  }

  const crateMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: textures.crateMap,
    roughness: 0.86,
    metalness: 0.04,
  });
  const crateClusters: [number, number][] = [
    [10, 6],
    [-10.5, -5],
    [6.2, 17],
    [-21, -8],
    [21, -10],
  ];
  for (const [cx, cz] of crateClusters) {
    const cluster = new THREE.Group();
    cluster.position.set(cx, 0, cz);
    const c1 = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.3, 1.4), crateMat);
    c1.position.set(0, 0.65, 0);
    c1.castShadow = !isSoftwareGl;
    c1.receiveShadow = true;
    cluster.add(c1);

    const c2 = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.0, 1.1), crateMat);
    c2.position.set(1.25, 0.5, 0.25);
    c2.rotation.y = 0.25;
    c2.castShadow = !isSoftwareGl;
    c2.receiveShadow = true;
    cluster.add(c2);

    const c3 = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, 0.95), crateMat);
    c3.position.set(0.15, 1.77, 0);
    c3.rotation.y = -0.3;
    c3.castShadow = !isSoftwareGl;
    c3.receiveShadow = true;
    cluster.add(c3);

    scene.add(cluster);
    registerBox(cx + 0.45, cz + 0.1, 2.7, 1.6, 2.2, cluster, 'crate');
  }

  // Interactive Destructible Supply Crates (shoot to break for ammo/medkit drops!)
  const supplyCrateCoords: [number, number][] = [
    [3.8, 13.8],
    [-8.2, 9.2],
    [11.2, -7.8],
    [-12.5, -12.5],
    [4.5, -16.5],
  ];
  supplyCrateCoords.forEach(([sx, sz], idx) => {
    const { group, colliderMesh } = createDestructibleCrate(textures, isSoftwareGl);
    group.position.set(sx, 0, sz);
    scene.add(group);
    colliderMesh.userData = { crateId: idx };
    const box: Aabb2D = {
      minX: sx - 0.6,
      maxX: sx + 0.6,
      minZ: sz - 0.6,
      maxZ: sz + 0.6,
      height: 1.15,
      label: `supply_crate_${idx}`,
    };
    colliders.push(box);
    destructibleCrates.push({
      id: idx,
      mesh: group,
      colliderMesh,
      box,
      x: sx,
      z: sz,
      hp: 45,
      destroyed: false,
    });
  });

  // 7. Shootable Explosive Fuel Barrels
  const barrelCoords: [number, number][] = [
    [-8.5, 4.5],
    [9.5, -2.5],
    [-4.5, -14.5],
    [12.0, 11.5],
    [-18.0, 14.0],
    [18.5, -14.5],
  ];
  const barrelHitMat = new THREE.MeshBasicMaterial({ visible: false });
  barrelCoords.forEach(([bx, bz], idx) => {
    const mesh = createFuelBarrel(isSoftwareGl);
    mesh.position.set(bx, 0, bz);
    scene.add(mesh);

    const colliderMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5, 0.5, 1.3, 8),
      barrelHitMat,
    );
    colliderMesh.position.set(bx, 0.65, bz);
    colliderMesh.layers.set(1);
    colliderMesh.userData = { barrelId: idx };
    scene.add(colliderMesh);

    barrels.push({
      id: idx,
      mesh,
      colliderMesh,
      x: bx,
      z: bz,
      hp: 45,
      exploded: false,
    });
  });

  // 8. Perimeter Concrete Walls + Canyon Cliffs
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x827868,
    roughness: 0.9,
    metalness: 0.05,
  });
  const wallGeo = new THREE.BoxGeometry(10, 3.2, 1.4);
  const wallCount = 32;
  const wallInst = new THREE.InstancedMesh(wallGeo, wallMat, wallCount);
  wallInst.receiveShadow = true;
  const dummy = new THREE.Object3D();
  let wi = 0;
  for (let side = 0; side < 4; side++) {
    for (let k = -3; k <= 4; k++) {
      if (wi >= wallCount) break;
      const offset = k * 10 - 5;
      if (side === 0) {
        dummy.position.set(offset, 1.6, -39);
        dummy.rotation.y = 0;
      } else if (side === 1) {
        dummy.position.set(offset, 1.6, 39);
        dummy.rotation.y = 0;
      } else if (side === 2) {
        dummy.position.set(-39, 1.6, offset);
        dummy.rotation.y = Math.PI / 2;
      } else {
        dummy.position.set(39, 1.6, offset);
        dummy.rotation.y = Math.PI / 2;
      }
      dummy.updateMatrix();
      wallInst.setMatrixAt(wi++, dummy.matrix);
    }
  }
  wallInst.computeBoundingSphere();
  scene.add(wallInst);
  obstacleRayTargets.push(wallInst);

  const rockGeo = new THREE.DodecahedronGeometry(6.5, 1);
  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x9b7a58,
    roughness: 0.95,
    metalness: 0.02,
    flatShading: true,
  });
  const rockCount = 28;
  const rockInst = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  const tint = new THREE.Color();
  for (let i = 0; i < rockCount; i++) {
    const angle = (i / rockCount) * Math.PI * 2 + (i % 3) * 0.09;
    const dist = 54 + (i % 4) * 11;
    dummy.position.set(Math.cos(angle) * dist, 1.5 + (i % 3) * 2.2, Math.sin(angle) * dist);
    dummy.rotation.set((i * 0.4) % 1, angle, (i * 0.25) % 0.5);
    const sx = 1.2 + (i % 5) * 0.35;
    const sy = 0.8 + (i % 4) * 0.55;
    const sz = 1.1 + ((i + 2) % 4) * 0.35;
    dummy.scale.set(sx, sy, sz);
    dummy.updateMatrix();
    rockInst.setMatrixAt(i, dummy.matrix);

    const shade = 0.85 + (i % 5) * 0.06;
    tint.setRGB(shade, shade * 0.93, shade * 0.84);
    rockInst.setColorAt(i, tint);
  }
  rockInst.computeBoundingSphere();
  scene.add(rockInst);

  // 9.5 Interactive Breach Doors (shoot / press [E] to trigger Slow-Mo Breach)
  const doorDefs: { x: number; z: number; rotY: number }[] = [
    { x: -13, z: -1, rotY: 0 },
    { x: 14, z: 2, rotY: 0 },
  ];
  doorDefs.forEach((d, idx) => {
    const { root, doorPanel } = createBreachDoor();
    root.position.set(d.x, 0, d.z);
    root.rotation.y = d.rotY;
    scene.add(root);
    const box: Aabb2D = {
      minX: d.x - 1.15,
      maxX: d.x + 1.15,
      minZ: d.z - 0.35,
      maxZ: d.z + 0.35,
      height: 2.7,
      label: `breach_door_${idx}`,
    };
    colliders.push(box);
    breachDoors.push({
      id: idx,
      root,
      doorPanel,
      box,
      x: d.x,
      z: d.z,
      breached: false,
      openProgress: 0,
    });
  });

  // 10. Animated Tactical Helicopter (visible during cutscenes / exfil)
  const helicopter = createTacticalHelicopter(isSoftwareGl);
  helicopter.root.position.set(0, 11.5, -2);
  helicopter.root.visible = false;
  scene.add(helicopter.root);

  // 11. Atmospheric dust / snow motes
  const dustCount = 80;
  const dustPositions = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPositions[i * 3] = (Math.random() - 0.5) * 68;
    dustPositions[i * 3 + 1] = 0.8 + Math.random() * 7.5;
    dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 68;
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
  const dustMat = new THREE.PointsMaterial({
    color: 0xffe2b0,
    size: 0.16,
    transparent: true,
    opacity: 0.52,
    depthWrite: false,
  });
  const dustPoints = new THREE.Points(dustGeo, dustMat);
  scene.add(dustPoints);

  const spawnPoints = [
    { x: -28, z: -28 },
    { x: 0, z: -31 },
    { x: 28, z: -28 },
    { x: -31, z: -4 },
    { x: 31, z: -5 },
    { x: -29, z: 22 },
    { x: 29, z: 24 },
  ];

  // 12. Per-Chapter & Per-Mode 3D Biome Landmark Architecture (visual diversity per chapter)
  const bunkerGroup = new THREE.Group();
  const bunkerBeamMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.5, metalness: 0.75 });
  const bunkerGlowMat = new THREE.MeshBasicMaterial({ color: 0x2dd4bf });
  for (const bz of [-26, -12, 2, 16]) {
    const beam = new THREE.Mesh(new THREE.BoxGeometry(74, 0.9, 1.1), bunkerBeamMat);
    beam.position.set(0, 12.5, bz);
    bunkerGroup.add(beam);
    const strip = new THREE.Mesh(new THREE.BoxGeometry(16, 0.16, 0.25), bunkerGlowMat);
    strip.position.set(0, 11.98, bz);
    bunkerGroup.add(strip);
  }
  for (const [rx, rz] of [[-32, -16], [32, -16], [-32, 14], [32, 14]]) {
    const col = new THREE.Mesh(new THREE.BoxGeometry(1.5, 12.5, 1.5), bunkerBeamMat);
    col.position.set(rx, 6.25, rz);
    bunkerGroup.add(col);
  }
  bunkerGroup.visible = false;
  scene.add(bunkerGroup);

  const oilRigGroup = new THREE.Group();
  const rigPipeMat = new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.45, metalness: 0.65 });
  const rigSteelMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.48, metalness: 0.78 });
  for (const px of [-34, 34]) {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 68, 10), rigPipeMat);
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(px, 1.35, 0);
    oilRigGroup.add(pipe);
  }
  for (const dx of [-3.2, 3.2]) {
    for (const dz of [-3.2, 3.2]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.45, 22, 0.45), rigSteelMat);
      leg.position.set(dx * 0.85, 11, -34 + dz * 0.7);
      leg.rotation.z = dx > 0 ? 0.09 : -0.09;
      oilRigGroup.add(leg);
    }
  }
  const derrickCrown = new THREE.Mesh(new THREE.BoxGeometry(4.4, 1.2, 4.4), rigPipeMat);
  derrickCrown.position.set(0, 21.8, -34);
  oilRigGroup.add(derrickCrown);
  oilRigGroup.visible = false;
  scene.add(oilRigGroup);

  const templeGroup = new THREE.Group();
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0xd9a05b, roughness: 0.92, metalness: 0.04 });
  const goldTrimMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.35, metalness: 0.7 });
  for (const [cx, cz] of [[-22, -26], [22, -26], [-26, 6], [26, 6], [-22, 26], [22, 26]]) {
    const base = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.8, 2.2), stoneMat);
    base.position.set(cx, 0.4, cz);
    templeGroup.add(base);
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.88, 7.6, 8), stoneMat);
    shaft.position.set(cx, 4.4, cz);
    templeGroup.add(shaft);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.65, 2.0), goldTrimMat);
    cap.position.set(cx, 8.4, cz);
    templeGroup.add(cap);
  }
  const archLintel = new THREE.Mesh(new THREE.BoxGeometry(16, 1.6, 2.2), stoneMat);
  archLintel.position.set(0, 8.6, -34);
  templeGroup.add(archLintel);
  templeGroup.visible = false;
  scene.add(templeGroup);

  const airfieldGroup = new THREE.Group();
  const runwayLineMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
  const taxiBlueMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
  for (let rz = -30; rz <= 30; rz += 7.5) {
    const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 3.8), runwayLineMat);
    dash.rotation.x = -Math.PI / 2;
    dash.position.set(0, 0.025, rz);
    airfieldGroup.add(dash);
  }
  for (let lz = -32; lz <= 32; lz += 8) {
    for (const lx of [-18, 18]) {
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), taxiBlueMat);
      lamp.position.set(lx, 0.18, lz);
      airfieldGroup.add(lamp);
    }
  }
  const jetBody = new THREE.Mesh(new THREE.ConeGeometry(0.95, 9.5, 6), rigSteelMat);
  jetBody.rotation.x = -Math.PI / 2;
  jetBody.position.set(22, 1.7, -30);
  airfieldGroup.add(jetBody);
  const jetWings = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.16, 2.8), rigSteelMat);
  jetWings.position.set(22, 1.6, -30);
  airfieldGroup.add(jetWings);
  airfieldGroup.visible = false;
  scene.add(airfieldGroup);

  const citadelGroup = new THREE.Group();
  const obsidianMat = new THREE.MeshStandardMaterial({ color: 0x180909, roughness: 0.35, metalness: 0.65 });
  const laserBeamMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.72 });
  for (const [px, pz] of [[-24, -20], [24, -20], [-24, 18], [24, 18], [-11, -30], [11, -30]]) {
    const monolith = new THREE.Mesh(new THREE.BoxGeometry(1.7, 10.5, 1.7), obsidianMat);
    monolith.position.set(px, 5.25, pz);
    citadelGroup.add(monolith);
    const core = new THREE.Mesh(new THREE.BoxGeometry(0.35, 9.2, 0.35), laserBeamMat);
    core.position.set(px, 5.0, pz);
    citadelGroup.add(core);
  }
  const laserGate = new THREE.Mesh(new THREE.BoxGeometry(20, 0.18, 0.18), laserBeamMat);
  laserGate.position.set(0, 6.2, -30);
  citadelGroup.add(laserGate);
  citadelGroup.visible = false;
  scene.add(citadelGroup);

  const firingRangeGroup = new THREE.Group();
  const laneStripMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.8 });
  for (const distZ of [-12, -20, -28]) {
    const strip = new THREE.Mesh(new THREE.PlaneGeometry(24, 0.28), laneStripMat);
    strip.rotation.x = -Math.PI / 2;
    strip.position.set(0, 0.025, distZ);
    firingRangeGroup.add(strip);
  }
  const benchMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.6 });
  const firingBench = new THREE.Mesh(new THREE.BoxGeometry(16, 0.92, 0.6), benchMat);
  firingBench.position.set(0, 0.46, -4.5);
  firingRangeGroup.add(firingBench);
  firingRangeGroup.visible = false;
  scene.add(firingRangeGroup);

  const setChapterAtmosphere = (
    chapter: number,
    blackoutActive = false,
    mode: GameMode = 'campaign',
  ) => {
    const fog = scene.fog as THREE.FogExp2;
    const isNight = chapter >= 5;
    for (const cone of floodlightCones) {
      cone.visible = isNight && !blackoutActive;
    }
    bunkerGroup.visible = mode !== 'firing_range' && chapter === 6;
    oilRigGroup.visible = mode !== 'firing_range' && chapter === 7;
    templeGroup.visible = mode !== 'firing_range' && chapter === 8;
    airfieldGroup.visible = mode !== 'firing_range' && chapter === 9;
    citadelGroup.visible = mode !== 'firing_range' && (chapter === 5 || chapter === 10);
    firingRangeGroup.visible = mode === 'firing_range';

    if (blackoutActive) {
      // Dynamic EMP Blackout Event: deep moonlit darkness with readable silhouette & tracer contrast
      horizonColor.setHex(0x111a26);
      skyMat.uniforms.topColor.value.setHex(0x050911);
      skyMat.uniforms.midColor.value.setHex(0x101827);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.015;
      sun.color.setHex(0x6484b4);
      sun.intensity = 0.72;
      hemi.color.setHex(0x3a5278);
      hemi.groundColor.setHex(0x141820);
      hemi.intensity = 0.65;
      rimLight.color.setHex(0xf59e0b);
      rimLight.intensity = 0.85;
      courtMat.color.setHex(0x7c8798);
      outerGroundMat.color.setHex(0x283240);
      dustMat.color.setHex(0x94a3b8);
      return;
    }

    if (chapter === 10) {
      // Chapter 10: Syndicate Citadel Final Boss (Crimson obsidian fortress)
      horizonColor.setHex(0x4b1212);
      skyMat.uniforms.topColor.value.setHex(0x180505);
      skyMat.uniforms.midColor.value.setHex(0x3a0c0c);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.014;
      sun.color.setHex(0xff6b6b);
      sun.intensity = 1.95;
      hemi.color.setHex(0x7c2d2d);
      hemi.groundColor.setHex(0x281010);
      hemi.intensity = 1.05;
      rimLight.color.setHex(0xff8e8e);
      rimLight.intensity = 1.1;
      courtMat.color.setHex(0x472c2c);
      outerGroundMat.color.setHex(0x261010);
      dustMat.color.setHex(0xff7b7b);
    } else if (chapter === 9) {
      // Chapter 9: Military Airfield (Cold steel slate)
      horizonColor.setHex(0x64748b);
      skyMat.uniforms.topColor.value.setHex(0x0f172a);
      skyMat.uniforms.midColor.value.setHex(0x334155);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.013;
      sun.color.setHex(0xe2e8f0);
      sun.intensity = 2.1;
      hemi.color.setHex(0x94a3b8);
      hemi.groundColor.setHex(0x1e293b);
      hemi.intensity = 0.92;
      rimLight.color.setHex(0x38bdf8);
      rimLight.intensity = 0.7;
      courtMat.color.setHex(0xe2e8f0);
      outerGroundMat.color.setHex(0x475569);
      dustMat.color.setHex(0xbae6fd);
    } else if (chapter === 8) {
      // Chapter 8: Ancient Desert Temple (Sandstone gold)
      horizonColor.setHex(0xd97706);
      skyMat.uniforms.topColor.value.setHex(0x451a03);
      skyMat.uniforms.midColor.value.setHex(0x92400e);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.012;
      sun.color.setHex(0xfde68a);
      sun.intensity = 2.4;
      hemi.color.setHex(0xfbbf24);
      hemi.groundColor.setHex(0x78350f);
      hemi.intensity = 1.0;
      rimLight.color.setHex(0xfcd34d);
      rimLight.intensity = 0.75;
      courtMat.color.setHex(0xfef3c7);
      outerGroundMat.color.setHex(0xb45309);
      dustMat.color.setHex(0xfde68a);
    } else if (chapter === 7) {
      // Chapter 7: Ocean Oil Rig (Stormy navy steel)
      horizonColor.setHex(0x1e3a8a);
      skyMat.uniforms.topColor.value.setHex(0x020617);
      skyMat.uniforms.midColor.value.setHex(0x1e293b);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.015;
      sun.color.setHex(0x93c5fd);
      sun.intensity = 1.6;
      hemi.color.setHex(0x3b82f6);
      hemi.groundColor.setHex(0x0f172a);
      hemi.intensity = 0.8;
      rimLight.color.setHex(0x60a5fa);
      rimLight.intensity = 0.8;
      courtMat.color.setHex(0x94a3b8);
      outerGroundMat.color.setHex(0x1e3a8a);
      dustMat.color.setHex(0x93c5fd);
    } else if (chapter === 6) {
      // Chapter 6: Underground Bunker (Industrial concrete teal)
      horizonColor.setHex(0x134e4a);
      skyMat.uniforms.topColor.value.setHex(0x042f2e);
      skyMat.uniforms.midColor.value.setHex(0x0f766e);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.016;
      sun.color.setHex(0x2dd4bf);
      sun.intensity = 1.5;
      hemi.color.setHex(0x14b8a6);
      hemi.groundColor.setHex(0x042f2e);
      hemi.intensity = 0.75;
      rimLight.color.setHex(0x5eead4);
      rimLight.intensity = 0.85;
      courtMat.color.setHex(0x99f6e4);
      outerGroundMat.color.setHex(0x115e59);
      dustMat.color.setHex(0x2dd4bf);
    } else if (isNight) {
      // Chapter 5: Night Operations ("XƏNCƏRİN SONU")
      horizonColor.setHex(0x202d42);
      skyMat.uniforms.topColor.value.setHex(0x070c14);
      skyMat.uniforms.midColor.value.setHex(0x162438);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.0122;
      sun.color.setHex(0x8cb8ff);
      sun.intensity = 1.05;
      hemi.color.setHex(0x4b70a2);
      hemi.groundColor.setHex(0x1b1e24);
      hemi.intensity = 0.68;
      rimLight.color.setHex(0xf59e0b);
      rimLight.intensity = 0.82;
      courtMat.color.setHex(0xcbd5e1);
      outerGroundMat.color.setHex(0x525c6b);
      dustMat.color.setHex(0x93c5fd);
    } else if (chapter === 4) {
      // Chapter 4: Alpine Snow Blizzard ("MÜHASİRƏ XƏTTİ")
      horizonColor.setHex(0xc9d9e8);
      skyMat.uniforms.topColor.value.setHex(0x4f6d8a);
      skyMat.uniforms.midColor.value.setHex(0x9fb6cc);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.0145;
      sun.color.setHex(0xeef6ff);
      sun.intensity = 2.0;
      hemi.color.setHex(0xd8e8f8);
      hemi.groundColor.setHex(0x8fa4b8);
      hemi.intensity = 1.05;
      rimLight.color.setHex(0xbae6fd);
      rimLight.intensity = 0.72;
      courtMat.color.setHex(0xe6eff8);
      outerGroundMat.color.setHex(0xbfd0e0);
      dustMat.color.setHex(0xf8fafc);
    } else if (chapter === 3) {
      // Chapter 3: Burnt-Amber Industrial Dust Storm Dusk
      horizonColor.setHex(0xb46d48);
      skyMat.uniforms.topColor.value.setHex(0x1f283b);
      skyMat.uniforms.midColor.value.setHex(0x6d5753);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.0128;
      sun.color.setHex(0xffb570);
      sun.intensity = 2.05;
      hemi.color.setHex(0x88a2c4);
      hemi.groundColor.setHex(0x5d432e);
      hemi.intensity = 0.85;
      rimLight.color.setHex(0x78aee6);
      rimLight.intensity = 0.66;
      courtMat.color.setHex(0xf5d6ba);
      outerGroundMat.color.setHex(0x8c6848);
      dustMat.color.setHex(0xffb878);
    } else if (chapter === 2) {
      // Chapter 2: Overcast Coastal Slate Mist
      horizonColor.setHex(0x8396a8);
      skyMat.uniforms.topColor.value.setHex(0x1e2c3d);
      skyMat.uniforms.midColor.value.setHex(0x54677a);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.0112;
      sun.color.setHex(0xdbeafe);
      sun.intensity = 1.85;
      hemi.color.setHex(0x94b3d4);
      hemi.groundColor.setHex(0x475569);
      hemi.intensity = 0.9;
      rimLight.color.setHex(0x93c5fd);
      rimLight.intensity = 0.68;
      courtMat.color.setHex(0xd8e0ea);
      outerGroundMat.color.setHex(0x687788);
      dustMat.color.setHex(0xcbd5e1);
    } else {
      // Chapter 1: Golden-Hour Dawn
      horizonColor.setHex(0xd2a374);
      skyMat.uniforms.topColor.value.setHex(0x284364);
      skyMat.uniforms.midColor.value.setHex(0x7c8594);
      skyMat.uniforms.bottomColor.value.copy(horizonColor);
      fog.color.copy(horizonColor);
      fog.density = 0.0102;
      sun.color.setHex(0xffdfb0);
      sun.intensity = 2.4;
      hemi.color.setHex(0x9fc2ea);
      hemi.groundColor.setHex(0x6b533b);
      hemi.intensity = 0.95;
      rimLight.color.setHex(0x78aee6);
      rimLight.intensity = 0.62;
      courtMat.color.setHex(0xffffff);
      outerGroundMat.color.setHex(0xa48966);
      dustMat.color.setHex(0xffe2b0);
    }
  };

  return {
    colliders,
    obstacleRayTargets,
    barrels,
    destructibleCrates,
    breachDoors,
    helicopter,
    jeepPos: { x: -2.5, z: -2.5 },
    spawnPoints,
    uavDrone,
    radarDish,
    dustPoints,
    sunLight: sun,
    setChapterAtmosphere,
    dispose: () => {
      skyGeo.dispose();
      skyMat.dispose();
      outerGroundMat.dispose();
      courtMat.dispose();
      lineMat.dispose();
      crateMat.dispose();
      coneGeo.dispose();
      coneMat.dispose();
      barrelHitMat.dispose();
      wallMat.dispose();
      rockMat.dispose();
      dustGeo.dispose();
      dustMat.dispose();
      bunkerBeamMat.dispose();
      bunkerGlowMat.dispose();
      rigPipeMat.dispose();
      rigSteelMat.dispose();
      stoneMat.dispose();
      goldTrimMat.dispose();
      runwayLineMat.dispose();
      taxiBlueMat.dispose();
      obsidianMat.dispose();
      laserBeamMat.dispose();
      laneStripMat.dispose();
      benchMat.dispose();
    },
  };
}
