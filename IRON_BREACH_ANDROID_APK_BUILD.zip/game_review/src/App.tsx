import { useCallback, useEffect, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import { ArsenalModal } from './components/ArsenalModal';
import { BuyStationModal } from './components/BuyStationModal';
import { CutsceneOverlay } from './components/CutsceneOverlay';
import { ErrorBoundary } from './components/ErrorBoundary';
import { GameModals } from './components/GameModals';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MissionBriefingModal } from './components/MissionBriefingModal';
import { SettingsModal } from './components/SettingsModal';
import { StoryChoiceModal } from './components/StoryChoiceModal';
import { StoryDossierModal } from './components/StoryDossierModal';
import { TacticalHud } from './components/TacticalHud';
import { TitleScreen } from './components/TitleScreen';
import { soundEngine } from './game/audio';
import { FpsEngine } from './game/FpsEngine';
import {
  computeRankFromXp,
  createDefaultCareerStats,
  createDefaultEquippedAttachments,
  createDefaultEquippedCamos,
  createInitialWeaponStates,
  INTEL_SPECS,
  KILLSTREAK_THRESHOLD,
  MAX_STORY_WAVES,
  UAV_THRESHOLD,
  WEAPON_LIST,
  type GraphicsQuality,
} from './game/rules';
import type { GameMode, HudSnapshot, MedalId, WeaponId } from './game/types';
import {
  loadOrSyncCloudProfile,
  signInWithGoogle,
  signOutGoogle,
  submitLeaderboardEntry,
  subscribeAuth,
} from './services/firebaseService';

const INITIAL_CAREER_STATS = createDefaultCareerStats(0);

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  gameMode: 'campaign',
  outcome: null,
  hp: 100,
  maxHp: 100,
  armor: 50,
  maxArmor: 50,
  wave: 1,
  maxWaves: MAX_STORY_WAVES,
  enemiesRemaining: 0,
  waveBanner: null,
  comboBanner: null,
  score: 0,
  bestScore: 0,
  credits: 0,
  kills: 0,
  headshots: 0,
  shotsFired: 0,
  shotsHit: 0,
  grenades: 3,
  flashbangs: 2,
  c4Count: 2,
  c4PlantedCount: 0,
  claymoreCount: 2,
  killstreakProgress: 0,
  killstreakThreshold: KILLSTREAK_THRESHOLD,
  uavThreshold: UAV_THRESHOLD,
  uavReady: false,
  uavActiveTimer: 0,
  killstreakReady: false,
  gunshipReady: false,
  gunshipActive: false,
  gunshipTimer: 0,
  gunshipShells: 12,
  carePackageReady: false,
  carePackageActive: false,
  stims: 2,
  maxStims: 3,
  stimBoostTimer: 0,
  isCrouching: false,
  isInspecting: false,
  grenadeWarning: null,
  mountedTurret: false,
  thermalActive: false,
  blackoutActive: false,
  breachSlowMoTimer: 0,
  sentryActiveCount: 0,
  buyStationOpen: false,
  interactPrompt: null,
  bossPhase: null,
  allySquad: [],
  unlockedMedalIds: [],
  medalBanner: null,
  collectedIntelIds: [],
  activeWeapon: 'm4a1',
  loadoutWeapons: ['m4a1', 'mp5'],
  weapons: createInitialWeaponStates(),
  reloading: false,
  reloadProgress: 0,
  isAds: false,
  isSprinting: false,
  isSliding: false,
  isNvgActive: false,
  slideCooldownPct: 1,
  crosshairSpread: 18,
  hitmarkerKind: 'none',
  damageFlash: 0,
  damageDirectionAngle: null,
  playerX: 0,
  playerZ: 22,
  playerYaw: 0,
  radarEnemies: [],
  projectedEnemies: [],
  killFeed: [],
  autoFire: true,
  elapsedTime: 0,
  pointerLocked: false,
  careerStats: INITIAL_CAREER_STATS,
  rankInfo: computeRankFromXp(INITIAL_CAREER_STATS.xp),
  equippedCamos: createDefaultEquippedCamos(),
  equippedAttachments: createDefaultEquippedAttachments(),
  selectedPerk: 'fast_reload',
  selectedDifficulty: 'regular',
  campaignPace: 'marathon',
  chapterStage: 1,
  chapterTotalStages: 4,
  checkpointStage: 1,
  checkpointBanner: null,
  cutscene: null,
  unlockedChapter: 1,
  armorPlates: 2,
  maxArmorPlates: 2,
  compassHeadingDeg: 0,
  activeObjectiveText: '',
  objectiveStage: 'combat',
  objectiveProgressPct: 0,
  objectiveWaypoint: null,
  radioMessage: null,
  lean: 'none',
  isLastStand: false,
  selfReviveKit: false,
  fieldUpgrade: 'shield',
  fieldUpgradeCooldownPct: 1,
  fieldUpgradeActiveTimer: 0,
  sensitivity: 1.0,
  fov: 75,
  volume: 1.0,
  touchControlsEnabled: true,
  bombObjective: null,
  firingRangeStats: null,
  canonLoadoutEnabled: true,
  activeStoryChoice: null,
  storyDecisions: [],
  squadTrust: 65,
  unlockedEndingIds: [],
  activeEnding: null,
  setPieceKind: null,
  hostagesAlive: 0,
  hostagesRescued: 0,
  hostagesTotal: 0,
  woundedAlly: null,
  escapeTimerSec: null,
  stealthSuspicionPct: 0,
  stealthDetected: false,
  bossQte: null,
};

function detectTouchViewport(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.innerWidth <= 960 ||
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0
  );
}

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<FpsEngine | null>(null);

  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [selectedWeapon, setSelectedWeapon] = useState<WeaponId>('m4a1');
  const [selectedChapter, setSelectedChapter] = useState<number>(1);
  const [arsenalOpen, setArsenalOpen] = useState(false);
  const [leaderboardOpen, setLeaderboardOpen] = useState(false);
  const [storyArchiveOpen, setStoryArchiveOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>('720p');
  const [cloudUser, setCloudUser] = useState<User | null>(null);
  const [syncingCloud, setSyncingCloud] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => detectTouchViewport());

  const selectedWeaponRef = useRef<WeaponId>(selectedWeapon);
  selectedWeaponRef.current = selectedWeapon;
  const selectedChapterRef = useRef<number>(selectedChapter);
  selectedChapterRef.current = selectedChapter;
  const cloudUserRef = useRef<User | null>(cloudUser);
  cloudUserRef.current = cloudUser;
  const prevPhaseRef = useRef<HudSnapshot['phase']>('title');

  const syncWithCloud = useCallback(async (user: User) => {
    const engine = engineRef.current;
    if (!engine) return;
    setSyncingCloud(true);
    try {
      const payload = engine.getCloudSyncPayload();
      const merged = await loadOrSyncCloudProfile(
        user,
        payload.careerStats,
        payload.unlockedChapter,
        payload.unlockedMedalIds,
        payload.collectedIntelIds,
      );
      engine.applyCloudSave({
        careerStats: {
          totalKills: merged.totalKills,
          totalHeadshots: merged.totalHeadshots,
          bestScore: merged.bestScore,
          totalExplosiveKills: merged.totalExplosiveKills,
          xp: merged.xp,
          completedChallengeIds: merged.completedChallengeIds,
        },
        unlockedChapter: merged.unlockedChapter,
        unlockedMedalIds: merged.unlockedMedalIds as MedalId[],
        collectedIntelIds: merged.collectedIntelIds,
      });
      setSyncMessage('Bulud profili sinxronizasiya olundu.');
    } catch {
      setSyncMessage('Bulud sinxronizasiyası tamamlanmadı (oflayn və ya icazə xətası).');
    } finally {
      setSyncingCloud(false);
    }
  }, []);

  const handleSignInGoogle = useCallback(async () => {
    try {
      const user = await signInWithGoogle();
      setCloudUser(user);
      await syncWithCloud(user);
    } catch {
      setSyncMessage('Google girişi ləğv edildi və ya mümkün olmadı.');
    }
  }, [syncWithCloud]);

  const handleSignOutGoogle = useCallback(async () => {
    try {
      await signOutGoogle();
      setCloudUser(null);
      setSyncMessage('Hesabdan çıxış edildi.');
    } catch {
      setSyncMessage('Hesabdan çıxış xətası.');
    }
  }, []);

  const handleStart = useCallback(() => {
    setArsenalOpen(false);
    setLeaderboardOpen(false);
    engineRef.current?.startGame(selectedWeaponRef.current, false, selectedChapterRef.current);
  }, []);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      soundEngine.setMuted(next);
      return next;
    });
  }, []);

  const handleToggleGraphicsQuality = useCallback(() => {
    setGraphicsQuality((prev) => {
      const next: GraphicsQuality = prev === '720p' ? 'ultra' : '720p';
      engineRef.current?.setGraphicsQuality(next);
      return next;
    });
  }, []);

  useEffect(() => {
    if (hud.phase !== 'title' && arsenalOpen) {
      setArsenalOpen(false);
    }
    if (hud.phase !== 'title' && storyArchiveOpen) {
      setStoryArchiveOpen(false);
    }
    if (hud.phase !== 'title' && hud.phase !== 'paused' && settingsOpen) {
      setSettingsOpen(false);
    }
    if (hud.phase !== 'title' && hud.phase !== 'gameover' && leaderboardOpen) {
      setLeaderboardOpen(false);
    }
  }, [hud.phase, arsenalOpen, storyArchiveOpen, settingsOpen, leaderboardOpen]);

  // Firebase Auth listener
  useEffect(() => {
    const unsub = subscribeAuth((user) => {
      setCloudUser(user);
      if (user) {
        void syncWithCloud(user);
      }
    });
    return () => unsub();
  }, [syncWithCloud]);

  // Auto-submit score & sync cloud profile on gameover
  useEffect(() => {
    const prevPhase = prevPhaseRef.current;
    prevPhaseRef.current = hud.phase;
    if (hud.phase === 'gameover' && prevPhase !== 'gameover' && cloudUserRef.current) {
      const user = cloudUserRef.current;
      void syncWithCloud(user);
      void submitLeaderboardEntry(user, {
        score: hud.score,
        kills: hud.kills,
        headshots: hud.headshots,
        rankLevel: hud.rankInfo.level,
        rankTitle: hud.rankInfo.title,
        difficulty: hud.selectedDifficulty,
        gameMode: hud.gameMode,
        wave: hud.wave,
        medalsCount: hud.unlockedMedalIds.length,
        intelCount: hud.collectedIntelIds.length,
      }).catch(() => {
        // non-blocking leaderboard submit error
      });
    }
  }, [
    hud.phase,
    hud.score,
    hud.kills,
    hud.headshots,
    hud.rankInfo.level,
    hud.rankInfo.title,
    hud.selectedDifficulty,
    hud.gameMode,
    hud.wave,
    hud.unlockedMedalIds.length,
    hud.collectedIntelIds.length,
    syncWithCloud,
  ]);

  useEffect(() => {
    document.body.dataset.state = 'title';
    const container = mountRef.current;
    if (!container) return;

    const engine = new FpsEngine(container, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;

    try {
      const savedRaw = localStorage.getItem('iron_breach_settings_v1');
      const parsed = savedRaw ? JSON.parse(savedRaw) : null;
      if (parsed && typeof parsed.touchControlsEnabled === 'boolean') {
        setShowTouchControls(parsed.touchControlsEnabled);
      } else {
        const touchDefault = detectTouchViewport();
        setShowTouchControls(touchDefault);
        engine.setTouchControlsEnabled(touchDefault);
      }
    } catch {
      const touchDefault = detectTouchViewport();
      setShowTouchControls(touchDefault);
      engine.setTouchControlsEnabled(touchDefault);
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      const modeParam = params.get('mode') as GameMode | null;
      if (
        modeParam === 'survival' ||
        modeParam === 'campaign' ||
        modeParam === 'firing_range' ||
        modeParam === 'spec_ops'
      ) {
        engine.setGameMode(modeParam);
      }
      const chParam = parseInt(params.get('chapter') || '1', 10);
      const weaponParam = params.get('weapon') as WeaponId | null;
      const startW =
        weaponParam && WEAPON_LIST.includes(weaponParam) ? weaponParam : undefined;
      engine.startGame(startW, true, Number.isFinite(chParam) ? chParam : 1);
    }

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Responsive check for touch controls on window resize
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth <= 768) {
        setShowTouchControls(true);
      }
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // Global keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyM') {
        handleToggleMute();
        return;
      }

      const phase = hud.phase;
      if (phase === 'title') {
        if (arsenalOpen || leaderboardOpen || settingsOpen || storyArchiveOpen) {
          if (e.code === 'Escape') {
            e.preventDefault();
            setArsenalOpen(false);
            setLeaderboardOpen(false);
            setSettingsOpen(false);
            setStoryArchiveOpen(false);
          }
          return;
        }
        if (e.code === 'Enter' || e.code === 'Space') {
          e.preventDefault();
          handleStart();
        }
      } else if (phase === 'briefing' && (e.code === 'Enter' || e.code === 'Space')) {
        e.preventDefault();
        engineRef.current?.deployWave();
      } else if (
        phase === 'cutscene' &&
        (e.code === 'Space' || e.code === 'Enter' || e.code === 'Escape')
      ) {
        e.preventDefault();
        engineRef.current?.skipCutscene();
      } else if (phase === 'playing') {
        if (hud.activeStoryChoice) {
          return;
        }
        if (hud.buyStationOpen) {
          if (e.code === 'Escape') {
            e.preventDefault();
            engineRef.current?.setBuyStationOpen(false);
          }
          return;
        }
        if (e.code === 'Escape' || e.code === 'KeyP') {
          e.preventDefault();
          engineRef.current?.pauseGame();
        }
      } else if (phase === 'paused' && (e.code === 'Escape' || e.code === 'KeyP')) {
        e.preventDefault();
        if (settingsOpen && e.code === 'Escape') {
          setSettingsOpen(false);
        } else {
          engineRef.current?.resumeGame();
        }
      } else if (phase === 'gameover' && leaderboardOpen && e.code === 'Escape') {
        e.preventDefault();
        setLeaderboardOpen(false);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    hud.phase,
    hud.buyStationOpen,
    hud.activeStoryChoice,
    arsenalOpen,
    settingsOpen,
    leaderboardOpen,
    storyArchiveOpen,
    handleStart,
    handleToggleMute,
  ]);

  return (
    <ErrorBoundary>
      <main className="relative w-full h-full overflow-hidden bg-[#0e1114]">
        {/* Isolated WebGL canvas mount */}
        <div ref={mountRef} className="absolute inset-0 w-full h-full" />

        {hud.phase === 'title' && (
          <TitleScreen
            gameMode={hud.gameMode}
            onSelectGameMode={(mode) => engineRef.current?.setGameMode(mode)}
            selectedWeapon={selectedWeapon}
            onSelectWeapon={setSelectedWeapon}
            selectedChapter={selectedChapter}
            unlockedChapter={hud.unlockedChapter}
            onSelectChapter={setSelectedChapter}
            campaignPace={hud.campaignPace}
            onSelectCampaignPace={(pace) => engineRef.current?.setCampaignPace(pace)}
            selectedDifficulty={hud.selectedDifficulty}
            onSelectDifficulty={(diff) => engineRef.current?.setDifficulty(diff)}
            selectedFieldUpgrade={hud.fieldUpgrade}
            onSelectFieldUpgrade={(fu) => engineRef.current?.setFieldUpgrade(fu)}
            selectedPerk={hud.selectedPerk}
            equippedAttachments={hud.equippedAttachments}
            equippedCamos={hud.equippedCamos}
            rankInfo={hud.rankInfo}
            cloudUser={cloudUser}
            onOpenArsenal={() => setArsenalOpen(true)}
            onOpenLeaderboard={() => setLeaderboardOpen(true)}
            onStart={handleStart}
            bestScore={hud.bestScore}
            muted={muted}
            onToggleMute={handleToggleMute}
            onOpenSettings={() => setSettingsOpen(true)}
            canonLoadoutEnabled={hud.canonLoadoutEnabled}
            onToggleCanonLoadout={() =>
              engineRef.current?.setCanonLoadoutEnabled(!hud.canonLoadoutEnabled)
            }
            unlockedEndingsCount={hud.unlockedEndingIds.length}
            collectedIntelCount={hud.collectedIntelIds.length}
            totalIntelCount={INTEL_SPECS.length}
            onOpenStoryArchive={() => setStoryArchiveOpen(true)}
          />
        )}

        {(hud.phase === 'title' || hud.phase === 'paused') && settingsOpen && (
          <SettingsModal
            isOpen={settingsOpen}
            onClose={() => setSettingsOpen(false)}
            sensitivity={hud.sensitivity}
            setSensitivity={(v) => engineRef.current?.setSensitivity(v)}
            fov={hud.fov}
            setFov={(v) => engineRef.current?.setFov(v)}
            volume={hud.volume}
            setVolume={(v) => {
              engineRef.current?.setVolume(v);
              soundEngine.setMuted(v === 0 || muted);
            }}
            touchControlsEnabled={showTouchControls}
            setTouchControlsEnabled={(enabled) => {
              setShowTouchControls(enabled);
              engineRef.current?.setTouchControlsEnabled(enabled);
            }}
          />
        )}

        {hud.phase === 'title' && arsenalOpen && (
          <ArsenalModal
            selectedWeapon={selectedWeapon}
            onSelectWeapon={setSelectedWeapon}
            equippedCamos={hud.equippedCamos}
            onSelectCamo={(weapon, camo) => engineRef.current?.setWeaponCamo(weapon, camo)}
            equippedAttachments={hud.equippedAttachments}
            onToggleAttachment={(weapon, att) => engineRef.current?.toggleAttachment(weapon, att)}
            selectedPerk={hud.selectedPerk}
            onSelectPerk={(perk) => engineRef.current?.setPerk(perk)}
            careerStats={hud.careerStats}
            rankInfo={hud.rankInfo}
            unlockedMedalIds={hud.unlockedMedalIds}
            collectedIntelIds={hud.collectedIntelIds}
            onClose={() => setArsenalOpen(false)}
          />
        )}

        {hud.phase === 'title' && storyArchiveOpen && (
          <StoryDossierModal
            squadTrust={hud.squadTrust}
            storyDecisions={hud.storyDecisions}
            unlockedEndingIds={hud.unlockedEndingIds}
            collectedIntelIds={hud.collectedIntelIds}
            unlockedChapter={hud.unlockedChapter}
            onSelectChapter={(ch) => setSelectedChapter(ch)}
            onClose={() => setStoryArchiveOpen(false)}
          />
        )}

        {hud.phase === 'briefing' && (
          <MissionBriefingModal
            hud={hud}
            onDeploy={() => engineRef.current?.deployWave()}
            onSwitchChapter={(ch) => {
              setSelectedChapter(ch);
              engineRef.current?.jumpToChapter(ch);
            }}
            onTitle={() => engineRef.current?.returnToTitle()}
          />
        )}

        {hud.phase === 'cutscene' && hud.cutscene && (
          <CutsceneOverlay
            cutscene={hud.cutscene}
            onSkip={() => engineRef.current?.skipCutscene()}
          />
        )}

        {hud.phase === 'playing' && (
          <TacticalHud
            hud={hud}
            muted={muted}
            showTouchControls={showTouchControls}
            onToggleTouchControls={() => {
              const next = !showTouchControls;
              setShowTouchControls(next);
              engineRef.current?.setTouchControlsEnabled(next);
            }}
            onToggleMute={handleToggleMute}
            onPause={() => engineRef.current?.pauseGame()}
            onToggleAutoFire={() => engineRef.current?.toggleAutoFire()}
            onToggleNvg={() => engineRef.current?.toggleNvg()}
            onToggleThermal={() => engineRef.current?.toggleThermal()}
            onMoveInput={(x, y) => engineRef.current?.setMoveInput(x, y)}
            onLookDelta={(dx, dy) => engineRef.current?.addLookDelta(dx, dy)}
            onFireHeld={(held) => engineRef.current?.setFireHeld(held)}
            onToggleAds={() => engineRef.current?.toggleAds()}
            onReload={() => engineRef.current?.triggerReload()}
            onGrenade={() => engineRef.current?.throwGrenade()}
            onThrowFlashbang={() => engineRef.current?.throwFlashbang()}
            onMelee={() => engineRef.current?.triggerMeleeStrike()}
            onTriggerC4={() => engineRef.current?.triggerC4()}
            onPlaceClaymore={() => engineRef.current?.placeClaymore()}
            onInteract={() => engineRef.current?.triggerInteract()}
            onGunship={() => engineRef.current?.triggerGunship()}
            onCallCarePackage={() => engineRef.current?.callCarePackage(false)}
            onUseStim={() => engineRef.current?.useStimShot()}
            onToggleCrouch={() => engineRef.current?.toggleCrouch()}
            onInspectWeapon={() => engineRef.current?.triggerWeaponInspect()}
            onOpenBuyStation={() => engineRef.current?.setBuyStationOpen(true)}
            onJump={() => engineRef.current?.triggerJump()}
            onSlide={() => engineRef.current?.triggerSlide()}
            onUseArmorPlate={() => engineRef.current?.useArmorPlate()}
            onTriggerUav={() => engineRef.current?.triggerUavSweep()}
            onKillstreak={() => engineRef.current?.triggerKillstreak()}
            onSwitchWeapon={(id) => engineRef.current?.switchWeapon(id)}
            onCycleLean={() => engineRef.current?.cycleLean()}
            onActivateFieldUpgrade={() => engineRef.current?.activateFieldUpgrade()}
            onSelfRevive={() => engineRef.current?.selfRevive()}
            onDefuseHeld={(held) => engineRef.current?.setDefuseHeld(held)}
            onResetFiringRange={() => engineRef.current?.resetFiringRange()}
            onBossQteStrike={() => engineRef.current?.triggerBossQteStrike()}
          />
        )}

        {hud.phase === 'playing' && hud.activeStoryChoice && (
          <StoryChoiceModal
            choice={hud.activeStoryChoice}
            squadTrust={hud.squadTrust}
            onSelectOption={(optIdx) => engineRef.current?.submitStoryChoice(optIdx)}
          />
        )}

        {hud.phase === 'playing' && hud.buyStationOpen && (
          <BuyStationModal
            credits={hud.credits}
            onBuyItem={(itemId) => engineRef.current?.buyStationPurchase(itemId)}
            onClose={() => engineRef.current?.setBuyStationOpen(false)}
          />
        )}

        {(hud.phase === 'paused' || hud.phase === 'gameover') && (
          <GameModals
            hud={hud}
            showTouchControls={showTouchControls}
            graphicsQuality={graphicsQuality}
            onToggleTouchControls={() => {
              const next = !showTouchControls;
              setShowTouchControls(next);
              engineRef.current?.setTouchControlsEnabled(next);
            }}
            onToggleGraphicsQuality={handleToggleGraphicsQuality}
            onOpenSettings={() => setSettingsOpen(true)}
            onResume={() => engineRef.current?.resumeGame()}
            onRestart={handleStart}
            onRestartCheckpoint={() => engineRef.current?.restartFromCheckpoint()}
            onSwitchChapter={(ch) => {
              setSelectedChapter(ch);
              engineRef.current?.jumpToChapter(ch);
            }}
            onTitle={() => engineRef.current?.returnToTitle()}
            onContinueEndless={() => engineRef.current?.continueEndless()}
            onOpenLeaderboard={() => setLeaderboardOpen(true)}
          />
        )}

        {(hud.phase === 'title' || hud.phase === 'gameover') && leaderboardOpen && (
          <LeaderboardModal
            user={cloudUser}
            syncing={syncingCloud}
            syncMessage={syncMessage}
            onSignIn={handleSignInGoogle}
            onSignOut={handleSignOutGoogle}
            onManualSync={() => cloudUser && void syncWithCloud(cloudUser)}
            onClose={() => setLeaderboardOpen(false)}
          />
        )}
      </main>
    </ErrorBoundary>
  );
}
