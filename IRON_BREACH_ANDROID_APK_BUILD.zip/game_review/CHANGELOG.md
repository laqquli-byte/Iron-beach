# IRON BREACH — Graphics Update

## Changes

- Added persistent graphics-quality preference (`720p` performance / `Ultra`).
- Ultra rendering now uses a higher pixel-ratio budget on supported GPUs and a 2048px directional shadow map on larger displays.
- Performance mode retains a lighter 1024px shadow map; compact displays also keep the lighter shadow map in Ultra to avoid overloading phones.
- Shadow maps are disposed and recreated when graphics quality changes, so the setting applies during play.
- Updated the pause-menu label to describe 720p as a performance preset rather than a mobile-only preset.

## Compatibility

The existing Three.js renderer, gameplay, controls, campaign data, and mobile touch UI are retained. Software-rendered WebGL devices continue to use the safe rendering path without real-time shadows.

## Verification status

The edited TypeScript/TSX files pass TypeScript transpilation syntax checks. A full dependency-backed build and runtime test could not be completed in this environment because package installation did not finish and the local npm cache does not contain the required dependencies.
