# Security Specification · IRON BREACH Firestore

## 1. Data Invariants
1. All `/users/{userId}` documents contain private PII (`email`, `photoUrl`) and career state; only `request.auth.uid == userId` with `email_verified == true` can create/update, and only `request.auth.uid == userId` can read (`get`). `list` is strictly denied.
2. All `/leaderboard/{entryId}` documents contain zero PII and must have `entryId == request.auth.uid` and `userId == request.auth.uid` on writes.
3. Server timestamps (`createdAt`, `updatedAt`) MUST equal `request.time`, and `userId` + `createdAt` are immutable after creation.
4. All strings have explicit `.size()` bounds; all lists are capped (`<= 20`); all document IDs pass `^[a-zA-Z0-9_\-]+$`.
5. No self-assigned role fields or unvalidated ghost keys are accepted (`hasAll` + `hasOnly` on create, `affectedKeys().hasOnly(...)` on update).

## 2. "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Write** to `/leaderboard/user1` -> `PERMISSION_DENIED` (`request.auth == null`).
2. **Unverified Email Write** (`email_verified: false`) to `/users/user1` -> `PERMISSION_DENIED`.
3. **Cross-User Read (PII Leak)** reading `/users/victimUid` as `attackerUid` -> `PERMISSION_DENIED`.
4. **Collection Scrape (`list`)** on `/users` -> `PERMISSION_DENIED` (`allow list: if false`).
5. **Identity Spoofing** writing `/leaderboard/attackerUid` with `data.userId = "victimUid"` -> `PERMISSION_DENIED`.
6. **ID Poisoning** writing `/leaderboard/victim_id_with$badchars` -> `PERMISSION_DENIED` (`isValidId`).
7. **Shadow Ghost Field** adding `isAdmin: true` to `/users/user1` on create -> `PERMISSION_DENIED` (`hasOnly`).
8. **Update-Gap Ghost Field** adding `vip: true` during update to `/leaderboard/user1` -> `PERMISSION_DENIED` (`affectedKeys().hasOnly`).
9. **Score Overflow / Negative Poisoning** setting `score: -500` or `score: 999999999` -> `PERMISSION_DENIED`.
10. **Array Exhaustion** pushing 500 items into `unlockedMedalIds` -> `PERMISSION_DENIED` (`size() <= 20`).
11. **Timestamp Forgery** passing `createdAt` != `request.time` -> `PERMISSION_DENIED`.
12. **Immutable Ownership Mutation** changing `userId` or `createdAt` on update -> `PERMISSION_DENIED`.
