# IRON BREACH

IRON BREACH is a browser-based 3D first-person shooter built with React, TypeScript, Three.js and Vite. The project includes campaign, survival, firing-range and special-operations modes, mobile touch controls, weapon customization, and Firebase-backed services.

## Run locally

**Requirements:** Node.js 22 or newer.

1. Install dependencies with `npm install`.
2. Copy `.env.example` to `.env.local` and add the required API/Firebase values for the services you intend to use.
3. Start the development server with `npm run dev`.
4. Create a production build with `npm run build`.

## Graphics presets

- **720p Performance:** lower render resolution budget and a 1024px shadow map, intended for phones and lower-powered devices.
- **Ultra:** higher render resolution budget and, on larger displays with hardware WebGL, a 2048px shadow map. Compact displays retain the 1024px shadow map to protect frame rate.

The selected graphics preset is saved locally and restored on the next launch. Software-rendered WebGL devices keep the safe fallback path.

See `CHANGELOG.md` for the latest update details.


## Android APK build

This project is configured to build an Android debug APK with GitHub Actions.
Upload the contents of this `game_review` folder to a GitHub repository, then open
Actions → Build IRON BREACH Android APK → Run workflow. When the run finishes,
download the `IRON-BREACH-debug-APK` artifact and extract `app-debug.apk`.

This is a debug APK for testing, not a signed Play Store release.
