# Implementation Plan - Achievement & Elite Challenge Expansion

## User Review Required

> [!IMPORTANT]
> Since the clarifying question was dismissed, we have prepared a comprehensive expansion plan featuring an **Achievement & Medal System** and **Elite Survival Wave Modifiers** to further elevate the Modern Warfare gameplay experience.

- **Achievement & Medal System**: Add 8 combat medals (e.g. "Sərrast Atıcı", "Dəmir Zireh", "Gecə Ovçusu", "Partlayıcı Ustası") with progress tracking and XP rewards visible in the Arsenal modal and Victory screen.
- **Elite Survival Challenges**: Introduce optional combat modifiers in endless mode (e.g. Hardcore recoil, Double speed rushers) for veteran players.

## Proposed Changes

### 1. Game Rules & Types (`src/game/types.ts`, `src/game/rules.ts`)
- Define `AchievementSpec` and `MedalId` types.
- Add achievement rules, progress check helpers, and unlock thresholds.

### 2. Arsenal & Victory UI (`src/components/ArsenalModal.tsx`, `src/components/GameModals.tsx`)
- Display unlocked medals and achievement badges with progress bars in the Arsenal modal.
- Show newly earned medals on Victory and Game Over cards.

### 3. Verification Plan
- Run unit tests (`rules.test.ts`).
- Compile and lint applet.
- Verify via Playwright.
